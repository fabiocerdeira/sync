﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.NfeGovBr.Configuration;
using Cecam.Tributario.NfeGovBr.Nota;

namespace Cecam.Tributario.NfeGovBr
{
    internal class Program
    {

        static async Task Main(string[] args)
        {
            // log acompanhamento
            Console.WriteLine("Sincronizador de Notas Fiscais Eletrônicas entre Prefeitura/Cecam e Gov.Br");
            Console.WriteLine("Data hora local " + DateTime.UtcNow.AddHours(-3).ToString());
            Console.WriteLine("Versão 1.0.0");

            // carregar arquivo de parametros
            AppSettingsNfeGov.Carregar();

            // inicializar a biblioteca CORE
            IniciarDatabase.Iniciar();

            // enviar notas fiscais.
            var enviarNotaManager = new EnviarNotaManager();
            await enviarNotaManager.Enviar();

            // log acompanhamento
            Console.WriteLine("Fim do sicronizador Prefeitura/Cecam x Gov.Br " + DateTime.UtcNow.AddHours(-3).ToString());
        }
    }
}
