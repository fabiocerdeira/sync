﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfeGovBr.Nota
{
    internal class CancelarNotaManager
    {
    }
}
