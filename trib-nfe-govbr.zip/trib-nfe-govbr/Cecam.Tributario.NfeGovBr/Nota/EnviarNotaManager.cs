﻿using Cecam.Tributario.Manager.Business.IssNotaFiscalGovBr;
using Cecam.Tributario.NfeGovBr.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfeGovBr.Nota
{
    internal class EnviarNotaManager
    {
        public async Task Enviar()
        {
            Console.WriteLine("EnviarNotaManager.Enviar() | inicio");

            Console.WriteLine("AdnUrl " + AppSettingsNfeGov.AdnUrl);
            Console.WriteLine("SefinUrl " + AppSettingsNfeGov.SefinUrl);

            // ------------------------------------------------------------------------------------

            var notaGovBus = new IssNotaFiscalGovBrBus();

            // exemplo de erro
            await notaGovBus.ConsultarProximaNotaFiscalParaEnvio();
            //await notaGovBus.FinalizarComErroNoEnvio("deu erro aqui");

            // ------------------------------------------------------------------------------------

            // exemplo de sucesso
            //await notaGovBus.ConsultarProximaNotaFiscalParaEnvio();
            //await notaGovBus.FinalizarComSucessoNoEnvio("muito sucesso");

            // ------------------------------------------------------------------------------------

            Console.WriteLine("EnviarNotaManager.Enviar() | fim com sucesso");

            await Task.FromResult(0);
        }
    }
}
