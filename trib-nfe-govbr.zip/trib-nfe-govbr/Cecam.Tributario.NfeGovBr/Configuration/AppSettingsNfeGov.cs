﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfeGovBr.Configuration
{
    public static class AppSettingsNfeGov
    {
        public static string AdnUrl { get; set; } = string.Empty;
        
        public static string SefinUrl { get; set; } = string.Empty;


        /// <summary>
        /// Carregar arquivo de parametros
        /// </summary>
        public static void Carregar()
        {
            // carregar arquivo de parametros
            IConfigurationBuilder builder = new ConfigurationBuilder()
                .AddJsonFile($"appSettings.json", false, true);

#if DEBUG
            builder.AddJsonFile($"appSettings.dev.json", true, true);
#endif

            // carregar
            IConfigurationRoot _configRoot = builder.Build();

            // atribuir nas propriedades os parametros de dentro do arquivo de settings.
            AdnUrl = "" + _configRoot["ApiProducaoRestrita:Adn:Url"];
            SefinUrl = "" + _configRoot["ApiProducaoRestrita:Sefin:Url"];
        }
    }
}
