﻿using System.Text;

namespace Cecam.Tributario.Extend.Utf8StringWriter
{
    public class Utf8StringWriter : StringWriter
    {
        public override Encoding Encoding => Encoding.UTF8;
    }
}
