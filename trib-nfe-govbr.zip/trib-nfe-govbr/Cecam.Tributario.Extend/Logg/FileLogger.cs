﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Logg
{
    public class FileLogger : ILogger
    {
        private readonly string _categoryName;
        private readonly StreamWriter _writer;


        public FileLogger(string categoryName)
        {
            if (string.IsNullOrWhiteSpace(categoryName))
                categoryName = "Geral";

            _categoryName = categoryName;

            var logPath = AppDomain.CurrentDomain.BaseDirectory + "Log\\" + DateTime.UtcNow.AddHours(-3).Year + "\\" + DateTime.UtcNow.AddHours(-3).ToString("MM") + "\\" + DateTime.UtcNow.AddHours(-3).ToString("dd");

            Directory.CreateDirectory(logPath);

            _writer = new StreamWriter(logPath + "\\" + categoryName + "_" + DateTime.UtcNow.AddHours(-3).ToString("yyyyMMdd_HH") + ".txt", true, Encoding.UTF8);
        }


        ~FileLogger() 
        {
            _writer.Flush();
            _writer.Close();
            _writer.Dispose();
        }


        public IDisposable? BeginScope<TState>(TState state) where TState : notnull
        {
            return null;
        }


        public bool IsEnabled(LogLevel logLevel)
        {
            // return logLevel < LogLevel.None;
            return true;
        }


        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            //if (!IsEnabled(logLevel))
            //    return;

            // var message = formatter(state, exception);

            _writer.WriteLine($"[{logLevel}] [{DateTime.UtcNow.AddHours(-3).ToString("HH:mm:ss:fff")}] " + formatter(state, exception));
            _writer.Flush();
        }
    }
}
