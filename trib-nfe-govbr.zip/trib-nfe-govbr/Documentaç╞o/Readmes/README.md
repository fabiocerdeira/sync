# Cecam.Tributario.CORE


### Links com mais documentações

- Projeto C# com todos os dados de Tributos 
    - [Cecam.Tributario.CORE | README.md](README.md)
- Explicações sobre funcionamento do sistema de NFe Gov.BR 
    - [NFe sincronizada com Gov.BR | NFSE_GOV_BR.md](NFSE_GOV_BR.md)
- Site Gov.BR com mais documentos e planilhas sobre o funcionamento do sistema de NFe 
    - [Gov.Br NFe Documentação | https://www.gov.br/nfse/pt-br/biblioteca/documentacao-tecnica](https://www.gov.br/nfse/pt-br/biblioteca/documentacao-tecnica)




# Falta fazer:

- logar para arquivo em disco
- logar telemetria 
- logar tempo de execução
- objeto para aplicar o filtro base separado
- melhorar a montagem das consultas sql
- testes unitários



# Estrutura dos projetos

### Cecam.Tributario.Chamador

Projeto console inicial que é executado (Set as startup project).
Ele chama objetos de negocios existentes dentro do projeto 'Cecam.Tributario.Manager'.


### Cecam.Tributario.Manager

Projeto com todas as regras de negocio do Tributos.
Ele chama objetos de banco de dados existentes dentro do projeto 'Cecam.Tributario.Database'.

Contem os seguintes grupos de classes:

- Business: classe com regras de negocio
- Configuration: funcionamento padrão (nada precisa ser alterado)
- Convert: converter uma classe Entity em View ou View em Entity
- Dependency: injeção de dependencias
	- BusinessDI.cs: incluir as classes do tipo 'Business'
- Request: classe com as propriedades de entrada
- Response: classe com as propriedades de saída


### Cecam.Tributario.Manager.Test

Projeto de teste para o projeto Cecam.Tributario.Manager


### Cecam.Tributario.Database

Projeto com as operações de banco de dados.
Select, Insert, Update, Delete usando SQL.
Select, Insert, Update, Delete usando LINQ.

Contem os seguintes grupos de classes:

- Configuration: funcionamento padrão (nada precisa ser alterado)
- Dependency: injeção de dependencias
	- QueryDI.cs: incluir as classes do tipo 'Query'
	- RepositoryDI.cs: incluir as classes do tipo 'Repository'
- Entity: classe com todos os campos da respectiva tabela do banco de dados
- EntityConfiguration: classe com de-para da classe 'Entity' com a respectiva tabela do banco de dados (mapeia a classe com o banco)
- Filter: classe de parametros usados nas classes de query
- Infra: funcionamento padrão (nada precisa ser alterado)
- Query: classe com operações via sintaxe sql
- Repository: classe que liga uma 'Entity' com o banco


### Cecam.Tributario.Database.Test

Projeto de teste para o projeto Cecam.Tributario.Database













