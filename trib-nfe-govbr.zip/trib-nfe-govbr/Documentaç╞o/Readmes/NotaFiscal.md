-- contribuintes com a maior qtd de notas emitidas
select top 10 nr_CGCCPF, count(*) from ISSNOTAFISCAL group by nr_CGCCPF order by 2 desc
