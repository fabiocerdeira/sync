# NFe sincronizada com Gov.BR


Este documento tem a finalidade de apresentar as alterações necessárias no módulo de ISS (Mobiliário) 
para atender a Lei Complementar n. 214, de 16 de Janeiro de 2025, 
que institui o Imposto sobre Bens e Serviços (IBS), 
a Contribuição Social sobre Bens e Serviços (CBS) 
e o Imposto Seletivo (IS) 
e a criação do Comitê Gestor do IBS.


### Arquivos que faltam encontrar e baixar para Documentação

- O documento DFe_Nota_Tecnica_2024.001_IBSCBS.pdf, faz referencia ao arquivo DFeTiposBasicos_v1.00.xsd que não existe no sharepoint.





### Links com mais documentações

- Projeto C# com todos os dados de Tributos 
    - [Cecam.Tributario.CORE | README.md](README.md)
- Explicações sobre funcionamento do sistema de NFe Gov.BR 
    - [NFe sincronizada com Gov.BR | NFSE_GOV_BR.md](NFSE_GOV_BR.md)
- Site Gov.BR
	- [Gov.BR/nfse](https://gov.br/nfse)
- Site Gov.BR com mais documentos e planilhas sobre o funcionamento do sistema de NFe 
    - [Gov.Br NFe Documentação | https://www.gov.br/nfse/pt-br/biblioteca/documentacao-tecnica](https://www.gov.br/nfse/pt-br/biblioteca/documentacao-tecnica)
- Site Emissor de NFSe
	- [https://www.nfse.gov.br/EmissorNacional/](https://www.nfse.gov.br/EmissorNacional/)




### API

#### API Município

[https://www.producaorestrita.nfse.gov.br/swagger/fisco/](https://www.producaorestrita.nfse.gov.br/swagger/fisco/)

[https://www.nfse.gov.br/swagger/fisco/](https://www.nfse.gov.br/swagger/fisco/)

- APIs PARA O CGNFSe, RFB e MUNICÍPIOS NO SISTEMA NACIONAL NFS-e
- Swagger Município

- Protocolo de comunicação: TLS 1.0, TLS 1.1 e TLS 1.2 com autenticação mútua
- Formato para troca de mensagens: JSON
- Formato dos documentos da NFS-e: XML 1.0 (https://www.w3.org/TR/REC-xml)
- Codificação de caracteres: UTF-8
- Certificado digital: Emitido por Autoridade Certificadora ICP-Brasil, tipo A1 ou A3, CNPJ ou CPF, com "Autenticação do Cliente"
- Padrão de assinatura dos documentos XML: XMLDSIG (https://www.w3.org/TR/xmldsig-core/)
- Padrão de compactação dos documentos XML para troca de mensagens: GZip com representao base64binary


#### API Contribuinte

[https://www.producaorestrita.nfse.gov.br/swagger/contribuintesissqn/](https://www.producaorestrita.nfse.gov.br/swagger/contribuintesissqn/)

[https://www.nfse.gov.br/swagger/contribuintesissqn/](https://www.nfse.gov.br/swagger/contribuintesissqn/)

- APIs PARA OS CONTRIBUINTES DO ISSQN NO SISTEMA NACIONAL NFS-e
- Swagger Contribuinte

- Protocolo de comunicação: TLS 1.0, TLS 1.1 e TLS 1.2 com autenticação mútua
- Formato para troca de mensagens: JSON
- Formato dos documentos da NFS-e: XML 1.0 (https://www.w3.org/TR/REC-xml)
- Codificação de caracteres: UTF-8
- Certificado digital: Emitido por Autoridade Certificadora ICP-Brasil, tipo A1 ou A3, CNPJ ou CPF, com "Autenticação do Cliente"
- Padrão de assinatura dos documentos XML: XMLDSIG (https://www.w3.org/TR/xmldsig-core/)
- Padrão de compactação dos documentos XML para troca de mensagens: GZip com representao base64binary



### GITHUB Exemplos

Seguem abaixo os links do Github com exemplos publicados: 

- NFS-e
	- Node.js: https://github.com/rscarvalho90/NFS-e-Node.js 

- NF-e Ouro (exemplos)
	- Node.js: https://github.com/rscarvalho90/NF-e-Ouro-Node.js
	- Python: https://github.com/rscarvalho90/NF-e-Ouro-Python
	- Java: https://github.com/rscarvalho90/NF-e-Ouro-Java

- NFS-e da PoC que fizemos em BH de 19 a 23/09/2022
	- https://github.com/nfe/poc-nfse-nacional



### Glosário

- SEFIN = Secretaria de Finanças
- RFB = Receita Federal 
- ADN = Ambiente de Dados Nacional
- SN = SEFIN Nacional
- SNNFS-e = Sistema Nacional NFS-e

- IBS = Imposto sobre Bens e Serviços
- CBS = Contribuição Social sobre Bens e Serviços
- IS = Imposto Seletivo 
- ISSQN = Imposto Sobre Serviço de Qualquer Natureza

- CodigoMunicipio = Identificador único do municipio no sistema 
- NSU = Números Sequenciais Únicos (aplica-se em contribuintes, DFE, NFSE, entre outros)

- CNC = Cadastro Nacional de Contribuintes 
- CNS-NSU = Número Sequencial Único do contribuinte enviado para o CNC

- DPS = Declaração de Prestação de Serviço
- DF-e = Documento Fiscal Eletrónico
- NF-e = Nota Fiscal Eletrônica
- NFS-e = Nota Fiscal de Serviços Eletrônica
- ChaveAcesso = Identificador único para uma NFe
- DANFS-e = Documento Auxiliar de Nota Fiscal de Serviço eletrônica

- NT = Nota Técnica
- ATM = Administração Tributária Municipal
- DAN = Declaração de Apuração Nacional
- DNA = Documento Nacional de Arrecadação
- MAN = Módulo de Apuração Nacional
- SPED = Sistema Público de Escrituração Digital




### Atores

- Prestador
- Tomador
- Intermediário
	- Município de incidência do ISSQN
	- Local da prestação do serviço 
	- Município do endereço dos estabelecimentos ou domicílio dos não emitentes da NFS-e


### Sistemas

- Portal Nacional NFS-e 
	- Site Gov.BR com informações, normas, leis, documentos, links e outras sobre NFS-e 

- Painel Administrativo Municipal NFS-e
	- Sistema/site utilizado pelo município 
	- Utilizado para parametrização de informações para emissão de NFe pelos contribuintes
	- Cadastro de contribuintes municipais
	- Lista de Serviços com código da tributação, alíquota, deduções/reduções
	- Retenções
	- Outros benefícios
	- Regime especial de tributação
	- Eventos da NFS-e
	- Consultas da gestão municipal

- Emissor Público Nacional NFS-e – API (Sefin Nacional NFS-e) (Em Desenvolvimento)
	- API para troca de informações entre o município e RFB
	- Utilizado pelo sistema da CECAM para enviar e receber NFS-e
	- Não tem tela de navegação

- Emissor Público Nacional NFS-e – Web (Em Desenvolvimento)
	- Sistema para gerenciamento de NFS-e 
	- Utilizado pelo contribuinte

- Painel de Créditos NFS-e (Em Desenvolvimento)	
	- Nesse momento não esta claro quem utiliza esse sistema (contribuinte e/ou municipio)
	- Talvez a inclusão dos créditos sejá feita pelo MAM e a consulta seja feita pelo contribuinte.
	
- Painel de Débitos NFS-e (Em Desenvolvimento)
	- Nesse momento não esta claro quem utiliza esse sistema (contribuinte e/ou municipio)
	- Talvez a inclusão dos débitos sejá feita pelo MAM e a consulta seja feita pelo contribuinte.

- Módulo de Apuração Nacional NFS-e (MAN NFS-e) (Em Desenvolvimento)
	- Utilizado pelo contribuinte
	- Contribuinte faz a seleção das NFS-e que deverão ser pagas
	- Apurar o ISSQN devido
	- Contribuinte emite o documento nacional de arrecadação






### CNC Cadastro Nacional de Contribuintes 

- Objetivos: a manutenção (inclusão, alteração, exclusão e consulta) do CNC NFS-e

- Planilha Excel com os campos: AnexoV-LeiautesRN_CNC-SNNFSe.xlsx e ANEXO_III-CNC-SNNFSe.xlsx

- 'Codigo_Município/CNPJ/InscricaoMunicipal' ou 'Codigo_Município/CPF/InscricaoMunicipal'

- Trata contribuintes CPF e CNPJ desde que tenham Inscrição Municipal no próprio município.

- O mesmo CNPJ/CPF pode ser informado por mais de um município e em um mesmo município, desde que tenha inscrições municipais diferentes.

- O 'NSU Cadastro' é uma identificação única para cada contribuinte gerada no momento de sua inclusão no CNC NFSe.

- O 'NSU Movimento' é uma identificação gerada para cada solicitação de movimentação de informações.

- No processamento da movimentação solicitada será verificado se já existe informações registradas para o contribuinte no município, para a inscrição municipal informada. Caso ainda não exista informações para a chave informada será considerada uma movimentação de inclusão. Independentemente de ser uma movimentação de inclusão ou alteração deverão ser enviadas todas as informações do contribuinte. Na movimentação de alteração serão sobrepostas as informações enviadas sobre aquelas já registradas.



### API Parâmetros Municipais

- Objetivo: a manutenção (inclusão, alteração, exclusão e consulta) das parametrizações de um município no sistema da Receita

- Grupos de informações:
	- convenio
	- aliquotas
	- regimes_especiais
	- retencoes
	- beneficiomunicipal

- Consultas:
	- Consulta os parâmetros do convênio de um município (/parametros_municipais/{codigoMunicipio}/convenio)
	- Consulta as alíquotas, regimes especiais de tributação e deduções/reduções por subitens da lista de serviço (/parametros_municipais/{ codigoMunicipio}/{codigoServico})
	- Consulta as retenções a que um contribuinte tem o dever de recolher para um município (/parametros_municipais/{codigoMunicipio}/{CPF/CNPJ})
	- Consulta os benefícios municipais a que um contribuinte tem direito em um município (/parametros_municipais/{codigoMunicipio}/{CPF/CNPJ})



###  API NFS-e 

- Objetivo: somente consultar as informações de uma determina NFS-e pela chave de acesso

- DUVIDA 1:
	- Em uma determinada documentação informa que essa API deverá fazer a "Recepção de um arquivo XML que representa a DPS"
	- Mas acho que isso não vai acontecer nessa API de NFS-e , mas sim na API DPS.



###  API DPS = Declaração de Prestação de Serviço

- Fluxo: 
	- Prefeitura envia uma DPS para a Receita
	- Receita verifica os dados da DPS
	- Receita emite a NFe
	- Prefeitura baixa os dados da NFe emitida

- Identificador da DPS 
	- Código IBGE do Município Emissor (7 caracteres) 
	- Tipo de Inscrição (1 caracter)
	- Inscrição Federal (14 caracteres - CPF completar com 000 à esquerda)
	- Série DPS (5 caracteres)
	- Núm. DPS (15 caracteres)

- Objetivo: Recupera a chave de acesso da NFS-e a partir do identificador do DPS.

- Arquivo: AnexoI-LeiautesRN_DPS_NFSe-SNNFSe.xlsx

- DUVIDA 1:
	- Na documentação não fala de enviar DPS, mas na API já consta um método POST de DFE. 
	- Não sei se DPS e DFE são a mesma coisa ou se estou no local correto?


### API DANFSe = Documento Auxiliar de Nota Fiscal de Serviço eletrônica

- Consulta ao banco de dados do ADN NFS-e para recuperar o XML da NFS-e solicitada e, a partir das informações contidas no documento NFS-e, gerar o PDF em leiaute específico.

- /danfse/{chaveAcesso} para recuperar o PDF da NFS-e







### API Eventos

- Eventos são as alterações em uma NFe após a sua emissão. Como por exemplo cancelamento, substituição, etc.

- Um evento sempre esta vinculado a uma única NFe. E uma NFe pode conter vários eventos. 
´
- Cada evento tem seu próprio identificador único

- Arquivo AnexoIILeiautesRN_Eventos-SNNFSe.xlsx

- Tipos de eventos:
	- Evento de Cancelamento de NFS-e
	- Evento de Cancelamento por Substituição de NFS-e
	- Solicitação de Análise Fiscal para Cancelamento de NFS-e
	- Cancelamento de NFS-e Deferido por Análise Fiscal
	- Cancelamento de NFS-e Indeferido por Análise Fiscal
	- Manifestação de NFS-e
	- Cancelamento de NFS-e por Ofício
	- Bloqueio de NFS-e por Ofício
	- Desbloqueio de NFS-e por Ofício







### Tipos de NFe

- Nota Fiscal Eletrônica (modelo 55)
- Nota Fiscal de Consumidor Eletrônica (modelo 65)
- CTe = Conhecimento de Transporte Eletrônico (modelo 57)
- Conhecimento de Transporte Eletrônico para Outros Serviços (modelo 67)
- BPe = Bilhete de Passagem Eletrônico (modelo 63)
- NF3e = Nota Fiscal de Energia Elétrica Eletrônica (modelo 66)
- NFCom = Nota Fiscal Fatura de Serviço de Comunicação Eletrônica (modelo 62)







	














