using Microsoft.Testing.Platform.Configurations;
using Microsoft.Testing.Platform.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Test.Preparacao
{
    [TestClass]
    public class TestBase
    {
        /*
        Mock<IConfiguration> _configurationMock = new Mock<IConfiguration>();
        protected Mock<IConfiguration> ConfigurationMock => _configurationMock;


        Mock<ILoggerFactory> _loggerFactoryMock = new Mock<ILoggerFactory>();
        protected Mock<ILoggerFactory> LoggerFactoryMock => _loggerFactoryMock;
        */

        /*
        Mock<ITributosContext> _tributosContextoMock = new Mock<ITributosContext>();
        Mock<IIssContribuinteRepository> _issContribuinteRepositorioMock = new Mock<IIssContribuinteRepository>();
        */

        [TestInitialize]
        public void Initialize()
        {
            /*
            // inicializar a biblioteca CORE

            // carregar arquivo de configura��es
            IConfiguration configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("coreSettingsTest.json")
                .Build();


            // logger
            ILoggerFactory loggerFactory = LoggerFactory.Create(b => { });


            // preparar EF Core para executar service colletion
            // que � o controlador de "DI"
            var services = new ServiceCollection();

            // incluir o iConfiguration na cole��o de servi�os par DI.
            services.AddSingleton<IConfiguration>(provider => configuration);
            services.AddSingleton<ILoggerFactory>(provider => loggerFactory);

            // configurar DI para dbContext, repositorios e opera��es de banco
            services.InfraAddServices();
            // services.InfraAddContext(configuration);
            // services.RepositoryAddServices();
            services.OperationAddServices();

            // mock de repositorios
            services.RemoveAll<IIssContribuinteRepository>();
            services.AddTransient<IIssContribuinteRepository>(provider => _issContribuinteRepositorioMock.Object);

            // configurar DI para objetos de negocio
            // services.BusinessAddServices();

            // build das configura��es acima.
            // _serviceProviderGlobal = services.BuildServiceProvider();
            ConfiguracaoCore.ServiceProviderGlobal = services.BuildServiceProvider();
            */
        }


        [TestCleanup]
        public void Cleanup()
        {
        }
    }
}
