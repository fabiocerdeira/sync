using Cecam.Tributario.Manager.Business.Iss;
using Cecam.Tributario.Manager.Test.Preparacao;

namespace Cecam.Tributario.Manager.Test;

[TestClass]
public class IssContribuinteBusTest : TestBase
{
    [TestMethod]
    public void TestMethod1()
    {
    }


    [TestMethod]
    public void IssContribuinteNeg_ListarTesteFabio_Sucesso()
    {
        var issContribuinteBus = new IssContribuinteBus();

        var lista = issContribuinteBus.ListarTesteFabio().Result;

        Assert.AreEqual(10, lista.Count);
    }

}
