﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Extend.Async;
using Cecam.Tributario.Manager.Business.Iss;
using Cecam.Tributario.Manager.Business.SysObject;

namespace Cecam.Tributario.Chamador
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            // inicializar a biblioteca CORE
            IniciarDatabase.Iniciar();

            // ------------------------------------------------------------

            // criar as classes templates no disco "C:\"
            var sis = new SysObjectBus();
            sis.Fazer();
            return;

            // ------------------------------------------------------------

            var issContribuinteBus = new IssContribuinteBus();

            AsyncHelper.RunSync(() => issContribuinteBus.UpdateExemplo());


            


            // issContribuinteBus.SalvarAsync().Wait();

            // ------------------------------------------------------------

            var lista = issContribuinteBus.ListarTesteFabio().Result;

            foreach (var item in lista)
            {
                Console.WriteLine(item.Cd_Contribuinte + item.Ds_RazaoSocial);
            }

        }
    }
}
