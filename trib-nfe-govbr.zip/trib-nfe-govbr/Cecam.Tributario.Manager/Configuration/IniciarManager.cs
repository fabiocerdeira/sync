﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Configuration
{
    public static class IniciarManager
    {
        public static void Iniciar()
        {
        }
    }
}
