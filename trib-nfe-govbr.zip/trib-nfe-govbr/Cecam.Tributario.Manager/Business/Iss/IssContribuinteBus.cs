﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.Query.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.Repository.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.Iss
{
    public class IssContribuinteBus
    {
        //private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<IssContribuinteBus> _logger;
        private readonly IIssContribuinteRepository _issContribuinteRepository;
        private readonly IIssContribuinteQuery _issContribuinteQuery;


        public IssContribuinteBus()
        {
            //_unitOfWork = ConfiguracaoCore.GetServico<IUnitOfWork>();
            _logger = ConfiguracaoDatabase.CreateLogger<IssContribuinteBus>();
            _issContribuinteRepository = ConfiguracaoDatabase.GetServico<IIssContribuinteRepository>();
            _issContribuinteQuery = ConfiguracaoDatabase.GetServico<IIssContribuinteQuery>();
        }



        public async Task UpdateExemplo()
        {
            await _issContribuinteQuery.UpdateExemploSQL();
        }



        public async Task<List<IssContribuinteEntity>> ListarTesteFabio()
        {
            /*
            _logger.LogCritical("ListarTesteFabio(xxx) começo do código");
            _logger.LogDebug("ListarTesteFabio(xxx) começo do código");
            _logger.LogError("ListarTesteFabio(xxx) começo do código");
            _logger.LogInformation("ListarTesteFabio(xxx) começo do código");
            _logger.LogTrace("ListarTesteFabio(xxx) começo do código");
            _logger.LogWarning("ListarTesteFabio(xxx) começo do código");
            */

            _logger.LogInformation("ListarTesteFabio(xxx) começo do código");

            var retorno = await _issContribuinteQuery.Listar(new IssContribuinteFilter()
            {
                QtdMaximaRegistrosRetornados = 5,
                Cd_Exercicio = 2025
            });

            retorno.AddRange(await _issContribuinteQuery.ListarSQL(new IssContribuinteFilter()
            {
                QtdMaximaRegistrosRetornados = 5,
                Cd_Exercicio = 2025
            }));

            return retorno;
        }


        public async Task SalvarAsync()
        {
            // USANDO UNIT OF WORK - sem transação

            using (var unit1 = new UnitOfWork())
            {
                var repo = new IssContribuinteRepository(unit1);

                var modelo = repo.DbSetEntity.FirstOrDefault();

                if (modelo != null)
                {
                    modelo.Ds_Obs = "unit-SEM-transacao-" + DateTime.Now.ToString("hh:mm:ss:fff");

                    await unit1.SaveChangesAsync();
                }
            }

            // USANDO UNIT OF WORK - COM transação Commit

            using (var unit1 = new UnitOfWork())
            {
                var repo = new IssContribuinteRepository(unit1);

                var modelo = repo.DbSetEntity.FirstOrDefault();

                if (modelo != null)
                {
                    await unit1.BeginTransactionAsync();

                    modelo.Ds_Obs = "unit-COM-transacao-" + DateTime.Now.ToString("hh:mm:ss:fff");

                    await unit1.SaveChangesAsync();

                    await unit1.CommitTransactionAsync();
                }
            }

            // USANDO UNIT OF WORK - COM transação RollBack

            using (var unit1 = new UnitOfWork())
            {
                var repo = new IssContribuinteRepository(unit1);

                var modelo = repo.DbSetEntity.FirstOrDefault();

                if (modelo != null)
                {
                    await unit1.BeginTransactionAsync();

                    modelo.Ds_Obs = "unit-COM-rollback-" + DateTime.Now.ToString("hh:mm:ss:fff");

                    await unit1.SaveChangesAsync();

                    await unit1.RollbackTransactionAsync();
                }
            }



            // ----------------

            // USANDO REPOSITORIO

            var ent1 = _issContribuinteRepository.DbSetEntity.FirstOrDefault();

            if (ent1 != null)
            {
                ent1.Ds_Obs = "reposit-" + DateTime.Now.ToString("hh:mm:ss:fff");

                await _issContribuinteRepository.SaveChangesAsync();
            }



            // ----------------

            // USANDO OPERATION

            var _issRepo_005 = new IssContribuinteRepository();

            var _issContribuinteQuery_005 = new IssContribuinteQuery(_issRepo_005);

            var lista = await _issContribuinteQuery_005.Listar(new IssContribuinteFilter()
            {
                QtdMaximaRegistrosRetornados = 1,
                Cd_Exercicio = 2025,
                AsNoTracking = false
            });

            var model = lista.FirstOrDefault();

            if (model != null)
            {
                model.Ds_Obs = "query-001-" + DateTime.Now.ToString("hh:mm:ss:fff");

                //_issRepo_005.Update(model);

                await _issRepo_005.SaveChangesAsync();
            }


            // ----------------

            // USANDO OPERATION para update com sql

            var qtd_006 = await _issContribuinteQuery_005.UpdateExemploSQL();

        }


    }
}
