﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Entity.SysObject;
using Cecam.Tributario.Database.RepositoryInterface.SysObject;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cecam.Tributario.Manager.Business.SysObject
{
    public class SysObjectBus
    {
        private readonly ISysObjectRepository _sysObjectRepository;
        private readonly ISysColumnRepository _sysColumnRepository;
        private readonly ISysIndexRepository _sysIndexRepository;
        private readonly ISysIndexColumnRepository _sysIndexColumnRepository;

        private string _nomeTabela = string.Empty;
        private string _nomeEspaco = string.Empty;
        private string _nomeClasse = string.Empty;
        private List<SysColumnEntity> _colunas = new List<SysColumnEntity>();


        public SysObjectBus()
        {
            _sysObjectRepository = ConfiguracaoDatabase.GetServico<ISysObjectRepository>();
            _sysColumnRepository = ConfiguracaoDatabase.GetServico<ISysColumnRepository>();
            _sysIndexRepository = ConfiguracaoDatabase.GetServico<ISysIndexRepository>();
            _sysIndexColumnRepository = ConfiguracaoDatabase.GetServico<ISysIndexColumnRepository>();
        }


        public void Fazer()
        {
            /*
            _nomeTabela = "ISSNotaFiscal_GovBr_FilaEntrada";
            _nomeEspaco = "ISSNotaFiscalGovBr";
            _nomeClasse = "ISSNotaFiscalGovBrFilaEntrada";

            _nomeTabela = "ISSNotaFiscal_GovBr_FilaSaida";
            _nomeEspaco = "ISSNotaFiscalGovBr";
            _nomeClasse = "ISSNotaFiscalGovBrFilaSaida";

             
            _nomeTabela = "ISSNotaFiscal";
            _nomeEspaco = "ISSNotaFiscal";
            _nomeClasse = "ISSNotaFiscal";
            */

            _nomeTabela = "ISSNotaFiscalItem";
            _nomeEspaco = "ISSNotaFiscal";
            _nomeClasse = "ISSNotaFiscalItem";

            ConsultarGravarArquivosDisco();
        }


        /// <summary>
        /// Consultar a base e criar alguns arquivos no disco com a representação da tabela da base.
        /// </summary>
        private void ConsultarGravarArquivosDisco()
        {
            if (string.IsNullOrWhiteSpace(_nomeTabela))
                return;

            var sysTabela = _sysObjectRepository.GetIQueryable().FirstOrDefault(x => x.Name == _nomeTabela);

            if (sysTabela == null)
                return;

            _colunas = _sysColumnRepository.GetIQueryable().Where(x => x.Object_id == sysTabela.Object_id).OrderBy(x => x.Column_id).ToList();

            if (_colunas == null || _colunas.Count <= 0)
                return;

            var sysIndexPk = _sysIndexRepository.GetIQueryable().FirstOrDefault(x => x.Object_id == sysTabela.Object_id && x.Is_primary_key);

            if (sysIndexPk != null)
            {
                var sysPkColunas = _sysIndexColumnRepository.GetIQueryable().Where(x => x.Object_id == sysTabela.Object_id && x.Index_id == sysIndexPk.Index_id).ToList();

                foreach (var pkItem in sysPkColunas)
                {
                    var pkCol = _colunas.Where(x => x.Column_id == pkItem.Column_id).FirstOrDefault();

                    if (pkCol != null)
                        pkCol.IsPk = true;
                }
            }

            // criar os arquivos em disco.
            CriarEntity();
            CriarRepositoryInterface();
            CriarRepository();
            CriarEntityConfiguration();
            CriarFilter();
            CriarQuery();
            CriarQueryInterface();
        }


        private void CriarEntity()
        {
            string modelo = @"using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.##nomeEspaco##
{
    public class ##nomeClasse##Entity : EntityBase
    {
        #region Propriedades

##props##

        #endregion

        #region Relacionamentos
        #endregion
    }
}
";
            string props = string.Empty;
            string tipo = string.Empty;

            foreach (var colunaItem in _colunas)
            {
                tipo = ConverterTipoSql2Net(colunaItem.System_type_id);

                props += "\t\t";

                props += "public " + tipo + (colunaItem.Is_nullable ? "?" : "") + " " + PrimeiraLetraMaiuscula(colunaItem.Name) + " { get; set; }";
                
                if (tipo == "string" && !colunaItem.Is_nullable)
                    props += " = string.Empty;";

                props += Environment.NewLine + Environment.NewLine;
            }


            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);
            modelo = modelo.Replace("##props##", props);

            GravarArquivoDisco("Entity\\" + _nomeEspaco, _nomeClasse + "Entity", modelo);
        }


        private void CriarRepositoryInterface()
        {
            string modelo = @"using Cecam.Tributario.Database.Entity.##nomeEspaco##;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.##nomeEspaco##
{
    public interface I##nomeClasse##Repository : IRepository<##nomeClasse##Entity>
    {
    }
}
";

            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);

            GravarArquivoDisco("RepositoryInterface\\" + _nomeEspaco, "I" + _nomeClasse + "Repository", modelo);
        }


        private void CriarRepository()
        {
            string modelo = @"using Cecam.Tributario.Database.Entity.##nomeEspaco##;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.##nomeEspaco##;

namespace Cecam.Tributario.Database.Repository.##nomeEspaco##
{
    public class ##nomeClasse##Repository : Repository<##nomeClasse##Entity>, I##nomeClasse##Repository
    {
        public ##nomeClasse##Repository() : base() { }
        public ##nomeClasse##Repository(ITributosContext dbContexto) : base(dbContexto) { }
        public ##nomeClasse##Repository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
";

            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);

            GravarArquivoDisco("Repository\\" + _nomeEspaco, _nomeClasse + "Repository", modelo);
        }


        private void CriarEntityConfiguration()
        {
            string modelo = @"using Cecam.Tributario.Database.Entity.##nomeEspaco##;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.##nomeEspaco##
{
    public class ##nomeClasse##EntityConfiguration : IEntityTypeConfiguration<##nomeClasse##Entity>
    {
        public void Configure(EntityTypeBuilder<##nomeClasse##Entity> builder)
        {
            builder.ToTable(""##nomeTabela##"");

            // primary key
##hasKey##


            #region Propriedades
##props##
            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
";

            string hasKey = string.Empty;
            string props = string.Empty;

            foreach (var colunaItem in _colunas)
            {
                props += "\t\t\t";

                props += "builder.Property(x => x." + PrimeiraLetraMaiuscula(colunaItem.Name) + ").HasColumnName(\"" + colunaItem.Name + "\")";

                // 60 money | 106 decimal | 108 numeric
                if (colunaItem.System_type_id == 60 || colunaItem.System_type_id == 106 || colunaItem.System_type_id == 108)
                {
                    props += $".HasColumnType(\"decimal({colunaItem.Precision},{colunaItem.Scale})\").HasPrecision({colunaItem.Precision},{colunaItem.Scale})";
                }

                if (colunaItem.Is_nullable)
                {
                    props += ".IsRequired(false)";
                }

                props += ";" + Environment.NewLine;

                // -----------------------------

                if (colunaItem.IsPk)
                {
                    if (!string.IsNullOrEmpty(hasKey))
                    {
                        hasKey += "," + Environment.NewLine;
                    }

                    hasKey += "\t\t\t\t";

                    hasKey += " x." + PrimeiraLetraMaiuscula(colunaItem.Name);
                }
            }

            if (string.IsNullOrEmpty(hasKey))
            {
                hasKey = "\t\t\t\tbuilder.HasNoKey();";
            }
            else
            {
                hasKey = "\t\t\tbuilder.HasKey(x => new {" + Environment.NewLine + hasKey + Environment.NewLine + "\t\t\t});" + Environment.NewLine + Environment.NewLine;
            }



            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);
            modelo = modelo.Replace("##nomeTabela##", _nomeTabela);
            modelo = modelo.Replace("##hasKey##", hasKey);
            modelo = modelo.Replace("##props##", props);

            GravarArquivoDisco("EntityConfiguration\\" + _nomeEspaco, _nomeClasse + "EntityConfiguration", modelo);
        }


        private void CriarFilter()
        {
            string modelo = @"using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.##nomeEspaco##
{
    public class ##nomeClasse##Filter : FiltroBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

##props##

        #endregion

        #region Relacionamentos
        #endregion
    }
}
";

            string props = string.Empty;
            string tipo = string.Empty;

            foreach (var colunaItem in _colunas)
            {
                tipo = ConverterTipoSql2Net(colunaItem.System_type_id);

                props += "\t\t";

                props += "public " + tipo + "? " + PrimeiraLetraMaiuscula(colunaItem.Name) + " { get; set; }";

                props += Environment.NewLine + Environment.NewLine;
            }

            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);
            modelo = modelo.Replace("##props##", props);

            GravarArquivoDisco("Filter\\" + _nomeEspaco, _nomeClasse + "Filter", modelo);
        }


        private void CriarQuery()
        {
            string modelo = @"using Cecam.Tributario.Database.Entity.##nomeEspaco##;
using Cecam.Tributario.Database.Filter.##nomeEspaco##;
using Cecam.Tributario.Database.QueryInterface.##nomeEspaco##;
using Cecam.Tributario.Database.RepositoryInterface.##nomeEspaco##;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.##nomeEspaco##
{
    public class ##nomeClasse##Query : QueryBase, I##nomeClasse##Query
    {
        protected readonly I##nomeClasse##Repository _##nomeClasseMin##Repositorio;


        public ##nomeClasse##Query(I##nomeClasse##Repository ##nomeClasseMin##Repositorio)
        {
            _##nomeClasseMin##Repositorio = ##nomeClasseMin##Repositorio;
        }


        public async Task<List<##nomeClasse##Entity>> Listar(##nomeClasse##Filter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _##nomeClasseMin##Repositorio.GetIQueryable();

            #region Propriedades

##props##

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<##nomeClasse##Entity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<##nomeClasse##Entity>> ListarSQL(##nomeClasse##Filter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine(""SELECT "");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($"" TOP {filtro.QtdMaximaRegistrosRetornados.Value} "");

            sql.AppendLine(""* FROM ##nomeTabela## WITH(NOLOCK) "");

            #region Propriedades

##propsql##

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine("" WHERE "" + sqlWhere.ToString());
            }

            return await _##nomeClasseMin##Repositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = ""UPDATE ##nomeTabela## SET campo = 'valor' WHERE pk = 666"";

            return await _##nomeClasseMin##Repositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
";

            string props = string.Empty;
            string propsql = string.Empty;
            string tipo = string.Empty;
            string nome = string.Empty;

            foreach (var colunaItem in _colunas)
            {
                tipo = ConverterTipoSql2Net(colunaItem.System_type_id);
                
                nome = PrimeiraLetraMaiuscula(colunaItem.Name);

                if (tipo == "string")
                {
                    props += "\t\t\t" + $"if (!string.IsNullOrWhiteSpace(filtro.{nome}))" + Environment.NewLine;
                    props += "\t\t\t\t" + $"consulta = consulta.Where(x => x.{nome} == filtro.{nome});" + Environment.NewLine;

                    propsql += "\t\t\t" + $"if (!string.IsNullOrWhiteSpace(filtro.{nome}))" + Environment.NewLine;
                    propsql += "\t\t\t" + "{" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "if (sqlWhere.Length > 0) sqlWhere.Append(\" AND \");" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "sqlWhere.AppendLine($\" " + nome + " = '{filtro." + nome + ".Trim().Replace(\"\\'\",\"\")}'\");" + Environment.NewLine;
                    propsql += "\t\t\t" + "}" + Environment.NewLine;
                }

                if (tipo == "byte" || tipo == "short" || tipo == "int" || tipo == "double" || tipo == "byte" || tipo == "decimal" || tipo == "long")
                {
                    props += "\t\t\t" + $"if (filtro.{nome}.HasValue && filtro.{nome}.Value > 0)" + Environment.NewLine;
                    props += "\t\t\t\t" + $"consulta = consulta.Where(x => x.{nome} == filtro.{nome}.Value);" + Environment.NewLine;

                    propsql += "\t\t\t" + $"if (filtro.{nome}.HasValue && filtro.{nome}.Value > 0)" + Environment.NewLine;
                    propsql += "\t\t\t" + "{" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "if (sqlWhere.Length > 0) sqlWhere.Append(\" AND \");" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "sqlWhere.AppendLine($\" " + nome + " = {filtro." + nome + "}\");" + Environment.NewLine;
                    propsql += "\t\t\t" + "}" + Environment.NewLine;
                }

                if (tipo == "bool" || tipo == "DateTime")
                {
                    props += "\t\t\t" + $"if (filtro.{nome}.HasValue)" + Environment.NewLine;
                    props += "\t\t\t\t" + $"consulta = consulta.Where(x => x.{nome} == filtro.{nome}.Value);" + Environment.NewLine;

                    propsql += "\t\t\t" + $"if (filtro.{nome}.HasValue)" + Environment.NewLine;
                    propsql += "\t\t\t" + "{" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "if (sqlWhere.Length > 0) sqlWhere.Append(\" AND \");" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "sqlWhere.AppendLine($\" " + nome + " = {filtro." + nome + "}\");" + Environment.NewLine;
                    propsql += "\t\t\t" + "}" + Environment.NewLine;
                }

                if (tipo == "Guid")
                {
                    props += "\t\t\t" + $"if (filtro.{nome}.HasValue)" + Environment.NewLine;
                    props += "\t\t\t\t" + $"consulta = consulta.Where(x => x.{nome} == filtro.{nome}.Value);" + Environment.NewLine;

                    propsql += "\t\t\t" + $"if (filtro.{nome}.HasValue)" + Environment.NewLine;
                    propsql += "\t\t\t" + "{" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "if (sqlWhere.Length > 0) sqlWhere.Append(\" AND \");" + Environment.NewLine;
                    propsql += "\t\t\t\t" + "sqlWhere.AppendLine($\" " + nome + " = '{filtro." + nome + ".Value}'\");" + Environment.NewLine;
                    propsql += "\t\t\t" + "}" + Environment.NewLine;
                }

                // tipo == "byte[]" não faz filtro

                props += Environment.NewLine;
                propsql += Environment.NewLine;
            }

            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeTabela##", _nomeTabela);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);
            modelo = modelo.Replace("##nomeClasseMin##", PrimeiraLetraMinuscula(_nomeClasse));
            modelo = modelo.Replace("##props##", props);
            modelo = modelo.Replace("##propsql##", propsql);

            GravarArquivoDisco("Query\\" + _nomeEspaco, _nomeClasse + "Query", modelo);
        }


        private void CriarQueryInterface()
        {
            string modelo = @"using Cecam.Tributario.Database.Entity.##nomeEspaco##;
using Cecam.Tributario.Database.Filter.##nomeEspaco##;

namespace Cecam.Tributario.Database.QueryInterface.##nomeEspaco##
{
    public interface I##nomeClasse##Query
    {
        Task<List<##nomeClasse##Entity>> Listar(##nomeClasse##Filter filtro);

        Task<List<##nomeClasse##Entity>> ListarSQL(##nomeClasse##Filter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
";

            // replace macros
            modelo = modelo.Replace("##nomeEspaco##", _nomeEspaco);
            modelo = modelo.Replace("##nomeClasse##", _nomeClasse);
            modelo = modelo.Replace("##nomeClasseMin##", PrimeiraLetraMinuscula(_nomeClasse));

            GravarArquivoDisco("QueryInterface\\" + _nomeEspaco, "I" + _nomeClasse + "Query", modelo);
        }






        #region Auxiliares


        /// <summary>
        /// Gravar arquivo em disco, substituindo caso já exista
        /// </summary>
        private void GravarArquivoDisco(string pasta, string nomeArquivo, string mensagem)
        {
            string pastaSaida = "C:\\Users\\fabio.cerdeira\\Downloads\\Futuro\\" + pasta;

            Directory.CreateDirectory(pastaSaida);

            File.WriteAllText(pastaSaida + "\\" + nomeArquivo + ".cs", mensagem, Encoding.UTF8);
        }


        /// <summary>
        /// Primeira letra maisucula
        /// </summary>
        private string PrimeiraLetraMaiuscula(string texto)
        {
            // 
            var arr = texto.Trim().ToCharArray();
            arr[0] = Char.ToUpperInvariant(arr[0]);
            return new string(arr);
        }


        /// <summary>
        /// Primeira letra minuscula
        /// </summary>
        private string PrimeiraLetraMinuscula(string texto)
        {
            // 
            var arr = texto.Trim().ToCharArray();
            arr[0] = Char.ToLowerInvariant(arr[0]);
            return new string(arr);
        }


        /// <summary>
        /// Converter o tipo do sql server em um tipo .net C#
        /// </summary>
        private string ConverterTipoSql2Net(byte system_type_id)
        {
            string tipo = string.Empty;

            switch (system_type_id)
            {
                case 36: // uniqueidentifier
                    tipo = "Guid";
                    break;

                case 48: // tinyint
                    tipo = "byte";
                    break;

                case 52: // smallint
                    tipo = "short";
                    break;

                case 34: // image
                case 165: // varbinary
                    tipo = "byte[]";
                    break;

                case 56: // int
                    tipo = "int";
                    break;

                case 62: // float
                    tipo = "double";
                    break;

                case 40: // date
                case 42: // datetime2
                case 58: // smalldatetime
                case 61: // datetime
                    tipo = "DateTime";
                    break;

                case 104: // bit
                    tipo = "bool";
                    break;

                case 60:  // money
                case 106: // decimal
                case 108: // numeric
                    tipo = "decimal";
                    break;

                case 127: // bigint
                    tipo = "long";
                    break;

                case 35:  // text
                case 99:  // ntext
                case 167: // varchar
                case 175: // char
                case 231: // nvarchar
                case 239: // nchar
                    tipo = "string";
                    break;

                default:
                    tipo = "ERRO-FALTA-TIPO";
                    break;
            }

            return tipo;
        }


        #endregion
    }
}
