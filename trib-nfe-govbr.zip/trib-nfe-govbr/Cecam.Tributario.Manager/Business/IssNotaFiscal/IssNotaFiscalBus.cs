﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscal
{
    public class IssNotaFiscalBus
    {
        private readonly ILogger<IssNotaFiscalBus> _logger;
        private readonly IIssNotaFiscalRepository _notaFiscalRepository;
        private readonly IIssNotaFiscalItemRepository _notaFiscalItemRepository;


        public IssNotaFiscalBus()
        {
            _logger = ConfiguracaoDatabase.CreateLogger<IssNotaFiscalBus>();
            _notaFiscalRepository = ConfiguracaoDatabase.GetServico<IIssNotaFiscalRepository>();
            _notaFiscalItemRepository = ConfiguracaoDatabase.GetServico<IIssNotaFiscalItemRepository>();
        }


        public async Task<IssNotaFiscalEntity?> CarregarUmaNotaFiscalCompleta(decimal cd_NotaFiscal)
        {
            if (cd_NotaFiscal == 0)
                return null;

            var notaFiscalEntity = await _notaFiscalRepository.GetIQueryable()
                .Where(x => x.Cd_NotaFiscal == cd_NotaFiscal)
                .Include(x => x.Itens)
                .FirstOrDefaultAsync();

            if (notaFiscalEntity == null)
                return null;

            // carregar o contribuinte

            return notaFiscalEntity;
        }
    }
}
