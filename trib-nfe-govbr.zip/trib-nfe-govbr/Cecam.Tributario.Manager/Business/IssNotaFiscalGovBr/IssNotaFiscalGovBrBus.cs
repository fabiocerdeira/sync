﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Utf8StringWriter;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrBus
    {
        //private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<IssNotaFiscalGovBrBus> _logger;
        private readonly IIssNotaFiscalGovBrFilaEntradaRepository  _filaEntradaRepository;
        private readonly IIssNotaFiscalGovBrFilaSaidaRepository  _filaSaidaRepository;


        // objetos globais.
        private IssNotaFiscalGovBrFilaEntradaEntity? _notaFiscalFilaEntrada;
        private IssNotaFiscalEntity? _notaFiscalEntity;


        public IssNotaFiscalGovBrBus()
        {
            //_unitOfWork = ConfiguracaoCore.GetServico<IUnitOfWork>();
            _logger = ConfiguracaoDatabase.CreateLogger<IssNotaFiscalGovBrBus>();
            _filaEntradaRepository = ConfiguracaoDatabase.GetServico<IIssNotaFiscalGovBrFilaEntradaRepository>();
            _filaSaidaRepository = ConfiguracaoDatabase.GetServico<IIssNotaFiscalGovBrFilaSaidaRepository>();
        }


        /// <summary>
        /// Carregar a próxima nota fiscal que precisa ser enviada para Gov.Br
        /// </summary>
        public async Task ConsultarProximaNotaFiscalParaEnvio()
        {
            _logger.LogInformation("ConsultarNotasFiscaisParaEnvio() procurar notas fiscais emitidas/criadas para enviar da Prefeitura para Gov.Br - início");

            // limpar os objetos dessa classe para próxima NFSe.
            LimparObjetosGlobais();

            // Carregar a partir da fila de entrada a próxima nota fiscal que precisa ser enviada para Gov.Br
            await CarregarProximaNotaFiscalParaEnvio();

            // Carregar a nota fiscal eletrônica com todas as informações filhas
            await CarregarNotaFiscal();

            // Varias validações e regras de negócio para determinar se a nota fiscal carregada pode ser enviada para o Gov.Br
            await VerificarSeNotaFiscalPodeSerEnviada();

            // Converter o objeto de nota fiscal da prefeitura/cecam em objeto Gov.Br
            await ConverterNotaFiscalParaXML();

            _logger.LogInformation("ConsultarNotasFiscaisParaEnvio() procurar notas fiscais emitidas/criadas para enviar da Prefeitura para Gov.Br - fim com sucesso");
        }


        /// <summary>
        /// Carregar a partir da fila de entrada a próxima nota fiscal que precisa ser enviada para Gov.Br
        /// </summary>
        private async Task CarregarProximaNotaFiscalParaEnvio()
        {
            _logger.LogInformation("CarregarProximaNotaFiscalParaEnvio() procurar próxima NFe emitida/criada na fila de entrada - início");

            // carregar uma nota fiscal que foi emitida/cridada (filaTipo=1) na fila de entrada
            // notas fiscais ainda não enviadas status=0
            // notas fiscais já tentou enviar anteriormente e deu erro status=1
            _notaFiscalFilaEntrada = await _filaEntradaRepository.GetIQueryable()
                .Where(x => x.FilaTipo == IssNotaFiscalGovBrEnum.FilaTipo_EMISSAO_NF &&
                            (
                                (x.Status == IssNotaFiscalGovBrEnum.Status_Aguardando_Processar) ||
                                (x.Status == IssNotaFiscalGovBrEnum.Status_Processado_Erro && x.EnvioDataHora.HasValue && x.EnvioDataHora.Value <= DateTime.UtcNow.AddHours(-4)))
                            )
                .OrderBy(x => x.Id)
                .FirstOrDefaultAsync();

            if (_notaFiscalFilaEntrada == null)
            {
                _logger.LogInformation("CarregarProximaNotaFiscalParaEnvio() NÃO existem notas fiscais na fila de entrada para enviar da Prefeitura para Gov.Br");
                return;
            }

            _logger.LogInformation("CarregarProximaNotaFiscalParaEnvio() fila de entrada para nota fiscal cd_cecam={_notaFiscalFilaEntrada.Cd_Cecam} carregada - fim com sucesso", _notaFiscalFilaEntrada.Cd_Cecam);
        }


        /// <summary>
        /// Carregar a nota fiscal eletrônica com todas as informações filhas
        /// </summary>
        private async Task CarregarNotaFiscal()
        {
            if (_notaFiscalFilaEntrada == null)
                return;

            _logger.LogInformation("ConsultarNotasFiscaisParaEnvio() carregados Cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} - início", _notaFiscalFilaEntrada.Cd_NotaFiscal);

            // objeto de negocio
            var notaFiscalBus = new IssNotaFiscalBus();

            // carregar a nota fiscal completa com todos os seus dados
            _notaFiscalEntity = await notaFiscalBus.CarregarUmaNotaFiscalCompleta(_notaFiscalFilaEntrada.Cd_NotaFiscal);

            if (_notaFiscalEntity == null)
            {
                _logger.LogError("ConsultarNotasFiscaisParaEnvio() **erro** ao consultar NFe Cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} que não foi encontrada.", _notaFiscalFilaEntrada.Cd_NotaFiscal);
                return;
            }

            _logger.LogInformation("ConsultarNotasFiscaisParaEnvio() todos os dados da NFe foram carregados com sucesso Cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} - fim com sucesso", _notaFiscalFilaEntrada.Cd_NotaFiscal);
        }


        /// <summary>
        /// Varias validações e regras de negócio para determinar se a nota fiscal carregada pode ser enviada para o gov.br
        /// </summary>
        private async Task VerificarSeNotaFiscalPodeSerEnviada()
        {
            if (_notaFiscalFilaEntrada == null)
                return;

            // usado somente para o log
            decimal cd_NotaFiscal = _notaFiscalFilaEntrada.Cd_NotaFiscal;

            _logger.LogInformation("VerificarSeNotaFiscalPodeSerEnviada() verificando se NFe cd_NotaFiscal={cd_NotaFiscal} pode ser enviada - início", cd_NotaFiscal);

            bool permiteEnviar = true;
            string motivo = string.Empty;

            // se nota fiscal carregada esta na fila de criação/emissão,
            // mas demorou muito tempo para ser enviada e já foi cancelada pelo contribuinte.
            // então não tem porque enviar uma nota cancelada que ainda nem foi enviada.
            motivo = "NFSe foi cancelada antes mesmo de ser enviada para Gov.Br";


            // teste nr 2 (pensar nas várias situação)


            if (!permiteEnviar)
            {
                // mover da fila de entrada para a fila de saída
                // colocar no campo 'envioMensagem' que não foi enviada pelo motivo da validação acima

                // limpar os objetos dessa classe para próxima NFSe.
                LimparObjetosGlobais();
            }

            _logger.LogInformation("VerificarSeNotaFiscalPodeSerEnviada() verificando se NFe cd_NotaFiscal={cd_NotaFiscal} pode ser enviada - fim com sucesso", cd_NotaFiscal);

            // para manter método como async
            // se não precisar acessar a base, então remover o 'async task' da declaração do méotod
            await Task.FromResult(0);
        }


        /// <summary>
        /// Converter o objeto de nota fiscal da prefeitura/cecam em objeto Gov.Br
        /// </summary>
        private async Task ConverterNotaFiscalParaXML()
        {
            if (_notaFiscalFilaEntrada == null)
                return;

            _logger.LogInformation("ConverterNotaFiscalParaXML() convertendo NFe cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} para XML - início", _notaFiscalFilaEntrada.Cd_NotaFiscal);



            // temporario somente para criar um objeto de exemplo para debug.
            var nfRaiz = new NfseXml();

            nfRaiz.Signature = new SignatureXml();

            nfRaiz.InfNFSe = new InfNfseXml()
            {
                Id = "id-teste",
                xLocEmi = "xLocEmi-teste",
                xLocPrestacao = "xLocPrestacao-teste",
                nNFSe = "nNFSe-teste",
                cLocIncid = "cLocIncid-teste",
            };

            nfRaiz.InfNFSe.Dps = new DpsXml();
            
            nfRaiz.InfNFSe.Dps.InfDps = new InfDpsXml();
            nfRaiz.InfNFSe.Dps.InfDps.id = "InfDps-id-teste";

            nfRaiz.InfNFSe.Dps.Signature = new SignatureXml();



            // nameSpaces vazio nó raiz da xml.
            var ns = new XmlSerializerNamespaces(new[] {XmlQualifiedName.Empty } );
            // ns.Add("", "");

            // objeto serializador
            var serializer = new System.Xml.Serialization.XmlSerializer(nfRaiz.GetType());

            using (var writer = new Utf8StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(writer, new XmlWriterSettings()
                {
                    Indent = true, // remover tabulação para economizar espaços
                    NamespaceHandling = NamespaceHandling.Default
                }))

                serializer.Serialize(xmlWriter, nfRaiz, ns);
                string xmlString = writer.ToString();

                // bacalhau
                // para corrigir nameSpace pq o XmlSerializer não esta inserindo no objeto interno qnd tem a mesma URl do objeto Root
                xmlString = xmlString.Replace("http://www.sped.fazenda.gov.br/nfse#", "http://www.sped.fazenda.gov.br/nfse");

                Console.WriteLine(xmlString);
            }




            // atualizar o corpo.
            _notaFiscalFilaEntrada.EnvioCorpo = "corpo XML de teste exemplo";
            
            await Task.FromResult(0);

            _logger.LogInformation("ConverterNotaFiscalParaXML() convertendo NFe cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} para XML - fim com sucesso", _notaFiscalFilaEntrada.Cd_NotaFiscal);
        }


        /// <summary>
        /// O envio da NFSe par gov.br aconteceu com sucesso.
        /// Mover uma nota fiscal da fila de entrada para fila de saída,
        /// Gravar as informações retornadas do gov.br
        /// etc...
        /// </summary>
        public async Task FinalizarComSucessoNoEnvio(string envioMensagem)
        {
            if (_notaFiscalFilaEntrada == null)
                return;

            _logger.LogInformation("MoverFilaEntradaParaSaida() movendo NFe cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} da fila de entrada para fila de saída - início", _notaFiscalFilaEntrada.Cd_NotaFiscal);

            var notaFiscalFilaSaida = new IssNotaFiscalGovBrFilaSaidaEntity()
            {
                Cd_Cecam = _notaFiscalFilaEntrada.Cd_Cecam,
                Cd_NotaFiscal = _notaFiscalFilaEntrada.Cd_NotaFiscal,
                EntradaDataHora = _notaFiscalFilaEntrada.EntradaDataHora,
                EnvioDataHora = DateTime.UtcNow.AddHours(-3),
                EnvioCorpo = _notaFiscalFilaEntrada.EnvioCorpo,
                EnvioMensagem = envioMensagem,
                FilaTipo = _notaFiscalFilaEntrada.FilaTipo
            };

            // salvar fila saída
            _filaSaidaRepository.DbSetEntity.Add(notaFiscalFilaSaida);
            await _filaSaidaRepository.SaveChangesAsync();

            // apagar da fila de entrada
            _filaEntradaRepository.DbSetEntity.Remove(_notaFiscalFilaEntrada);
            await _filaEntradaRepository.SaveChangesAsync();

            _logger.LogInformation("MoverFilaEntradaParaSaida() movendo NFe cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} da fila de entrada para fila de saída - fim com sucesso", _notaFiscalFilaEntrada.Cd_NotaFiscal);
        }


        /// <summary>
        /// Durante o envio da nota fiscal para gov.br aconteceu um erro.
        /// Atualizar a fila de entrada com mensagem de erro
        /// Gravar as informações retornadas do gov.br
        /// etc...
        /// </summary>
        public async Task FinalizarComErroNoEnvio(string envioMensagem)
        {
            if (_notaFiscalFilaEntrada == null)
                return;

            _logger.LogInformation("FilaEntradaComErro() atualizando NFe cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} na fila de entrada - início", _notaFiscalFilaEntrada.Cd_NotaFiscal);

            // atualizar a nota fiscla na fila de entrada
            _notaFiscalFilaEntrada.EnvioDataHora = DateTime.UtcNow.AddHours(-3);
            _notaFiscalFilaEntrada.Status = IssNotaFiscalGovBrEnum.Status_Processado_Erro;
            _notaFiscalFilaEntrada.EnvioMensagem = envioMensagem;

            // atualizar na base
            await _filaEntradaRepository.SaveChangesAsync();

            _logger.LogInformation("FilaEntradaComErro() atualizando NFe cd_NotaFiscal={_notaFiscalFilaEntrada.Cd_NotaFiscal} na fila de entrada - fim com sucesso", _notaFiscalFilaEntrada.Cd_NotaFiscal);
        }


        #region Auxiliares

        /// <summary>
        /// Limpar os objetos globais para processar uma nova NFSe
        /// </summary>
        private void LimparObjetosGlobais()
        {
            _notaFiscalFilaEntrada = null;
            _notaFiscalEntity = null;
        }

        #endregion
    }
}
