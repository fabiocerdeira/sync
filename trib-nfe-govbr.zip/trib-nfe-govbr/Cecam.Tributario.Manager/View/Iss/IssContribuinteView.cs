﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.View.ISS
{
    public class IssContribuinteView
    {
        public decimal Cd_Contribuinte { get; set; }

        public int Cd_Exercicio { get; set; }

        public string? Ds_RazaoSocial { get; set; }

        public string? Nr_CGCCPF { get; set; }
    }
}
