﻿using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    public class DpsXml
    {
        /// <summary>
        /// Versão do leiaute da DPS.
        /// </summary>
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";


        [XmlElement("infDPS")]
        public InfDpsXml? InfDps { get; set; }


        [XmlElement("Signature", Namespace = "http://www.w3.org/2000/09/xmldsig#", IsNullable = false)]
        public SignatureXml? Signature { get; set; }
    }
}
