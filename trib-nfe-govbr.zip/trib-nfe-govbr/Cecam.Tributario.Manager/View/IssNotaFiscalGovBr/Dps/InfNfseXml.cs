﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    public class InfNfseXml
    {
        /// <summary>
        /// Informar o identificador precedido do literal ‘ID’.
        ///  
        /// A formação do identificador de 53 posições da NFS é:
        /// 
        /// "NFS" + 
        /// Cód.Mun. (7) + 
        /// Amb.Ger. (1) + 
        /// Tipo de Inscrição Federal (1) + 
        /// Inscrição Federal (14 - CPF completar com 000 à esquerda) + 
        /// nNFSe (13) +
        /// AnoMes Emis. da DPS (4) + 
        /// Cód.Num. (9) + 
        /// DV (1)
        /// 
        /// Código numérico de 9 Posições numérico, aleatório, gerado automaticamente pelo sistema gerador da NFS-e.
        /// </summary>
        [XmlAttribute("id")]
        public string Id { get; set; } = string.Empty;


        #region Elementos


        /// <summary>
        /// Descrição do código de 7 dígitos da localidade emissora da NFS-e.
        /// Tabela IssParametrosNfSE => cd_IBGE
        /// </summary>
        [XmlElement("xLocEmi")]
        public string xLocEmi { get; set; } = string.Empty;


        /// <summary>
        /// Descrição do código de 7 dígitos referente ao local da prestação do serviço.
        /// Tabela ISSNotaFiscal => campo fl_localPrestacao ==> se for 1 ISSParametrosCalc = cod_IBGE  se for 4??????????
        /// </summary>
        [XmlElement("xLocPrestacao")]
        public string xLocPrestacao { get; set; } = string.Empty;


        /// <summary>
        /// Número da NFS-e (Sequencial pelo emitente e tipo de emitente da NFS-e)
        /// Tabela ISSNotafiscal => nr_notafiscal
        /// </summary>
        [XmlElement("nNFSe")]
        public string nNFSe { get; set; } = string.Empty;


        /// <summary>
        /// Código de 7 dígitos da localidade de incidência do ISSQN.
        /// Tabela CECAMMunicipio => cd_MunicipioIBGE
        /// </summary>
        [XmlElement("cLocIncid")]
        public string cLocIncid { get; set; } = string.Empty;


        /// <summary>
        /// Descrição da localidade de incidência do ISSQN.
        /// Tabela CECAMMunicipio = ds_NomeMunicipio
        /// </summary>
        [XmlElement("xLocIncid")]
        public string xLocIncid { get; set; } = string.Empty;


        /// <summary>
        /// Descrição do código de tributação nacional do ISSQN.
        /// CRIAR TABELA DE SERVIÇOS NACIONAL ?????????????? FMC FMC FMC atenção ?????????
        /// </summary>
        [XmlElement("xTribNac")]
        public string xTribNac { get; set; } = string.Empty;


        /// <summary>
        /// Descrição do código de tributação municipal do ISSQN.
        /// CRIAR TABELA DE SERVIÇOS NACIONAL ?????????????? FMC FMC FMC atenção ?????????
        /// </summary>
        [XmlElement("xTribMun")]
        public string xTribMun { get; set; } = string.Empty;


        /// <summary>
        /// Descrição do código da NBS.
        /// CRIAR TABELA DE SERVIÇOS NACIONAL ?????????????? FMC FMC FMC atenção ?????????
        /// </summary>
        [XmlElement("xNBS")]
        public string xNBS { get; set; } = string.Empty;


        /// <summary>
        /// Versão da aplicação que gerou a NFS-e.
        /// Versão do integrador
        /// </summary>
        [XmlElement("verAplic")]
        public string verAplic { get; set; } = string.Empty;


        /// <summary>
        /// Ambiente gerador da NFS-e:
        /// 1- Sistema Próprio do Município;
        /// 2- Sefin Nacional NFS-e;
        /// Sistema Próprio do Municipio = 1 
        /// </summary>
        [XmlElement("ambGer")]
        public string ambGer { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de emissão da NFS-e:
        /// 1 - Emissão normal no modelo da NFS-e Nacional;
        /// 2 - Emissão original em leiaute próprio do município com transcrição para o modelo da NFS-e Nacional.
        /// Tipo de emissão da NFS-e = 2
        /// </summary>
        [XmlElement("tpEmis")]
        public string tpEmis { get; set; } = string.Empty;


        /// <summary>
        /// Processo de Emissão da DPS:
        /// 1 - Emissão com aplicativo do contribuinte (via Web Service);
        /// 2 - Emissão com aplicativo disponibilizado pelo fisco (Web);
        /// 3 - Emissão com aplicativo disponibilizado pelo fisco (App);
        /// Deixar em branco, não preencher esse campo
        /// </summary>
        [XmlElement("procEmi")]
        public string procEmi { get; set; } = string.Empty;


        /// <summary>
        /// Situações possíveis:
        /// 100 - NFS-e Gerada;
        /// 101 - NFS-e de Substituição Gerada;
        /// 102 - NFS-e de Decisão Judicial;
        /// 103 - NFS-e Avulsa;"
        /// Situação possíveis sempre preencher com 100
        /// </summary>
        [XmlElement("cStat")]
        public string cStat { get; set; } = string.Empty;


        /// <summary>
        /// Data/Hora da validação da DPS e geração da NFS-e.
        /// Data e hora no formato UTC (Universal Coordinated Time):
        /// AAAA-MM-DDThh:mm:ssTZD
        /// Tabela ISSNotaFiscal ==> campo dt_emissao
        /// </summary>
        [XmlElement("dhProc")]
        public string dhProc { get; set; } = string.Empty;


        /// <summary>
        /// Número sequencial do documento gerado por ambiente gerador de DFe do múnicípio.	
        /// Tabela ISSNotaFiscal ==> campo ==> cd_notafiscal 
        /// </summary>
        [XmlElement("nDFe")]
        public string nDFe { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações da DPS relativas ao emitente da NFS-e
        /// </summary>
        [XmlElement("emit")]
        public EmitenteXml? Emit { get; set; }


        /// <summary>
        /// Grupo de valores referentes ao serviço prestado
        /// </summary>
        [XmlElement("valores")]
        public InfNfseValoresXml? Valores { get; set; }







        /* falta revisar daqui p baixo */

        [XmlElement("DPS", Namespace = "http://www.sped.fazenda.gov.br/nfse#", IsNullable = false)]
        public DpsXml? Dps { get; set; }

    }
}
