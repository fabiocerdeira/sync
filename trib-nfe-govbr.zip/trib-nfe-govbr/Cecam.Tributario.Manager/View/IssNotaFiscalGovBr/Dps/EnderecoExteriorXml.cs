﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    /// <summary>
    /// Grupo de informações do endereço no exterior.
    /// </summary>
    public class EnderecoExteriorXml
    {
        /// <summary>
        /// Código do país do endereço do prestador/tomador/intermediário do serviço.
        /// (Tabela de Países ISO)
        /// </summary>
        [XmlElement("cPais")]
        public string cPais { get; set; } = string.Empty;


        /// <summary>
        /// Código alfanumérico do Endereçamento Postal no exterior do prestador/tomador/intermediário do serviço.
        /// </summary>
        [XmlElement("cEndPost")]
        public string cEndPost { get; set; } = string.Empty;


        /// <summary>
        /// Nome da cidade no exterior do prestador/tomador/intermediário do serviço.
        /// </summary>
        [XmlElement("xCidade")]
        public string xCidade { get; set; } = string.Empty;


        /// <summary>
        /// Estado, província ou região da cidade no exterior do prestador/tomador/intermediário do serviço.
        /// </summary>
        [XmlElement("xEstProvReg")]
        public string xEstProvReg { get; set; } = string.Empty;
    }
}
