﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    /// <summary>
    /// Grupo de informações do endereço nacional reduzido do prestador/tomador/intermediário da NFS-e
    /// </summary>
    public class EnderecoNacionalReduzidoXml
    {
        /// <summary>
        /// Código do município do endereço do prestador/tomador/intermediário.
        /// (Tabela do IBGE)
        /// </summary>
        [XmlElement("cMun")]
        public string cMun { get; set; } = string.Empty;


        /// <summary>
        /// Número do CEP do endereço do prestador/tomador/intermediário.
        /// (Informar os zeros não significativos)
        /// </summary>
        [XmlElement("CEP")]
        public string CEP { get; set; } = string.Empty;
    }
}
