﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento
{
    /// <summary>
    /// Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
    /// </summary>
    public class InfDpsValoresDeducaoReducaoDocumentoDedRedXml
    {
        #region Elementos


        /// <summary>
        /// Chave de acesso da NFS-e (padrão nacional).
        /// </summary>
        [XmlElement("chNFSe")]
        public string chNFSe { get; set; } = string.Empty;


        /// <summary>
        /// Chave de acesso da NF-e.
        /// </summary>
        [XmlElement("chNFe")]
        public string chNFe { get; set; } = string.Empty;


        /// <summary>
        /// Identificador de documento fiscal diferente dos demais do grupo.
        /// </summary>
        [XmlElement("nDocFisc")]
        public string nDocFisc { get; set; } = string.Empty;


        /// <summary>
        /// Identificador de documento não fiscal diferente dos demais do grupo.
        /// </summary>
        [XmlElement("nDoc")]
        public string nDoc { get; set; } = string.Empty;


        /// <summary>
        /// Tipo da Dedução/Redução:
        /// 01 – Alimentação e bebidas/frigobar; 
        /// 02 – Materiais;
        /// 03 – Produção externa;
        /// 04 – Reembolso de despesas;
        /// 05 – Repasse consorciado;
        /// 06 – Repasse plano de saúde;
        /// 07 – Serviços;
        /// 08 – Subempreitada de mão de obra;
        /// 99 – Outras deduções;
        /// </summary>
        [XmlElement("tpDedRed")]
        public string tpDedRed { get; set; } = string.Empty;


        /// <summary>
        /// Descrição da Dedução/Redução quando a opção é "99 – Outras Deduções".
        /// </summary>
        [XmlElement("xDescOutDed")]
        public string xDescOutDed { get; set; } = string.Empty;


        /// <summary>
        /// Data da emissão do documento dedutível.
        /// Ano, mês e dia (AAAA-MM-DD)
        /// </summary>
        [XmlElement("dtEmiDoc")]
        public string dtEmiDoc { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário total dedutível/redutível no documento informado (R$).
        /// Este é o valor total no documento informado que é passível de dedução/redução.
        /// </summary>
        [XmlElement("vDedutivelRedutivel")]
        public string vDedutivelRedutivel { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário utilizado para dedução/redução do valor do serviço da NFS-e que está sendo emitida (R$). 
        /// Deve ser menor ou igual ao valor deduzível/redutível (vDedutivelRedutivel).
        /// </summary>
        [XmlElement("vDeducaoReducao")]
        public string vDeducaoReducao { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do fornecedor do serviço prestado
        /// </summary>
        [XmlElement("fornec")]
        public InfDpsValoresDeducaoReducaoDocumentoDedRedFornecedorXml? fornec{ get; set; }
    }
}
