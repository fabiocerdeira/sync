﻿using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Federal;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Municipal;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Total;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo
{
    /// <summary>
    /// Grupo de informações relacionados aos tributos relacionados ao serviço prestado
    /// </summary>
    public class InfDpsValoresTributoXml
    {
        /// <summary>
        /// Grupo de informações relacionados ao Imposto Sobre Serviços de Qualquer Natureza - ISSQN
        /// </summary>
        [XmlElement("tribMun")]
        public InfDpsValoresTributoMunicipalXml? tribMun { get; set; }



        /// <summary>
        /// Grupo de informações de outros tributos relacionados ao serviço prestado
        /// </summary>
        [XmlElement("tribFed")]
        public InfDpsValoresTributoFederalXml? tribFed { get; set; }



        /// <summary>
        /// Grupo de informações para totais aproximados dos tributos relacionados ao serviço prestado
        /// </summary>
        [XmlElement("totTrib")]
        public InfDpsValoresTributoTotalXml? totTrib { get; set; }
    }
}
