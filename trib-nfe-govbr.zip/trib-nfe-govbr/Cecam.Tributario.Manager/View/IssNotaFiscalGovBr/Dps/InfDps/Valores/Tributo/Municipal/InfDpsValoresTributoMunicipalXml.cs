﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Municipal
{
    /// <summary>
    /// Grupo de informações relacionados ao Imposto Sobre Serviços de Qualquer Natureza - ISSQN
    /// </summary>
    public class InfDpsValoresTributoMunicipalXml
    {
        #region Elementos


        /// <summary>
        /// Tributação do ISSQN sobre o serviço prestado:
        ///
        ///1 - Operação tributável;
        ///2 - Imunidade
        ///3 - Exportação de serviço;
        ///4 - Não Incidência;
        /// </summary>
        [XmlElement("tribISSQN")]
        public string tribISSQN { get; set; } = string.Empty;


        /// <summary>
        /// Código do país onde se verficou o resultado da prestação do serviço para o caso de 
        ///Exportação de Serviço.
        ///(Tabela de Países ISO)
        /// </summary>
        [XmlElement("cPaisResult")]
        public string cPaisResult { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações sobre o tipo do Benefício Municipal
        /// </summary>
        [XmlElement("BM")]
        public InfDpsValoresTributoMunicipalBeneficioMunicipalXml? BM { get; set; }


        /// <summary>
        /// Informações para a suspensão da Exigibilidade do ISSQN
        /// </summary>
        [XmlElement("exigSusp")]
        public InfDpsValoresTributoMunicipalExigibilidadeSuspXml? exigSusp { get; set; }
    }
}
