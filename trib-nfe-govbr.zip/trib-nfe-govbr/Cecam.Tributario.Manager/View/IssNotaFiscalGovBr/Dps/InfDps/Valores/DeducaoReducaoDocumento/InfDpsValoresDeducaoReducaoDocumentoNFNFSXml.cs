﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento
{
    /// <summary>
    /// Grupo de informações de NF ou NFS
    ///(Modelo não eletrônico)
    /// </summary>
    public class InfDpsValoresDeducaoReducaoDocumentoNFNFSXml
    {
        /// <summary>
        /// Número da Nota Fiscal NF ou NFS.
        /// </summary>
        [XmlElement("nNFS")]
        public string nNFS { get; set; } = string.Empty;


        /// <summary>
        /// Modelo da Nota Fiscal NF ou NFS.
        /// </summary>
        [XmlElement("modNFS")]
        public string modNFS { get; set; } = string.Empty;


        /// <summary>
        /// Série Nota Fiscal NF ou NFS.
        /// </summary>
        [XmlElement("serieNFS")]
        public string serieNFS { get; set; } = string.Empty;
    }
}
