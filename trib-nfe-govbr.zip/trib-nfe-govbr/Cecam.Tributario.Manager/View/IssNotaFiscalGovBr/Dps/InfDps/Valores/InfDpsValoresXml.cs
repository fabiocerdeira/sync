﻿using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores
{
    /// <summary>
    /// Grupo de informações relativas à valores do serviço prestado
    /// </summary>
    public class InfDpsValoresXml
    {
        /// <summary>
        /// Grupo de informações relativas aos valores do serviço prestado
        /// </summary>
        [XmlElement("vServPrest")]
        public InfDpsValoresServicoPrestadoXml? vServPrest { get; set; }


        /// <summary>
        /// Grupo de informações relativas aos descontos condicionados e incondicionados
        /// </summary>
        [XmlElement("vDescCondIncond")]
        public InfDpsValoresDescontoCondIncondXml? vDescCondIncond { get; set; }


        /// <summary>
        /// Grupo de informações relativas ao valores para dedução/redução do valor da base de cálculo (valor do serviço)
        /// </summary>
        [XmlElement("vDedRed")]
        public InfDpsValoresDeducaoReducaoXml? vDedRed { get; set; }


        /// <summary>
        /// Grupo de informações relacionados aos tributos relacionados ao serviço prestado
        /// </summary>
        [XmlElement("trib")]
        public InfDpsValoresTributoXml? trib { get; set; }

    }
}

