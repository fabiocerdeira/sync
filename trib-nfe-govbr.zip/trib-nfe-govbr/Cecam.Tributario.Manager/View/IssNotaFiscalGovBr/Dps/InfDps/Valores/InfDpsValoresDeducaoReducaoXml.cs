﻿using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores
{
    /// <summary>
    /// Grupo de informações relativas ao valores para dedução/redução do valor da base de cálculo (valor do serviço)
    /// </summary>
    public class InfDpsValoresDeducaoReducaoXml
    {
        #region Elementos


        /// <summary>
        /// Valor percentual padrão para dedução/redução do valor do serviço.
        /// </summary>
        [XmlElement("pDR")]
        public string pDR { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário padrão para dedução/redução do valor do serviço.
        /// </summary>
        [XmlElement("vDR")]
        public string vDR { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
        /// </summary>
        [XmlElement("documentos")]
        public InfDpsValoresDeducaoReducaoDocumentoXml? documentos { get; set; }
    }
}
