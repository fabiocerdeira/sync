﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Federal
{
    /// <summary>
    /// Grupo de informações de outros tributos relacionados ao serviço prestado
    /// </summary>
    public class InfDpsValoresTributoFederalXml
    {
        #region Elementos


        /// <summary>
        /// Valor monetário do CP(R$).
        /// </summary>
        [XmlElement("vRetCP")]
        public string vRetCP { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário do IRRF (R$).
        /// </summary>
        [XmlElement("vRetIRRF")]
        public string vRetIRRF { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário do CSLL (R$).
        /// </summary>
        [XmlElement("vRetCSLL")]
        public string vRetCSLL { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações dos tributos PIS/COFINS
        /// </summary>
        [XmlElement("piscofins")]
        public InfDpsValoresTributoFederalPisCofinsXml? poscofins { get; set; }

    }
}
