﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Municipal
{
    /// <summary>
    /// Informações para a suspensão da Exigibilidade do ISSQN
    /// </summary>
    public class InfDpsValoresTributoMunicipalExigibilidadeSuspXml
    {
        #region Elementos


        /// <summary>
        /// Opção para Exigibilidade Suspensa:
        /// 1 - Exigibilidade do ISSQN Suspensa por Decisão Judicial;
        /// 2 - Exigibilidade do ISSQN Suspensa por Processo Administrativo;
        /// </summary>
        [XmlElement("tpSusp")]
        public string tpSusp { get; set; } = string.Empty;


        /// <summary>
        /// Número do processo judicial ou administrativo de suspensão da exigibilidade.
        /// </summary>
        [XmlElement("nProcesso")]
        public string nProcesso { get; set; } = string.Empty;


        /// <summary>
        /// Identificação da Imunidade do ISSQN – somente para o caso de Imunidade.
        /// Tipos de Imunidades:
        /// 0 - Imunidade (tipo não informado na nota de origem);
        /// 1 - Patrimônio, renda ou serviços, uns dos outros (CF88, Art 150, VI, a);
        /// 2 - Templos de qualquer culto (CF88, Art 150, VI, b);
        /// 3 - Patrimônio, renda ou serviços dos partidos políticos, inclusive suas fundações, das entidades sindicais dos trabalhadores, das instituições de educação e de assistência social, sem fins lucrativos, atendidos os requisitos da lei (CF88, Art 150, VI, c);
        /// 4 - Livros, jornais, periódicos e o papel destinado a sua impressão (CF88, Art 150, VI, d);
        /// 5 - Fonogramas e videofonogramas musicais produzidos no Brasil contendo obras musicais ou literomusicais de autores brasileiros e/ou obras em geral interpretadas por artistas brasileiros bem como os suportes materiais ou arquivos digitais que os contenham, salvo na etapa de replicação industrial de mídias ópticas de leitura a laser.   (CF88, Art 150, VI, e);
        /// </summary>
        [XmlElement("tpImunidade")]
        public string tpImunidade { get; set; } = string.Empty;


        /// <summary>
        /// Valor da alíquota (%) do serviço prestado relativo ao município sujeito ativo (município de incidência) do ISSQN.
        /// </summary>
        [XmlElement("pAliq")]
        public string pAliq { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de retencao do ISSQN:
        /// 1 - Não Retido;
        /// 2 - Retido pelo Tomador;
        /// 3 - Retido pelo Intermediario;
        /// </summary>
        [XmlElement("tpRetISSQN")]
        public string tpRetISSQN { get; set; } = string.Empty;


        #endregion
    }
}
