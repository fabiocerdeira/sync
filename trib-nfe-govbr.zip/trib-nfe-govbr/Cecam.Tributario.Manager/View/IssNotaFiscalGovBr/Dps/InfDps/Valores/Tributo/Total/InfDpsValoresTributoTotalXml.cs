﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Total
{
    /// <summary>
    /// Grupo de informações para totais aproximados dos tributos relacionados ao serviço prestado
    /// </summary>
    public class InfDpsValoresTributoTotalXml
    {
        #region Elementos


        /// <summary>
        /// Indicador de informação de valor total de tributos. 
        /// Se informado indica que o emitente opta por não informar nenhum valor estimado para os Tributos 
        /// (Decreto 8.264/2014).
        /// 0 - Não;
        /// </summary>
        [XmlElement("indTotTrib")]
        public string indTotTrib { get; set; } = string.Empty;


        /// <summary>
        /// Valor percentual aproximado do total dos tributos da alíquota do Simples Nacional (%).
        /// </summary>
        [XmlElement("pTotTribSN")]
        public string pTotTribSN { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Valor monetário total aproximado dos tributos, em conformidade com o artigo 1o da Lei no 12.741/2012
        /// </summary>
        [XmlElement("vTotTrib")]
        public InfDpsValoresTributoTotalValorXml? vTotTrib { get; set; }



        /// <summary>
        /// Valor percentual total aproximado dos tributos, em conformidade com o artigo 1o da Lei no 12.741/2012
        /// </summary>
        [XmlElement("pTotTrib")]
        public InfDpsValoresTributoTotalPercentualXml? pTotTrib { get; set; }
    }
}
