﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Federal
{
    /// <summary>
    /// Grupo de informações dos tributos PIS/COFINS
    /// </summary>
    public class InfDpsValoresTributoFederalPisCofinsXml
    {
        #region Elementos


        /// <summary>
        /// Código de Situação Tributária do PIS/COFINS (CST):
        /// 00 - Nenhum;      
        /// 01 - Operação Tributável com Alíquota Básica;
        /// 02 - Operação Tributável com Alíquota Diferenciada;
        /// 03 - Operação Tributável com Alíquota por Unidade de Medida de Produto;
        /// 04 - Operação Tributável monofásica - Revenda a Alíquota Zero;
        /// 05 - Operação Tributável por Substituição Tributária;
        /// 06 - Operação Tributável a Alíquota Zero;
        /// 07 - Operação Tributável da Contribuição;
        /// 08 - Operação sem Incidência da Contribuição;
        /// 09 - Operação com Suspensão da Contribuição;
        /// </summary>
        [XmlElement("CST")]
        public string CST { get; set; } = string.Empty;


        /// <summary>
        /// Valor da Base de Cálculo do PIS/COFINS (R$).
        /// </summary>
        [XmlElement("vBCPisCofins")]
        public string vBCPisCofins { get; set; } = string.Empty;


        /// <summary>
        /// Valor da Alíquota do PIS (%).
        /// </summary>
        [XmlElement("pAliqPis")]
        public string pAliqPis { get; set; } = string.Empty;


        /// <summary>
        /// Valor da Alíquota da COFINS (%).
        /// </summary>
        [XmlElement("pAliqCofins")]
        public string pAliqCofins { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário do PIS (R$).
        /// </summary>
        [XmlElement("vPis")]
        public string vPis { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário do COFINS (R$).
        /// </summary>
        [XmlElement("vCofins")]
        public string vCofins { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de retencao do Pis/Cofins:
        /// 1 - Retido;
        /// 2 - Não Retido;
        /// </summary>
        [XmlElement("tpRetPisCofins")]
        public string tpRetPisCofins { get; set; } = string.Empty;


        #endregion
    }
}
