﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento
{
    /// <summary>
    /// Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
    /// </summary>
    public class InfDpsValoresDeducaoReducaoDocumentoXml
    {
        #region Elementos



        #endregion


        /// <summary>
        /// Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
        /// </summary>
        [XmlElement("docDedRed")]
        public InfDpsValoresDeducaoReducaoDocumentoDedRedXml? docDedRed { get; set; }


        /// <summary>
        /// "Grupo de informações para outras notas eletrônicas municipais
        /// (Nota eletrônica municipal emitida fora do padrão nacional)"
        /// </summary>
        [XmlElement("NFSeMun")]
        public InfDpsValoresDeducaoReducaoDocumentoNFSeMunXml? NFSeMun { get; set; }


        /// <summary>
        /// "Grupo de informações de NF ou NFS
        /// (Modelo não eletrônico)
        /// </summary>
        [XmlElement("NFNFS")]
        public InfDpsValoresDeducaoReducaoDocumentoNFNFSXml? NFNFS { get; set; }
    }
}
