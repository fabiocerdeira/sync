﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores
{
    /// <summary>
    /// Grupo de informações relativas aos valores do serviço prestado
    /// </summary>
    public class InfDpsValoresServicoPrestadoXml
    {
        /// <summary>
        /// Valor monetário recebido pelo intermediário do serviço (R$).
        /// </summary>
        [XmlElement("vReceb")]
        public string vReceb { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário do serviço (R$).
        /// </summary>
        [XmlElement("vServ")]
        public string vServ { get; set; } = string.Empty;
    }
}
