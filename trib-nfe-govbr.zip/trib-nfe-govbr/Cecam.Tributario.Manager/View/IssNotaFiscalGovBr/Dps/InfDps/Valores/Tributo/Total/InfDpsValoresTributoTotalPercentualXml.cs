﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Total
{
    /// <summary>
    /// Valor percentual total aproximado dos tributos, em conformidade com o artigo 1o da Lei no 12.741/2012
    /// </summary>
    public class InfDpsValoresTributoTotalPercentualXml
    {
        /// <summary>
        /// Valor percentual total aproximado dos tributos federais (%).
        /// </summary>
        [XmlElement("pTotTribFed")]
        public string pTotTribFed { get; set; } = string.Empty;


        /// <summary>
        /// Valor percentual total aproximado dos tributos estaduais (%).
        /// </summary>
        [XmlElement("pTotTribEst")]
        public string pTotTribEst { get; set; } = string.Empty;


        /// <summary>
        /// Valor percentual total aproximado dos tributos municipais (%).
        /// </summary>
        [XmlElement("pTotTribMun")]
        public string pTotTribMun { get; set; } = string.Empty;
    }
}
