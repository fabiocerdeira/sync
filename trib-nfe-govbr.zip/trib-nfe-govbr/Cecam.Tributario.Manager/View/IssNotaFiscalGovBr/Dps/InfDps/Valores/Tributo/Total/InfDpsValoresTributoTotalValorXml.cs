﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.Tributo.Total
{
    /// <summary>
    /// Valor monetário total aproximado dos tributos, em conformidade com o artigo 1o da Lei no 12.741/2012
    /// </summary>
    public class InfDpsValoresTributoTotalValorXml
    {
        /// <summary>
        /// Valor monetário total aproximado dos tributos federais (R$).
        /// </summary>
        [XmlElement("vTotTribFed")]
        public string vTotTribFed { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário total aproximado dos tributos estaduais (R$).
        /// </summary>
        [XmlElement("vTotTribEst")]
        public string vTotTribEst { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário total aproximado dos tributos municipais (R$).
        /// </summary>
        [XmlElement("vTotTribMun")]
        public string vTotTribMun { get; set; } = string.Empty;
    }
}
