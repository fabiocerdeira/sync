﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento
{
    /// <summary>
    /// Grupo de informações para outras notas eletrônicas municipais
    ///(Nota eletrônica municipal emitida fora do padrão nacional)
    /// </summary>
    public class InfDpsValoresDeducaoReducaoDocumentoNFSeMunXml
    {
        /// <summary>
        /// Código Município emissor da nota eletrônica municipal.
        ///(Tabela do IBGE)
        /// </summary>
        [XmlElement("cMunNFSeMun")]
        public string cMunNFSeMun { get; set; } = string.Empty;


        /// <summary>
        /// Número da nota eletrônica municipal.
        /// </summary>
        [XmlElement("nNFSeMun")]
        public string nNFSeMun { get; set; } = string.Empty;


        /// <summary>
        /// Código de Verificação da nota eletrônica municipal.
        /// </summary>
        [XmlElement("cVerifNFSeMun")]
        public string cVerifNFSeMun { get; set; } = string.Empty;
    }
}
