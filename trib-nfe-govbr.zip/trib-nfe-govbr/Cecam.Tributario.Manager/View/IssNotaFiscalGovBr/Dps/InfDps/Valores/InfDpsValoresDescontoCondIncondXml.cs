﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores
{
    /// <summary>
    /// Grupo de informações relativas aos descontos condicionados e incondicionados
    /// </summary>
    public class InfDpsValoresDescontoCondIncondXml
    {
        /// <summary>
        /// Valor monetário do desconto incondicionado (R$).
        /// </summary>
        [XmlElement("vDescIncond")]
        public string vDescIncond { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário do desconto condicionado (R$).
        /// </summary>
        [XmlElement("vDescCond")]
        public string vDescCond { get; set; } = string.Empty;
    }
}
