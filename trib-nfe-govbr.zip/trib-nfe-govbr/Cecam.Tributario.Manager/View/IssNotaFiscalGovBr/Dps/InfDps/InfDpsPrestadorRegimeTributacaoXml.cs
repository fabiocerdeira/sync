﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps
{
    /// <summary>
    /// Grupo de informações relativas aos regimes de tributação do prestador de serviços
    /// </summary>
    public class InfDpsPrestadorRegimeTributacaoXml
    {
        /// <summary>
        /// Situação perante Simples Nacional:
        /// 1 - Não Optante;
        /// 2 - Optante - Microempreendedor Individual (MEI);
        /// 3 - Optante - Microempresa ou Empresa de Pequeno Porte (ME/EPP);
        /// </summary>
        [XmlElement("opSimpNac")]
        public string opSimpNac { get; set; } = string.Empty;


        /// <summary>
        /// Regime de Apuração Tributária pelo Simples Nacional.
        /// Opção para que o contribuinte optante pelo Simples Nacional ME/EPP (opSimpNac = 3) possa indicar, ao emitir o documento fiscal, em qual regime de apuração os tributos federais e municipal estão inseridos, caso tenha ultrapassado algum sublimite ou limite definido para o Simples Nacional.
        /// 1 – Regime de apuração dos tributos federais e municipal pelo SN;
        /// 2 – Regime de apuração dos tributos federais pelo SN e o ISSQN pela NFS-e conforme respectiva legislação municipal do tributo;
        /// 3 – Regime de apuração dos tributos federais e municipal pela NFS-e conforme respectivas legilações federal e municipal de cada tributo;
        /// </summary>
        [XmlElement("regApTribSN")]
        public string regApTribSN { get; set; } = string.Empty;


        /// <summary>
        /// Tipos de Regimes Especiais de Tributação Municipal:
        /// 0 - Nenhum;
        /// 1 - Ato Cooperado (Cooperativa);
        /// 2 - Estimativa;
        /// 3 - Microempresa Municipal;
        /// 4 - Notário ou Registrador;
        /// 5 - Profissional Autônomo;
        /// 6 - Sociedade de Profissionais;
        /// </summary>
        [XmlElement("regEspTrib")]
        public string regEspTrib { get; set; } = string.Empty;
    }
}
