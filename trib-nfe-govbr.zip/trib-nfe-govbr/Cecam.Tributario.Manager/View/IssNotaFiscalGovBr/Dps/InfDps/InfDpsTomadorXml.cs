﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps
{
    /// <summary>
    /// Grupo de informações relativas ao tomador do serviço
    /// </summary>
    public class InfDpsTomadorXml
    {
        #region Elementos


        /// <summary>
        /// Número da inscrição federal (CNPJ) do tomador de serviço.
        /// </summary>
        [XmlElement("CNPJ")]
        public string CNPJ { get; set; } = string.Empty;


        /// <summary>
        /// Número da inscrição federal (CPF) do tomador do serviço.
        /// </summary>
        [XmlElement("CPF")]
        public string CPF { get; set; } = string.Empty;


        /// <summary>
        /// Número de identificação fiscal fornecido por órgão de administração tributária no exterior.
        /// </summary>
        [XmlElement("NIF")]
        public string NIF { get; set; } = string.Empty;


        /// <summary>
        /// Motivo para não informação do NIF:
        ///
        ///0 - Não informado na nota de origem;
        ///1 - Dispensado do NIF;
        ///2 - Não exigência do NIF;
        /// </summary>
        [XmlElement("cNaoNIF")]
        public string cNaoNIF { get; set; } = string.Empty;


        /// <summary>
        /// Número do Cadastro de Atividade Econômica da Pessoa Física (CAEPF) do tomador do serviço.
        /// </summary>
        [XmlElement("CAEPF")]
        public string CAEPF { get; set; } = string.Empty;


        /// <summary>
        /// Número de inscrição municipal do tomador do serviço.
        /// </summary>
        [XmlElement("IM")]
        public string IM { get; set; } = string.Empty;


        /// <summary>
        /// Nome / Razão Social do tomador.
        /// </summary>
        [XmlElement("xNome")]
        public string xNome { get; set; } = string.Empty;

        
        /// <summary>
        /// Número do telefone do tomador.
        /// (Preencher com o Código DDD + número do telefone. 
        /// Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)
        /// </summary>
        [XmlElement("fone")]
        public string fone { get; set; } = string.Empty;


        /// <summary>
        /// E-mail do tomador.
        /// </summary>
        [XmlElement("email")]
        public string email { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço do tomador do serviço.
        /// </summary>
        [XmlElement("end")]
        public InfDpsTomadorEnderecoXml? end { get; set; }



    }
}
