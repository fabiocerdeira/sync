﻿using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico;
using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps
{
    public class InfDpsXml
    {
        #region Elementos


        /// <summary>
        /// O identificador da DPS é composto pela concatenação de campos que constam no leiaute da DPS.
        ///A formação deste identificador considera o literal "DPS" associado a outras 42 posições numéricas, conforme descrito abaixo:
        ///
        ///"DPS" + 
        ///Cód.Mun. (7) + 
        ///Tipo de Inscrição Federal (1) + 
        ///Inscrição Federal (14 - CPF completar com 000 à esquerda) + 
        ///Série DPS (5) + 
        ///Núm. DPS (15)
        /// </summary>
        [XmlAttribute("id")]
        public string id { get; set; } = string.Empty;


        /// <summary>
        /// Versão do leiaute da DPS.
        /// </summary>
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";


        /// <summary>
        /// Identificação do tipo de ambiente no Sistema Nacional NFS-e: 
        ///1 - Produção; 
        ///2 - Homologação;
        /// </summary>
        [XmlElement("tpAmb")]
        public string tpAmb { get; set; } = string.Empty;


        /// <summary>
        /// Data e hora da emissão da DPS.
        ///Data e hora no formato UTC (Universal Coordinated Time):
        ///AAAA-MM-DDThh:mm:ssTZD
        /// </summary>
        [XmlElement("dhEmi")]
        public string dhEmi { get; set; } = string.Empty;


        /// <summary>
        /// Versão do aplicativo que gerou a DPS.
        /// </summary>
        [XmlElement("verAplic")]
        public string verAplic { get; set; } = string.Empty;


        /// <summary>
        /// Série da DPS.
        /// </summary>
        [XmlElement("serie")]
        public string serie { get; set; } = string.Empty;


        /// <summary>
        /// Número da DPS.
        /// </summary>
        [XmlElement("nDPS")]
        public string nDPS { get; set; } = string.Empty;


        /// <summary>
        /// Data de competência da prestação do serviço.
        ///Ano, Mês e Dia (AAAA-MM-DD)
        /// </summary>
        [XmlElement("dCompet")]
        public string dCompet { get; set; } = string.Empty;


        /// <summary>
        /// Emitente da DPS:
        ///
        ///1 - Prestador;
        ///2 - Tomador;
        ///3 - Intermediário;
        /// </summary>
        [XmlElement("tpEmit")]
        public string tpEmit { get; set; } = string.Empty;


        /// <summary>
        /// Código de 7 dígitos da localidade emissora da NFS-e.
        /// </summary>
        [XmlElement("cLocEmi")]
        public string cLocEmi { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações relativas à NFS-e a ser substituída
        /// </summary>
        [XmlElement("subst")]
        public InfDpsSubstituicaoXml? subst { get; set; }


        /// <summary>
        /// Grupo de informações relativas ao prestador do serviço
        /// </summary>
        [XmlElement("prest")]
        public InfDpsPrestadorXml? prest { get; set; }


        /// <summary>
        /// Grupo de informações relativas ao tomador do serviço
        /// </summary>
        [XmlElement("toma")]
        public InfDpsTomadorXml? toma { get; set; }


        /// <summary>
        /// Grupo de informações relativas ao intermediário do serviço
        /// </summary>
        [XmlElement("interm")]
        public InfDpsIntermediarioXml? interm { get; set; }


        /// <summary>
        /// Grupo de informações relativas ao serviço prestado
        /// </summary>
        [XmlElement("serv")]
        public InfDpsServicoXml? serv { get; set; }


        /// <summary>
        ///Grupo de informações relativas à valores do serviço prestado
        /// </summary>
        [XmlElement("valores")]
        public InfDpsValoresXml? valores { get; set; }
    }
}
