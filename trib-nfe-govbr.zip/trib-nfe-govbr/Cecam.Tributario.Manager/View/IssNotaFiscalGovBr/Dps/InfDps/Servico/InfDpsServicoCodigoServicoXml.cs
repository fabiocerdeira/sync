﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas ao código do serviço prestado
    /// </summary>
    public class InfDpsServicoCodigoServicoXml
    {
        /// <summary>
        /// Código de tributação nacional do ISSQN.
        /// </summary>
        [XmlElement("cTribNac")]
        public string cTribNac { get; set; } = string.Empty;


        /// <summary>
        /// Código de tributação municipal do ISSQN.
        /// </summary>
        [XmlElement("cTribMun")]
        public string cTribMun { get; set; } = string.Empty;


        /// <summary>
        /// Descrição completa do serviço prestado
        /// </summary>
        [XmlElement("xDescServ")]
        public string xDescServ { get; set; } = string.Empty;


        /// <summary>
        /// Código NBS correspondente ao serviço prestado
        /// </summary>
        [XmlElement("cNBS")]
        public string cNBS { get; set; } = string.Empty;


        /// <summary>
        /// Código interno do contribuinte
        /// </summary>
        [XmlElement("cIntContrib")]
        public string cIntContrib { get; set; } = string.Empty;
    }
}
