﻿using Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Valores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas ao serviço prestado
    /// </summary>
    public class InfDpsServicoXml
    {
        /// <summary>
        /// Grupo de informações relativas ao local da prestação do serviço
        /// </summary>
        [XmlElement("locPrest")]
        public InfDpsServicoLocalPrestacaoXml? locPrest { get; set; }


        /// <summary>
        /// Grupo de informações relativas ao código do serviço prestado
        /// </summary>
        [XmlElement("cServ")]
        public InfDpsServicoCodigoServicoXml? cServ { get; set; }


        /// <summary>
        /// Grupo de informações relativas à exportação/importação do serviço prestado
        /// </summary>
        [XmlElement("comExt")]
        public InfDpsServicoComercioExteriorXml? comExt { get; set; }


        /// <summary>
        /// Grupo de informações relativas a atividades de Locação, sublocação, arrendamento, direito de passagem ou permissão de uso, compartilhado ou não, de ferrovia, rodovia, postes, cabos, dutos e condutos de qualquer natureza.
        /// </summary>
        [XmlElement("lsadppu")]
        public InfDpsServicoLsadppuXml? lsadppu { get; set; }


        /// <summary>
        /// Grupo de informações relativas à obras de construção civil e congêneres
        /// </summary>
        [XmlElement("obra")]
        public InfDpsServicoObraXml? obra { get; set; }


        /// <summary>
        /// Grupo de informações relativas à atividades de eventos
        /// </summary>
        [XmlElement("atvEvento")]
        public InfDpsServicoAtividadeEventoXml? atvEvento { get; set; }


        /// <summary>
        /// Grupo de informações relativas a atividades de Exploração de Rodovia
        /// </summary>
        [XmlElement("explRod")]
        public InfDpsServicoExploracaoRodoviaXml? explRod { get; set; }


        /// <summary>
        /// Grupo de informações complementares disponível para todos os serviços prestados
        /// </summary>
        [XmlElement("infoCompl")]
        public InfDpsServicoInformacaoComplementarXml? infoCompl { get; set; }
    }
}
