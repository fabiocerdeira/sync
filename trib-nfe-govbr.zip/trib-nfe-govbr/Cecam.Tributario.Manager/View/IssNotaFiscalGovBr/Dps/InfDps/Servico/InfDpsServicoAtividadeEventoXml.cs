﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas à atividades de eventos
    /// </summary>
    public class InfDpsServicoAtividadeEventoXml
    {
        #region Elementos


        /// <summary>
        /// Nome do evento Artístico, Cultural, Esportivo, ...
        /// </summary>
        [XmlElement("xNome")]
        public string xNome { get; set; } = string.Empty;


        /// <summary>
        /// Data de início da atividade de evento.
        ///Ano, Mês e Dia (AAAA-MM-DD)
        /// </summary>
        [XmlElement("dtIni")]
        public string dtIni { get; set; } = string.Empty;


        /// <summary>
        /// Data de fim da atividade de evento.
        ///Ano, Mês e Dia (AAAA-MM-DD)
        /// </summary>
        [XmlElement("dtFim")]
        public string dtFim { get; set; } = string.Empty;


        /// <summary>
        /// Identificação da Atividade de Evento 
        ///(código identificador de evento determinado pela Administração Tributária Municipal)
        /// </summary>
        [XmlElement("idAtvEv")]
        public string idAtvEv { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço da atividade de evento.
        /// </summary>
        [XmlElement("end")]
        public InfDpsServicoAtividadeEventoEnderecoXml? end { get; set; }
    }
}
