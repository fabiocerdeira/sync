﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas a atividades de Exploração de Rodovia
    /// </summary>
    public class InfDpsServicoExploracaoRodoviaXml
    {
        /// <summary>
        /// Categorias de veículos para cobrança:
        ///
        ///00 - Categoria de Veículos (tipo não informado na nota de origem);
        ///01 - Automóvel, caminhonete e furgão;
        ///02 - Caminhão leve, ônibus, caminhão trator e furgão;
        ///03 - Automóvel e caminhonete com semireboque;
        ///04 - Caminhão, caminhão-trator, caminhão-trator com semi-reboque e ônibus;
        ///05 - Automóvel e caminhonete com reboque;
        ///06 - Caminhão com reboque e caminhãotrator com semi-reboque;
        ///07 - Caminhão com reboque e caminhãotrator com semi-reboque;
        ///08 - Caminhão com reboque e caminhãotrator com semi-reboque;
        ///09 - Motocicletas, motonetas e bicicletas motorizadas;
        ///10 - Veículo especial;
        ///11 - Veículo Isento;
        /// </summary>
        [XmlElement("categVeic")]
        public string categVeic { get; set; } = string.Empty;


        /// <summary>
        /// Número de eixos para fins de cobrança.
        /// </summary>
        [XmlElement("nEixos")]
        public string nEixos { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de rodagem:
        ///
        ///1 - Simples;
        ///2 - Dupla;
        /// </summary>
        [XmlElement("rodagem")]
        public string rodagem { get; set; } = string.Empty;


        /// <summary>
        /// Orientação de passagem do veículo:
        ///
        ///Ângulo em graus a partir do norte geográfico em sentido horário, número inteiro de 0 a 359, onde 0º seria o norte, 90º o leste, 180º o sul, 270º o oeste. Precisão mínima de 10.
        /// </summary>
        [XmlElement("sentido")]
        public string sentido { get; set; } = string.Empty;


        /// <summary>
        /// Placa do veículo.
        /// </summary>
        [XmlElement("placa")]
        public string placa { get; set; } = string.Empty;


        /// <summary>
        /// Código de acesso gerado automaticamente pelo sistema emissor da concessionária.
        /// </summary>
        [XmlElement("codAcessoPed")]
        public string codAcessoPed { get; set; } = string.Empty;


        /// <summary>
        /// Código de contrato gerado automaticamente pelo sistema nacional no cadastro da concessionária.
        /// </summary>
        [XmlElement("codContrato")]
        public string codContrato { get; set; } = string.Empty;
    }
}
