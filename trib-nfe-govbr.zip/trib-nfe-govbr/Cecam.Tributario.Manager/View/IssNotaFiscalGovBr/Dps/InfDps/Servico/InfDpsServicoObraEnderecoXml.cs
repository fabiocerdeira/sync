﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações do endereço da obra.
    /// </summary>
    public class InfDpsServicoObraEnderecoXml
    {
        #region Elementos


        /// <summary>
        /// Código de Endereçamento Postal numérico do endereço nacional da obra.
        /// </summary>
        [XmlElement("CEP")]
        public string CEP { get; set; } = string.Empty;


        /// <summary>
        /// Tipo e nome do logradouro do endereço do endereço da obra
        /// </summary>
        [XmlElement("xLgr")]
        public string xLgr { get; set; } = string.Empty;


        /// <summary>
        /// Número no logradouro do endereço do endereço da obra.
        /// </summary>
        [XmlElement("nro")]
        public string nro { get; set; } = string.Empty;


        /// <summary>
        /// Complemento do endereço do endereço da obra
        /// </summary>
        [XmlElement("xCpl")]
        public string xCpl { get; set; } = string.Empty;


        /// <summary>
        /// Bairro do endereço do endereço da obra
        /// </summary>
        [XmlElement("xBairro")]
        public string xBairro { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço no exterior.
        /// </summary>
        [XmlElement("endExt")]
        public EnderecoExteriorXml? endExt { get; set; }
    }
}
