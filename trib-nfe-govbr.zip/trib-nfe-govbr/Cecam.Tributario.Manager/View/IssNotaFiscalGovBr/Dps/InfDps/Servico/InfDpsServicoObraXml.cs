﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas à obras de construção civil e congêneres
    /// </summary>
    public class InfDpsServicoObraXml
    {
        #region Elementos


        /// <summary>
        /// Inscrição imobiliária fiscal 
        ///(código fornecido pela Prefeitura Municipal para a identificação da obra ou para fins de recolhimento do IPTU)
        /// </summary>
        [XmlElement("inscImobFisc")]
        public string inscImobFisc { get; set; } = string.Empty;


        /// <summary>
        /// Número de identificação da obra.
        ///Cadastro Nacional de Obras (CNO) ou Cadastro Específico do INSS (CEI).
        /// </summary>
        [XmlElement("cObra")]
        public string cObra { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço da obra.
        /// </summary>
        [XmlElement("end")]
        public InfDpsServicoObraEnderecoXml? end { get; set; }
    }
}
