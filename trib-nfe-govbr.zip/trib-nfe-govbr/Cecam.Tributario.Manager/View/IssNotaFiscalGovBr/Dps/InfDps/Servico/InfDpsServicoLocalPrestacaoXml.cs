﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas ao local da prestação do serviço
    /// </summary>
    public class InfDpsServicoLocalPrestacaoXml
    {
        /// <summary>
        /// Código da localidade da prestação do serviço.
        /// </summary>
        [XmlElement("cLocPrestacao")]
        public string cLocPrestacao { get; set; } = string.Empty;


        /// <summary>
        /// Código do país onde ocorreu a prestação do serviço.
        ///(Tabela de Países ISO)
        /// </summary>
        [XmlElement("cPaisPrestacao")]
        public string cPaisPrestacao { get; set; } = string.Empty;


        /// <summary>
        /// Código do país onde ocorreu o consumo do serviço prestado.
        ///(Tabela de Países ISO)
        /// </summary>
        [XmlElement("cPaisConsum")]
        public string cPaisConsum { get; set; } = string.Empty;
    }
}
