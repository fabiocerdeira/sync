﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações complementares disponível para todos os serviços prestados
    /// </summary>
    public class InfDpsServicoInformacaoComplementarXml
    {
        /// <summary>
        /// Identificador de Documento de Responsabilidade Técnica:
        ///ART, RRT, DRT, Outros.
        /// </summary>
        [XmlElement("idDocTec")]
        public string idDocTec { get; set; } = string.Empty;


        /// <summary>
        /// Chave da nota, número identificador da nota, número do contrato ou outro identificador de documento emitido pelo prestador de serviços, que subsidia a emissão dessa nota pelo tomador do serviço ou intermediário (preenchimento obrigatório caso a nota esteja sendo emitida pelo Tomador ou intermediário do serviço).
        /// </summary>
        [XmlElement("docRef")]
        public string docRef { get; set; } = string.Empty;


        /// <summary>
        /// Campo livre para preenchimento pelo contribuinte.
        /// </summary>
        [XmlElement("xInfComp")]
        public string xInfComp { get; set; } = string.Empty;
    }
}
