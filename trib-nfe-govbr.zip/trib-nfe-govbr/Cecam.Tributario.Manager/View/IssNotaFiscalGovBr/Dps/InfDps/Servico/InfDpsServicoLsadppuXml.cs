﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas a atividades de Locação, sublocação, arrendamento, direito de passagem ou permissão de uso, compartilhado ou não, de ferrovia, rodovia, postes, cabos, dutos e condutos de qualquer natureza.
    /// </summary>
    public class InfDpsServicoLsadppuXml
    {
        /// <summary>
        /// Categorias do serviço:
        ///
        ///1 - Locação;
        ///2 - sublocação;
        ///3 - arrendamento;
        ///4 - direito de passagem;
        ///5 - permissão de uso;
        /// </summary>
        [XmlElement("categ")]
        public string categ { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de objetos da locação, sublocação, arrendamento, direito de passagem ou permissão de uso:
        ///
        ///1 - Ferrovia;
        ///2 - Rodovia;
        ///3 - Postes;
        ///4 - Cabos;
        ///5 - Dutos;
        ///6 - Condutos de qualquer natureza;
        /// </summary>
        [XmlElement("objeto")]
        public string objeto { get; set; } = string.Empty;


        /// <summary>
        /// Extensão total da ferrovia, rodovia, cabos, dutos ou condutos.
        /// </summary>
        [XmlElement("extensao")]
        public string extensao { get; set; } = string.Empty;


        /// <summary>
        /// Número total de postes.
        /// </summary>
        [XmlElement("nPostes")]
        public string nPostes { get; set; } = string.Empty;
    }
}
