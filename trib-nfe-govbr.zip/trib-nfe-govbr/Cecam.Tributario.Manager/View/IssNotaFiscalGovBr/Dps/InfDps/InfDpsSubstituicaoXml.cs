﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps.InfDps
{
    /// <summary>
    /// Grupo de informações relativas à NFS-e a ser substituída
    /// </summary>
    public class InfDpsSubstituicaoXml
    {
        /// <summary>
        /// Chave de Acesso da NFS-e a ser substituída.
        /// </summary>
        [XmlElement("chSubstda")]
        public string chSubstda { get; set; } = string.Empty;


        /// <summary>
        /// Código de justificativa para substituição de NFS-e:
        ///
        ///01 - Desenquadramento de NFS-e do Simples Nacional;
        ///02 - Enquadramento de NFS-e no Simples Nacional;
        ///03 - Inclusão Retroativa de Imunidade/Isenção para NFS-e;
        ///04 - Exclusão Retroativa de Imunidade/Isenção para NFS-e;
        ///05 - Rejeição de NFS-e pelo tomador ou pelo intermediário se responsável pelo recolhimento do tributo;
        ///99 - Outros;
        /// </summary>
        [XmlElement("cMotivo")]
        public string cMotivo { get; set; } = string.Empty;


        /// <summary>
        /// Descrição do motivo da substituição da NFS-e quando o emitente deve descrever o motivo da substituição para outros motivos (cMotivo = 9).
        /// </summary>
        [XmlElement("xMotivo")]
        public string xMotivo { get; set; } = string.Empty;
    }
}
