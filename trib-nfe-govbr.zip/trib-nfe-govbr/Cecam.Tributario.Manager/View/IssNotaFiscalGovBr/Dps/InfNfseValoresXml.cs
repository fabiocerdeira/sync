﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    /// <summary>
    /// Grupo de valores referentes ao serviço prestado
    /// </summary>
    public class InfNfseValoresXml
    {
        /// <summary>
        /// Valor monetário (R$) de dedução/redução da base de cálculo (BC) do ISSQN.
        /// </summary>
        [XmlElement("vCalcDR")]
        public string vCalcDR { get; set; } = string.Empty;


        /// <summary>
        /// Tipo Benefício Municipal (BM):
        /// 1) "Isenção";
        /// 2) "Redução da BC em 'ppBM' %";
        /// 3) "Redução da BC em R$ 'vInfoBM' ";
        /// 4) "Alíquota Diferenciada de 'aliqDifBM' %";
        /// </summary>
        [XmlElement("tpBM")]
        public string tpBM { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário (R$) do percentual de redução da base de cálculo (BC) do ISSQN devido a um benefício municipal (BM).
        /// </summary>
        [XmlElement("vCalcBM")]
        public string vCalcBM { get; set; } = string.Empty;


        /// <summary>
        /// Valor da Base de Cálculo do ISSQN (R$) = Valor do Serviço - Desconto Incondicionado - Deduções/Reduções - Benefício Municipal
        /// vBC = vServ - descIncond - (vDR ou vCalcDR + vCalcReeRepRes) - (vRedBCBM ou VCalcBM)
        /// </summary>
        [XmlElement("vBC")]
        public string vBC { get; set; } = string.Empty;


        /// <summary>
        /// Alíquota aplicada sobre a base de cálculo para apuração do ISSQN.
        /// </summary>
        [XmlElement("pAliqAplic")]
        public string pAliqAplic { get; set; } = string.Empty;


        /// <summary>
        /// Valor do ISSQN (R$) = Valor da Base de Cálculo x Alíquota
        /// vISSQN = vBC x pAliqAplic
        /// </summary>
        [XmlElement("vISSQN")]
        public string vISSQN { get; set; } = string.Empty;


        /// <summary>
        /// Valor total de retenções (R$) = S(CP + IRRF + CSLL + ISSQN* + (PIS + CONFINS)**)
        /// vTotalRet = (vRetCP + vRetIRRF + vRetCSLL) + vISSQN* + 
        /// (vPIS + vCOFINS)**
        /// </summary>
        [XmlElement("vTotalRet")]
        public string vTotalRet { get; set; } = string.Empty;


        /// <summary>
        /// Valor líquido (R$) = Valor do serviço - Desconto condicionado - Desconto incondicionado - Valores retidos (CP, IRRF, CSLL)* - Valores, se retidos (ISSQN, PIS, COFINS)**
        /// VLiq = vServ – vDescIncond – vDescCond – (vRetCP + vRetIRRF + vRetCSLL)* – (vISSQN + vPIS + vCOFINS)**
        /// </summary>
        [XmlElement("vLiq")]
        public string vLiq { get; set; } = string.Empty;


        /// <summary>
        /// Uso da Administração Tributária Municipal.
        /// </summary>
        [XmlElement("xOutInf")]
        public string xOutInf { get; set; } = string.Empty;
    }
}
