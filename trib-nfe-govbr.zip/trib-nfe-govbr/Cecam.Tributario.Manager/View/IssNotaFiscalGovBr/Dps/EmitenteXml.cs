﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    /// <summary>
    /// Grupo de informações da DPS relativas ao emitente da NFS-e
    /// </summary>
    public class EmitenteXml
    {
        #region Elementos


        /// <summary>
        /// Número da inscrição federal (CNPJ) do emitente da NFS-e.
        /// </summary>
        [XmlElement("CNPJ")]
        public string CNPJ { get; set; } = string.Empty;


        /// <summary>
        /// Número da inscrição federal (CPF) do emitente da NFS-e.
        /// </summary>
        [XmlElement("CPF")]
        public string CPF { get; set; } = string.Empty;


        /// <summary>
        /// Número de inscrição municipal do emitente da NFS-e.
        /// </summary>
        [XmlElement("IM")]
        public string IM { get; set; } = string.Empty;


        /// <summary>
        /// Nome / Razão Social do emitente.
        /// </summary>
        [XmlElement("xNome")]
        public string xNome { get; set; } = string.Empty;


        /// <summary>
        /// Nome / Fantasia do emitente.
        /// </summary>
        [XmlElement("xFant")]
        public string xFant { get; set; } = string.Empty;


        /// <summary>
        /// Número do telefone do emitente.
        /// (Preencher com o Código DDD + número do telefone. 
        /// Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)
        /// </summary>
        [XmlElement("fone")]
        public string fone { get; set; } = string.Empty;


        /// <summary>
        /// E-mail do emitente.
        /// </summary>
        [XmlElement("email")]
        public string email { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço nacional do Emitente da NFS-e
        /// </summary>
        [XmlElement("enderNac")]
        public EnderecoNacionalXml? enderNac { get; set; }
    }
}
