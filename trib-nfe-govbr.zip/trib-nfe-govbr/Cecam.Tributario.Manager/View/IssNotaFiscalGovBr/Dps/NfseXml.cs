﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    /// <summary>
    /// Classe raiz da XML de envio da Nota Fiscal Serviço Eletronica 
    /// </summary>
    [XmlRoot("NFSe", Namespace = "http://www.sped.fazenda.gov.br/nfse", IsNullable = false)]
    public class NfseXml
    {
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";


        [XmlElement("infNFSe")]
        public InfNfseXml? InfNFSe { get; set; }


        [XmlElement("Signature", Namespace = "http://www.w3.org/2000/09/xmldsig#", IsNullable = false)]
        public SignatureXml? Signature { get; set; }
    }
}
