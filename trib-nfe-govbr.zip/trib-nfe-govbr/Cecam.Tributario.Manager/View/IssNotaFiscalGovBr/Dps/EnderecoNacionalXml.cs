﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.IssNotaFiscalGovBr.Dps
{
    /// <summary>
    /// Grupo de informações do endereço nacional do emitente/prestador/tomador/intermediário da NFS-e
    /// </summary>
    public class EnderecoNacionalXml
    {
        #region Elementos


        /// <summary>
        /// Tipo e nome do logradouro da localização do endereço do emitente/prestador/tomador/intermediário.
        /// </summary>
        [XmlElement("xLgr")]
        public string xLgr { get; set; } = string.Empty;


        /// <summary>
        /// Número do imóvel do endereço do emitente/prestador/tomador/intermediário.
        /// </summary>
        [XmlElement("nro")]
        public string nro { get; set; } = string.Empty;


        /// <summary>
        /// Complemento do endereço do emitente/prestador/tomador/intermediário.
        /// </summary>
        [XmlElement("xCpl")]
        public string xCpl { get; set; } = string.Empty;


        /// <summary>
        /// Bairro do endereço do emitente/prestador/tomador/intermediário.
        /// </summary>
        [XmlElement("xBairro")]
        public string xBairro { get; set; } = string.Empty;


        /// <summary>
        /// Código do município do endereço do emitente/prestador/tomador/intermediário.
        /// (Tabela do IBGE)
        /// </summary>
        [XmlElement("cMun")]
        public string cMun { get; set; } = string.Empty;


        /// <summary>
        /// Sigla da unidade da federação do município do endereço do emitente/prestador/tomador/intermediário.
        /// </summary>
        [XmlElement("UF")]
        public string UF { get; set; } = string.Empty;


        /// <summary>
        /// Número do CEP do endereço do emitente/prestador/tomador/intermediário.
        /// (Informar os zeros não significativos)
        /// </summary>
        [XmlElement("CEP")]
        public string CEP { get; set; } = string.Empty;


        #endregion
    }
}
