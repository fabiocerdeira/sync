﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Manager.View.ISS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.ConvertEntityToView.Iss
{
    public class IssContribuinteConvert
    {

        public IssContribuinteView ConverterEntityToView(IssContribuinteEntity entity)
        {
            return new IssContribuinteView() 
            { 
                Cd_Contribuinte = entity.Cd_Contribuinte,
                Cd_Exercicio = entity.Cd_Exercicio,
                Nr_CGCCPF = entity.Nr_CGCCPF,
                Ds_RazaoSocial = entity.Ds_RazaoSocial,
            };
        }


        public IssContribuinteEntity ConverterViewToEntity(IssContribuinteView view)
        {
            return new IssContribuinteEntity()
            {
                Cd_Contribuinte = view.Cd_Contribuinte,
                Cd_Exercicio = view.Cd_Exercicio,
                Nr_CGCCPF = view.Nr_CGCCPF,
                Ds_RazaoSocial = view.Ds_RazaoSocial,
            };
        }

    }
}
