﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Dependency
{
    public static class BusinessDI
    {
        public static IServiceCollection BusinessAddServices(this IServiceCollection services)
        {
            // business
            /*
            services.AddTransient<DVATRemessaProtestoSiplanCriticaBusiness>();
            services.AddTransient<DVATRemessaProtestoSiplanLogBusiness>();
            services.AddTransient<ApontarBusiness>();
            services.AddTransient<ConsultarBusiness>();
            services.AddTransient<CancelarBusiness>();
            services.AddTransient<MainBusiness>();
            services.AddTransient<FakeDesenvolvimentoBusiness>();
            services.AddTransient<LogHelper>();
            */

            return services;
        }
    }
}
