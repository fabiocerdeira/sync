﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Dependency;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Moq;

namespace Cecam.Tributario.Database.Test.Preparacao
{
    [TestClass]
    public class TestBase
    {
        protected Mock<ITributosContext> _tributosContextoMock = new Mock<ITributosContext>();
        protected Mock<IIssContribuinteRepository> _issContribuinteRepositorioMock = new Mock<IIssContribuinteRepository>();


        [TestInitialize]
        public void Initialize()
        {
            // inicializar a biblioteca CORE

            // carregar arquivo de configurações
            IConfiguration configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("databaseSettingsTest.json")
                .Build();

            // parametros do settings.json para memória.
            ParametrosDatabase.Carregar(configuration);

            // logger
            ILoggerFactory loggerFactory = LoggerFactory.Create(b => { });

            // preparar EF Core para executar service colletion
            // que é o controlador de "DI"
            var services = new ServiceCollection();
            services.Clear();

            // incluir o iConfiguration na coleção de serviços par DI.
            services.AddSingleton<IConfiguration>(provider => configuration);
            services.AddSingleton<ILoggerFactory>(provider => loggerFactory);

            // configurar DI para dbContext, repositorios e operações de banco
            services.InfraAddServices();
            // services.InfraAddContext(configuration);
            // services.RepositoryAddServices();
            services.QueryAddServices();

            // mock contexto
            services.RemoveAll<ITributosContext>();
            services.AddTransient<ITributosContext>(provider => _tributosContextoMock.Object);

            // mock de repositorios
            // services.RemoveAll<IIssContribuinteRepository>();
            services.AddTransient<IIssContribuinteRepository>(provider => _issContribuinteRepositorioMock.Object);

            // configurar DI para objetos de negocio
            // services.BusinessAddServices();

            // build das configurações acima.
            ConfiguracaoDatabase.ServiceProviderGlobal = services.BuildServiceProvider();
        }


        [TestCleanup]
        public void Cleanup()
        {
        }
    }
}
