﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.Test.Preparacao;
using MockQueryable;

namespace Cecam.Tributario.Database.Test.Iss
{
    [TestClass]
    public class IssContribuinteQueryTest : TestBase
    {
        private List<IssContribuinteEntity> _issContribuinteDatabase = new List<IssContribuinteEntity>();


        private void MockDataBase()
        {
            _issContribuinteDatabase.Add(new IssContribuinteEntity()
            {
                Cd_Cecam = ParametrosDatabase.Cd_Cecam,
                Cd_Contribuinte = 1,
                Cd_Exercicio = DateTime.UtcNow.Year,
                Nr_CGCCPF = "001.002.003-04",
                Ds_RazaoSocial = "Razão social mocada"
            });

            _issContribuinteDatabase.Add(new IssContribuinteEntity()
            {
                Cd_Cecam = ParametrosDatabase.Cd_Cecam,
                Cd_Contribuinte = 2,
                Cd_Exercicio = DateTime.UtcNow.Year - 2,
                Nr_CGCCPF = "222.404.505-05",
                Ds_RazaoSocial = "Razão social #2 mocada"
            });

            var issContribuinteDatabaseMock = _issContribuinteDatabase.BuildMock();

            _issContribuinteRepositorioMock.Setup(x => x.GetIQueryable()).Returns(issContribuinteDatabaseMock);
        }


        [TestMethod]
        public async Task Listar_Filter_Sucesso()
        {
            // arrange
            MockDataBase();

            // act
            var query = ConfiguracaoDatabase.GetServico<IIssContribuinteQuery>();

            var lista = await query.Listar(new IssContribuinteFilter()
            {
                Cd_Exercicio = DateTime.UtcNow.Year,
                AsNoTracking = true,
                QtdMaximaRegistrosRetornados = 10,
            });

            // assert
            Assert.IsNotNull(lista);
            Assert.AreEqual(1, lista.Count);
        }
    }
}
