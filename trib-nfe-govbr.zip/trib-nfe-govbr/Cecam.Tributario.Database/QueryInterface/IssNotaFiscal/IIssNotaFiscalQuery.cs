﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalQuery
    {
        Task<List<IssNotaFiscalEntity>> Listar(IssNotaFiscalFilter filtro);

        Task<List<IssNotaFiscalEntity>> ListarSQL(IssNotaFiscalFilter filtro);

        //Task<int> UpdateExemploSQL();
    }
}
