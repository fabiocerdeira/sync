﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalItemQuery
    {
        Task<List<IssNotaFiscalItemEntity>> Listar(IssNotaFiscalItemFilter filtro);

        Task<List<IssNotaFiscalItemEntity>> ListarSQL(IssNotaFiscalItemFilter filtro);

        //Task<int> UpdateExemploSQL();
    }
}
