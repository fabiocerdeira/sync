﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssContribuinteQuery
    {
        Task<List<IssContribuinteEntity>> Listar(IssContribuinteFilter filtro);

        Task<List<IssContribuinteEntity>> ListarSQL(IssContribuinteFilter filtro);

        Task<int> UpdateExemploSQL();
    }
}
