﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr
{
    public interface IIssNotaFiscalGovBrFilaSaidaQuery
    {
        Task<List<IssNotaFiscalGovBrFilaSaidaEntity>> Listar(IssNotaFiscalGovBrFilaSaidaFilter filtro);

        Task<List<IssNotaFiscalGovBrFilaSaidaEntity>> ListarSQL(IssNotaFiscalGovBrFilaSaidaFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
