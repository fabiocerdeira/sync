﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr
{
    public interface IIssNotaFiscalGovBrFilaEntradaQuery
    {
        Task<List<IssNotaFiscalGovBrFilaEntradaEntity>> Listar(IssNotaFiscalGovBrFilaEntradaFilter filtro);

        Task<List<IssNotaFiscalGovBrFilaEntradaEntity>> ListarSQL(IssNotaFiscalGovBrFilaEntradaFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
