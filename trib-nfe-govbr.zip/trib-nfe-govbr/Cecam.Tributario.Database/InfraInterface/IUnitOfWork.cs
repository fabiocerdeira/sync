﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.InfraInterface
{
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        /// Contexto
        /// </summary>
        ITributosContext DbContext { get; }


        /// <summary>
        /// Start the database Transaction
        /// </summary>
        [Obsolete("Utilizar BeginTransactionAsync")]
        void BeginTransaction();


        /// <summary>
        /// Start the database Transaction
        /// </summary>
        Task BeginTransactionAsync();


        /// <summary>
        /// Commit the database Transaction
        /// </summary>
        [Obsolete("Utilizar CommitTransactionAsync")]
        void CommitTransaction();


        /// <summary>
        /// Commit the database Transaction
        /// </summary>
        Task CommitTransactionAsync();


        /// <summary>
        /// Rollback the database Transaction
        /// </summary>
        [Obsolete("Utilizar RollbackTransactionAsync")]
        void RollbackTransaction();


        /// <summary>
        /// Rollback the database Transaction
        /// </summary>
        Task RollbackTransactionAsync();


        /// <summary>
        /// Salvar dentro da transação
        /// </summary>
        [Obsolete("Utilizar SaveChangesAsync")]
        int SaveChanges();

        /// <summary>
        /// Salvar dentro da transação
        /// </summary>
        Task<int> SaveChangesAsync();
    }
}
