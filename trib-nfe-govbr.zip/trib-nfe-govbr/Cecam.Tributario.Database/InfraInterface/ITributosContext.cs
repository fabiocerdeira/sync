﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace Cecam.Tributario.Database.InfraInterface
{
    public interface ITributosContext : IDisposable
    {
        #region Usado para repositorio generico

        DbSet<TEntity> Set<TEntity>() where TEntity : class;


        EntityEntry Entry(object entity);


        [Obsolete("Utilizar SaveChangesAsync")]
        int SaveChanges();


        Task<int> SaveChangesAsync(CancellationToken cancellationToken);


        DatabaseFacade Database { get; }

        #endregion
    }
}
