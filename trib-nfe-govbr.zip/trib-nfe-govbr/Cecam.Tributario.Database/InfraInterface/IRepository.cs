﻿using Microsoft.EntityFrameworkCore;

namespace Cecam.Tributario.Database.InfraInterface
{
    public interface IRepository<TEntity> where TEntity : class
    {
        ITributosContext DbContext { get; }

        DbSet<TEntity> DbSetEntity { get; }

        IQueryable<TEntity> GetIQueryable();

        void Update(TEntity entity);

        void UpdateList(List<TEntity> entities);

        Task<int> SaveChangesAsync();


        /*
        void Add(TEntity entity);

        void AddRange(IEnumerable<TEntity> entity);


        void UpdateRange(IEnumerable<TEntity> entities);

        void Delete(TEntity entity);

        void DeleteRange(IEnumerable<TEntity> entity);

        [Obsolete("Utilize SaveChangesAsync")]
        int SaveChanges();

        */

    }
}
