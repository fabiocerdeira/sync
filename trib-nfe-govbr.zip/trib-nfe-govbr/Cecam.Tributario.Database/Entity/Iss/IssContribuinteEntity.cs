﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssContribuinteEntity : EntityBase
    {

        #region Propriedades

        #region PK Chave Primária

        public int Cd_Cecam { get; set; }
        
        public decimal Cd_Contribuinte { get; set; }

        #endregion

        public int Cd_Exercicio { get; set; }

        public int? Cd_TipoImposto { get; set; }

        public int? Cd_TipoCalculo { get; set; }

        public int? Cd_Estimado { get; set; }

        public int? Cd_Periodo { get; set; }

        public string Ds_Inscricao_Municipal { get; set; } = string.Empty;

        public int? Cd_Conselho_Regional { get; set; }
        
        public decimal? cd_Imovel { get; set; }

        public string? Cd_Logradouro { get; set; }

        public int? Cd_Bairro { get; set; }
        
        public int? Cd_Trecho { get; set; }
        
        public int? cd_Contador { get; set; }

        public string? Ds_RazaoSocial { get; set; }

        public string? Ds_Fantasia { get; set; }

        public string? Cd_Numero { get; set; }

        public string? Ds_Complemento { get; set; }

        public string? Ds_Andar { get; set; }

        public string? Ds_Apto { get; set; }

        public string? Cd_LogradouroCorr { get; set; }

        public string? Ds_TipoLogradouroCorr { get; set; }

        public string? Ds_EnderCorr { get; set; }

        public string? Cd_NumCorr { get; set; }


        /*
         
         faltam vários outros campos dessa tabela

        */

        public string? Nr_CGCCPF { get; set; }

        public string? Ds_Obs { get; set; }
        
        public DateTime? Dt_AberturaEmpresa { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
