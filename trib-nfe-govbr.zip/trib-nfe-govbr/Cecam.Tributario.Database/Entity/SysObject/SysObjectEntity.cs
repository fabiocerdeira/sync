﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.SysObject
{
    public class SysObjectEntity : EntityBase
    {
        #region Propriedades

        public int Object_id { get; set; }

        public string Name { get; set; } = string.Empty;
        
        public string Type { get; set; } = string.Empty;
        
        public string Type_Desc { get; set; } = string.Empty;

        #endregion

        #region Relacionamentos
        #endregion
    }
}
