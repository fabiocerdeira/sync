﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Cecam.Tributario.Database.Entity.SysObject
{
    public class SysColumnEntity : EntityBase
    {
        #region Propriedades

        public int Object_id { get; set; }

        public string Name { get; set; } = string.Empty;

        public int Column_id { get; set; }

        public byte System_type_id { get; set; }

        public short Max_length { get; set; }

        public byte Precision { get; set; }

        public byte Scale { get; set; }

        public bool Is_nullable { get; set; }


        [NotMapped]
        public bool IsPk { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
