﻿namespace Cecam.Tributario.Database.Entity.SysObject
{
    public class SysIndexEntity : EntityBase
    {
        #region Propriedades
        
        public int Object_id { get; set; }

        public string Name { get; set; } = string.Empty;

        public int Index_id { get; set; }

        public bool Is_primary_key { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
