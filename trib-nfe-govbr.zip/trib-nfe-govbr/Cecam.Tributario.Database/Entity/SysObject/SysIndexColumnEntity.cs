﻿namespace Cecam.Tributario.Database.Entity.SysObject
{
    public class SysIndexColumnEntity : EntityBase
    {
        #region Propriedades

        public int Object_id { get; set; }
        
        public int Index_id { get; set; }

        public int Index_column_id { get; set; }

        public int Column_id { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
