﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalItemEntity : EntityBase
    {
        #region Propriedades

        public int Cd_Cecam { get; set; }

		public decimal Cd_NotaFiscal { get; set; }

		public string Cd_Servico { get; set; } = string.Empty;

		public int Cd_GrupoAtividade { get; set; }

		public int Cd_SubGrupoAtividade { get; set; }

		public int Cd_ItemAtividade { get; set; }

		public decimal Vl_Item { get; set; }

		public decimal Vl_Deducao { get; set; }

		public decimal Pc_Aliquota { get; set; }

		public decimal Vl_Tomado { get; set; }

		public byte Fl_Retido { get; set; }

		public byte Fl_Exportado { get; set; }

		public int? Cd_Pais { get; set; }

		public int? Nr_Quantidade { get; set; }

		public int? Cd_Unidade { get; set; }

		public string? Ds_ItemServico { get; set; }

		public decimal? Vl_BaseCalculo { get; set; }

		public decimal? Vl_DevidoItem { get; set; }

		public decimal? Vl_Devido { get; set; }

        #endregion

        #region Relacionamentos

        /// <summary>
        /// Tabela/Objeto pai
        /// </summary>
        public IssNotaFiscalEntity? NotaFiscal { get; set; }

        #endregion
    }
}
