﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrFilaEntradaEntity : EntityBase
    {
        #region Propriedades
        
		public int Id { get; set; }

		public int Cd_Cecam { get; set; }

		public decimal Cd_NotaFiscal { get; set; }

		public int FilaTipo { get; set; }

		public int Status { get; set; }

		public DateTime EntradaDataHora { get; set; }

		public DateTime? EnvioDataHora { get; set; }

		public string? EnvioCorpo { get; set; }

		public string? EnvioMensagem { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
