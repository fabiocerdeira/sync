﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Configuration
{
    public static class ConfiguracaoDatabase
    {
        /// <summary>
        /// Referencia ao servico global
        /// </summary>
        public static IServiceProvider ServiceProviderGlobal { get; set; } = new ServiceCollection().BuildServiceProvider();


        /// <summary>
        /// Retornar um servico global
        /// </summary>
        public static TEntity GetServico<TEntity>() where TEntity : notnull
        {
            return ServiceProviderGlobal.GetRequiredService<TEntity>();
        }


        /// <summary>
        /// Criar e retornar objeto para LOG
        /// </summary>
        public static ILogger<TEntity> CreateLogger<TEntity>() where TEntity : notnull
        {
            return GetServico<ILoggerFactory>().CreateLogger<TEntity>();
        }
    }
}
