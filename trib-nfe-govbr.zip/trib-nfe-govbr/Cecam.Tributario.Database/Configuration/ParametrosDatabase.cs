﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Configuration
{
    public static class ParametrosDatabase
    {
        public static int Cd_Cecam { get; set; }


        public static void Carregar(IConfiguration _configuration)
        {
            int cdCecam = 0;
            int.TryParse("" + _configuration["Cd_Cecam"], out cdCecam);
            Cd_Cecam = cdCecam;
        }
    }
}
