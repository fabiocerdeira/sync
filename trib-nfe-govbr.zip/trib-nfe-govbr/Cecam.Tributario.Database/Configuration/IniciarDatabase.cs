﻿using Cecam.Tributario.Database.Dependency;
using Cecam.Tributario.Extend.Logg;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Cecam.Tributario.Database.Configuration
{
    public static class IniciarDatabase
    {
        public static void Iniciar()
        {
            // carregar arquivo de configurações
            IConfiguration configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("databaseSettings.json")
                .Build();

            // parametros do settings.json para memória.
            ParametrosDatabase.Carregar(configuration);

            // logger
            ILoggerFactory loggerFactory = LoggerFactory.Create(b =>
            {
                b.AddConfiguration(configuration.GetSection("Logging"));
                b.AddConsole();
                b.AddDebug();
                b.AddProvider(new FileLoggerProvider());
            });

            // preparar EF Core para executar service colletion
            // que é o controlador de "DI"
            var services = new ServiceCollection();
            services.Clear();

            // incluir o iConfiguration na coleção de serviços par DI.
            services.AddSingleton<IConfiguration>(provider => configuration);
            services.AddTransient<ILoggerFactory>(provider => loggerFactory);

            // configurar DI para dbContext, repositorios e operações de banco
            services.InfraAddServices();
            services.InfraAddContext(configuration);
            services.RepositoryAddServices();
            services.QueryAddServices();

            // configurar DI para objetos de negocio
            // services.BusinessAddServices();

            // build das configurações acima.
            // _serviceProviderGlobal = services.BuildServiceProvider();
            ConfiguracaoDatabase.ServiceProviderGlobal = services.BuildServiceProvider();
        }
    }
}
