﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.InfraInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Infra
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ITributosContext _dbContext;
        private bool _disposed;

        #region Construtor

        public UnitOfWork()
        {
            _dbContext = ConfiguracaoDatabase.GetServico<ITributosContext>();
        }


        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        ~UnitOfWork()
        {
            Dispose(false);
        }


        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
                if (disposing)
                    _dbContext.Dispose();
            _disposed = true;
        }

        #endregion


        public ITributosContext DbContext => _dbContext;


        [Obsolete("Utilizar BeginTransactionAsync")]
        public void BeginTransaction()
        {
            _dbContext.Database.BeginTransaction();
        }


        public async Task BeginTransactionAsync()
        {
            await _dbContext.Database.BeginTransactionAsync(new CancellationToken());
        }


        [Obsolete("Utilizar CommitTransactionAsync")]
        public void CommitTransaction()
        {
            _dbContext.Database.CommitTransaction();
        }


        public async Task CommitTransactionAsync()
        {
            await _dbContext.Database.CommitTransactionAsync(new CancellationToken());
        }


        [Obsolete("Utilizar RollbackTransactionAsync")]
        public void RollbackTransaction()
        {
            _dbContext.Database.RollbackTransaction();
        }

        
        public async Task RollbackTransactionAsync()
        {
            await _dbContext.Database.RollbackTransactionAsync(new CancellationToken());
        }


        [Obsolete("Utilizar SaveChangesAsync")]
        public int SaveChanges()
        {
            return _dbContext.SaveChanges();
        }


        public async Task<int> SaveChangesAsync()
        {
            return await _dbContext.SaveChangesAsync(new CancellationToken());
        }
    }
}
