﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.Iss;

namespace Cecam.Tributario.Database.Repository.Iss
{
    public class IssContribuinteRepository : Repository<IssContribuinteEntity>, IIssContribuinteRepository
    {
        public IssContribuinteRepository() : base() { }
        public IssContribuinteRepository(ITributosContext dbContexto) : base(dbContexto) { }
        public IssContribuinteRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
