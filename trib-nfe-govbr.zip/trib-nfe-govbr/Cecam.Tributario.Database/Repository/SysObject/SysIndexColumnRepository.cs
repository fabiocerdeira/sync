﻿using Cecam.Tributario.Database.Entity.SysObject;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.SysObject;

namespace Cecam.Tributario.Database.Repository.SysObject
{
    public class SysIndexColumnRepository : Repository<SysIndexColumnEntity>, ISysIndexColumnRepository
    {
        public SysIndexColumnRepository() : base() { }
        public SysIndexColumnRepository(ITributosContext dbContexto) : base(dbContexto) { }
        public SysIndexColumnRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
