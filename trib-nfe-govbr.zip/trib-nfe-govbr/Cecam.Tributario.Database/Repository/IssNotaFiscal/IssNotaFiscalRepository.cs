﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscal
{
    public class ISSNotaFiscalRepository : Repository<IssNotaFiscalEntity>, IIssNotaFiscalRepository
    {
        public ISSNotaFiscalRepository() : base() { }
        public ISSNotaFiscalRepository(ITributosContext dbContexto) : base(dbContexto) { }
        public ISSNotaFiscalRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
