﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscal
{
    public class ISSNotaFiscalItemRepository : Repository<IssNotaFiscalItemEntity>, IIssNotaFiscalItemRepository
    {
        public ISSNotaFiscalItemRepository() : base() { }
        public ISSNotaFiscalItemRepository(ITributosContext dbContexto) : base(dbContexto) { }
        public ISSNotaFiscalItemRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
