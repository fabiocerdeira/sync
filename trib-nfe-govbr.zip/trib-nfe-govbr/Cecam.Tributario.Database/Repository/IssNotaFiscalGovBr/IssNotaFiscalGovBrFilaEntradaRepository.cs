﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrFilaEntradaRepository : Repository<IssNotaFiscalGovBrFilaEntradaEntity>, IIssNotaFiscalGovBrFilaEntradaRepository
    {
        public IssNotaFiscalGovBrFilaEntradaRepository() : base() { }
        public IssNotaFiscalGovBrFilaEntradaRepository(ITributosContext dbContexto) : base(dbContexto) { }
        public IssNotaFiscalGovBrFilaEntradaRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
