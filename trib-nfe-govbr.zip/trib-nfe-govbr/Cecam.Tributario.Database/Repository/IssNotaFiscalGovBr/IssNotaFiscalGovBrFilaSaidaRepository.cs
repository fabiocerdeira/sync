﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrFilaSaidaRepository : Repository<IssNotaFiscalGovBrFilaSaidaEntity>, IIssNotaFiscalGovBrFilaSaidaRepository
    {
        public IssNotaFiscalGovBrFilaSaidaRepository() : base() { }
        public IssNotaFiscalGovBrFilaSaidaRepository(ITributosContext dbContexto) : base(dbContexto) { }
        public IssNotaFiscalGovBrFilaSaidaRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
