﻿using Cecam.Tributario.Database.Filter;
using Cecam.Tributario.Database.InfraInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Cecam.Tributario.Database.Entity;

namespace Cecam.Tributario.Database.Query
{
    public class QueryBase
    {
        public QueryBase()
        {
        }


        protected IQueryable<T> ListarFilterBase<T>(IQueryable<T> consulta, FiltroBase filtroBase)
            where T : EntityBase
        {
            if (filtroBase.AsNoTracking)
                consulta = consulta.AsNoTracking();

            if (filtroBase.QtdMaximaRegistrosRetornados.HasValue && filtroBase.QtdMaximaRegistrosRetornados.Value > 0)
                consulta = consulta.Take(filtroBase.QtdMaximaRegistrosRetornados.Value);

            return consulta;
        }

    }
}
