﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssContribuinteQuery : QueryBase, IIssContribuinteQuery
    {
        protected readonly IIssContribuinteRepository _issContribuinteRepositorio;
        private readonly ILogger<IssContribuinteQuery> _logger;


        public IssContribuinteQuery(IIssContribuinteRepository issContribuinteRepositorio)
        {
            _issContribuinteRepositorio = issContribuinteRepositorio;
            _logger = ConfiguracaoDatabase.CreateLogger<IssContribuinteQuery>();
        }


        public async Task<List<IssContribuinteEntity>> Listar(IssContribuinteFilter filtro)
        {
            var consulta = _issContribuinteRepositorio.GetIQueryable();

            #region Propriedades

            if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
                consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

            if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
                consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
                consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssContribuinteEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssContribuinteEntity>> ListarSQL(IssContribuinteFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssContribuintes c WITH(NOLOCK) ");

            if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" c.Cd_Cecam = {filtro.Cd_Cecam}");
            }

            if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" c.Cd_Exercicio = {filtro.Cd_Exercicio}");
            }

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" c.Nr_CGCCPF = '{filtro.Nr_CGCCPF.Trim().Replace("\'","")}'");
            }

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            // log para acompanhamento
            /*
            _logger.LogCritical(sql.ToString());
            _logger.LogError(sql.ToString());
            _logger.LogInformation(sql.ToString());
            _logger.LogWarning(sql.ToString());
            _logger.LogDebug(sql.ToString());
            */
            _logger.LogTrace(sql.ToString());

            return await _issContribuinteRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        public async Task<int> UpdateExemploSQL()
        {
            string sql = "UPDATE IssContribuintes SET Ds_Obs = 'dentro-query" + DateTime.Now.ToString("hh:mm:ss:fff") + "' WHERE cd_Contribuinte = 36031";

            // log para acompanhamento
            _logger.LogTrace(sql);

            return await _issContribuinteRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }

    }
}

