﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrFilaSaidaQuery : QueryBase, IIssNotaFiscalGovBrFilaSaidaQuery
    {
        protected readonly IIssNotaFiscalGovBrFilaSaidaRepository _issNotaFiscalGovBrFilaSaidaRepositorio;


        public IssNotaFiscalGovBrFilaSaidaQuery(IIssNotaFiscalGovBrFilaSaidaRepository issNotaFiscalGovBrFilaSaidaRepositorio)
        {
            _issNotaFiscalGovBrFilaSaidaRepositorio = issNotaFiscalGovBrFilaSaidaRepositorio;
        }


        public async Task<List<IssNotaFiscalGovBrFilaSaidaEntity>> Listar(IssNotaFiscalGovBrFilaSaidaFilter filtro)
        {
            var consulta = _issNotaFiscalGovBrFilaSaidaRepositorio.GetIQueryable();

            #region Propriedades

            if (filtro.Id.HasValue && filtro.Id.Value > 0)
				consulta = consulta.Where(x => x.Id == filtro.Id.Value);

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

			if (filtro.FilaTipo.HasValue && filtro.FilaTipo.Value > 0)
				consulta = consulta.Where(x => x.FilaTipo == filtro.FilaTipo.Value);

			if (filtro.EntradaDataHora.HasValue)
				consulta = consulta.Where(x => x.EntradaDataHora == filtro.EntradaDataHora.Value);

			if (filtro.EnvioDataHora.HasValue)
				consulta = consulta.Where(x => x.EnvioDataHora == filtro.EnvioDataHora.Value);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalGovBrFilaSaidaEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalGovBrFilaSaidaEntity>> ListarSQL(IssNotaFiscalGovBrFilaSaidaFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscal_GovBr_FilaSaida WITH(NOLOCK) ");

            #region Propriedades
            
			if (filtro.Id.HasValue && filtro.Id.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Id = {filtro.Id}");
			}

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
			}

			if (filtro.FilaTipo.HasValue && filtro.FilaTipo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" FilaTipo = {filtro.FilaTipo}");
			}

			if (filtro.EntradaDataHora.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" EntradaDataHora = {filtro.EntradaDataHora}");
			}

			if (filtro.EnvioDataHora.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" EnvioDataHora = {filtro.EnvioDataHora}");
			}

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalGovBrFilaSaidaRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }

		/*
        public async Task<int> UpdateExemploSQL()
        {
            string sql = "UPDATE ISSNotaFiscal_GovBr_FilaSaida SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalGovBrFilaSaidaRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
		*/
    }
}
