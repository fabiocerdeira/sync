﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrFilaEntradaQuery : QueryBase, IIssNotaFiscalGovBrFilaEntradaQuery
    {
        protected readonly IIssNotaFiscalGovBrFilaEntradaRepository _issNotaFiscalGovBrFilaEntradaRepositorio;


        public IssNotaFiscalGovBrFilaEntradaQuery(IIssNotaFiscalGovBrFilaEntradaRepository issNotaFiscalGovBrFilaEntradaRepositorio)
        {
            _issNotaFiscalGovBrFilaEntradaRepositorio = issNotaFiscalGovBrFilaEntradaRepositorio;
        }


        public async Task<List<IssNotaFiscalGovBrFilaEntradaEntity>> Listar(IssNotaFiscalGovBrFilaEntradaFilter filtro)
        {
            var consulta = _issNotaFiscalGovBrFilaEntradaRepositorio.GetIQueryable();

            #region Propriedades

            if (filtro.Id.HasValue && filtro.Id.Value > 0)
				consulta = consulta.Where(x => x.Id == filtro.Id.Value);

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

			if (filtro.FilaTipo.HasValue && filtro.FilaTipo.Value > 0)
				consulta = consulta.Where(x => x.FilaTipo == filtro.FilaTipo.Value);

			if (filtro.Status.HasValue && filtro.Status.Value > 0)
				consulta = consulta.Where(x => x.Status == filtro.Status.Value);

			if (filtro.EntradaDataHora.HasValue)
				consulta = consulta.Where(x => x.EntradaDataHora == filtro.EntradaDataHora.Value);

			if (filtro.EnvioDataHora.HasValue)
				consulta = consulta.Where(x => x.EnvioDataHora == filtro.EnvioDataHora.Value);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalGovBrFilaEntradaEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalGovBrFilaEntradaEntity>> ListarSQL(IssNotaFiscalGovBrFilaEntradaFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscal_GovBr_FilaEntrada WITH(NOLOCK) ");

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Id = {filtro.Id}");
			}

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
			}

			if (filtro.FilaTipo.HasValue && filtro.FilaTipo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" FilaTipo = {filtro.FilaTipo}");
			}

			if (filtro.Status.HasValue && filtro.Status.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Status = {filtro.Status}");
			}

			if (filtro.EntradaDataHora.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" EntradaDataHora = {filtro.EntradaDataHora}");
			}

			if (filtro.EnvioDataHora.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" EnvioDataHora = {filtro.EnvioDataHora}");
			}

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalGovBrFilaEntradaRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }

		/*
        public async Task<int> UpdateExemploSQL()
        {
            string sql = "UPDATE ISSNotaFiscal_GovBr_FilaEntrada SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalGovBrFilaEntradaRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
		*/
    }
}
