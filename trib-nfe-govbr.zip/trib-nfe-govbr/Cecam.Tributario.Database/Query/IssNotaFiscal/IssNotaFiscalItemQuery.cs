﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.ISSNotaFiscal
{
    public class IssNotaFiscalItemQuery : QueryBase, IIssNotaFiscalItemQuery
    {
        protected readonly IIssNotaFiscalItemRepository _issNotaFiscalItemRepositorio;


        public IssNotaFiscalItemQuery(IIssNotaFiscalItemRepository issNotaFiscalItemRepositorio)
        {
            _issNotaFiscalItemRepositorio = issNotaFiscalItemRepositorio;
        }


        public async Task<List<IssNotaFiscalItemEntity>> Listar(IssNotaFiscalItemFilter filtro)
        {
            var consulta = _issNotaFiscalItemRepositorio.GetIQueryable();

            #region Propriedades

            if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
				consulta = consulta.Where(x => x.Cd_Servico == filtro.Cd_Servico);

			if (filtro.Cd_GrupoAtividade.HasValue && filtro.Cd_GrupoAtividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_GrupoAtividade == filtro.Cd_GrupoAtividade.Value);

			if (filtro.Cd_SubGrupoAtividade.HasValue && filtro.Cd_SubGrupoAtividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_SubGrupoAtividade == filtro.Cd_SubGrupoAtividade.Value);

			if (filtro.Cd_ItemAtividade.HasValue && filtro.Cd_ItemAtividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_ItemAtividade == filtro.Cd_ItemAtividade.Value);

			if (filtro.Vl_Item.HasValue && filtro.Vl_Item.Value > 0)
				consulta = consulta.Where(x => x.Vl_Item == filtro.Vl_Item.Value);

			if (filtro.Vl_Deducao.HasValue && filtro.Vl_Deducao.Value > 0)
				consulta = consulta.Where(x => x.Vl_Deducao == filtro.Vl_Deducao.Value);

			if (filtro.Pc_Aliquota.HasValue && filtro.Pc_Aliquota.Value > 0)
				consulta = consulta.Where(x => x.Pc_Aliquota == filtro.Pc_Aliquota.Value);

			if (filtro.Vl_Tomado.HasValue && filtro.Vl_Tomado.Value > 0)
				consulta = consulta.Where(x => x.Vl_Tomado == filtro.Vl_Tomado.Value);

			if (filtro.Fl_Retido.HasValue && filtro.Fl_Retido.Value > 0)
				consulta = consulta.Where(x => x.Fl_Retido == filtro.Fl_Retido.Value);

			if (filtro.Fl_Exportado.HasValue && filtro.Fl_Exportado.Value > 0)
				consulta = consulta.Where(x => x.Fl_Exportado == filtro.Fl_Exportado.Value);

			if (filtro.Cd_Pais.HasValue && filtro.Cd_Pais.Value > 0)
				consulta = consulta.Where(x => x.Cd_Pais == filtro.Cd_Pais.Value);

			if (filtro.Nr_Quantidade.HasValue && filtro.Nr_Quantidade.Value > 0)
				consulta = consulta.Where(x => x.Nr_Quantidade == filtro.Nr_Quantidade.Value);

			if (filtro.Cd_Unidade.HasValue && filtro.Cd_Unidade.Value > 0)
				consulta = consulta.Where(x => x.Cd_Unidade == filtro.Cd_Unidade.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ItemServico))
				consulta = consulta.Where(x => x.Ds_ItemServico == filtro.Ds_ItemServico);

			if (filtro.Vl_BaseCalculo.HasValue && filtro.Vl_BaseCalculo.Value > 0)
				consulta = consulta.Where(x => x.Vl_BaseCalculo == filtro.Vl_BaseCalculo.Value);

			if (filtro.Vl_DevidoItem.HasValue && filtro.Vl_DevidoItem.Value > 0)
				consulta = consulta.Where(x => x.Vl_DevidoItem == filtro.Vl_DevidoItem.Value);

			if (filtro.Vl_Devido.HasValue && filtro.Vl_Devido.Value > 0)
				consulta = consulta.Where(x => x.Vl_Devido == filtro.Vl_Devido.Value);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalItemEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalItemEntity>> ListarSQL(IssNotaFiscalItemFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscalItem WITH(NOLOCK) ");

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Servico = '{filtro.Cd_Servico.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_GrupoAtividade.HasValue && filtro.Cd_GrupoAtividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_GrupoAtividade = {filtro.Cd_GrupoAtividade}");
			}

			if (filtro.Cd_SubGrupoAtividade.HasValue && filtro.Cd_SubGrupoAtividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_SubGrupoAtividade = {filtro.Cd_SubGrupoAtividade}");
			}

			if (filtro.Cd_ItemAtividade.HasValue && filtro.Cd_ItemAtividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ItemAtividade = {filtro.Cd_ItemAtividade}");
			}

			if (filtro.Vl_Item.HasValue && filtro.Vl_Item.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Item = {filtro.Vl_Item}");
			}

			if (filtro.Vl_Deducao.HasValue && filtro.Vl_Deducao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Deducao = {filtro.Vl_Deducao}");
			}

			if (filtro.Pc_Aliquota.HasValue && filtro.Pc_Aliquota.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_Aliquota = {filtro.Pc_Aliquota}");
			}

			if (filtro.Vl_Tomado.HasValue && filtro.Vl_Tomado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Tomado = {filtro.Vl_Tomado}");
			}

			if (filtro.Fl_Retido.HasValue && filtro.Fl_Retido.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Retido = {filtro.Fl_Retido}");
			}

			if (filtro.Fl_Exportado.HasValue && filtro.Fl_Exportado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Exportado = {filtro.Fl_Exportado}");
			}

			if (filtro.Cd_Pais.HasValue && filtro.Cd_Pais.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Pais = {filtro.Cd_Pais}");
			}

			if (filtro.Nr_Quantidade.HasValue && filtro.Nr_Quantidade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Quantidade = {filtro.Nr_Quantidade}");
			}

			if (filtro.Cd_Unidade.HasValue && filtro.Cd_Unidade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Unidade = {filtro.Cd_Unidade}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ItemServico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ItemServico = '{filtro.Ds_ItemServico.Trim().Replace("\'","")}'");
			}

			if (filtro.Vl_BaseCalculo.HasValue && filtro.Vl_BaseCalculo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_BaseCalculo = {filtro.Vl_BaseCalculo}");
			}

			if (filtro.Vl_DevidoItem.HasValue && filtro.Vl_DevidoItem.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_DevidoItem = {filtro.Vl_DevidoItem}");
			}

			if (filtro.Vl_Devido.HasValue && filtro.Vl_Devido.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Devido = {filtro.Vl_Devido}");
			}



            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalItemRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }

		/*
        public async Task<int> UpdateExemploSQL()
        {
            string sql = "UPDATE ISSNotaFiscalItem SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalItemRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
		*/
    }
}
