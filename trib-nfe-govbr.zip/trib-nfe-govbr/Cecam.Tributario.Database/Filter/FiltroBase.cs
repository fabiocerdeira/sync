﻿using Cecam.Tributario.Database.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Filter
{
    public abstract class FiltroBase
    {
        public bool AsNoTracking { get; set; } = true;

        public int? QtdMaximaRegistrosRetornados { get; set; }

        #region Propriedades

        public int? Cd_Cecam { get; set; } = ParametrosDatabase.Cd_Cecam;

        public int? Cd_Exercicio { get; set; }

        #endregion
    }
}

