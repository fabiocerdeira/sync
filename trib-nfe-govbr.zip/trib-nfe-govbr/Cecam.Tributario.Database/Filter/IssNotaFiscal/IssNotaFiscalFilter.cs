﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscal
{
    public class IssNotaFiscalFilter : FiltroBase
    {
        #region Propriedades

        public decimal? Cd_NotaFiscal { get; set; }

		public int? Cd_Referencia { get; set; }

		public string? Nr_CGCCPF { get; set; }

		public int? Cd_TipoDocumento { get; set; }

		public decimal? Nr_NotaFiscal { get; set; }

		public byte? Cd_Situacao { get; set; }

		public DateTime? Dt_Emissao { get; set; }

		public string? Nr_CGCCPFTomador { get; set; }

		public string? Ds_Observacao { get; set; }

		public string? Nr_CGCCPFUsuarioCriacao { get; set; }

		public DateTime? Dt_Criacao { get; set; }

		public string? Nr_CGCCPFUsuarioAtualizacao { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public decimal? Nr_Certificado { get; set; }

		public decimal? Nr_NotaFiscalSubstituta { get; set; }

		public byte? Fl_LocalPrestacao { get; set; }

		public string? Ds_LocalPrestacao { get; set; }

		public string? Ds_LocalPrestacaoCompl { get; set; }

		public decimal? Cd_Imovel { get; set; }

		public decimal? Cd_CidadePrestacao { get; set; }

		public string? Nm_Logradouro { get; set; }

		public string? Nr_Numero { get; set; }

		public string? Ds_Complemento { get; set; }

		public string? Nm_Bairro { get; set; }

		public string? Cd_CEP { get; set; }

		public string? Nr_Aviso { get; set; }

		public byte? Fl_PrestadorNaoInscrito { get; set; }

		public byte? Fl_Tomador { get; set; }

		public byte? Fl_Web { get; set; }

		public decimal? Cd_Contribuinte { get; set; }

		public string? Nr_ChaveValidacao { get; set; }

		public Guid? Cd_RPS { get; set; }

		public string? Ds_MotivoCancelamento { get; set; }

		public int? Nr_Lote { get; set; }

		public decimal? Cd_PreNota { get; set; }

		public decimal? Cd_Tomador { get; set; }

		public byte? Fl_AliquotaLocalPrestacao { get; set; }

		public int? Cd_TipoCalculo { get; set; }

		public decimal? Nr_GuiaUnificada { get; set; }

		public DateTime? Dt_cancelamento { get; set; }

		public decimal? Nr_AliquotaBeneficio { get; set; }

		public string? Ds_DescricaoPercentualImposto { get; set; }

        #endregion

        #region Relacionamentos

		public bool IncluirItens { get; set; }

        #endregion
    }
}
