﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrFilaSaidaFilter : FiltroBase
    {
        #region Propriedades

        public int? Id { get; set; }

		public decimal? Cd_NotaFiscal { get; set; }

		public int? FilaTipo { get; set; }

		public DateTime? EntradaDataHora { get; set; }

		public DateTime? EnvioDataHora { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
