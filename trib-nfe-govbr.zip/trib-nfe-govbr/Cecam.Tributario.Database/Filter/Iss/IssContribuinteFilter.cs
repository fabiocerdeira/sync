﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssContribuinteFilter : FiltroBase
    {
        #region Propriedades

        public string? Nr_CGCCPF { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
