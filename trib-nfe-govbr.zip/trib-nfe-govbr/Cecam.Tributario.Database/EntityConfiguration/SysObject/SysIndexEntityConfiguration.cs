﻿using Cecam.Tributario.Database.Entity.SysObject;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.SysObject
{
    public class SysIndexEntityConfiguration : IEntityTypeConfiguration<SysIndexEntity>
    {
        public void Configure(EntityTypeBuilder<SysIndexEntity> builder)
        {
            builder.ToTable("indexes", "sys");

            builder.HasNoKey();

            #region Propriedades

            builder.Property(x => x.Object_id).HasColumnName("Object_id");
            builder.Property(x => x.Name).HasColumnName("Name");
            builder.Property(x => x.Index_id).HasColumnName("Index_id");
            builder.Property(x => x.Is_primary_key).HasColumnName("Is_primary_key");

            #endregion

            #region Relacionamentos
            #endregion
        }
    }
}
