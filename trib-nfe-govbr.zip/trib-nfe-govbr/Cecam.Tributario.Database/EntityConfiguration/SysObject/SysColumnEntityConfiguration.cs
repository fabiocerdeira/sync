﻿using Cecam.Tributario.Database.Entity.SysObject;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.SysObject
{
    public class SysColumnEntityConfiguration : IEntityTypeConfiguration<SysColumnEntity>
    {
        public void Configure(EntityTypeBuilder<SysColumnEntity> builder)
        {
            builder.ToTable("columns", "sys");

            builder.HasNoKey();

            #region Propriedades

            builder.Property(x => x.Object_id).HasColumnName("object_id");
            builder.Property(x => x.Name).HasColumnName("name");
            builder.Property(x => x.Column_id).HasColumnName("column_id");
            builder.Property(x => x.System_type_id).HasColumnName("system_type_id");
            builder.Property(x => x.Max_length).HasColumnName("max_length");
            builder.Property(x => x.Precision).HasColumnName("precision");
            builder.Property(x => x.Scale).HasColumnName("scale");
            builder.Property(x => x.Is_nullable).HasColumnName("is_nullable");

            #endregion

            #region Relacionamentos
            #endregion
        }
    }
}
