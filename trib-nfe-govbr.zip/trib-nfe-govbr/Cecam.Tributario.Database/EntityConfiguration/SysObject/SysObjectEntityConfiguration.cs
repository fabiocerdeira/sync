﻿using Cecam.Tributario.Database.Entity.SysObject;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.SysObject
{
    public class SysObjectEntityConfiguration : IEntityTypeConfiguration<SysObjectEntity>
    {
        public void Configure(EntityTypeBuilder<SysObjectEntity> builder)
        {
            builder.ToTable("objects", "sys");

            builder.HasNoKey();

            #region Propriedades

            builder.Property(x => x.Object_id).HasColumnName("object_id");
            builder.Property(x => x.Name).HasColumnName("name");
            builder.Property(x => x.Type).HasColumnName("type");
            builder.Property(x => x.Type_Desc).HasColumnName("type_desc");

            #endregion

            #region Relacionamentos
            #endregion
        }
    }
}
