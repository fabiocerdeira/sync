﻿using Cecam.Tributario.Database.Entity.SysObject;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.SysObject
{
    public class SysIndexColumnEntityConfiguration : IEntityTypeConfiguration<SysIndexColumnEntity>
    {
        public void Configure(EntityTypeBuilder<SysIndexColumnEntity> builder)
        {
            builder.ToTable("index_columns", "sys");

            builder.HasNoKey();

            #region Propriedades

            builder.Property(x => x.Object_id).HasColumnName("object_id");
            builder.Property(x => x.Index_id).HasColumnName("index_id");
            builder.Property(x => x.Index_column_id).HasColumnName("index_column_id");
            builder.Property(x => x.Column_id).HasColumnName("column_id");

            #endregion

            #region Relacionamentos
            #endregion
        }
    }
}
