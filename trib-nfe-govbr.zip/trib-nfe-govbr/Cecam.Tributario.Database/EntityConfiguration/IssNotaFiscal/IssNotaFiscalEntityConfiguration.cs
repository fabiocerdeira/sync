﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.ISSNotaFiscal
{
    public class ISSNotaFiscalEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalEntity> builder)
        {
            builder.ToTable("ISSNotaFiscal");

			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_NotaFiscal
			});

            #region Propriedades

            builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_NotaFiscal).HasColumnName("cd_NotaFiscal").HasColumnType("decimal(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Cd_Referencia).HasColumnName("cd_Referencia");
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF");
			builder.Property(x => x.Cd_TipoDocumento).HasColumnName("cd_TipoDocumento");
			builder.Property(x => x.Nr_NotaFiscal).HasColumnName("nr_NotaFiscal").HasColumnType("decimal(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Cd_Situacao).HasColumnName("cd_Situacao");
			builder.Property(x => x.Dt_Emissao).HasColumnName("dt_Emissao");
			builder.Property(x => x.Nr_CGCCPFTomador).HasColumnName("nr_CGCCPFTomador").IsRequired(false);
			builder.Property(x => x.Ds_Observacao).HasColumnName("ds_Observacao").IsRequired(false);
			builder.Property(x => x.Nr_CGCCPFUsuarioCriacao).HasColumnName("nr_CGCCPFUsuarioCriacao");
			builder.Property(x => x.Dt_Criacao).HasColumnName("dt_Criacao");
			builder.Property(x => x.Nr_CGCCPFUsuarioAtualizacao).HasColumnName("nr_CGCCPFUsuarioAtualizacao").IsRequired(false);
			builder.Property(x => x.Dt_Atualizacao).HasColumnName("dt_Atualizacao").IsRequired(false);
			builder.Property(x => x.Nr_Certificado).HasColumnName("nr_Certificado").HasColumnType("decimal(18,0)").HasPrecision(18,0).IsRequired(false);
			builder.Property(x => x.Nr_NotaFiscalSubstituta).HasColumnName("nr_NotaFiscalSubstituta").HasColumnType("decimal(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Fl_LocalPrestacao).HasColumnName("fl_LocalPrestacao");
			builder.Property(x => x.Ds_LocalPrestacao).HasColumnName("ds_LocalPrestacao").IsRequired(false);
			builder.Property(x => x.Ds_LocalPrestacaoCompl).HasColumnName("ds_LocalPrestacaoCompl").IsRequired(false);
			builder.Property(x => x.Cd_Imovel).HasColumnName("cd_Imovel").HasColumnType("decimal(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Cd_CidadePrestacao).HasColumnName("cd_CidadePrestacao").HasColumnType("decimal(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Nm_Logradouro).HasColumnName("nm_Logradouro").IsRequired(false);
			builder.Property(x => x.Nr_Numero).HasColumnName("nr_Numero").IsRequired(false);
			builder.Property(x => x.Ds_Complemento).HasColumnName("ds_Complemento").IsRequired(false);
			builder.Property(x => x.Nm_Bairro).HasColumnName("nm_Bairro").IsRequired(false);
			builder.Property(x => x.Cd_CEP).HasColumnName("cd_CEP").IsRequired(false);
			builder.Property(x => x.Nr_Aviso).HasColumnName("nr_Aviso").IsRequired(false);
			builder.Property(x => x.Fl_PrestadorNaoInscrito).HasColumnName("fl_PrestadorNaoInscrito");
			builder.Property(x => x.Fl_Tomador).HasColumnName("fl_Tomador");
			builder.Property(x => x.Fl_Web).HasColumnName("fl_Web").IsRequired(false);
			builder.Property(x => x.Cd_Contribuinte).HasColumnName("Cd_Contribuinte").HasColumnType("decimal(18,0)").HasPrecision(18,0).IsRequired(false);
			builder.Property(x => x.Nr_ChaveValidacao).HasColumnName("nr_ChaveValidacao").IsRequired(false);
			builder.Property(x => x.Cd_RPS).HasColumnName("cd_RPS").IsRequired(false);
			builder.Property(x => x.Ds_MotivoCancelamento).HasColumnName("ds_MotivoCancelamento").IsRequired(false);
			builder.Property(x => x.Nr_Lote).HasColumnName("Nr_Lote");
			builder.Property(x => x.Cd_PreNota).HasColumnName("cd_PreNota").HasColumnType("decimal(18,0)").HasPrecision(18,0).IsRequired(false);
			builder.Property(x => x.Cd_Tomador).HasColumnName("cd_Tomador").HasColumnType("decimal(18,0)").HasPrecision(18,0).IsRequired(false);
			builder.Property(x => x.Fl_AliquotaLocalPrestacao).HasColumnName("fl_AliquotaLocalPrestacao");
			builder.Property(x => x.Cd_TipoCalculo).HasColumnName("cd_TipoCalculo").IsRequired(false);
			builder.Property(x => x.Nr_GuiaUnificada).HasColumnName("nr_GuiaUnificada").HasColumnType("decimal(20,0)").HasPrecision(20,0).IsRequired(false);
			builder.Property(x => x.Dt_cancelamento).HasColumnName("dt_cancelamento").IsRequired(false);
			builder.Property(x => x.Nr_AliquotaBeneficio).HasColumnName("nr_AliquotaBeneficio").HasColumnType("decimal(10,2)").HasPrecision(10,2).IsRequired(false);
			builder.Property(x => x.Ds_DescricaoPercentualImposto).HasColumnName("ds_DescricaoPercentualImposto").IsRequired(false);

            #endregion

            #region Relacionamentos

            builder.HasMany(x => x.Itens).WithOne(x => x.NotaFiscal);
            
			#endregion

        }
    }
}
