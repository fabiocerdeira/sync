﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.ISSNotaFiscal
{
    public class ISSNotaFiscalItemEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalItemEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalItemEntity> builder)
        {
            builder.ToTable("ISSNotaFiscalItem");

			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_NotaFiscal,
				 x.Cd_Servico
			});

            #region Propriedades

            builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_NotaFiscal).HasColumnName("cd_NotaFiscal").HasColumnType("decimal(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Cd_Servico).HasColumnName("cd_Servico");
			builder.Property(x => x.Cd_GrupoAtividade).HasColumnName("cd_GrupoAtividade");
			builder.Property(x => x.Cd_SubGrupoAtividade).HasColumnName("cd_SubGrupoAtividade");
			builder.Property(x => x.Cd_ItemAtividade).HasColumnName("cd_ItemAtividade");
			builder.Property(x => x.Vl_Item).HasColumnName("vl_Item").HasColumnType("decimal(18,4)").HasPrecision(18,4);
			builder.Property(x => x.Vl_Deducao).HasColumnName("vl_Deducao").HasColumnType("decimal(18,4)").HasPrecision(18,4);
			builder.Property(x => x.Pc_Aliquota).HasColumnName("pc_Aliquota").HasColumnType("decimal(10,4)").HasPrecision(10,4);
			builder.Property(x => x.Vl_Tomado).HasColumnName("vl_Tomado").HasColumnType("decimal(18,4)").HasPrecision(18,4);
			builder.Property(x => x.Fl_Retido).HasColumnName("fl_Retido");
			builder.Property(x => x.Fl_Exportado).HasColumnName("fl_Exportado");
			builder.Property(x => x.Cd_Pais).HasColumnName("cd_Pais").IsRequired(false);
			builder.Property(x => x.Nr_Quantidade).HasColumnName("nr_Quantidade").IsRequired(false);
			builder.Property(x => x.Cd_Unidade).HasColumnName("cd_Unidade").IsRequired(false);
			builder.Property(x => x.Ds_ItemServico).HasColumnName("ds_ItemServico").IsRequired(false);
			builder.Property(x => x.Vl_BaseCalculo).HasColumnName("vl_BaseCalculo").HasColumnType("decimal(18,4)").HasPrecision(18,4).IsRequired(false);
			builder.Property(x => x.Vl_DevidoItem).HasColumnName("vl_DevidoItem").HasColumnType("decimal(18,4)").HasPrecision(18,4).IsRequired(false);
			builder.Property(x => x.Vl_Devido).HasColumnName("vl_Devido").HasColumnType("decimal(34,12)").HasPrecision(34,12).IsRequired(false);

            #endregion

            #region Relacionamentos

            builder.HasOne(x => x.NotaFiscal).WithMany(x => x.Itens).HasForeignKey(x => new { x.Cd_Cecam, x.Cd_NotaFiscal });

            #endregion
        }
    }
}
