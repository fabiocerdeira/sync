﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssContribuinteEntityConfiguration : IEntityTypeConfiguration<IssContribuinteEntity>
    {
        public void Configure(EntityTypeBuilder<IssContribuinteEntity> builder)
        {
            builder.ToTable("ISSContribuintes");


            builder.HasKey(x => new {
                x.Cd_Cecam,
                x.Cd_Contribuinte
            });


            #region Propriedades

            // --------------------------------------------------------------
            // Pk
            builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
            builder.Property(x => x.Cd_Contribuinte).HasColumnName("Cd_Contribuinte").HasColumnType("decimal(10,0)").HasPrecision(10, 0);

            // --------------------------------------------------------------
            builder.Property(x => x.Cd_Exercicio).HasColumnName("Cd_Exercicio");
            builder.Property(x => x.Cd_TipoImposto).HasColumnName("Cd_TipoImposto").IsRequired(false);
            builder.Property(x => x.Cd_TipoCalculo).HasColumnName("Cd_TipoCalculo").IsRequired(false);
            builder.Property(x => x.Cd_Estimado).HasColumnName("Cd_Estimado").IsRequired(false);
            builder.Property(x => x.Cd_Periodo).HasColumnName("Cd_Periodo").IsRequired(false);
            builder.Property(x => x.Ds_Inscricao_Municipal).HasColumnName("Ds_Inscricao_Municipal");
            builder.Property(x => x.Cd_Conselho_Regional).HasColumnName("Cd_Conselho_Regional").IsRequired(false);
            builder.Property(x => x.cd_Imovel).HasColumnName("cd_Imovel").HasColumnType("decimal(10,0)").HasPrecision(10, 0);
            builder.Property(x => x.Cd_Logradouro).HasColumnName("Cd_Logradouro").IsRequired(false);
            builder.Property(x => x.Cd_Bairro).HasColumnName("Cd_Bairro").IsRequired(false);
            builder.Property(x => x.Cd_Trecho).HasColumnName("Cd_Trecho").IsRequired(false);
            builder.Property(x => x.cd_Contador).HasColumnName("cd_Contador").IsRequired(false);
            builder.Property(x => x.Ds_RazaoSocial).HasColumnName("Ds_RazaoSocial").IsRequired(false);
            builder.Property(x => x.Ds_Fantasia).HasColumnName("Ds_Fantasia").IsRequired(false);
            builder.Property(x => x.Cd_Numero).HasColumnName("Cd_Numero").IsRequired(false);
            builder.Property(x => x.Ds_Complemento).HasColumnName("Ds_Complemento").IsRequired(false);
            builder.Property(x => x.Ds_Andar).HasColumnName("Ds_Andar").IsRequired(false);
            builder.Property(x => x.Ds_Apto).HasColumnName("Ds_Apto").IsRequired(false);
            builder.Property(x => x.Cd_LogradouroCorr).HasColumnName("Cd_LogradouroCorr").IsRequired(false);
            builder.Property(x => x.Ds_TipoLogradouroCorr).HasColumnName("Ds_TipoLogradouroCorr").IsRequired(false);
            builder.Property(x => x.Ds_EnderCorr).HasColumnName("Ds_EnderCorr").IsRequired(false);
            builder.Property(x => x.Cd_NumCorr).HasColumnName("Cd_NumCorr").IsRequired(false);

            /*

             faltam vários outros campos dessa tabela

            */

            builder.Property(x => x.Nr_CGCCPF).HasColumnName("Nr_CGCCPF").IsRequired(false);
            builder.Property(x => x.Ds_Obs).HasColumnName("Ds_Obs").IsRequired(false);
            builder.Property(x => x.Dt_AberturaEmpresa).HasColumnName("Dt_AberturaEmpresa").IsRequired(false);

            #endregion

            #region Relacionamentos
            #endregion
        }
    }
}
