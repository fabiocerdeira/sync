﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr
{
    public interface IIssNotaFiscalGovBrFilaSaidaRepository : IRepository<IssNotaFiscalGovBrFilaSaidaEntity>
    {
    }
}
