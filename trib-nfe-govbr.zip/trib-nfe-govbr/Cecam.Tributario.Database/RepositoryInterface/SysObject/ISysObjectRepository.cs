﻿using Cecam.Tributario.Database.Entity.SysObject;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.SysObject
{
    public interface ISysObjectRepository : IRepository<SysObjectEntity>
    {
    }
}
