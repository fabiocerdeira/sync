﻿using Cecam.Tributario.Database.Repository.Iss;
using Cecam.Tributario.Database.Repository.IssNotaFiscal;
using Cecam.Tributario.Database.Repository.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Repository.SysObject;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.SysObject;
using Microsoft.Extensions.DependencyInjection;

namespace Cecam.Tributario.Database.Dependency
{
    public static class RepositoryDI
    {
        public static IServiceCollection RepositoryAddServices(this IServiceCollection services)
        {
            // repositorios

            // ISS
            services.AddTransient<IIssContribuinteRepository>(p => { return new IssContribuinteRepository(); });

            services.AddTransient<IIssNotaFiscalRepository>(p => { return new ISSNotaFiscalRepository(); });
            services.AddTransient<IIssNotaFiscalItemRepository>(p => { return new ISSNotaFiscalItemRepository(); });

            services.AddTransient<IIssNotaFiscalGovBrFilaEntradaRepository>(p => { return new IssNotaFiscalGovBrFilaEntradaRepository(); });
            services.AddTransient<IIssNotaFiscalGovBrFilaSaidaRepository>(p => { return new IssNotaFiscalGovBrFilaSaidaRepository(); });


            // SysObject
            services.AddTransient<ISysColumnRepository>(p => { return new SysColumnRepository(); });
            services.AddTransient<ISysObjectRepository>(p => { return new SysObjectRepository(); });
            services.AddTransient<ISysIndexRepository>(p => { return new SysIndexRepository(); });
            services.AddTransient<ISysIndexColumnRepository>(p => { return new SysIndexColumnRepository(); });

            return services;
        }
    }
}
