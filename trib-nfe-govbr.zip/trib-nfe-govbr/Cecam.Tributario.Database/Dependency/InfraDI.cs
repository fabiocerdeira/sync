﻿using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Dependency
{
    public static class InfraDI
    {
        public static IServiceCollection InfraAddServices(this IServiceCollection services)
        {
            /*
             AddSingleton
                - web = sempre mesmo objeto em todas as sessões e requisições ao servidor
                - console = mesmo objeto para cada vez que iniciar a dll

             AddTransient
                - web e console = sempre uma NOVA instancia do objeto mesmo dentro da mesma sessão de usuario

             AddScoped
                - web = mesmo objeto para cada sessão de usuario
                - console = mesmo objeto para cada vez que iniciar a dll
             */

            // interfaces para injeção de dependências.
            services.AddTransient<ITributosContext, TributosContext>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();

            return services;
        }


        public static IServiceCollection InfraAddContext(this IServiceCollection services, IConfiguration _configuration)
        {
            // montar string de conexão com o banco de dados
            var server = _configuration["ConnectionStrings:Server"];
            var database = _configuration["ConnectionStrings:Database"];
            string connectionString = $"Server={server};Database={database};User Id=CECAMAdmin;Password=4667FA51647FDA07894A8E1150A2C8FF;TrustServerCertificate=True";
            // string connectionString = $"Server={server};Database={database};Integrated Security = SSPI; Persist Security Info = False";

            // services.AddDbContextPool<DbContexto>( ====> versão FMC com pool de conexao ao bd
            // services.AddDbContext<DbContexto>( =====>> versão original SEM pool de conexao

            services.AddDbContext<TributosContext>(
                dbContextOptions => dbContextOptions
                    .UseSqlServer(connectionString, o => o.UseCompatibilityLevel(120))
#if DEBUG
                    // The following three options help with debugging, but should
                    // be changed or removed for production.
                    .LogTo(Console.WriteLine, LogLevel.Information)
                    .EnableSensitiveDataLogging()
                    .EnableDetailedErrors()
#endif
            );

            return services;
        }
    }
}
