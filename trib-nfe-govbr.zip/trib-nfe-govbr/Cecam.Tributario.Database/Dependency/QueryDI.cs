﻿using Cecam.Tributario.Database.Query.Iss;
using Cecam.Tributario.Database.Query.IssNotaFiscal;
using Cecam.Tributario.Database.Query.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Microsoft.Extensions.DependencyInjection;

namespace Cecam.Tributario.Database.Dependency
{
    public static class QueryDI
    {
        public static IServiceCollection QueryAddServices(this IServiceCollection services)
        {
            // queries 
            services.AddTransient<IIssContribuinteQuery, IssContribuinteQuery>();
            services.AddTransient<IIssNotaFiscalQuery, IssNotaFiscalQuery>();
            services.AddTransient<IIssNotaFiscalGovBrFilaEntradaQuery, IssNotaFiscalGovBrFilaEntradaQuery>();
            services.AddTransient<IIssNotaFiscalGovBrFilaSaidaQuery, IssNotaFiscalGovBrFilaSaidaQuery>();

            return services;
        }
    }
}
