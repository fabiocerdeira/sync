﻿namespace Cecam.Tributario.Database.Enumerado
{
    public static class IssNotaFiscalGovBrEnum
    {
        public const int FilaTipo_EMISSAO_NF = 1;
        public const int FilaTipo_CANCELAMENTO_NF = 2;


        public const int Status_Aguardando_Processar = 0;
        public const int Status_Processado_Erro = 1;
    }
}
