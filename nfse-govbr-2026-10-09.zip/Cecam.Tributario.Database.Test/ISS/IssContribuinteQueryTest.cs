﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.Test.Preparacao;
using Cecam.Tributario.Extend.Globals;
using MockQueryable;

namespace Cecam.Tributario.Database.Test.Iss
{
    [TestClass]
    public class IssContribuinteQueryTest : TestBase
    {
        private List<IssContribuinteEntity> _issContribuinteDatabase = new List<IssContribuinteEntity>();


        private void MockDataBase()
        {
            _issContribuinteDatabase.Add(new IssContribuinteEntity()
            {
                Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                Cd_Contribuinte = 1,
                Cd_Exercicio = DateTime.UtcNow.Year,
                Nr_CGCCPF = "98765432000198",
                Ds_inscricao_municipal = "inscricao-municipal",
                Ds_razaosocial = "Razão social mocada",
                Ds_fantasia = "Nome fantasia",

                Cd_Bairro = 1,
                Bairro = new Entity.Endereco.CecamBairroEntity
                {
                    Cd_Bairro = 1,
                    Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                    Ds_Bairro = "descrição do bairro",
                },
                Sg_Estado = "SP",
                Ds_Cidade = "cidade cecam",

                Dt_AberturaEmpresa = DateTime.UtcNow.AddYears(-1),
                Dt_cadastrobanco = DateTime.UtcNow.AddYears(-1),
                Dt_inicio_ativ = DateTime.UtcNow.AddYears(-1),
            });

            _issContribuinteDatabase.Add(new IssContribuinteEntity()
            {
                Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                Cd_Contribuinte = 2,
                Cd_Exercicio = DateTime.UtcNow.Year - 2,
                Nr_CGCCPF = "222.404.505-05",
                Ds_razaosocial = "Razão social #2 mocada"
            });

            var issContribuinteDatabaseMock = _issContribuinteDatabase.BuildMock();

            _issContribuinteRepositorioMock.Setup(x => x.GetIQueryable()).Returns(issContribuinteDatabaseMock);
        }


        [TestMethod]
        public async Task Listar_Filter_Sucesso()
        {
            // arrange
            MockDataBase();

            // act
            var query = ServiceProviderGlobal.GetServico<IIssContribuinteQuery>();

            var lista = await query.Listar(new IssContribuinteFilter()
            {
                Cd_Exercicio = DateTime.UtcNow.Year,
                AsNoTracking = true,
                QtdMaximaRegistrosRetornados = 10,
            });

            // assert
            Assert.IsNotNull(lista);
            Assert.AreEqual(1, lista.Count);
        }
    }
}
