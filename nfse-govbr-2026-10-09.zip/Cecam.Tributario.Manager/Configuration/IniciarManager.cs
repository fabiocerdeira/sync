﻿using Cecam.Tributario.Database.Configuration;
using Cecam.Tributario.Extend.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Configuration
{
    public static class IniciarManager
    {
        public static void Iniciar()
        {
            // Criar o configuration do extend.
            IniciarExtend.Create();

            // configurar DI para objetos de negocio
            // services.BusinessAddServices();

            // iniciar a biblioteca de base de dados.
            IniciarDatabase.Iniciar();

            // build do configuration
            IniciarExtend.Build();
        }
    }
}
