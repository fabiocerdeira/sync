﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Manager.Api.Request.NfseGovBr.Sefin;
using Cecam.Tributario.Manager.Api.Response.External;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Sefin;
using Microsoft.Extensions.Logging;
using System.Security.Authentication;
using System.Text;

namespace Cecam.Tributario.Manager.External.NfseGovBr
{
    internal class NfseGovBrSefinNacionalExternal
    {
        #region Declarações


        private readonly ILogger<NfseGovBrSefinNacionalExternal> _logger;
        private readonly HttpClient _httpClient;


        public NfseGovBrSefinNacionalExternal()
        {
            // logger
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrSefinNacionalExternal>();

            // parametros do httpClient
            var httpClientHandler = new HttpClientHandler();

            // versão do protocolo ssl.
            httpClientHandler.SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13;

            // para evitar certificados seguros inválidos.
            httpClientHandler.ClientCertificateOptions = ClientCertificateOption.Manual;
            httpClientHandler.ServerCertificateCustomValidationCallback = (httpRequestMessage, cert, cetChain, policyErrors) => { return true; };
            httpClientHandler.CheckCertificateRevocationList = false;

            // incluir o certificado seguro no header
            var certificadoHelp = new X509CertificateHelper();
            var certificadoSeguro = certificadoHelp.GetCertificate();
            if (certificadoSeguro != null)
                httpClientHandler.ClientCertificates.Add(certificadoSeguro);

            // novo httpClient
            _httpClient = new HttpClient(httpClientHandler);
            _httpClient.BaseAddress = new Uri(ParametrosGlobal.NfseGovBr_Sefin_Url);
            _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("CecamApp/1.0");

            // web-api-key
            _httpClient.DefaultRequestHeaders.Add("X-API-KEY", ParametrosGlobal.WebApiKey);
            // _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("X-API-KEY", ParametrosGlobal.WebApiKey);

            // time out em produção
            _httpClient.Timeout = TimeSpan.FromMinutes(5);

#if DEBUG
            // time out em desenvolvimento
            _httpClient.Timeout = TimeSpan.FromHours(1);
#endif
        }


        #endregion


        /// <summary>
        /// Recuperar o corpo da NFSe em formato de objeto a partir do servidor gov.br, utilizando a chava de acesso para encontrar a NFSe
        /// </summary>
        public async Task<ExternalBaseResponse<NfseGovBrSefinExternalNfseConsultarResponse>> NfseConsultar(string chaveAcesso)
        {
            // log inicio
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.NfseConsultar() - Inicio");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrSefinExternalNfseConsultarResponse>();

            try
            {
                // verificar se temos chave de acesso?
                if (string.IsNullOrWhiteSpace(chaveAcesso))
                    throw new Exception("'ChaveAcesso' informada esta vázia então não pode ser enviado para Gov.Br");

                // log inicio
                _logger.LogDebug($"NfseGovBrSefinNacionalExternal.NfseConsultar().GetAsync('{_httpClient.BaseAddress}SefinNacional/nfse/{chaveAcesso}')");

                // recuperar nfse pela chave de acesso
                var respostaApi = await _httpClient.GetAsync($"SefinNacional/nfse/{chaveAcesso}");

                // verificar se recebeu resposta?
                if (respostaApi == null)
                    throw new Exception("Erro no servidor gov.br sem resposta");

                // resposta da API copiada para resposta desse método
                retornoExternal.StatusCode = (int)respostaApi.StatusCode;

                // corpo retornado
                var jsonResult = await respostaApi.Content.ReadAsStringAsync();

                // verificar se temos corpo na resposta?
                if (string.IsNullOrWhiteSpace(jsonResult))
                    throw new Exception("Conteudo da resposta do servidor gov.br esta em branco");

                try
                {
                    if (respostaApi.IsSuccessStatusCode)
                    {
                        // converter de string json para objeto
                        retornoExternal.Item = new NfseGovBrSefinExternalNfseConsultarResponse();
                        retornoExternal.Item.Item = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrSefinNfseConsultarResponse>(jsonResult);

                        // verificar se converteu com sucesso 
                        if (retornoExternal.Item == null || 
                            retornoExternal.Item.Item == null ||
                            string.IsNullOrWhiteSpace(retornoExternal.Item.Item.NfseXmlGZipB64))
                            throw new Exception("Resposta do gov.br em branco");

                        /*
                        // descompactar campo resposta.Item.NfseXmlGZipB64 com a xml da Nfse
                        using (var rgziped = new MemoryStream(Encoding.UTF8.GetBytes("" + retornoExternal.Item.Item.NfseXmlGZipB64)))
                        {
                            using (var cryptoStream = new CryptoStream(rgziped, new FromBase64Transform(), CryptoStreamMode.Read))
                            {
                                using (var gzip = new GZipStream(cryptoStream, CompressionMode.Decompress))
                                {
                                    using (var streamReader = new StreamReader(gzip, Encoding.UTF8))
                                    {
                                        // colocar xml no formato string no objeto de retorno
                                        retornoExternal.Item.NfseFormatoXmlString = streamReader.ReadToEnd();
                                    }
                                }
                            }
                        }
                        */

                        // descompactar campo resposta.Item.NfseXmlGZipB64 com a xml da Nfse
                        var gzip = new GZipHelper();
                        retornoExternal.Item.NfseFormatoXmlString = gzip.DescompactarBase64ToString("" + retornoExternal.Item.Item.NfseXmlGZipB64);
                    }
                    else
                    {
                        // converter de string json para objeto
                        retornoExternal.Item = new NfseGovBrSefinExternalNfseConsultarResponse();
                        retornoExternal.Item.Erro = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrErroResponse>(jsonResult);
                    }
                }
                catch (Exception ex)
                {
                    // não consegue converter do json para objeto tipado, então retornar em forma de string.
                    throw new Exception(jsonResult, ex);
                }
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrSefinNacionalExternal.NfseConsultar()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log fim
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.NfseConsultar() - Fim");

            // valor retornado pelo método
            return retornoExternal;
        }


        #region Eventos


        /// <summary>
        /// Enviar um evento de NFSe para o servidor gov.br
        /// </summary>
        public async Task<ExternalBaseResponse<NfseGovBrSefinExternalEventoEnviarResponse>> NfseEventosEnviar(string chaveAcesso, string corpoXml)
        {
            // log inicio
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.NfseEventosEnviar() - Inicio");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrSefinExternalEventoEnviarResponse>();

            try
            {
                // verificar se temos o parametro com a chave de acesso da NFSe que esta recebendo o evento?
                if (string.IsNullOrWhiteSpace(chaveAcesso))
                    throw new Exception("'ChaveAcesso' esta vázio então não pode ser enviado para a Sefin do Gov.Br");

                // verificar se temos o parametro com o corpo do evento da NFSe?
                if (string.IsNullOrWhiteSpace(corpoXml))
                    throw new Exception("'CorpoXml' esta vázio então não pode ser enviado para a Sefin do Gov.Br");

                // compactar corpo
                var gzip = new GZipHelper();

                // request com o evento (zipado em base64)
                var request = new NfseGovBrSefinEventoEnviarRequest()
                {
                    PedidoRegistroEventoXmlGZipB64 = gzip.CompactarStringTobase64(corpoXml)
                };

                // converter objeto em json
                string jsonRequest = Newtonsoft.Json.JsonConvert.SerializeObject(request);

                // corpo que será enviado.
                var corpoEnviar = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                // envio
                var respostaApi = await _httpClient.PostAsync($"nfse/{chaveAcesso}/eventos", corpoEnviar);

                // verificar se recebeu resposta?
                if (respostaApi == null)
                    throw new Exception("Erro no servidor gov.br sem resposta");

                // resposta da API copiada para resposta desse método
                retornoExternal.StatusCode = (int)respostaApi.StatusCode;
                retornoExternal.Item = new NfseGovBrSefinExternalEventoEnviarResponse();

                // corpo retornado
                var respostaCorpo = await respostaApi.Content.ReadAsStringAsync();

                // verificar se temos corpo na resposta?
                if (string.IsNullOrWhiteSpace(respostaCorpo))
                    throw new Exception("Conteudo da resposta do servidor gov.br esta em branco");

                try
                {
                    // verificar se temos sucesso ao nivel de https?
                    if (respostaApi.IsSuccessStatusCode)
                    {
                        // converter de string json para objeto
                        retornoExternal.Item.EventoEnviado = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrSefinEventoEnviarResponse>(respostaCorpo);

                        // verificar se temos a xml de resposta?
                        if (retornoExternal.Item.EventoEnviado == null || retornoExternal.Item.EventoEnviado.EventoXmlGZipB64 == null)
                            throw new Exception("EventoXML do conteudo da resposta do servidor gov.br esta em branco");

                        // descompactar campo resposta.Item.NfseXmlGZipB64 com a xml da Nfse
                        retornoExternal.Item.EventoEnviado.EventoXml = gzip.DescompactarBase64ToString(retornoExternal.Item.EventoEnviado.EventoXmlGZipB64);

                        // marcar como sucesso
                        retornoExternal.Sucesso = true;
                    }
                    else
                    {
                        // converter de string json para objeto
                        retornoExternal.Item.ErroDetails = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrErroResponse>(respostaCorpo);
                    }
                }
                catch (Exception ex)
                {
                    // não consegue converter do json para objeto tipado, então retornar em forma de string.
                    throw new Exception(respostaCorpo, ex);
                }
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrSefinNacionalExternal.NfseEventosEnviar()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log final
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.NfseEventosEnviar() - Fim com sucesso");

            // valor retornado pelo método
            return retornoExternal;
        }


        /// <summary>
        /// Recuperar os eventos da NFSe em formato de objeto a partir do servidor gov.br
        /// </summary>
        public async Task<ExternalBaseResponse<NfseGovBrDfeResponse>> NfseEventosConsultar(string chaveAcesso)
        {
            // log inicio
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.NfseEventosConsultar() - Inicio");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrDfeResponse>();

            try
            {
                // verificar se temos o parametro chaveAcesso?
                if (string.IsNullOrWhiteSpace(chaveAcesso))
                    throw new Exception("Campo 'chaveAcesso' precia ser informado");

                // consultar api externa do gov.br
                var respostaApi = await _httpClient.GetAsync($"nfse/{chaveAcesso}/eventos");

                // verificar se recebeu resposta?
                if (respostaApi == null)
                    throw new Exception("Erro no servidor gov.br sem resposta");

                // resposta da API copiada para resposta desse método
                retornoExternal.StatusCode = (int)respostaApi.StatusCode;

                // corpo retornado pela api externa do gov.br
                var respostaCorpo = await respostaApi.Content.ReadAsStringAsync();

                // verificar se temos corpo na resposta?
                if (string.IsNullOrWhiteSpace(respostaCorpo))
                    throw new Exception("Conteudo da resposta do servidor gov.br esta em branco");

                try
                {
                    // verificar se temos sucesso ao nivel de https?
                    if (respostaApi.IsSuccessStatusCode)
                    {
                        // converter de string json para objeto
                        retornoExternal.Item = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrDfeResponse>(respostaCorpo);

                        // verificar se temos a DFE de resposta?
                        if (retornoExternal.Item == null)
                            throw new Exception("DFE do conteudo da resposta do servidor gov.br esta em branco");

                        // marcar como sucesso
                        retornoExternal.Sucesso = true;
                    }
                    else
                    {
                        // resposta da api foi SEM sucesso.
                        throw new Exception("Resposta do servidor gov.br sem sucesso");
                    }
                }
                catch (Exception ex)
                {
                    // não consegue converter do json para objeto tipado, então retornar em forma de string.
                    throw new Exception(respostaCorpo, ex);
                }
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrSefinNacionalExternal.NfseEventosConsultar()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log final
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.NfseEventosConsultar() - Fim com sucesso");

            // valor retornado pelo método
            return retornoExternal;
        }


        #endregion


        /// <summary>
        /// Consultar a Danfse de uma determinada NFSe do site gov.br
        /// Retorna a Danfse como Base64 de um pdf.
        /// </summary>
        public async Task<ExternalBaseResponse<string>> DanfseConsultar(string chaveAcesso)
        {
            // log inicio
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.ConsultarDanfseAsBase64Pdf() - Inicio");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<string>();

            try
            {
                // verificar se temos chave de acesso?
                if (string.IsNullOrWhiteSpace(chaveAcesso))
                   throw new Exception("'ChaveAcesso' informada esta vázia então não pode ser enviado para Gov.Br");

                // recuperar nfse pela chave de acesso
                var respostaApi = await _httpClient.GetAsync($"danfse/{chaveAcesso}");

                // verificar se recebeu resposta?
                if (respostaApi == null)
                    throw new Exception("Erro no servidor gov.br sem resposta");

                // resposta da API copiada para resposta desse método
                retornoExternal.StatusCode = (int)respostaApi.StatusCode;

                // recuperar o corpo
                var respostaCorpo = await respostaApi.Content.ReadAsStringAsync();

                // verificar se temos corpo na resposta?
                if (string.IsNullOrWhiteSpace(respostaCorpo))
                    throw new Exception("Conteudo da resposta do servidor gov.br esta em branco");

                try
                {
                    if (respostaApi.IsSuccessStatusCode)
                    {
                        // objeto helper para base64
                        // resposta da API copiada para resposta desse método
                        // retornoExternal.Item = new Base64Helper().DecodeBase64ToString(respostaCorpo);
                        retornoExternal.Item = respostaCorpo;
                        retornoExternal.Sucesso = true;
                    }
                    else
                    {
                        // resposta da api foi SEM sucesso.
                        throw new Exception("Resposta do servidor gov.br sem sucesso");
                    }
                }
                catch (Exception ex)
                {
                    // não consegue converter do json para objeto tipado, então retornar em forma de string.
                    throw new Exception(respostaCorpo, ex);
                }
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrSefinNacionalExternal.ConsultarDanfseAsBase64Pdf()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log fim
            _logger.LogDebug("NfseGovBrSefinNacionalExternal.ConsultarDanfseAsBase64Pdf() - Fim");

            // valor retornado pelo método
            return retornoExternal;
        }
    }
}
