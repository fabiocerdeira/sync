﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Manager.Api.Request.NfseGovBr.Adn;
using Cecam.Tributario.Manager.Api.Response.External;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Adn.Dfe;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Security.Authentication;
using System.Text;

namespace Cecam.Tributario.Manager.External.NfseGovBr
{
    internal class NfseGovBrAdnExternal
    {
        #region Declarações


        public enum eTipoNsu
        {
            Distribuicao = 1,
            Recepcao = 2,
            Geral = 3,
            MEI = 4
        }


        private readonly ILogger<NfseGovBrAdnExternal> _logger;
        private readonly HttpClient _httpClient;


        public NfseGovBrAdnExternal()
        {
            // logger
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrAdnExternal>();

            // parametros do httpClient
            var httpClientHandler = new HttpClientHandler();

            // versão do protocolo ssl.
            httpClientHandler.SslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13;

            // para evitar certificados seguros inválidos.
            httpClientHandler.ClientCertificateOptions = ClientCertificateOption.Manual; 
            // httpClientHandler.ServerCertificateCustomValidationCallback = (httpRequestMessage, cert, cetChain, policyErrors) => { return true; };
            // httpClientHandler.CheckCertificateRevocationList = false;
            httpClientHandler.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;

            // incluir o certificado seguro no header
            var certificadoHelp = new X509CertificateHelper();

            // versão mais completa de carregamento do certificado
            // carrega do registro do windows, usando thumbPrint
             var certificadoSeguro = certificadoHelp.GetCertificate();

            // versão que funciona com sucesso, mas somente carrega do arquivo .PFX do disco.
            // var certificadoSeguro = certificadoHelp.GetCertificatOldLoad(); 

            // validar carregamento do certificado
            if (certificadoSeguro == null)
                throw new Exception("Certificado digital da prefeitura não foi encontrado no servidor da prefeitura, então nenhuma NFSe pode ser baixada. Por favor corrigir.");

            // data de expiração do certificado seguro da prefeitura
            _logger.LogDebug($"NfseGovBrAdnExternal.NfseGovBrAdnExternal() - Certificado seguro prefeitura .pfx data expiração = {certificadoSeguro.NotAfter}");

            // incluir o certificado digital na chamada http.
            httpClientHandler.ClientCertificates.Add(certificadoSeguro);

            // novo httpClient
            _httpClient = new HttpClient(httpClientHandler);
            _httpClient.BaseAddress = new Uri(ParametrosGlobal.NfseGovBr_Adn_Url);
            _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("CecamApp/1.0.0");

            // Ip de origem
            var meuIp = new MeuIpHelper();
            _httpClient.DefaultRequestHeaders.Add("X-Forwarded-For", meuIp.RetornarMeuIp());

            // certificado digital (novamente pq gov.br é burro e pede o mesmo certificado em 3 lugares diferentes)
            _httpClient.DefaultRequestHeaders.Add("X-SSL-Client-Cert", certificadoSeguro.GetRawCertDataString());

            // web-api-key
            _httpClient.DefaultRequestHeaders.Add("X-API-KEY", ParametrosGlobal.WebApiKey);
            // _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("X-API-KEY", ParametrosGlobal.WebApiKey);

            // time out em produção
            _httpClient.Timeout = TimeSpan.FromMinutes(5);

#if DEBUG
            // time out em desenvolvimento
            _httpClient.Timeout = TimeSpan.FromHours(1);
#endif
        }


        #endregion


        /// <summary>
        /// Enviar uma única NFSe para o gov.br
        /// Mas internamente é possível enviar um lote com várias NFSe, porem da muito trabalho por conta dos retornos que tmb devem ser separados para cada NFSe.
        /// Vou deixar assim como único para facilitar o momento atual do projeto.
        /// </summary>
        public async Task<ExternalBaseResponse<NfseGovBrAdnExternalDfeEnviarResponse>> DfeEnviar(string corpoNfse)
        {
            // log inicio
            _logger.LogDebug("NfseGovBrAdnExternal.DfeEnviar() - Inicio");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrAdnExternalDfeEnviarResponse>();

            try
            {
                // verificar se temos o parametro com o corpo da nota fiscal?
                if (string.IsNullOrWhiteSpace(corpoNfse))
                    throw new Exception("'CorpoNfse' esta vázio então não pode ser enviado para a ADN do Gov.Br");

                /*
                // compactar corpo
                var gziped = new MemoryStream();

                using (var gzip = new GZipStream(gziped, CompressionMode.Compress))
                    gzip.Write(Encoding.UTF8.GetBytes(corpoNfse));

                var dpsXmlGZipB64 = Convert.ToBase64String(gziped.ToArray());
                */

                // compactar corpo
                var gzip = new GZipHelper();

                // request com os varios lotes (cada um deles zipados em base64)
                // no momento só enviamos um único corpo embora o endpoint pode receber vários em lote/lista
                var request = new DfeEnviarRequest()
                {
                    LoteXmlGZipB64 = new List<string>()
                    {
                        // { dpsXmlGZipB64 }
                        { gzip.CompactarStringTobase64(corpoNfse) }
                    }
                };

                // converter objeto em json
                string jsonRequest = Newtonsoft.Json.JsonConvert.SerializeObject(request);

                // corpo que será enviado.
                var corpoEnviar = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                // envio
                var respostaApi = await _httpClient.PostAsync("dfe", corpoEnviar);

                // verificar se recebeu resposta?
                if (respostaApi == null)
                    throw new Exception("Erro no servidor gov.br sem resposta");

                // resposta da API copiada para resposta desse método
                retornoExternal.StatusCode = (int)respostaApi.StatusCode;
                retornoExternal.Item = new NfseGovBrAdnExternalDfeEnviarResponse();

                // corpo retornado
                var respostaCorpo = await respostaApi.Content.ReadAsStringAsync();

                // verificar se temos corpo na resposta?
                if (string.IsNullOrWhiteSpace(respostaCorpo))
                    throw new Exception("Conteudo da resposta do servidor gov.br esta em branco");

                try
                {
                    // verificar se temos sucesso ao nivel de https?
                    if (respostaApi.IsSuccessStatusCode)
                    {
                        // converter de string json para objeto
                        retornoExternal.Item.DfeRecepcaoLote = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrAdnDfeResponse>(respostaCorpo);

                        // verificar se temos a xml de resposta?
                        if (retornoExternal.Item.DfeRecepcaoLote == null)
                            throw new Exception("DfeRecepcaoLote do conteudo da resposta do servidor gov.br esta em branco");

                        // marcar como sucesso
                        retornoExternal.Sucesso = true;
                    }
                    else
                    {
                        // converter de string json para objeto
                        retornoExternal.Item.ProblemDetails = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrProblemDetailsResponse>(respostaCorpo);
                    }
                }
                catch (Exception ex)
                {
                    // não consegue converter do json para objeto tipado, então retornar em forma de string.
                    throw new Exception(respostaCorpo, ex);
                }
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrAdnExternal.DfeEnviar()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log final
            _logger.LogDebug("NfseGovBrAdnExternal.DfeEnviar() - Fim com sucesso");

            // valor retornado pelo método
            return retornoExternal;
        }



        /// <summary>
        /// Retornar um lote contendo até 50 Documentos Fiscais de Servico a partir da NSU informada. Sem incluir a própria NSU.
        /// </summary>
        /// <param name="nsuInicial">o primeiro é 0 (zero)</param>
        /// <param name="tipoNsu">DISTRIBUICAO, RECEPCAO, GERAL, MEI</param>
        /// <param name="lote">true/false</param>
        public async Task<ExternalBaseResponse<NfseGovBrDfeResponse>> MunicipiosDfeConsultar(long nsuInicial, eTipoNsu tipoNsu, bool lote = true)
        {
            // log inicio
            _logger.LogDebug($"NfseGovBrAdnExternal.MunicipiosDfeConsultar() - Inicio nsuInicial {nsuInicial} tipoNsu {tipoNsu} lote {lote}");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrDfeResponse>();

            try
            {
                // verificar se temos o parametro nsu?
                if (nsuInicial < 0)
                    throw new Exception("Campo 'Nsu' precia ser informado");
               
                // tipo Nsu usado na url é no formato texto
                var tipoNsuTexto = "DISTRIBUICAO";
                switch (tipoNsu)
                {
                    case eTipoNsu.Distribuicao:
                        tipoNsuTexto = "DISTRIBUICAO";
                        break;
                    case eTipoNsu.Recepcao:
                        tipoNsuTexto = "RECEPCAO";
                        break;
                    case eTipoNsu.Geral:
                        tipoNsuTexto = "GERAL";
                        break;
                    case eTipoNsu.MEI:
                        tipoNsuTexto = "MEI";
                        break;
                    default:
                        throw new Exception("Campo 'tipoNsu' precia ser informado");
                }

                // consultar api externa do gov.br
                retornoExternal = await MunicipiosConsultarProcessar($"municipios/dfe/{nsuInicial}?tipoNSU={tipoNsuTexto}&lote={lote}");
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrAdnExternal.MunicipiosDfeConsultar()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log final
            _logger.LogDebug("NfseGovBrAdnExternal.MunicipiosDfeConsultar() - Fim com sucesso");

            // valor retornado pelo método
            return retornoExternal;
        }



        /// <summary>
        /// Retorna um lote contendo até 50 Documentos Fiscais de Serviço do tipo Evento vinculados à chave de acesso informada
        /// </summary>
        public async Task<ExternalBaseResponse<NfseGovBrDfeResponse>> MunicipiosNfseEventosConsultar(string chaveAcesso)
        {
            // log inicio
            _logger.LogDebug($"NfseGovBrAdnExternal.MunicipiosNfseEventosConsultar() - {_httpClient.BaseAddress}municipios/NFSe/{chaveAcesso}/Eventos");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrDfeResponse>();

            try
            {
                // verificar se temos o parametro chave de acesso?
                if (string.IsNullOrWhiteSpace(chaveAcesso))
                    throw new Exception("Campo 'ChaveAcesso' precia ser informado");

                // consultar api externa do gov.br
                retornoExternal = await MunicipiosConsultarProcessar($"municipios/NFSe/{chaveAcesso.Trim()}/Eventos");
            }
            catch (Exception ex)
            {
                retornoExternal.ErroMensagens.Add("NfseGovBrAdnExternal.MunicipiosNfseEventosConsultar()");
                retornoExternal.ErroMensagens.Add(ex.ToString());
                retornoExternal.Sucesso = false;
            }

            // log final
            _logger.LogDebug("NfseGovBrAdnExternal.MunicipiosNfseEventosConsultar() - Fim com sucesso");

            // valor retornado pelo método
            return retornoExternal;
        }


        /// <summary>
        /// Método de consulta ao servidor externo do gov.br
        /// </summary>
        private async Task<ExternalBaseResponse<NfseGovBrDfeResponse>> MunicipiosConsultarProcessar(string url)
        {
            // log inicio
            _logger.LogDebug($"NfseGovBrAdnExternal.MunicipiosConsultarProcessar() - Início url {_httpClient.BaseAddress}{url}");

            // consultar api externa do gov.br
            var respostaApi = await _httpClient.GetAsync(url);

            // verificar se recebeu resposta?
            if (respostaApi == null)
                throw new Exception("Erro no servidor gov.br sem resposta");

            // corpo retornado pela api externa do gov.br
            var respostaCorpo = await respostaApi.Content.ReadAsStringAsync();

            // verificar se temos corpo na resposta?
            if (string.IsNullOrWhiteSpace(respostaCorpo))
                throw new Exception("Conteudo da resposta do servidor gov.br esta em branco");

            // valor retornado pelo método
            var retornoExternal = new ExternalBaseResponse<NfseGovBrDfeResponse>();

            try
            {
                // resposta da API copiada para resposta desse método
                retornoExternal.StatusCode = (int)respostaApi.StatusCode;

                /*
                {
                "StatusProcessamento":"NENHUM_DOCUMENTO_LOCALIZADO",
                "LoteDFe":[],
                "Alertas":[],
                "Erros":[
                    {
                    "Mensagem":{},
                    "Codigo":"E2020",
                    "Descricao":"Nenhum documento localizado - não existem documentos fiscais para o Município a partir do NSU informado."
                    }
                ],
                "TipoAmbiente":"HOMOLOGACAO",
                "VersaoAplicativo":"1.0.0.0",
                "DataHoraProcessamento":"2025-11-04T10:40:49.1850772-03:00"
                }
                */

                // verificar se temos sucesso ao nivel de https?
                // verificar se retornou um 404 formatado, que contem resposta correta, mas não contem lotes ?
                if ((respostaApi.IsSuccessStatusCode) || (!respostaApi.IsSuccessStatusCode && respostaApi.StatusCode == HttpStatusCode.NotFound))
                {
                    // converter de string json para objeto
                    retornoExternal.Item = Newtonsoft.Json.JsonConvert.DeserializeObject<NfseGovBrDfeResponse>(respostaCorpo);

                    // verificar se temos a DFE de resposta?
                    if (retornoExternal.Item == null)
                        throw new Exception("DFE do conteudo da resposta do servidor gov.br esta em branco");

                    // marcar como sucesso
                    retornoExternal.Sucesso = true;
                }
                else
                {
                    // resposta da api foi SEM sucesso.
                    throw new Exception($"Resposta do servidor gov.br sem sucesso - StatusCode {respostaApi.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                // não consegue converter do json para objeto tipado, então retornar em forma de string.
                throw new Exception(respostaCorpo, ex);
            }

            // log final
            _logger.LogDebug($"NfseGovBrAdnExternal.MunicipiosConsultarProcessar() - Fim com sucesso url {url}");

            // valor retornado pelo método
            return retornoExternal;
        }


    }
}
