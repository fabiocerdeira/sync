﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Request.NfseGovBr.Adn
{
    public class DfeEnviarRequest
    {
        public List<string>? LoteXmlGZipB64 { get; set; }
    }
}
