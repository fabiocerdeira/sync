﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace Cecam.Tributario.Manager.Api.Request.NfseGovBr.Sefin
{
    public class NfseGovBrSefinEventoEnviarRequest
    {
        /// <summary>
        /// Recepciona o Pedido de Registro de Evento e gera Eventos de NFS-e, crédito, débito e apuração.
        /// Estrutura contendo o pedido de registro de evento compactado no padrão GZip com representação base64binary
        /// POST https://sefin.producaorestrita.nfse.gov.br/SefinNacionall/nfse/{chaveAcesso}​/eventos
        /// </summary>
        public string PedidoRegistroEventoXmlGZipB64 { get; set; } = string.Empty;
    }
}

