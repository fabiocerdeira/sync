﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Adn.Dfe
{
    public class NfseGovBrAdnDfeResponse
    {
        /// <summary>
        /// Lote de documentos processados
        /// </summary>
        public List<NfseGovBrAdnDfeDocumentoResponse>? Lote { get; set; }

        public string? TipoAmbiente { get; set; }
        
        public string? VersaoAplicativo { get; set; }
        
        public string? DataHoraProcessamento { get; set; }
    }
}
