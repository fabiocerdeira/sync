﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Adn.Dfe
{
    public class NfseGovBrAdnExternalDfeEnviarResponse
    {
        public NfseGovBrAdnDfeResponse? DfeRecepcaoLote { get; set; }

        public NfseGovBrProblemDetailsResponse? ProblemDetails { get; set; }
    }
}
