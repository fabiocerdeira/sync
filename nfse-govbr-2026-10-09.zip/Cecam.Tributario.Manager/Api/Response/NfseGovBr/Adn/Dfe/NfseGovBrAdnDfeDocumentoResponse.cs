﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Adn.Dfe
{
    public class NfseGovBrAdnDfeDocumentoResponse
    {
        /// <summary>
        /// Chave de acesso
        /// </summary>
        public string? ChaveAcesso { get; set; }

        /// <summary>
        /// NSU - Número Sequencial de Busca
        /// </summary>
        public string? Nsu { get; set; }

        /// <summary>
        /// Status do processamento
        /// </summary>
        public string? StatusProcessamento { get; set; }

        /// <summary>
        /// Alertas da NFS-e
        /// </summary>
        public List<NfseGovBrMensagemProcessamentoResponse>? Alertas { get; set; }

        /// <summary>
        /// Erros da NFS-e gerada
        /// </summary>
        public List<NfseGovBrMensagemProcessamentoResponse>? Erros { get; set; }

    }
}
