﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr
{
    public class NfseGovBrMensagemProcessamentoResponse
    {
        public object? Mensagem { get; set; }
        
        public string? Codigo { get; set; }
        
        public string? Descricao { get; set; }
        
        public string? Complemento { get; set; }
       
        public List<string>? Parametros { get; set; }        

        public override string ToString()
        {
            string par = string.Empty;
            if (Parametros != null)
                par = string.Join(';', Parametros);

            return "Codigo=" + Codigo + "|Descricao=" + Descricao + "|Complemento=" + Complemento + "|Parametros=" + par;
        }
    }
}
