﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr
{
    public class NfseGovBrProblemDetailsResponse
    {
        public string? Type { get; set; }
                
        public string? Properties { get; set; }
        
        public string? Title { get; set; }

        public int? Status { get; set; }
        
        public string? Detail { get; set; }
        
        public string? Instance { get; set; }
        
        public string? AdditionalProperties { get; set; }
    }
}
