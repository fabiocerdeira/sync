﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Sefin
{
    public class NfseGovBrSefinExternalEventoEnviarResponse
    {
        public NfseGovBrSefinEventoEnviarResponse? EventoEnviado { get; set; }

        public NfseGovBrErroResponse? ErroDetails { get; set; }
    }
}
