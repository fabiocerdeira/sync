﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Sefin
{
    public class NfseGovBrSefinExternalNfseConsultarResponse
    {
        /// <summary>
        /// Nfse string no formato XML
        /// </summary>
        public string? NfseFormatoXmlString { get; set; }


        /// <summary>
        /// Corpo da nfse recuperada do gov.br
        /// </summary>
        public NfseGovBrSefinNfseConsultarResponse? Item { get; set; }


        /// <summary>
        /// Erro ao recuperar nfse do gov.br
        /// </summary>
        public NfseGovBrErroResponse? Erro { get; set; }
    }
}
