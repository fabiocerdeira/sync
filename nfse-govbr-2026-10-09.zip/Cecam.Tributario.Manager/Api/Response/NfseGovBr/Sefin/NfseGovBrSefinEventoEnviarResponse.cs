﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Sefin
{
    /// <summary>
    /// O evento da NFS-e foi registrado com sucesso
    /// </summary>
    public class NfseGovBrSefinEventoEnviarResponse
    {
        /// <summary>
        /// Tipo de ambiente (1-Produção | 2-Homologação)
        /// </summary>
        public int? TipoAmbiente { get; set; }

        /// <summary>
        /// Versão do aplicativo que processou a requisição
        /// </summary>
        public string? VersaoAplicativo { get; set; }

        /// <summary>
        /// Data e hora de processamento da requisição
        /// example: 2020-07-30T17:28:42.578Z
        /// </summary>
        public string? DataHoraProcessamento { get; set; }

        /// <summary>
        /// Corpo do evento em base64 de um gzip de um xml
        /// </summary>
        public string? EventoXmlGZipB64 { get; set; }

        /// <summary>
        /// Corpo do evento em string com formato XML
        /// </summary>
        public string? EventoXml { get; set; }
    }
}
