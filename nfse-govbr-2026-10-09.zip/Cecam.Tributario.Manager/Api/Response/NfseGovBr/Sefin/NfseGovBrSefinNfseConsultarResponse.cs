﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Sefin
{
    public class NfseGovBrSefinNfseConsultarResponse
    {
        /// <summary>
        /// Tipo de ambiente (1-Produção | 2-Homologação)
        /// </summary>
        public int? TipoAmbiente { get; set; }

        /// <summary>
        /// Versão do aplicativo que processou a requisição
        /// </summary>
        public string? VersaoAplicativo { get; set; }

        /// <summary>
        /// Data e hora de processamento da requisição
        /// example: 2020-07-30T17:28:42.578Z
        /// </summary>
        public string? DataHoraProcessamento { get; set; }

        /// <summary>
        /// Chave de acesso que representa a nota fiscal de serviço eletrônico
        /// </summary>
        public string? ChaveAcesso { get; set; }

        /// <summary>
        /// Corpo da nfse em base64 de um gzip de um xml
        /// </summary>
        public string? NfseXmlGZipB64 { get; set; }
    }
}
