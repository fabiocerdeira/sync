﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr
{
    public class NfseGovBrErroResponse
    {
        /// <summary>
        /// Tipo de ambiente (1-Produção | 2-Homologação)
        /// </summary>
        public int? TipoAmbiente { get; set; }

        /// <summary>
        /// Versão do aplicativo que processou a requisição
        /// </summary>
        public string? VersaoAplicativo { get; set; }

        /// <summary>
        /// Data e hora de processamento da requisição
        /// example: 2020-07-30T17:28:42.578Z
        /// </summary>
        public string? DataHoraProcessamento { get; set; }

        /// <summary>
        /// Detalhes do erro do processamento
        /// </summary>
        public NfseGovBrMensagemProcessamentoResponse? Erro { get; set; }
    }
}
