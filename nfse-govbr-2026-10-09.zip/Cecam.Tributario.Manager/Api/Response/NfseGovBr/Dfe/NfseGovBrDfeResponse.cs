﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe
{
    public class NfseGovBrDfeResponse
    {
        /// <summary>
        /// REJEICAO, NENHUM_DOCUMENTO_LOCALIZADO, DOCUMENTOS_LOCALIZADOS
        /// </summary>
        public string? StatusProcessamento { get; set; }

        /// <summary>
        ///  PRODUCAO, HOMOLOGACAO
        /// </summary>
        public string? TipoAmbiente { get; set; }


        public string? VersaoAplicativo { get; set; }


        /// <summary>
        /// Exemplo: "2025-10-16T19:08:12.070Z"
        /// </summary>
        public string? DataHoraProcessamento { get; set; }



        public List<NfseGovBrDfeDocumentoResponse>? LoteDFe { get; set; }


        /// <summary>
        /// Alertas da NFS-e
        /// </summary>
        public List<NfseGovBrMensagemProcessamentoResponse>? Alertas { get; set; }


        /// <summary>
        /// Erros da NFS-e gerada
        /// </summary>
        public List<NfseGovBrMensagemProcessamentoResponse>? Erros { get; set; }
    }
}
