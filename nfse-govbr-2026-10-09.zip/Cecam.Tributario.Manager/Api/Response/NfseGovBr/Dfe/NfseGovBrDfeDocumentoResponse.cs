﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe
{
    public class NfseGovBrDfeDocumentoResponse
    {
        /// <summary>
        /// Chave de acesso
        /// </summary>
        public string? ChaveAcesso { get; set; }


        /// <summary>
        /// NSU - Número Sequencial Único
        /// </summary>
        public long? Nsu { get; set; }


        /// <summary>
        /// NENHUM, DPS, PEDIDO_REGISTRO_EVENTO, NFSE, EVENTO, CNC
        /// </summary>
        public string? TipoDocumento { get; set; }


        /// <summary>
        /// CANCELAMENTO, SOLICITACAO_CANCELAMENTO_ANALISE_FISCAL, CANCELAMENTO_POR_SUBSTITUICAO, CANCELAMENTO_DEFERIDO_ANALISE_FISCAL, CANCELAMENTO_INDEFERIDO_ANALISE_FISCAL,<br/>
        /// CONFIRMACAO_PRESTADOR, REJEICAO_PRESTADOR, CONFIRMACAO_TOMADOR, REJEICAO_TOMADOR, CONFIRMACAO_INTERMEDIARIO, REJEICAO_INTERMEDIARIO,<br/>
        /// CONFIRMACAO_TACITA, ANULACAO_REJEICAO, CANCELAMENTO_POR_OFICIO, BLOQUEIO_POR_OFICIO, DESBLOQUEIO_POR_OFICIO, <br/>
        /// INCLUSAO_NFSE_DAN - qnd contribuinte no govbr emite guia de recolhimento (chamada DNA) <br/>
        /// TRIBUTOS_NFSE_RECOLHIDOS - qnd govbr (MAM) encontra o pagamento da guia de recolhimento (DNA) pelo contribuinte
        /// </summary>
        public string? TipoEvento { get; set; }
        
        
        public string? ArquivoXml { get; set; }


        /// <summary>
        /// Exemplo: "2025-10-16T19:08:12.070Z"
        /// </summary>
        public string? DataHoraRecebimento { get; set; }


        /// <summary>
        /// Exemplo: "2025-10-16T19:08:12.070Z"
        /// </summary>
        public string? DataHoraGeracao { get; set; }
    }
}
