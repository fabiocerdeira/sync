﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Api.Response.External
{
    /// <summary>
    /// Encapsulamento das respostas externas ao sistema
    /// Com esse objeto de resposta posso consultar sucesso e/ou erro direto nas propriedades
    /// Criando um modelo de retorno para tudo que é externo ao site
    /// </summary>
    public class ExternalBaseResponse<T>
    {
        /// <summary>
        /// Indica sucesso na chamada da api externa
        /// </summary>
        public bool Sucesso { get; set; }


        /// <summary>
        /// HttpStatusCode (400, 404, 500, etc) retornado pela api externa
        /// </summary>
        public int StatusCode { get; set; } = 0;


        /// <summary>
        /// RequestGuid para os logs do sistema serem encontrados de forma agrupada ou sequencial
        /// </summary>
        public string RequestGuid { get; set; } = Guid.NewGuid().ToString();


        /// <summary>
        /// Item retornado
        /// </summary>
        public T? Item {get; set;}


        /// <summary>
        /// Lista de itens retornada
        /// </summary>
        public List<T>? Lista { get; set; }



        /// <summary>
        /// Mensagens de erro
        /// </summary>
        public List<string> ErroMensagens { get; set; } = new List<string>();


        /// <summary>
        /// Mensagens de aviso
        /// </summary>
        public List<string> AvisoMensagens { get; set; } = new List<string>();


        #region Conversores


        /// <summary>
        /// Retornar todas as mensagens de erro da lista em formato string concatenadas
        /// </summary>
        public string ErroMensagensToString()
        {
            if (ErroMensagens != null)
                return string.Join(";", this.ErroMensagens);

            return string.Empty;
        }


        /// <summary>
        /// Retornar todas as mensagens de aviso da lista em formato string concatenadas
        /// </summary>
        public string AvisoMensagensToString()
        {
            if (AvisoMensagens != null)
                return string.Join(";", this.AvisoMensagens);

            return string.Empty;
        }


        #endregion
    }
}
