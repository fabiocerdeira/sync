﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Enumerado.Endereco;
using Cecam.Tributario.Database.Enumerado.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Extend.Globals;
using Microsoft.Extensions.Logging;

namespace Cecam.Tributario.Manager.Business.Iss
{
    public class IssTomadorBus
    {
        #region Declarações

        // log
        private readonly ILogger<IssTomadorBus> _logger;

        // repositorios
        private readonly IIssTomadorQuery _issTomadorQuery;


        public IssTomadorBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<IssTomadorBus>();

            // repositorios
            _issTomadorQuery = ServiceProviderGlobal.GetServico<IIssTomadorQuery>();
        }

        #endregion


        /// <summary>
        /// Com o tomador informado no parametro, 
        /// primeiro se cd_tomar == 0 então verificar se já existe na base usando PK (cd_cecam, nr_cgccpf, cd_usuario)
        /// se existir, então atualizar tomador
        /// se não existir, então criar novo tomador
        /// </summary>
        public async Task CriarOuEditar(IssTomadorEntity tomadorEntity)
        {
            // log inicial
            _logger.LogInformation("IssTomadorBus.CriarOuEditar() - inicio");

            // cd_cecam
            if (tomadorEntity.Cd_Cecam <= 0)
                tomadorEntity.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // cd_tomador NÃO informado, então verificar se já existe um tomador com a mesma PK ?
            if (tomadorEntity.Cd_Tomador == 0)
            {
                // tentar carregar pela PK
                var tomadorCarregado = await _issTomadorQuery.PrimeiroOuNull(new IssTomadorFilter()
                {
                    Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                    Nr_CGCCPF = tomadorEntity.Nr_CGCCPF,
                    Cd_Usuario = tomadorEntity.Cd_Usuario
                });

                // tomador foi encontrado na base.
                if (tomadorCarregado != null)
                {
                    // atribuir cd_tomador carregado da base no tomador informado no parametro.
                    // isso acontece pq entrou um tomador sem cd_tomador quando é importação de NFSe do gov.br
                    // o tomador na XML do gov.br não possui o campo cd_tomador (pq é uma pk da cecam)
                    tomadorEntity.Cd_Tomador = tomadorCarregado.Cd_Tomador;
                }
            }

            // criar ou editar o tomador na base.
            await Salvar(tomadorEntity);

            // log final
            _logger.LogInformation("IssTomadorBus.CriarOuEditar() - fim");
        }



        /// <summary>
        /// Salvar na base o tomador informado no parametro.
        /// Para criar um novo cd_tomador precisa ser null ou 0 (Zero)
        /// Para editar um já existente cd_tomador precisa ser informado.
        /// </summary>
        public async Task Salvar(IssTomadorEntity tomadorEntity)
        {
            // log inicial
            _logger.LogInformation("IssTomadorBus.Salvar() - inicio");

            // cd_cecam
            if (tomadorEntity.Cd_Cecam <= 0)
                tomadorEntity.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // repo
            using (var repo = ServiceProviderGlobal.GetServico<IIssTomadorRepository>())
            {
                try
                {
                    // verificar se é alteração ou novo ?
                    if (tomadorEntity.Cd_Tomador > 0)
                        repo.Update(tomadorEntity);
                    else
                        repo.Add(tomadorEntity);

                    // salvar
                    await repo.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogError("IssTomadorBus.Salvar()");
                    _logger.LogError(ex.ToString());
                    throw;
                }
            }

            // log final
            _logger.LogInformation("IssTomadorBus.Salvar() - fim");
        }
    
    
    
        /// <summary>
        /// Criar e retornar um IssTomadorEntity com campos obrigatórios quando é de Outro Pais Estrangeiro
        /// Esse método não grava o tomador na base.
        /// </summary>
        public async Task<IssTomadorEntity> CriarTomadorOutroPaisEstrangeiro()
        {
            // valor retornado pelo método
            var tomadorEntity = new IssTomadorEntity()
            {
                Dt_Atualizacao = DateTime.UtcNow.AddHours(-3)
            };

            // criar um cnpj/cpf aleatório com formato de outro pais estrangeiro
            tomadorEntity.CriarCnpjCpfOutroPais();

            // estado como OP = Outro Pais
            tomadorEntity.Sg_UF = CecamEnderecoEnum.kEstadoOutroPais;

            // tipo pessoa 
            // exterior é sempre 2 (dois) = outro pais estrangeiro
            tomadorEntity.Fl_TipoPessoa = (byte)IssTomadorEnum.enumFlTipoPessoa.OutroPaisEstrangeiro;

            // -------------

            // Municipios do Brasil com respectivos IBGE 
            var cecamMunicipioQuery = ServiceProviderGlobal.GetServico<ICecamMunicipioQuery>();

            // carregar o municipio que representa outro pais.
            var outroPais = await cecamMunicipioQuery.CarregarOutroPais();

            // codigo do municipio no exterior
            tomadorEntity.Cd_MunicipioTomador = outroPais.Cd_MunicipioIBGE;

            // -------------

            // valor retornado pelo método
            return tomadorEntity;
        }
    }
}
