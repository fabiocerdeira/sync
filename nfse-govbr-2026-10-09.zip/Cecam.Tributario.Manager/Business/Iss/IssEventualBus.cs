﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.Iss
{
    public class IssEventualBus
    {
        #region Declarações

        // log
        private readonly ILogger<IssEventualBus> _logger;

        // repositorios
        private readonly IIssEventualQuery _issEventualQuery;
        // private readonly IIssEventualRepository _issEventualRepository;

        public IssEventualBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<IssEventualBus>();

            // repositorios
            _issEventualQuery = ServiceProviderGlobal.GetServico<IIssEventualQuery>();
            // _issEventualRepository = ServiceProviderGlobal.GetServico<IIssEventualRepository>();
        }

        #endregion


        /// <summary>
        /// Com o eventual informado no parametro, 
        /// primeiro se cd_eventual == 0 então verificar se já existe na base usando PK (cd_cecam, nr_cgccpf)
        /// se existir, então atualizar eventual
        /// se não existir, então criar novo eventual
        /// </summary>
        public async Task<decimal> CriarOuEditar(IssEventualEntity eventualEntity)
        {
            // log inicial
            _logger.LogInformation("IssEventualBus.CriarOuEditar() - inicio");

            // cd_eventual NÃO informado, então verificar se já existe um eventual com a mesma PK ?
            if (eventualEntity.Cd_Eventual == 0)
            {
                // tentar carregar pela PK
                var eventualCarregado = await _issEventualQuery.PrimeiroOuNull(new IssEventualFilter
                {
                    Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                    Nr_CGCCPF = eventualEntity.Nr_CGCCPF
                });

                // eventual foi encontrado na base.
                if (eventualCarregado != null)
                {
                    // alterar os campos do eventual carregado da base com os dados que estão na XML
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Ds_Razaosocial)) eventualCarregado.Ds_Razaosocial = eventualEntity.Ds_Razaosocial;
                    // dados de contato
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Ds_Email)) eventualCarregado.Ds_Email = eventualEntity.Ds_Email;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Ds_EmailTributario)) eventualCarregado.Ds_EmailTributario = eventualEntity.Ds_EmailTributario;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Ds_EmailCorr)) eventualCarregado.Ds_EmailCorr = eventualEntity.Ds_EmailCorr;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Cd_TelefoneTributario)) eventualCarregado.Cd_TelefoneTributario = eventualEntity.Cd_TelefoneTributario;
                    // endereço
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Ds_EnderTributario)) eventualCarregado.Ds_EnderTributario = eventualEntity.Ds_EnderTributario;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Cd_NumeroTributario)) eventualCarregado.Cd_NumeroTributario = eventualEntity.Cd_NumeroTributario;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Ds_BairroTributario)) eventualCarregado.Ds_BairroTributario = eventualEntity.Ds_BairroTributario;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Sg_EstadoTributario)) eventualCarregado.Sg_EstadoTributario = eventualEntity.Sg_EstadoTributario;
                    if (string.IsNullOrWhiteSpace(eventualCarregado.Cd_CepTributario)) eventualCarregado.Cd_CepTributario = eventualEntity.Cd_CepTributario;

                    // alterar eventual na base
                    await Salvar(eventualCarregado);

                    // colocar a nova PK no objeto recebido como parametro
                    eventualEntity.Cd_Eventual = eventualCarregado.Cd_Eventual;

                    // log final
                    _logger.LogInformation("IssEventualBus.CriarOuEditar() - fim de alteração do eventual");

                    // sair porque já alterou o eventual na base.
                    return eventualEntity.Cd_Eventual;
                }
            }

            // se chegou até aqui, então é não encontrou CNPJ/CPF na base, então é novo eventual

            // criar ou editar o eventual na base.
            await Salvar(eventualEntity);

            // log final
            _logger.LogInformation("IssEventualBus.CriarOuEditar() - fim de criar eventual");

            // retornar o codigo do eventual
            return eventualEntity.Cd_Eventual;
        }


        /// <summary>
        /// Salvar na base o eventual informado no parametro.
        /// Para criar um novo cd_eventual precisa ser null ou 0 (Zero)
        /// Para editar um já existente cd_eventual precisa ser informado.
        /// </summary>
        public async Task Salvar(IssEventualEntity eventualEntity)
        {
            // log inicial
            _logger.LogInformation("IssEventualBus.Salvar() - inicio");

            // cd_cecam
            if (eventualEntity.Cd_Cecam <= 0)
                eventualEntity.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // repo
            using (var repo = ServiceProviderGlobal.GetServico<IIssEventualRepository>())
            {
                try
                {
                    // verificar se é alteração ou novo ?
                    if (eventualEntity.Cd_Eventual > 0)
                    {
                        // data/hora da atualização
                        eventualEntity.Dt_Atualizacao = DateTime.UtcNow.AddHours(-3);

                        // atualizar
                        repo.Update(eventualEntity);
                    }
                    else
                    {
                        // procurar a próxima pk
                        decimal? novaPk = repo.GetIQueryable().OrderByDescending(x => x.Cd_Eventual).Select(x => x.Cd_Eventual).FirstOrDefault();

                        // se não encontrar a nova PK a partir da base, então atribuir valor default.
                        if (novaPk == null || novaPk == 0)
                            novaPk = 9000000001;
                        else
                            novaPk = novaPk + 1; // achou o último então incrementar para próxima pk

                        // atribuir nova pk
                        eventualEntity.Cd_Eventual = novaPk.Value;

                        // data/hora da criação
                        eventualEntity.Dt_Criacao = DateTime.UtcNow.AddHours(-3);
                        eventualEntity.Dt_Atualizacao = null;

                        // adicionar
                        repo.Add(eventualEntity);
                    }

                    // salvar
                    await repo.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogError("IssEventualBus.Salvar()");
                    _logger.LogError(ex.ToString());
                    throw;
                }
            }

            // log final
            _logger.LogInformation("IssEventualBus.Salvar() - fim");
        }


        /// <summary>
        /// Tratar o tamanho máximo dos campos string para não gerar erro na gravação do banco
        /// </summary>
        public void TratarTamanhoCampos(IssEventualEntity eventualEntity)
        {
            // string helper para tratar textos.
            var stringHelp = new StringHelper();

            // limpar espaços em branco duplicados e reduzir o texto para a qtd máxima de caracteres.
            eventualEntity.Ds_Razaosocial = stringHelp.ReduzirTamanho(150, eventualEntity.Ds_Razaosocial, "...");

            // dados de contato
            eventualEntity.Ds_Email = stringHelp.ReduzirTamanho(60, eventualEntity.Ds_Email, "...");
            eventualEntity.Ds_EmailTributario = stringHelp.ReduzirTamanho(60, eventualEntity.Ds_EmailTributario, "...");
            eventualEntity.Cd_TelefoneTributario = stringHelp.ReduzirTamanho(20, eventualEntity.Cd_TelefoneTributario, "...");

            // endereco
            eventualEntity.Ds_EnderTributario = stringHelp.ReduzirTamanho(60, eventualEntity.Ds_EnderTributario, "...");
            eventualEntity.Cd_NumeroTributario = stringHelp.ReduzirTamanho(10, eventualEntity.Cd_NumeroTributario, "...");
            eventualEntity.Ds_BairroTributario = stringHelp.ReduzirTamanho(40, eventualEntity.Ds_BairroTributario, "...");
            eventualEntity.Sg_EstadoTributario = stringHelp.ReduzirTamanho(2, eventualEntity.Sg_EstadoTributario, "");
            eventualEntity.Cd_CepTributario = stringHelp.ReduzirTamanho(8, eventualEntity.Cd_CepTributario, "");
        }
    }
}
