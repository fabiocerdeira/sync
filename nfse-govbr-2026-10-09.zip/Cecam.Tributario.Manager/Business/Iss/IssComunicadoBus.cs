﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Microsoft.EntityFrameworkCore;

namespace Cecam.Tributario.Manager.Business.Iss
{
    public class IssComunicadoBus
    {
        #region Declarações

        // repositorios
        private readonly IIssComunicadoWebRepository _comunicadoWebRepository;
        private readonly IIssComunicadoUsuarioWebRepository _comunicadoUsuarioRepository;
        private readonly IIssNotaFiscalRejeicaoRepository _rejeicaoRepository;

        public IssComunicadoBus()
        {
            // repositorios
            _comunicadoWebRepository = ServiceProviderGlobal.GetServico<IIssComunicadoWebRepository>();
            _comunicadoUsuarioRepository = ServiceProviderGlobal.GetServico<IIssComunicadoUsuarioWebRepository>();
            _rejeicaoRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalRejeicaoRepository>();
        }

        #endregion


        /// <summary>
        /// Criar um comunicado de rejeição da nota fiscal informada
        /// </summary>
        public async Task CriarComunicadoRejeicao(IssNotaFiscalEntity notaFiscal)
        {
            // razao social
            var razaoSocial = string.Empty;

            /*
             
            AQUI EU ESTOU EM DUVIDA:
            SE NA REJEICAO DEVO USAR O CD_CONTRIBUINTE OU CNPJ PARA CARREGAR O RESPECTIVO CONTRIBUINTE
            PQ AO ACEITAR UMA NOTA GRAVAR NA BASE ELE TROCA O CAMPO CD-CONTRIBUINTE COM OUTRO VALOR
            NÃO LEMBRO DIREITO TEM QUE PROCURAR ESSA REGRA.
             */


            // carregar contribuinte
            var issContribuinteBus = new IssContribuinteBus();
            var issContribuinteEntity = await issContribuinteBus.CarregarUm(new Filter.IssContribuinteBusFilter { Nr_CnpjCpf = notaFiscal.Nr_CGCCPFTomador });

            // verificar se achou como contribuinte?
            if (issContribuinteEntity != null)
            {
                // achou o contribuinte, então recuperar razao social
                razaoSocial = "" + issContribuinteEntity.Ds_razaosocial;
            }
            else
            {
                // não achou como contribuinte, então buscar como eventual
                var eventualQuery = ServiceProviderGlobal.GetServico<IIssEventualQuery>();
                var eventualEntity = await eventualQuery.PrimeiroOuNull(new Database.Filter.Iss.IssEventualFilter { Cd_Eventual = notaFiscal.Cd_Contribuinte });

                // verificar se achou como eventual?
                if (eventualEntity != null)
                {
                    // achou como eventual, então recuperar razao social
                    razaoSocial = "" + eventualEntity.Ds_Razaosocial;
                }
                else
                {
                    // não achou como eventual, vai buscar como tomador
                    var tomadorQuery = ServiceProviderGlobal.GetServico<IIssTomadorQuery>();
                    var tomadorEntity = await tomadorQuery.PrimeiroOuNull(new Database.Filter.Iss.IssTomadorFilter { Cd_Tomador = notaFiscal.Cd_Tomador });

                    // verificar se achou como tomador?
                    if (tomadorEntity != null)
                    {
                        // achou como tomador, então recuperar razao social
                        razaoSocial = "" + tomadorEntity.Ds_RazaoSocial;
                    }
                }
            }


            // --------------------------------------------------

            // carregar o motivo da rejeição da base.
            var rejeicaoMotivo = await _rejeicaoRepository.GetIQueryable()
                .Where(x => x.Cd_NotaFiscal == notaFiscal.Cd_NotaFiscal)
                .Select(x => x.Ds_Rejeicao)
                .FirstOrDefaultAsync();

            // criar novo comunicado
            var comunicadoWeb = new IssComunicadoWebEntity
            {
                Ds_Titulo = "Nota fiscal rejeitada",
                Ds_Anexo = "Nota fiscal rejeitada",
                Ds_Assunto = $"A nota fiscal Nº {notaFiscal.Nr_Numero} foi rejeitada.\nNúmero da nota: {notaFiscal.Nr_Numero}\nDocumento do tomador: {notaFiscal.Nr_CGCCPFTomador}\nRazão social: {razaoSocial}\nMês de referência: {notaFiscal.Cd_Referencia}\nMotivo da rejeicao: {rejeicaoMotivo}"
            };

            // gravar comunicado na base
            // a rejeição da nota ocorre pelo tomador, então precisa notificar o prestador (que é a contra parte)
            await Gravar(comunicadoWeb, notaFiscal.Nr_CGCCPF);
        }


        /// <summary>
        /// Criar um comunicado de cancelamento para a nota fiscal informada
        /// </summary>
        /// 
        public async Task CriarComunicadoCancelamento(IssNotaFiscalEntity notaFiscal)
        {
            // razao social
            var razaoSocial = string.Empty;

            // verificar se achou como contribuinte?
            if (notaFiscal.Contribuinte != null)
            {
                // achou o contribuinte, então recuperar razao social
                razaoSocial = "" + notaFiscal.Contribuinte.Ds_razaosocial;
            }
            else if (notaFiscal.Eventual != null)
            {
                // verificar se achou como eventual?
                // achou como eventual, então recuperar razao social
                razaoSocial = "" + notaFiscal.Eventual.Ds_Razaosocial;
            }

            // criar novo comunicado
            var comunicadoWeb = new IssComunicadoWebEntity
            {
                Ds_Titulo = "Nota fiscal cancelada",
                Ds_Anexo = "Nota fiscal cancelada",
                Ds_Assunto = $"A nota fiscal Nº {notaFiscal.Nr_Numero} foi cancelada.\nNúmero da nota: {notaFiscal.Nr_Numero}\nDocumento do prestador: {notaFiscal.Nr_CGCCPF}\nRazão social: {razaoSocial} - ({notaFiscal.Cd_Contribuinte})\nMês de referência: {notaFiscal.Cd_Referencia}\nMotivo do cancelamento: {notaFiscal.Ds_MotivoCancelamento}"
            };

            // gravar comunicado na base
            // o cancelamento ocorre pelo prestador, então precisa notificar o tomador (que é a contra parte)
            await Gravar(comunicadoWeb, notaFiscal.Nr_CGCCPFTomador);
        }



        private async Task Gravar(IssComunicadoWebEntity comunicadoWeb, string? cnpjUsuarioParaSerInformado)
        {
            // completar comunicado
            comunicadoWeb.Cd_Cecam = ParametrosGlobal.Cd_Cecam;
            comunicadoWeb.Cd_Comunicado = await CriarProximaPk();
            comunicadoWeb.Dt_Criacao = DateTime.UtcNow.AddHours(-3);
            comunicadoWeb.Dt_Validade = DateTime.UtcNow.AddHours(-3).AddDays(30);
            comunicadoWeb.Fl_Especifico = 1;

            // salvar comunicado na base
            _comunicadoWebRepository.Add(comunicadoWeb);
            await _comunicadoWebRepository.SaveChangesAsync();

            // -----------------------------------------

            // limpar simbolos do cnpj/cpf
            var cnpjHelp = new CnpjCpfHelper();
            cnpjUsuarioParaSerInformado = cnpjHelp.RetornaSomenteNumerosLetras("" + cnpjUsuarioParaSerInformado);

            // recuperar cnpj do tomador e converter para decimal
            if (decimal.TryParse(cnpjUsuarioParaSerInformado, out var nrCnpjCpfTomador))
            {
                // criar novo comunicado usuario
                var comunicadoUsuario = new IssComunicadoUsuarioWebEntity
                {
                    Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                    Cd_Comunicado = comunicadoWeb.Cd_Comunicado,
                    Nr_CGCCPF = nrCnpjCpfTomador
                };

                // salvar comunicado do usuario na base
                _comunicadoUsuarioRepository.Add(comunicadoUsuario);
                await _comunicadoUsuarioRepository.SaveChangesAsync();
            }
        }


        /// <summary>
        /// Criar a próxima Pk da tabela IssComunicadoWeb
        /// </summary>
        private async Task<decimal> CriarProximaPk()
        {
            return (await _comunicadoWebRepository.GetIQueryable()
                .OrderByDescending(x => x.Cd_Comunicado)
                .Select(x => x.Cd_Comunicado)
                .FirstOrDefaultAsync()) + 1;
        }
    }
}
