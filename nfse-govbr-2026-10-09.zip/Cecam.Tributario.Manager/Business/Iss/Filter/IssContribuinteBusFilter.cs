﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.Iss.Filter
{
    public class IssContribuinteBusFilter
    {
        public decimal? Cd_Contribuinte { get; set; }

        public string? Nr_CnpjCpf { get; set; }

        public string? Ds_InscricaoMunicipal { get; set; }

        public bool IncluirLogradouro { get; set; }

        public bool IncluirBairro { get; set; }
    }
}
