﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.Iss.Filter
{
    public class IssTomadorBusFilter
    {
        #region PK

        public string? Nr_CGCCPF { get; set; }

        public string? Cd_Usuario { get; set; }

        #endregion

        public string? Ds_inscricao_municipal { get; set; }

        public decimal? Cd_Tomador { get; set; }

        public decimal? Cd_MunicipioTomador { get; set; }

        public string? Sg_UF { get; set; }
    }
}
