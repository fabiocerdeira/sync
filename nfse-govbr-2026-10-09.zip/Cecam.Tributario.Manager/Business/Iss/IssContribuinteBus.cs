﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.Iss.Filter;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.Iss
{
    public class IssContribuinteBus
    {
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<IssContribuinteBus> _logger;

        /// <summary>
        /// Query de IssContribuinte
        /// </summary>
        private readonly IIssContribuinteQuery _issContribuinteQuery;

        // repositorios
        private ICecamLogradouroRepository? _logradouroRepository;
        private ICecamBairroRepository? _bairroRepository;


        public IssContribuinteBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<IssContribuinteBus>();

            // repositorios
            _issContribuinteQuery = ServiceProviderGlobal.GetServico<IIssContribuinteQuery>();
        }


        /// <summary>
        /// Carregar um IssContribuinte a partir da pk Cd_Contribuinte
        /// </summary>
        public async Task<IssContribuinteEntity?> CarregarUm(IssContribuinteBusFilter filtro)
        {
            var contribuinte = await _issContribuinteQuery.PrimeiroOuNull(ConverterFilter(filtro));

            if (contribuinte == null)
                return null;

            // Carregar as informações complementares/filhas do IssContribuinte
            CarregarFilhos(contribuinte, filtro);

            return contribuinte;
        }


        /// <summary>
        /// Carregar um IssContribuinte a partir do CNPJ informado, 
        /// levar em consideração qual esta com a IM aberta ou se não encontrar aberta,
        /// levar em consideração qual encerrou por último.
        /// </summary>
        public async Task<IssContribuinteEntity?> CarregarContribuinteEmAtividade(IssContribuinteBusFilter filtro)
        {
            // carregar a lista do mesmo contribuinte que tem o mesmo cnpj
            // isso existe porque em algumas prefeituras o mesmo cpnj da mesma empresa aparece várias vezes na base
            // então o próximo passo é filtrar por data de encerramento/fechamento
            var listaContribuintes = await _issContribuinteQuery.Listar(ConverterFilter(filtro));

            if (listaContribuintes?.Any() != true)
                return null;

            // contribuinte escolhido para ser retornado
            IssContribuinteEntity contribuinte;

            // só existe um então retornar esse único
            if (listaContribuintes.Count == 1)
            {
                // retornar o único contribuinte encontrado
                contribuinte = listaContribuintes.First();
            }
            else
            {
                // percorrer todos os IssContribuintes carregados
                // e decidir qual vai retornar por base das datas de encerramentos e abertuas

                // remover os encerrados que nunca tiveram reabertura
                listaContribuintes.RemoveAll(x => x.Dt_encerramento != null && x.Dt_reabertura == null);

                // remover os encerrados após uma reabertura
                listaContribuintes.RemoveAll(x => x.Dt_encerramento != null && x.Dt_reabertura != null && x.Dt_encerramento >= x.Dt_reabertura);

                // remover todos os excluidos do IssWeb com Fl_IgnorarISSWEB
                listaContribuintes.RemoveAll(x => x.Fl_IgnorarISSWEB.GetValueOrDefault() == 1);

                // só existe um então retornar esse único
                if (listaContribuintes.Count == 1)
                {
                    // retornar o único contribuinte encontrado
                    contribuinte = listaContribuintes.First();
                }
                else if (listaContribuintes.Count == 0)
                {
                    // o contribuinte já existiu na prefeitura mas hoje esta encerrado em todas as suas decas.
                    return null;
                }
                else
                {
                    // ainda não conseguiu filtrar o contribuinte em 'atividade/funcionamento' entre os seus vários cadastros na base.
                    // isso acontece porque ele tem várias decas abertas (não encerradas)
                    // então retornar erro
                    throw new NotImplementedException($"O contribuinte {filtro.Nr_CnpjCpf} possui várias Decas vigentes, por favor corrigir os cadastros deixando apenas uma Deca vigentes", new Exception("CarregarEscolhendoPorDataAberturaEncerramento() não foi implementado"));
                }
            }

            // Carregar as informações complementares/filhas do IssContribuinte
            CarregarFilhos(contribuinte, filtro);

            // retornar contribuinte
            return contribuinte;
        }



        #region Auxiliares


        /// <summary>
        /// Carregar as informações complementares/filhas do IssContribuinte
        /// </summary>
        public void CarregarFilhos(IssContribuinteEntity? contribuinte, IssContribuinteBusFilter? filtro)
        {
            if (contribuinte == null || filtro == null)
                return;

            // carregar respectivo logradouro
            if (filtro.IncluirLogradouro && !string.IsNullOrWhiteSpace(contribuinte.Cd_Logradouro))
            {
                _logradouroRepository = ServiceProviderGlobal.GetServico<ICecamLogradouroRepository>();
                contribuinte.Logradouro = _logradouroRepository.GetIQueryable().Where(x => x.Cd_Logradouro == contribuinte.Cd_Logradouro).FirstOrDefault();
            }

            // carregar respectivo logradouro
            if (filtro.IncluirBairro && contribuinte.Cd_Bairro.HasValue)
            {
                _bairroRepository = ServiceProviderGlobal.GetServico<ICecamBairroRepository>();
                contribuinte.Bairro = _bairroRepository.GetIQueryable().Where(x => x.Cd_Bairro == contribuinte.Cd_Bairro).FirstOrDefault();
            }
        }


        /// <summary>
        /// Converter um objeto IssContribuinteBusFilter em IssContribuinteFilter para consultar a base sql
        /// </summary>
        public IssContribuinteFilter ConverterFilter(IssContribuinteBusFilter filtro)
        {
            return new IssContribuinteFilter
            {
                Cd_Exercicio = null,
                Cd_Contribuinte = filtro.Cd_Contribuinte,
                Nr_CgcCpf= filtro.Nr_CnpjCpf,
                Ds_Inscricao_Municipal = filtro.Ds_InscricaoMunicipal,
            };                
        }

        #endregion
    }
}
