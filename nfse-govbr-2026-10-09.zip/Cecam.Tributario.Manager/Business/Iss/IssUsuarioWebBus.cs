﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.Iss
{
    public class IssUsuarioWebBus
    {
        #region Declarações

        // log
        private readonly ILogger<IssUsuarioWebBus> _logger;

        // repositorios
        private readonly IIssUsuarioWebQuery _issUsuarioWebQuery;

        public IssUsuarioWebBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<IssUsuarioWebBus>();

            // repositorios
            _issUsuarioWebQuery = ServiceProviderGlobal.GetServico<IIssUsuarioWebQuery>();
        }

        #endregion


        /// <summary>
        /// Criar ou editar o IssUsuarioWeb informado no parametro
        /// </summary>
        public async Task CriarSeNaoExistir(IssUsuarioWebEntity usuarioEntity)
        {
            // log inicial
            _logger.LogInformation("IssUsuarioWebBus.CriarSeNaoExistir() - inicio");

            // tentar carregar o usuário da base usando a PK
            var usuarioCarregado = await _issUsuarioWebQuery.PrimeiroOuNull(new IssUsuarioWebFilter
            {
                Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                Nr_CGCCPF = usuarioEntity.Nr_CGCCPF
            });

            if (usuarioCarregado != null)
                return;

            // cd_cecam
            if (usuarioEntity.Cd_Cecam <= 0)
                usuarioEntity.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // repo
            using (var repo = ServiceProviderGlobal.GetServico<IIssUsuarioWebRepository>())
            {
                try
                {
                    // adicionar
                    repo.Add(usuarioEntity);

                    // salvar
                    await repo.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogError("IssUsuarioWebBus.CriarSeNaoExistir()");
                    _logger.LogError(ex.ToString());
                    throw;
                }
            }

            // log final
            _logger.LogInformation("IssUsuarioWebBus.CriarSeNaoExistir() - fim");
        }


        /// <summary>
        /// Tratar o tamanho máximo dos campos string para não gerar erro na gravação do banco
        /// </summary>
        public void TratarTamanhoCampos(IssUsuarioWebEntity usuarioEntity)
        {
            // helper para campos string
            var stringHelp = new StringHelper();

            // tratar tamanho maximo dos campos
            usuarioEntity.Nm_Usuario = "" + stringHelp.ReduzirTamanho(60, usuarioEntity.Nm_Usuario, "");
        }
    }
}
