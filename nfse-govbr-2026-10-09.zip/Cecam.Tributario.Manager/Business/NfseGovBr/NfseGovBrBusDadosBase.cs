﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr
{
    public class NfseGovBrBusDadosBase
    {
        #region Declarações


        // constantes globais
        public const string VersaoGeradorNfse = "1.00.00";
        public const string MoedaComValorZero = "0.00";


        /// <summary>
        /// Marcação de campo dentro da XML que falta ser desenvolvido
        /// </summary>
        public const string FaltaDesenvolver = "---erro--falta--desenvolver---";


        // objetos entity globais
        public IssNotaFiscalGovBrFilaEntradaEntity? NotaFiscalFilaEntrada;
        public IssNotaFiscalEntity? IssNotaFiscal;


        /// <summary>
        /// Xml no formato texto/string com o objeto de NFSe ou Evento para ser enviado para gov.br
        /// </summary>
        public string XmlParaEnvioAsString = string.Empty;


        #endregion


        /// <summary>
        /// Retornar o Cd_NotaFiscal do registro carregado, com tratamento de nullo e zero.
        /// </summary>
        public decimal Cd_NotaFiscal
        {
            get
            {
                if (NotaFiscalFilaEntrada != null)
                {
                    return NotaFiscalFilaEntrada.Cd_NotaFiscal;
                }

                return 0;
            }
        }

    }
}
