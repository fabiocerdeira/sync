﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar
{
    internal class NfseGovBrDfeEnviarBusDados : NfseGovBrBusDadosBase
    {
        #region Declarações


        /// <summary>
        /// Classe raiz da XMl em formato objeto com a NFSe para ser enviada para gov.br
        /// </summary>
        public NfseXml NotaFiscalParaEnvio = new NfseXml();     


        /// <summary>
        /// Parametros da NFSe utilizados pelo sistema da cecam
        /// </summary>
        public IssParametrosCalcEntity? IssParametrosCalc;


        /// <summary>
        /// Parametros do Gov.br da Nota Fiscal de Service
        /// </summary>
        public IssParametrosNfseEntity? IssParametrosNfse;


        /// <summary>
        /// Informações do Contribuinte da NFSE
        /// </summary>
        public IssContribuinteEntity? IssContribuinte;


        /// <summary>
        /// Informações dos municpios do Brasil
        /// </summary>
        public CecamMunicipioEntity? Municipio;


        #endregion
    }
}
