﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento;
using Microsoft.Extensions.Logging;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoValor
    {
        #region Declarações


        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;


        public NfseGovBrEnviarCorpoValor(NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";
        }


        #endregion


        public void Processar()
        {
            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDados();
        }


        private void PreencherObjetoComDados()
        {
            // validar objetos obrigatorios
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null ||
                _dadosOrigem.IssContribuinte == null ||
                _dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.IssNotaFiscal.Itens == null ||
                _dadosOrigem.IssParametrosNfse == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsValor.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");


            if (_dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null || _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null)
                return;

            // atalho para não dar mensagem de possível null
            var infDpsXml = _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps;
            if (infDpsXml == null)
                return;

            // Grupo de informações relativas aos valores do serviço prestado
            var valorXML = new InfDpsValoresXml();
            infDpsXml.valores = valorXML;

            // Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
            var vDedRedXml = new InfDpsValoresDeducaoReducaoXml();
            valorXML.vDedRed = vDedRedXml;

            // Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
            vDedRedXml.documentos = new InfDpsValoresDeducaoReducaoDocumentoXml();

            // Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
            var docDedRedXml = new InfDpsValoresDeducaoReducaoDocumentoDedRedXml();
            vDedRedXml.documentos.docDedRed = docDedRedXml;

            var nfItem = _dadosOrigem.IssNotaFiscal.Itens.FirstOrDefault();
            if (nfItem == null)
                throw new Exception($"NfsValor.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} ISSNotaFiscalItem é obrigatório e não foi encontrado.");

            if (nfItem.Vl_Deducao > 0)
            {
                // Chave de acesso da NFS-e (padrão nacional).
                // Tabela ISSNotaFiscal ==> trazer preenchido o campo nr_chavevalidacao quando ==> nr_cgccpf ==> nr_notafiscal ==> cd_notafiscal ==> Tabela ISSNotaFiscalItem ==> cd_notafiscal ==> Vl_Deducao > 0
                docDedRedXml.chNFSe = "" + _dadosOrigem.IssNotaFiscal.Nr_ChaveValidacao;

                // Chave de acesso da NF-e.
                // Tabela ISSNotaFiscal ==> trazer preenchido o campo nr_chavevalidacao quando ==> nr_cgccpf ==> nr_notafiscal ==> cd_notafiscal ==> Tabela ISSNotaFiscalItem ==> cd_notafiscal ==> Vl_Deducao > 0
                docDedRedXml.chNFe = "" + _dadosOrigem.IssNotaFiscal.Nr_ChaveValidacao;
            }

            // Data da emissão do documento dedutível. Ano, mês e dia(AAAA-MM-DD)
            // Tabela ISSNotafiscal ==> campo ==> dt_emissao
            docDedRedXml.dtEmiDoc = _dadosOrigem.IssNotaFiscal.Dt_Emissao.ToString("yyyy-MM-dd");

            // Valor monetário total dedutível/redutível no documento informado (R$).
            // Este é o valor total no documento informado que é passível de dedução / redução.
            // Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao 
            docDedRedXml.vDedutivelRedutivel = nfItem.Vl_Deducao.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);

            // Valor monetário utilizado para dedução/redução do valor do serviço da NFS-e que está sendo emitida (R$). 
            // Deve ser menor ou igual ao valor deduzível/ redutível(vDedutivelRedutivel).
            // Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao 
            docDedRedXml.vDeducaoReducao = nfItem.Vl_Deducao.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);



            // -------------------------------------------------------------------------------------------

            // Grupo de informações para outras notas eletrônicas municipais
            // (Nota eletrônica municipal emitida fora do padrão nacional)
            var nFSeMunXml = new InfDpsValoresDeducaoReducaoDocumentoNFSeMunXml();
            docDedRedXml.NFSeMun = nFSeMunXml;

            // Código Município emissor da nota eletrônica municipal. (Tabela do IBGE) 
            // Tabela IssParametrosNfse ==> campo ==> Cd_IBGE
            nFSeMunXml.cMunNFSeMun = _dadosOrigem.IssParametrosNfse.Cd_IBGE.HasValue? _dadosOrigem.IssParametrosNfse.Cd_IBGE.Value.ToString() : string.Empty;

            // Número da nota eletrônica municipal.	
            // Tabela ISSNOtaFiscal ==> campo ==> nr_notafiscal
            nFSeMunXml.nNFSeMun = _dadosOrigem.IssNotaFiscal.Nr_NotaFiscal.ToString();

            // Código de Verificação da nota eletrônica municipal.	
            // Tabela ISSNOtaFiscal ==> campo ==> nr_notafiscal ==> campo ==> nr_chavevalidacao
            nFSeMunXml.cVerifNFSeMun = "" + _dadosOrigem.IssNotaFiscal.Nr_ChaveValidacao;

            // -------------------------------------------------------------------------------------------

            // Grupo de informações de NF ou NFS (Modelo não eletrônico)
            var nfNfsXML = new InfDpsValoresDeducaoReducaoDocumentoNFNFSXml();
            docDedRedXml.NFNFS = nfNfsXML;

            // Número da Nota Fiscal NF ou NFS.	
            // Tabela ISSNOtaFiscal ==> campo ==> nr_notafiscal
            nfNfsXML.nNFS = _dadosOrigem.IssNotaFiscal.Nr_NotaFiscal.ToString();

            // -------------------------------------------------------------------------------------------

            // log fim
            _loggerHelper.GravarTexto($"NfsValor.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }
    }
}
