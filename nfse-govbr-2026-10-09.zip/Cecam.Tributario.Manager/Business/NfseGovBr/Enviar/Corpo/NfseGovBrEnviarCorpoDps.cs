﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoDps
    {
        #region Declarações


        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;


        public NfseGovBrEnviarCorpoDps(NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";
        }


        #endregion


        public void Processar()
        {
            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDados();
        }


        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDados()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.IssParametrosNfse == null)
                return;

            // log início
            _loggerHelper.GravarObjeto($"NfseGovBrEnviarCorpoDps.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps = new DpsXml();

            // atalho para dps xml
            var infDpsXml = new InfDpsXml();
            _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps = infDpsXml;

            // helper com várias funções para cnpj e cpf.
            var cnpjCpfHelper = new CnpjCpfHelper();

            /*
            O identificador da DPS é composto pela concatenação de campos que constam no leiaute da DPS.
            A formação deste identificador considera o literal ""DPS"" associado a outras 42 posições numéricas, conforme descrito abaixo:

            "DPS" + 
            Cód.Mun. (7) + 
            Tipo de Inscrição Federal (1) + 
            Inscrição Federal (14 - CPF completar com 000 à esquerda) + 
            Série DPS (5) + 
            Núm. DPS (15)

            DPS" = prefixo 'DPS' + 
            Cód.Mun. (7)  = TAbela IssParametrosNfse ==> Cd_IBGE + 
            Tipo de Inscrição Federal (1)  ==>  Tabela ISSNotafiscal ==> nr_CGCCPF se = 1 (CPF) se = 2 (CNPJ) + 
            Inscrição Federal (14 - CPF completar com 000 à esquerda) ==> Tabela ISSNotadiscal ==> campo nr_CGCCPF + 
            Série DPS (5) Verificar nova regra + 
            Núm. DPS (15) Verificar nova regra
            */
            infDpsXml.id = "DPS" +
                _dadosOrigem.IssParametrosNfse.Cd_IBGE.GetValueOrDefault().ToString().PadLeft(7, '0') + "1" +
                ((int)cnpjCpfHelper.VerificarTipo(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF)).ToString() +
                cnpjCpfHelper.RetornaSomenteNumerosLetras(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF).PadLeft(14, '0') +
                NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;

            // Identificação do tipo de ambiente no Sistema Nacional NFS-e: 
            // 1 - Produção;
            // 2 - Homologação;
            infDpsXml.tpAmb = ParametrosGlobal.NfseGovBr_HeAmbienteProducao ? "1" : "2";

            /*
            Data e hora da emissão da DPS.
            Data e hora no formato UTC (Universal Coordinated Time):
            AAAA-MM-DDThh:mm:ssTZD"
            Tabela ISSNotafiscal ==> campo ==> dt_emissao
            */
            infDpsXml.dhEmi = _dadosOrigem.IssNotaFiscal.Dt_Emissao.ToString("O");

            // Versão do aplicativo que gerou a DPS.
            infDpsXml.verAplic = NfseGovBrDfeEnviarBusDados.VersaoGeradorNfse;

            // Série da DPS.	
            // 00001 a 49999
            infDpsXml.serie = NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;

            // Número da DPS.
            infDpsXml.nDPS = NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;

            /*
            Data de competência da prestação do serviço.
            Ano, Mês e Dia (AAAA-MM-DD)
            Tabela ISSNotafiscal ==> campo ==> dt_emissao
            */
            infDpsXml.dCompet = _dadosOrigem.IssNotaFiscal.Dt_Emissao.ToString("yyyy-MM-dd");

            /*
            Emitente da DPS:
            1 - Prestador;
            2 - Tomador;
            3 - Intermediário;
            Preencher sempre com 1 - Prestador
            */
            infDpsXml.tpEmit = "1";

            // Código de 7 dígitos da localidade emissora da NFS-e.	
            infDpsXml.cLocEmi = _dadosOrigem.IssParametrosNfse.Cd_IBGE.HasValue ? _dadosOrigem.IssParametrosNfse.Cd_IBGE.Value.ToString() : string.Empty;

            // log fim
            _loggerHelper.GravarObjeto($"NfseGovBrEnviarCorpoDps.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }
    }
}
