﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Servico;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoServico
    {
        #region Declarações


        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;


        public NfseGovBrEnviarCorpoServico(NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";
        }


        #endregion


        public void Processar()
        {
            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDados();
        }


        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDados()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null ||
                _dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.IssParametrosNfse == null)
                return;

            // log início
            _loggerHelper.GravarObjeto($"NfseGovBrEnviarCorpoServico.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // atalho para infDps
            var infDpsXml = _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps;
            if (infDpsXml == null)
                return;

            // atalho para servico xml
            var infDpsServicoXml = new InfDpsServicoXml();
            infDpsXml.serv = infDpsServicoXml;



            /*
            cTribNac = vou pegar da ListaServicoNacional campo 'cd_tributacaoNacional' exemplo '070202'
            Correto Fabio, tabela ISS_NFSE_ListaServicoNacional e campo: 'cd_tributacaoNacional'

            cTribMun = código do tributo municipal, eu não sei de onde pegar
            tabela issserviços e campo: cd_servico, pode levar também o cd_exercicio do ano corrente

            xDescServ = descrição completa do serviço prestado, eu não sei de onde pegar
            na documentação não deixa claro, se é descrição da Lista Nacional ou NBS,  vamos deixar o da Lista Nacional
            tabela ISS_NFSE_ListaServicoNacional e campo: ‘ds_servicodescricao

            cNBS = código NBS vou pegar da 'ISS_NFSE_listaNBS' campo 'cd_nbsFormatado' Exemplo '1.0203.10.00'
            (correto, o Fabinho começou a implementação, agora após o almoço)             
            */

            // atalho para servico Xml
            var codigoServicoXml = new InfDpsServicoCodigoServicoXml();
            infDpsServicoXml.cServ = codigoServicoXml;

            // Código interno do contribuinte
            codigoServicoXml.cIntContrib = _dadosOrigem.IssNotaFiscal.Cd_Contribuinte.HasValue ? _dadosOrigem.IssNotaFiscal.Cd_Contribuinte.Value.ToString() : "";

            // temos item da nota fiscal ?
            if (_dadosOrigem.IssNotaFiscal.Itens != null && _dadosOrigem.IssNotaFiscal.Itens.Count > 0)
            {
                var itemEntity = _dadosOrigem.IssNotaFiscal.Itens.FirstOrDefault();

                if (itemEntity != null)
                {
                    if (itemEntity.ServicoNacional != null && !string.IsNullOrWhiteSpace(itemEntity.ServicoNacional.Cd_tributacaoNacional))
                    {
                        // Código de tributação nacional do ISSQN.
                        codigoServicoXml.cTribNac = "" + itemEntity.ServicoNacional.Cd_tributacaoNacional;

                        // Descrição completa do serviço prestado
                        codigoServicoXml.xDescServ = itemEntity.ServicoNacional.Cd_tributacaoNacional + " - " + itemEntity.ServicoNacional.Ds_servicoDescricao;
                    }

                    // Código de tributação municipal do ISSQN.
                    if (itemEntity.Servico != null)
                        codigoServicoXml.cTribMun = "" + itemEntity.Servico.Cd_Servico;

                    // Código NBS correspondente ao serviço prestado
                    if (itemEntity.NBS != null)
                        codigoServicoXml.cNBS = "" + itemEntity.NBS.Cd_nbsFormatado;
                }
            }




            // log fim
            _loggerHelper.GravarObjeto($"NfseGovBrEnviarCorpoServico.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }
    }
}
