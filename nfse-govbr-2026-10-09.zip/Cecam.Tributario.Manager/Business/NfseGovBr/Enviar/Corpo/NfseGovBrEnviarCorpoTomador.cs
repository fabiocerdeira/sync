﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.Iss;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoTomador
    {
        #region Declarações


        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;


        /// <summary>
        /// Contribuinte tomador da nota fiscal
        /// </summary>
        private IssTomadorEntity? _issTomadorEntity;


        /// <summary>
        /// Repositório Tomador
        /// </summary>
        private readonly IIssTomadorQuery _issTomadorQuery;


        public NfseGovBrEnviarCorpoTomador(
            NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";

            // repositorio tomador
            _issTomadorQuery = ServiceProviderGlobal.GetServico<IIssTomadorQuery>();
        }


        #endregion


        public async Task Processar()
        {
            // Carregar as várias entidades da base de dados para memória
            await CarregarDados();

            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDados();
        }


        /// <summary>
        /// Carregar as várias entidades da base de dados para memória
        /// </summary>
        private async Task CarregarDados()
        {
            if (_dadosOrigem.IssNotaFiscal == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsTomador.CarregarDados() Cd_NotaFiscal ={_dadosOrigem.Cd_NotaFiscal} Início");

            if (_dadosOrigem.IssNotaFiscal.Cd_Tomador == null)
                throw new Exception($"NfsTomador.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} Não foi possível carregar IssTomador pq cd_tomador == null");

            // carregar o tomador
            _issTomadorEntity = await _issTomadorQuery.PrimeiroOuNull(new Database.Filter.Iss.IssTomadorFilter { Cd_Tomador = _dadosOrigem.IssNotaFiscal.Cd_Tomador.GetValueOrDefault() });

            if (_issTomadorEntity == null)
                throw new Exception($"NfsTomador.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} Não foi possível carregar IssTomador não encontrado");

            // log fim
            _loggerHelper.GravarTexto($"NfsTomador.CarregarDados() Cd_NotaFiscal ={_dadosOrigem.Cd_NotaFiscal} Fim com sucesso");
        }


        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDados()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null ||
                _issTomadorEntity == null ||
                _dadosOrigem.IssNotaFiscal == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsTomador.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            if (_dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null || _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null)
                return;

            // atalho para não dar mensagem de possível null
            var infDpsXml = _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps;
            if (infDpsXml == null)
                return;

            // Grupo de informações relativas ao tomador do serviço
            var tomadorXml = new InfDpsTomadorXml();
            infDpsXml.toma = tomadorXml;

            // helper com várias funções para cnpj e cpf.
            var cnpjCpfHelper = new CnpjCpfHelper();

            // Número da inscrição federal (CPF ou CNPJ) do tomador da NFS-e.
            switch (cnpjCpfHelper.VerificarTipo("" + _dadosOrigem.IssNotaFiscal.Nr_CGCCPFTomador))
            {
                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CPF:

                    // Número da inscrição federal (CPF) do tomador da NFS-e.
                    tomadorXml.CPF = "" + _dadosOrigem.IssNotaFiscal.Nr_CGCCPFTomador;
                    break;

                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CNPJ:
                    // Número da inscrição federal (CNPJ) do tomador da NFS-e.
                    tomadorXml.CNPJ = "" + _dadosOrigem.IssNotaFiscal.Nr_CGCCPFTomador;
                    break;
            }

            // Número de identificação fiscal fornecido por órgão de administração tributária no exterior.
            // Se o campo tpEmit for ígual a 1, então NIF do tomador não pode ser informado.	
            tomadorXml.NIF = string.Empty;

            /*
            Motivo para não informação do NIF:
            0 - Não informado na nota de origem;
            1 - Dispensado do NIF;
            2 - Não exigência do NIF;
            sempre preencher com 2.
            */
            tomadorXml.cNaoNIF = "2";

            // Número do Cadastro de Atividade Econômica da Pessoa Física (CAEPF) do tomador do serviço.
            // tomadorXml.CAEPF = IssNotaFiscalGovBrEnvioDados.FaltaDesenvolver;

            // Número de inscrição municipal do tomador da NFS-e.
            tomadorXml.IM = "" + _issTomadorEntity.Ds_inscricao_municipal;

            // Nome / Razão Social do tomador
            tomadorXml.xNome = "" + _issTomadorEntity.Ds_RazaoSocial;

            /*
            Número do telefone do tomador.
            (Preencher com o Código DDD + número do telefone. 
            Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)
            */
            tomadorXml.fone = "";

            // E-mail do tomador.
            tomadorXml.email = "" + _issTomadorEntity.Ds_Email;

            // -------------------------------------

            // Grupo de informações do endereço do tomador de serviço.
            var enderecoXml = new InfDpsTomadorEnderecoXml();
            enderecoXml.endNac = new EnderecoNacionalReduzidoXml();
            enderecoXml.endExt = new EnderecoExteriorXml();
            tomadorXml.end = enderecoXml;


            // Tipo e nome do logradouro do endereço do tomador do serviço.
            // Tabela ISSNOtaFiscal ==> campo ==> nr_cgccpftomador  ==> Tabela ISSTomador ==> nr_cgccpf ==> ds_logradouro
            enderecoXml.xLgr = "" + _issTomadorEntity.Ds_Logradouro;

            // Número no logradouro do endereço do tomador do serviço.
            // Tabela ISSNOtaFiscal ==> campo ==> nr_cgccpftomador  ==> Tabela ISSTomador ==> nr_cgccpf ==> cd_numero
            enderecoXml.nro = "" + _issTomadorEntity.Cd_Numero;

            // Complemento do endereço do tomador do serviço.
            // Tabela ISSNOtaFiscal ==> campo ==> nr_cgccpftomador  ==> Tabela ISSTomador ==> nr_cgccpf ==> ds_complemento
            enderecoXml.xCpl = "" + _issTomadorEntity.Ds_Complemento;

            // Bairro do endereço do tomador do serviço.
            // Tabela ISSNOtaFiscal ==> campo ==> nr_cgccpftomador  ==> Tabela ISSTomador ==> nr_cgccpf ==> ds_bairro
            enderecoXml.xBairro = "" + _issTomadorEntity.Ds_Bairro;

            // Código do município do endereço do tomador do serviço.(Tabela do IBGE)
            // Tabela ISSNOtaFiscal ==> campo ==> nr_cgccpftomador  ==> Tabela ISSTomador ==> nr_cgccpf ==> cd_MunicipioTomador
            enderecoXml.endNac.cMun = "" + _issTomadorEntity.Cd_MunicipioTomador.ToString();

            // Código numérico do Endereçamento Postal nacional (CEP) do endereço do tomador do serviço.
            // Tabela ISSNOtaFiscal ==> campo ==> nr_cgccpftomador  ==> Tabela ISSTomador ==> nr_cgccpf ==> cd_cep
            enderecoXml.endNac.CEP = "" + _issTomadorEntity.Cd_CEP;

            // Código do país do endereço do tomador do tomador do serviço. (Tabela de Países ISO)
            enderecoXml.endExt.cPais = "" + _issTomadorEntity.Sg_Pais_ISO2;

            // Código alfanumérico do Endereçamento Postal no exterior do tomador do serviço.
            enderecoXml.endExt.cEndPost = "" + _issTomadorEntity.Ds_EnderecoExt;

            // Nome da cidade no exterior do tomador do serviço.
            enderecoXml.endExt.xCidade = "" + _issTomadorEntity.Ds_CidadeExt;

            // Estado, província ou região da cidade no exterior do tomador do serviço.
            enderecoXml.endExt.xEstProvReg = "" + _issTomadorEntity.Ds_EstadoExt;

            // log fim
            _loggerHelper.GravarTexto($"Nfstomador.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }

    }
}
