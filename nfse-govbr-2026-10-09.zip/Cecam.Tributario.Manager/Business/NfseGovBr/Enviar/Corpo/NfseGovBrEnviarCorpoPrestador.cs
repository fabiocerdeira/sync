﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoPrestador
    {
        #region Declarações


        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;


        public NfseGovBrEnviarCorpoPrestador(NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";
        }


        #endregion


        public void Processar()
        {
            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDadosPrestador();
            PreencherObjetoComDadosRegimeTributario();
        }


        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDadosPrestador()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null ||
                _dadosOrigem.IssContribuinte == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsPrestador.PreencherObjetoComDadosPrestador() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            if (_dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null || _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null)
                return;

            // atalho para não dar mensagem de possível null
            var infDpsXml = _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps;
            if (infDpsXml == null)
                return;

            // Grupo de informações relativas ao prestador do serviço
            var prestadorXml = new InfDpsPrestadorXml();
            infDpsXml.prest = prestadorXml;

            // helper com várias funções para cnpj e cpf.
            var cnpjCpfHelper = new CnpjCpfHelper();

            // Número da inscrição federal (CPF ou CNPJ) do emitente da NFS-e.
            switch (cnpjCpfHelper.VerificarTipo("" + _dadosOrigem.IssContribuinte.Nr_CGCCPF))
            {
                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CPF:

                    // Número da inscrição federal (CPF) do emitente da NFS-e.
                    prestadorXml.CPF = "" + _dadosOrigem.IssContribuinte.Nr_CGCCPF;
                    break;

                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CNPJ:
                    // Número da inscrição federal (CNPJ) do emitente da NFS-e.
                    prestadorXml.CNPJ = "" + _dadosOrigem.IssContribuinte.Nr_CGCCPF;
                    break;
            }

            // Número de identificação fiscal fornecido por órgão de administração tributária no exterior.
            // Se o campo tpEmit for ígual a 1, então NIF do prestador não pode ser informado.	
            prestadorXml.NIF = string.Empty;

            // Número de inscrição municipal do emitente da NFS-e.
            prestadorXml.IM = _dadosOrigem.IssContribuinte.Ds_inscricao_municipal;

            /*
            Motivo para não informação do NIF:
            0 - Não informado na nota de origem;
            1 - Dispensado do NIF;
            2 - Não exigência do NIF;
            sempre preencher com 2.
            */
            prestadorXml.cNaoNIF = "2";

            // Número do Cadastro de Atividade Econômica da Pessoa Física (CAEPF) do prestador do serviço.
            prestadorXml.CAEPF = NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;

            // Nome / Razão Social do prestador
            prestadorXml.xNome = "" + _dadosOrigem.IssContribuinte.Ds_razaosocial;

            /*
            Número do telefone do prestador.
            (Preencher com o Código DDD + número do telefone. 
            Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)
            Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_telefone
            */
            prestadorXml.fone = "" + _dadosOrigem.IssContribuinte.Cd_telefone;

            // E-mail do prestador.
            prestadorXml.email = "" + _dadosOrigem.IssContribuinte.Ds_email;

            // -------------------------------------

            // Grupo de informações do endereço do prestador de serviço.
            var enderecoXml = new InfDpsPrestadorEnderecoXml();
            enderecoXml.endNac = new EnderecoNacionalReduzidoXml();
            enderecoXml.endExt = new EnderecoExteriorXml();
            prestadorXml.end = enderecoXml;


            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_logradouros ==> CECAMLogradouro ==> ds_tipologradouro / ds_logradouro
            // Tipo e nome do logradouro do endereço do prestador do serviço.
            enderecoXml.xLgr = (_dadosOrigem.IssContribuinte.Logradouro?.Ds_TipoLogradouro + " " + _dadosOrigem.IssContribuinte.Logradouro?.Ds_Logradouro).Trim();

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_numero
            // Número no logradouro do endereço do prestador do serviço.
            enderecoXml.nro = "" + _dadosOrigem.IssContribuinte.Cd_numero;

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> ds_complemento
            // Complemento do endereço do prestador do serviço.
            enderecoXml.xCpl = "" + _dadosOrigem.IssContribuinte.Ds_complemento;

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_bairro ==> CECAMBairros ==> ds_bairro
            // Bairro do endereço do prestador do serviço.
            enderecoXml.xBairro = "" + _dadosOrigem.IssContribuinte.Bairro?.Ds_Bairro;

            // Código do município do endereço do prestador do serviço.(Tabela do IBGE)
            // Tabela ISSParametrosCalc ==> campo ==> cod_IBGE ==> CECAMMunicipio ==> Cd_MunicipioIBGE
            enderecoXml.endNac.cMun = "" + _dadosOrigem.Municipio?.Cd_MunicipioIBGE.ToString();

            // Tabela ISSParametrosCalc ==> campo ==> cod_IBGE ==> CECAMMunicipio ==> cd_cepinicial
            // Código numérico do Endereçamento Postal nacional (CEP) do endereço do prestador do serviço.
            enderecoXml.endNac.CEP = "" + _dadosOrigem.Municipio?.Cd_CEPInicial.ToString();

            // Código do país do endereço do prestador do prestador do serviço. (Tabela de Países ISO)
            // sempre preencher com BR = Brasil
            enderecoXml.endExt.cPais = "BR";

            // log fim
            _loggerHelper.GravarTexto($"NfsPrestador.PreencherObjetoComDadosPrestador() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }


        private void PreencherObjetoComDadosRegimeTributario()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null ||
                _dadosOrigem.IssContribuinte == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsPrestador.PreencherObjetoComDadosRegimeTributario() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            if (_dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null || _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null)
                return;

            // atalho para não dar mensagem de possível null
            var infDpsXml = _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps;
            if (infDpsXml == null)
                return;

            var prestadorXml = infDpsXml.prest;
            if (prestadorXml == null)
                return;

            // Grupo de informações relativas aos regimes de tributação do prestador de serviços
            var regimeTributacaoXml = new InfDpsPrestadorRegimeTributacaoXml();
            prestadorXml.regTrib = regimeTributacaoXml;

            /*
            Situação perante Simples Nacional:
            1 - Não Optante;
            2 - Optante - Microempreendedor Individual (MEI);
            3 - Optante - Microempresa ou Empresa de Pequeno Porte (ME/EPP);
            IssContribuintes ==> campo cd_tipocalculo ==> 
                se for 1 a 5 = 1 Não optante  
                se for 7     = 2 Optante - Microempreendedor Individual (MEI)  
                se for 6     = 3 Optante - Microempresa ou Empresa de Pequeno Porte (ME/EPP)
            */
            switch (_dadosOrigem.IssContribuinte.Cd_tipocalculo.GetValueOrDefault())
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    regimeTributacaoXml.opSimpNac = "1";
                    break;

                case 6:
                    regimeTributacaoXml.opSimpNac = "3";
                    break;

                case 7:
                    regimeTributacaoXml.opSimpNac = "2";
                    break;

                default:
                    throw new Exception($"NfsPrestador.PreencherObjetoComDadosRegimeTributario() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} Campo IssContribuinte.Cd_tipocalculo é obrigatório, mas esta vazio na base.");
            }


            /*
            Regime de Apuração Tributária pelo Simples Nacional.
            Opção para que o contribuinte optante pelo Simples Nacional ME/EPP (opSimpNac = 3) possa indicar, ao emitir o documento fiscal, em qual regime de apuração os tributos federais e municipal estão inseridos, caso tenha ultrapassado algum sublimite ou limite definido para o Simples Nacional.
            1 – Regime de apuração dos tributos federais e municipal pelo SN;
            2 – Regime de apuração dos tributos federais pelo SN e o ISSQN pela NFS-e conforme respectiva legislação municipal do tributo;
            3 – Regime de apuração dos tributos federais e municipal pela NFS-e conforme respectivas legilações federal e municipal de cada tributo;
            IssContribuintes ==> campo cd_tipocalculo 
            */
            switch (_dadosOrigem.IssContribuinte.Cd_tipocalculo.GetValueOrDefault())
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    regimeTributacaoXml.regApTribSN = "3";
                    break;

                case 6:
                case 7:
                    regimeTributacaoXml.regApTribSN = "1";
                    break;

                case 8:
                    regimeTributacaoXml.regApTribSN = "2";
                    break;

                default:
                    throw new Exception($"NfsPrestador.PreencherObjetoComDadosRegimeTributario() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} Campo IssContribuinte.Cd_tipocalculo desconhecido.");
            }


            /*
            Tipos de Regimes Especiais de Tributação Municipal:
            0 - Nenhum;
            1 - Ato Cooperado (Cooperativa);
            2 - Estimativa;
            3 - Microempresa Municipal;
            4 - Notário ou Registrador;
            5 - Profissional Autônomo;
            6 - Sociedade de Profissionais
            Desenvolvimento no TFS 138027
            */
            regimeTributacaoXml.regEspTrib = NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;


            // log fim
            _loggerHelper.GravarTexto($"NfsPrestador.PreencherObjetoComDadosRegimeTributario() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }
    }
}
