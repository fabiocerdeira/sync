﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.Iss;
using Cecam.Tributario.Manager.Business.Iss.Filter;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoEmitente
    {
        #region Declarações


        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;


        public NfseGovBrEnviarCorpoEmitente(NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";
        }


        #endregion


        public async Task Processar()
        {
            // Carregar as várias entidades da base de dados para memória
            await CarregarDados();

            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDados();
        }


        /// <summary>
        /// Carregar as várias entidades da base de dados para memória
        /// </summary>
        private async Task CarregarDados()
        {
            if (_dadosOrigem.IssNotaFiscal == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsEmitente.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // contribuinte emitente da nota fiscal
            var issContribuinteBus = new IssContribuinteBus();

            // carregar contribuinte
            _dadosOrigem.IssContribuinte = await issContribuinteBus.CarregarUm(
                new IssContribuinteBusFilter() 
                { 
                    Cd_Contribuinte = _dadosOrigem.IssNotaFiscal.Cd_Contribuinte.GetValueOrDefault(),
                    IncluirBairro = true, 
                    IncluirLogradouro = true 
                });

            if (_dadosOrigem.IssContribuinte == null)
                throw new Exception($"NfsEmitente.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} Não foi possível carregar IssContribuinte");

            // log fim
            _loggerHelper.GravarTexto($"NfsEmitente.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }


        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDados()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.IssContribuinte == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsEmitente.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // Grupo de informações da DPS relativas ao emitente da NFS - e
            var emitenteXml = new EmitenteXml();
            _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Emit = emitenteXml;

            // helper com várias funções para cnpj e cpf.
            var cnpjCpfHelper = new CnpjCpfHelper();

            // Número da inscrição federal (CPF ou CNPJ) do emitente da NFS-e.
            switch (cnpjCpfHelper.VerificarTipo("" + _dadosOrigem.IssContribuinte.Nr_CGCCPF))
            {
                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CPF:

                    // Número da inscrição federal (CPF) do emitente da NFS-e.
                    emitenteXml.CPF = "" + _dadosOrigem.IssContribuinte.Nr_CGCCPF;
                    break;

                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CNPJ:
                    // Número da inscrição federal (CNPJ) do emitente da NFS-e.
                    emitenteXml.CNPJ = "" + _dadosOrigem.IssContribuinte.Nr_CGCCPF;
                    break;
            }

            // Número de inscrição municipal do emitente da NFS-e.
            emitenteXml.IM = _dadosOrigem.IssContribuinte.Ds_inscricao_municipal;

            // Nome / Razão Social do emitente.
            emitenteXml.xNome = "" + _dadosOrigem.IssContribuinte.Ds_razaosocial;

            // Nome / Fantasia do emitente.
            emitenteXml.xFant = "" + _dadosOrigem.IssContribuinte.Ds_fantasia;

            // Número do telefone do emitente.
            // (Preencher com o Código DDD +número do telefone.
            // Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)"
            emitenteXml.fone = "" + _dadosOrigem.IssContribuinte.Cd_telefone;

            // E-mail do emitente.
            emitenteXml.email = "" + _dadosOrigem.IssContribuinte.Ds_email;


            // -------------------------------------

            // Grupo de informações do endereço nacional do Emitente da NFS-e
            var enderecoXml = new EnderecoNacionalXml();
            emitenteXml.enderNac = enderecoXml;

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_logradouros ==> CECAMLogradouro ==> ds_tipologradouro / ds_logradouro
            // Tipo e nome do logradouro da localização do endereço do emitente.
            enderecoXml.xLgr = (_dadosOrigem.IssContribuinte.Logradouro?.Ds_TipoLogradouro + " " + _dadosOrigem.IssContribuinte.Logradouro?.Ds_Logradouro).Trim();

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_numero
            // Número do imóvel do endereço do emitente.
            enderecoXml.nro = "" + _dadosOrigem.IssContribuinte.Cd_numero;

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> ds_complemento
            // Complemento do endereço do emitente.
            enderecoXml.xCpl = "" + _dadosOrigem.IssContribuinte.Ds_complemento;

            // Tabela ISSNotaFiscal ==> campo==> cd_contribuinte ==> Tabela ISSContribuinte ==> cd_bairro ==> CECAMBairros ==> ds_bairro
            // Bairro do endereço do emitente.
            enderecoXml.xBairro = "" + _dadosOrigem.IssContribuinte.Bairro?.Ds_Bairro;

            // Tabela ISSParametrosCalc ==> campo ==> cod_IBGE ==> CECAMMunicipio ==> Cd_MunicipioIBGE
            // Código do município do endereço do emitente. (Tabela do IBGE)
            enderecoXml.cMun = "" + _dadosOrigem.Municipio?.Cd_MunicipioIBGE.ToString();

            // Estado com valor fixo de 'SP'
            // Sigla da unidade da federação do município do endereço do emitente.
            enderecoXml.UF = "" + _dadosOrigem.Municipio?.Sg_UF;

            // Tabela ISSParametrosCalc ==> campo ==> cod_IBGE ==> CECAMMunicipio ==> cd_cepinicial
            // Número do CEP do endereço do emitente.
            // (Informar os zeros não significativos)
            enderecoXml.CEP = "" + _dadosOrigem.Municipio?.Cd_CEPInicial.ToString();

            // log fim
            _loggerHelper.GravarTexto($"NfsEmitente.PreencherObjetoComDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }

    }
}
