﻿using Cecam.Tributario.Database.Enumerado.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.Business.IssNotaFiscal.Filter;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo
{
    internal class NfseGovBrEnviarCorpoCabeca
    {
        #region Declarações

        // logs
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;

        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração da nota fiscal
        /// </summary>
        private readonly NfseGovBrDfeEnviarBusDados _dadosOrigem;

        // queries
        private readonly IIssParametrosCalcQuery _issParametrosCalcQuery;
        private readonly IIssParametrosNfseQuery _issParametrosNfseQuery;

        // repositorios
        private readonly ICecamMunicipioRepository _municipioRepository;


        public NfseGovBrEnviarCorpoCabeca(NfseGovBrDfeEnviarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";

            // queries
            _issParametrosCalcQuery = ServiceProviderGlobal.GetServico<IIssParametrosCalcQuery>();
            _issParametrosNfseQuery = ServiceProviderGlobal.GetServico<IIssParametrosNfseQuery>();

            // repositorios
            _municipioRepository = ServiceProviderGlobal.GetServico<ICecamMunicipioRepository>();
        }


        #endregion


        /// <summary>
        /// Preencher o objeto de Nota Fiscal e seus filhos em memória com os dados carregados da base
        /// </summary>
        public async Task Processar()
        {
            // Carregar as várias entidades da base de dados para memória
            await CarregarDados();

            // verificar dados carregados e regras de negócio
            VerificarDados();

            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDadosCabeca();
            PreencherObjetoComDadosValores();
        }


        /// <summary>
        /// Carregar as várias entidades da base de dados para memória
        /// </summary>
        private async Task CarregarDados()
        {
            // prefixo das mensagens de log
            string logMensagem = $"NfsCabeca.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} ";

            // log início
            _loggerHelper.GravarTexto(logMensagem + "Início");

            // objeto de negocio
            var notaFiscalBus = new IssNotaFiscalBus();

            // carregar a nota fiscal completa com todos os seus dados
            _dadosOrigem.IssNotaFiscal = await notaFiscalBus.Carregar(new IssNotaFiscalBusFilter() 
            { 
                Cd_NotaFiscal = _dadosOrigem.Cd_NotaFiscal,
                IncluirItens = true,
                IncluirTomador = true,
                IncluirIntermediario = true,
                IncluirImpostos = true,
                IncluirServico = true,
                IncluirNbs = true,
                IncluirServicoNacional = true
            });

            if (_dadosOrigem.IssNotaFiscal == null)
                throw new Exception(logMensagem + "NFSe não foi encontrada.");

            // todas as notas fiscais da Cecam tem obrigatoriamente 1 (um) e somente 1 (um) item.
            if (_dadosOrigem.IssNotaFiscal.Itens == null || _dadosOrigem.IssNotaFiscal.Itens.Count != 1)
                throw new Exception(logMensagem + "Qtd de registros na IssNotaFiscalIntes esta errada (obrigatório um e somente um item)");

            // ---------------------------------

            // iss parametros de calculo da nota fiscal
            _dadosOrigem.IssParametrosCalc = await _issParametrosCalcQuery.Carregar();

            if (_dadosOrigem.IssParametrosCalc == null)
                throw new Exception(logMensagem + "Não foi possível carregar IssParametrosCalc");

            // ---------------------------------

            // iss parametros da nota fiscal gov.br
            _dadosOrigem.IssParametrosNfse = await _issParametrosNfseQuery.Carregar();

            if (_dadosOrigem.IssParametrosNfse == null ||
                !_dadosOrigem.IssParametrosNfse.Cd_IBGE.HasValue ||
                string.IsNullOrWhiteSpace(_dadosOrigem.IssParametrosNfse.Nr_CNPJMunicipio))
            {
                throw new Exception(logMensagem + "Não foi possível carregar IssParametrosNfse");
            }

            // ---------------------------------

            // informações do município a partir da tabela IBGE
            _dadosOrigem.Municipio = await _municipioRepository.GetIQueryable()
                .Where(x => x.Cd_MunicipioIBGE == _dadosOrigem.IssParametrosNfse.Cd_IBGE.GetValueOrDefault())
                .FirstOrDefaultAsync();

            // log fim
            _loggerHelper.GravarTexto(logMensagem + "Fim com sucesso");
        }



        /// <summary>
        /// Verificar se todos os dados carregados são suficientes e 
        /// estão corretos para a criação da nota fiscal.
        /// </summary>
        private void VerificarDados()
        {
            if (_dadosOrigem.IssNotaFiscal == null)
                return;

            // inicio da mensagem de erro
            string logMensagem = $"NfsCabeca.VerificarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} ";

            // log início
            _loggerHelper.GravarTexto(logMensagem + "Verificar se pode ser enviada - Início");

            // TODO:
            // se nota fiscal carregada esta na fila de criação/emissão,
            // mas demorou muito tempo para ser enviada e já foi cancelada pelo contribuinte.
            // então não tem porque enviar uma nota cancelada que ainda nem foi enviada.
            if (false)
                throw new Exception(logMensagem + "NFSe foi cancelada antes mesmo de ser enviada para Gov.Br");

            // validar se o campo cnpj/cpf tem os tamanhos corretos ?
            // acontece muitos erros em prefeituras que não emitem a nota fiscal pelo nosso sistema.
            var cnpjCpfHelper = new CnpjCpfHelper();

            if (cnpjCpfHelper.VerificarTipo("" + _dadosOrigem.IssNotaFiscal.Nr_CGCCPF) == CnpjCpfHelper.CnpjCpfHelperTipoEnum.Erro)
                throw new Exception(logMensagem + "O campo ISSNotaFiscal.Nr_CGCCPF não é um CNPJ válido com 14 caracteres e não é um CPF válido com 11 caracteres");

            // campo Nr_ChaveValidacao não pode ser vazio, porque são enviadas somente notas fiscais geradas pelo sistema da Cecam.
            // quando esse campo esta vazio, então essa nota fiscal foi somente escriturada no sistema da cecam, logo não pode ser enviada.
            if (string.IsNullOrWhiteSpace(_dadosOrigem.IssNotaFiscal.Nr_ChaveValidacao))
                throw new Exception(logMensagem + "O campo ISSNotaFiscal.Nr_ChaveValidacao não pode ser vazio, porque somente NFse geradas no sistema da Cecam podem ser enviadas para Gov.Br");

            // log fim
            _loggerHelper.GravarTexto(logMensagem + "Verificar se pode ser enviada - Fim com sucesso");
        }


        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDadosCabeca()
        {
            if (_dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.IssNotaFiscal.Itens == null ||
                _dadosOrigem.IssNotaFiscal.Itens.Count != 1 ||
                _dadosOrigem.IssParametrosNfse == null ||
                _dadosOrigem.NotaFiscalParaEnvio == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosCabeca() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // helper com várias funções para cnpj e cpf.
            var cnpjCpfHelper = new CnpjCpfHelper();

            // criar cabeça da nota fiscal
            var infNfseXml = new InfNfseXml();
            _dadosOrigem.NotaFiscalParaEnvio.InfNFSe = infNfseXml;

            /*
                Informar o identificador precedido do literal 'ID'.

                A formação do identificador de 53 posições da NFS-e é:
                'ID' (o texto 'ID' faz parte da chave)
                'NFS' (o texto 'NFS' faz parte da chave) + 
                Cód.Mun. (7) + 
                Amb.Ger. (1) + 
                Tipo de Inscrição Federal (1) + 
                Inscrição Federal (14 - CPF completar com 000 à esquerda) + 
                nNFSe (13) +
                AnoMes Emis. (4) + 
                Cód.Num. (9) + 
                DV (1)
            */
            infNfseXml.Id = "NFS" +
                _dadosOrigem.IssParametrosNfse.Cd_IBGE.GetValueOrDefault().ToString().PadLeft(7, '0') + "1" +
                ((int)cnpjCpfHelper.VerificarTipo(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF)).ToString() +
                cnpjCpfHelper.RetornaSomenteNumerosLetras(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF).PadLeft(14, '0') +
                _dadosOrigem.IssNotaFiscal.Nr_NotaFiscal.ToString().PadLeft(13, '0') +
                _dadosOrigem.IssNotaFiscal.Cd_Referencia.ToString().Replace("20", "") +
                _dadosOrigem.IssNotaFiscal.Cd_NotaFiscal.ToString().PadLeft(9, '0') + "1";

            // Descrição do código de 7 dígitos da localidade emissora da NFS-e.
            infNfseXml.xLocEmi = _dadosOrigem.IssParametrosNfse.Cd_IBGE.GetValueOrDefault().ToString();

            // Descrição do código de 7 dígitos referente ao local da prestação do serviço.
            if (_dadosOrigem.IssNotaFiscal.Fl_LocalPrestacao == 1)
                infNfseXml.xLocPrestacao = _dadosOrigem.IssParametrosNfse.Cd_IBGE.GetValueOrDefault().ToString();
            else
                infNfseXml.xLocPrestacao = NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;

            // Número da NFS-e (Sequencial pelo emitente e tipo de emitente da NFS-e)
            infNfseXml.nNFSe = _dadosOrigem.IssNotaFiscal.Nr_NotaFiscal.ToString();

            // Código de 7 dígitos da localidade de incidência do ISSQN.
            infNfseXml.cLocIncid = _dadosOrigem.IssParametrosNfse.Cd_IBGE.GetValueOrDefault().ToString();

            // Descrição da localidade de incidência do ISSQN.
            infNfseXml.xLocIncid = "" + _dadosOrigem.Municipio?.Ds_NomeMunicipio ;

            // temos item da nota fiscal ?
            if (_dadosOrigem.IssNotaFiscal.Itens != null && _dadosOrigem.IssNotaFiscal.Itens.Count > 0)
            {
                var itemEntity = _dadosOrigem.IssNotaFiscal.Itens.FirstOrDefault();

                if (itemEntity != null)
                {
                    // Descrição do código de tributação nacional do ISSQN.
                    if (itemEntity.ServicoNacional != null && !string.IsNullOrWhiteSpace(itemEntity.ServicoNacional.Cd_tributacaoNacional))
                        infNfseXml.xTribNac = itemEntity.ServicoNacional.Cd_tributacaoNacional + " - " + itemEntity.ServicoNacional.Ds_servicoDescricao;

                    // Descrição do código de tributação municipal do ISSQN.
                    if (itemEntity.Servico != null && !string.IsNullOrWhiteSpace(itemEntity.Servico.Cd_Servico))
                        infNfseXml.xTribMun = itemEntity.Servico.Cd_Servico + " - " + itemEntity.Servico.Ds_Servico;

                    // Descrição do código da NBS.
                    if (itemEntity.NBS != null && !string.IsNullOrWhiteSpace(itemEntity.NBS.Cd_nbsFormatado))
                        infNfseXml.xNBS = itemEntity.NBS.Cd_nbsFormatado + " - " + itemEntity.NBS.Ds_nbsDescricao;
                }
            }

            // Versão da aplicação que gerou a NFS-e.
            infNfseXml.verAplic = NfseGovBrDfeEnviarBusDados.VersaoGeradorNfse;

            // Ambiente gerador da NFS-e
            // 1 - Sistema Próprio do Município
            // 2 - Sefin Nacional NFS-e
            infNfseXml.ambGer = "1";

            // Tipo de emissão da NFS-e
            // 1 - Emissão normal no modelo da NFS - e Nacional
            // 2 - Emissão original em leiaute próprio do município com transcrição para o modelo da NFS - e Nacional
            infNfseXml.tpEmis = "2";

            // Situações possíveis:
            // 100 - NFS - e Gerada;
            // 101 - NFS - e de Substituição Gerada;
            // 102 - NFS - e de Decisão Judicial;
            // 103 - NFS - e Avulsa; "
            infNfseXml.cStat = "100";


            // Data/Hora da validação da DPS e geração da NFS-e.
            // Data e hora no formato UTC(Universal Coordinated Time)
            // AAAA-MM-DDThh:mm:ssTZD
            infNfseXml.dhProc = _dadosOrigem.IssNotaFiscal.Dt_Emissao.ToString("O");

            // Número sequencial do documento gerado por ambiente gerador de DFe do múnicípio.
            infNfseXml.nDFe = _dadosOrigem.IssNotaFiscal.Cd_NotaFiscal.ToString();

            // log fim
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosCabeca() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }



        private void PreencherObjetoComDadosValores()
        {
            if (_dadosOrigem.NotaFiscalParaEnvio == null ||
                _dadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                _dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.IssNotaFiscal.Itens == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosValores() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // atalho pra item da nota fiscal
            var itemNf = _dadosOrigem.IssNotaFiscal.Itens.FirstOrDefault();

            if (itemNf == null)
                throw new Exception($"NfsCabeca.PreencherObjetoComDadosValores() **erro** Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} não possui IssNotaFiscalItem.");

            var infNfseValoresXml = new InfNfseValoresXml();
            _dadosOrigem.NotaFiscalParaEnvio.InfNFSe.Valores = infNfseValoresXml;

            // Valor monetário (R$) de dedução/redução da base de cálculo (BC) do ISSQN.
            // Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao
            infNfseValoresXml.vCalcDR = itemNf.Vl_Deducao.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);

            /*
                Tipo Benefício Municipal (BM):
                1) Isenção;
                2) Redução da BC em 'ppBM' %;
                3) Redução da BC em R$ 'vInfoBM';
                4) Alíquota Diferenciada de 'aliqDifBM' %;
            */
            // Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao > 0  = 3
            infNfseValoresXml.tpBM = itemNf.Vl_Deducao > 0 ? "3" : string.Empty;


            // Valor monetário (R$) do percentual de redução da base de cálculo (BC) do ISSQN devido a um benefício municipal (BM).
            // Tabela ISSNotaFiscal ==> campo ==> cd_notafiscal ==> Tabela ISSNotaFiscaItem ==> vl_Deducao
            infNfseValoresXml.vCalcBM = itemNf.Vl_Deducao.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);

            /*
            Valor da Base de Cálculo do ISSQN (R$) = Valor do Serviço - Desconto Incondicionado - Deduções/Reduções - Benefício Municipal
            vBC = vServ - descIncond - (vDR ou vCalcDR) - (vRedBCBM ou VCalcBM)
            */
            // Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_item - vl_Deducao
            infNfseValoresXml.vBC = (itemNf.Vl_Item - itemNf.Vl_Deducao).ToString("F2", System.Globalization.CultureInfo.InvariantCulture);

            // Alíquota aplicada sobre a base de cálculo para apuração do ISSQN.
            // Tabela ISSNotaFiscal ==> campo ==> cd_notafiscal ==> Tabela ISSNotaFiscaItem ==> pc_Aliquota
            infNfseValoresXml.pAliqAplic = itemNf.Pc_Aliquota.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);

            // Valor do ISSQN (R$) = Valor da Base de Cálculo x Alíquota
            // vISSQN = vBC x pAliqAplic
            // Tabela ISSNotaFiscal ==> campo ==> cd_notafiscal ==> Tabela ISSNotaFiscaItem ==> Vl_Devido
            infNfseValoresXml.vISSQN = itemNf.Vl_Devido.GetValueOrDefault().ToString("F2", System.Globalization.CultureInfo.InvariantCulture);

            /*
            Valor total de retenções (R$) = Σ(CP + IRRF + CSLL  + ISSQN* +  (PIS + CONFINS)**)
            vTotalRet = (vRetCP + vRetIRRF + vRetCSLL) + vISSQN* + (vPIS + vCOFINS)**
            */
            // Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> fl_retido = 1 ==> vl_Tomado (Verificar tabela ISSNotaFiscalImposto)
            infNfseValoresXml.vTotalRet = NfseGovBrDfeEnviarBusDados.MoedaComValorZero;

            if (itemNf.Fl_Retido == (byte)IssNotaFiscalItemEnum.enumFlRetido.RetidoPeloPrestador && _dadosOrigem.IssNotaFiscal.Impostos != null && _dadosOrigem.IssNotaFiscal.Impostos.Count > 0)
            {
                // somar todos os valores de impostos 
                infNfseValoresXml.vTotalRet = _dadosOrigem.IssNotaFiscal.Impostos.Sum(x => x.Vl_Imposto.GetValueOrDefault()).ToString("F2", System.Globalization.CultureInfo.InvariantCulture);
            }

            /*
            Valor líquido (R$) = Valor do serviço - Desconto condicionado - Desconto incondicionado - Valores retidos (CP, IRRF, CSLL)* - Valores, se retidos (ISSQN, PIS, COFINS)**
            VLiq = vServ – vDescIncond – vDescCond – (vRetCP + vRetIRRF + vRetCSLL)* – ( vISSQN - vPIS + vCOFINS)**
            */
            // Verificar no código da aplicação como é a regra do cálculo do valor líquido da Nota Fiscal 
            infNfseValoresXml.vLiq = NfseGovBrDfeEnviarBusDados.FaltaDesenvolver;

            // log fim
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosValores() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }
    }
}
