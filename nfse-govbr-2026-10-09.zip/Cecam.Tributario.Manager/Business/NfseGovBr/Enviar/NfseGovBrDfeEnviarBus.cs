﻿using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Utf8StringWriter;
using Cecam.Tributario.Manager.Business.NfseGovBr.Enviar.Corpo;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Enviar
{
    /// <summary>
    /// Enviar a próxima Nfse (nota fiscal de serviço eletrônica) para o servidor do gov.br
    /// </summary>
    public class NfseGovBrDfeEnviarBus : NfseGovBrBusBase
    {
        #region Declarações


        /// <summary>
        /// log
        /// </summary>
        private readonly ILogger<NfseGovBrDfeEnviarBus> _logger;


        /// <summary>
        /// converter objeto dados origem base para o dados origem DfeEnviar
        /// </summary>
        private NfseGovBrDfeEnviarBusDados DadosOrigem => (NfseGovBrDfeEnviarBusDados)_dadosOrigem;



        public NfseGovBrDfeEnviarBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrDfeEnviarBus>();
            _loggerHelper.Logger = _logger;

            // Contem TODOS os dados carregados da base para a criação da nota fiscal de serviço
            _dadosOrigem = new NfseGovBrDfeEnviarBusDados();
        }


        #endregion


        /// <summary>
        /// Enviar a próxima Nfse (nota fiscal de serviço eletrônica) para o servidor do gov.br
        /// </summary>
        [Obsolete("NÃO PODE SER USADO, PQ NÃO FAZEMOS ENVIO DE NFSE PARA GOV.BR")]
        public async Task EnviarProximaNotaFiscal()
        {
            // log inicio
            LogAtalho("EnviarProximaNotaFiscal()", "Início");

            try
            {
                // limpar os objetos dessa classe para próxima NFSe.
                LimparObjetosGlobais();

                // Carregar a partir da fila de entrada a próxima nota fiscal que precisa ser enviada para Gov.Br
                if (!(await CarregarProximaNotaFiscalParaEnvio(NfseGovBrEnum.enumFilaTipo.NFSe)))
                    return;

                // Carregar a nota fiscal eletrônica com todas as informações filhas
                await PreencherObjetoNotaFiscalComDados();

                // Converter o objeto de nota fiscal da prefeitura/cecam em texto no formato do objeto Gov.Br
                await ConverterObjetoNotaFiscalParaXML(DadosOrigem.NotaFiscalParaEnvio);

                // Assinar a XML com o certificado seguro
                await PreencherXmlComCertificado();

                // Validar a XML criada contra o XSD do gov.br
                await ValidarXmlContraXsd();

                // realizar o envio da nota fiscal para o servidor da receita federal
                await EnviarNotaFiscal();

                // finalizar o envio da nota fiscal gravando na base na fila de entrada ou na fila de saída.
                await FinalizarComSucessoNoEnvio();
            }
            catch (Exception ex)
            {
                // logar erro
                LogAtalho("EnviarProximaNotaFiscal()", ex.ToString(), LogLevel.Error);

                // marcar Nota Fiscal na fila de entrada como erro e gravar o respectivo erro
                await FinalizarComErroNoEnvio(ex.ToString());

                // limpar os objetos dessa classe para próxima NFSe.
                LimparObjetosGlobais();
            }

            // log fim
            LogAtalho("EnviarProximaNotaFiscal()", "Fim");
        }




        /// <summary>
        /// Carregar a nota fiscal eletrônica com todas as informações filhas
        /// </summary>
        private async Task PreencherObjetoNotaFiscalComDados()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null)
                return;

            // log inicio
            LogAtalho("PreencherObjetoNotaFiscalComDados()", "Início");

            // preencher a cabeça da nota fiscal
            var cabeca = new NfseGovBrEnviarCorpoCabeca(DadosOrigem);
            await cabeca.Processar();

            // emitente
            var emitente = new NfseGovBrEnviarCorpoEmitente(DadosOrigem);
            await emitente.Processar();

            // dps
            var dps = new NfseGovBrEnviarCorpoDps(DadosOrigem);
            dps.Processar();

            // prestador
            var prestador = new NfseGovBrEnviarCorpoPrestador(DadosOrigem);
            prestador.Processar();

            // tomador
            var tomador = new NfseGovBrEnviarCorpoTomador(DadosOrigem);
            await tomador.Processar();

            // servicos
            var servicos = new NfseGovBrEnviarCorpoServico(DadosOrigem);
            servicos.Processar();

            // valores
            var valor = new NfseGovBrEnviarCorpoValor(DadosOrigem);
            valor.Processar();

            // log fim
            LogAtalho("PreencherObjetoNotaFiscalComDados()", "Fim com suceso");
        }


        /// <summary>
        /// Converter o objeto de nota fiscal da prefeitura/cecam em texto no formato do objeto Gov.Br
        /// </summary>
        private async Task ConverterObjetoNotaFiscalParaXML__desligado()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.IssNotaFiscal == null ||
                DadosOrigem.NotaFiscalParaEnvio == null)
                return;

            // log inicio
            LogAtalho("ConverterObjetoNotaFiscalParaXML()", "Início");

            // nameSpaces vazio nó raiz da xml.
            var ns = new XmlSerializerNamespaces(new[] {XmlQualifiedName.Empty } );
            // ns.Add("", "");

            // objeto serializador
            var serializer = new XmlSerializer(DadosOrigem.NotaFiscalParaEnvio.GetType());

            using (var writer = new Utf8StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(writer, new XmlWriterSettings()
                {
                    Indent = true, // remover tabulação para economizar espaços
                    NamespaceHandling = NamespaceHandling.Default
                }))

                serializer.Serialize(xmlWriter, DadosOrigem.NotaFiscalParaEnvio, ns);
                DadosOrigem.XmlParaEnvioAsString = writer.ToString();

                // desligado em 2025-10-14 pq vou resolver via xmlSerializer !!
                // bacalhau
                // para corrigir nameSpace pq o XmlSerializer não esta inserindo no objeto interno qnd tem a mesma Url do objeto Root
                // DadosOrigem.XmlParaEnvioAsString = DadosOrigem.XmlParaEnvioAsString.Replace("http://www.sped.fazenda.gov.br/nfse#", "http://www.sped.fazenda.gov.br/nfse");

                // somente par debugar
                // Console.WriteLine(DadosOrigem.XmlParaEnvioAsString);

                // log trace
                _logger.LogTrace(DadosOrigem.XmlParaEnvioAsString);
            }

            // atualizar o corpo na fila de entrada
            DadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo = DadosOrigem.XmlParaEnvioAsString;

            // gravar somente a xml em arquivo separado
            // _logSimpleHelper.GravarLogArquivoDisco("nfse_" + DadosOrigem.Cd_NotaFiscal.ToString() + "_xml", DadosOrigem.XmlParaEnvioAsString);

            // log fim
            LogAtalho("ConverterObjetoNotaFiscalParaXML()", "Fim");

            await Task.FromResult(0);
        }


        /// <summary>
        /// Assinar a XML com o certificado seguro
        /// </summary>
        private async Task PreencherXmlComCertificado()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.IssNotaFiscal == null ||
                DadosOrigem.NotaFiscalParaEnvio == null ||
                DadosOrigem.NotaFiscalParaEnvio.InfNFSe == null ||
                DadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps == null ||
                DadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps == null ||
                DadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("PreencherXmlComCertificado()", "Início");

            // a NFSe tem 2 assinaturas, uma para a NFSe outra para a DPS, cada uma com seu respectivo ID
            var dicNodes = new Dictionary<string, string>();
            dicNodes.Add("NFSe", "" + DadosOrigem.NotaFiscalParaEnvio.InfNFSe.Id);
            dicNodes.Add("DPS", "" + DadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps?.id);

            // assinar a xml com o certificado seguro nos nodes informados.
            PreencherXmlComCertificadoVariosNodes(dicNodes);

            // log fim
            LogAtalho("PreencherXmlComCertificado()", "Fim");

            await Task.CompletedTask;
        }


        /// <summary>
        /// Validar a XML criada contra o XSD do gov.br
        /// </summary>
        private async Task ValidarXmlContraXsd()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("ValidarXmlContraXsd()", "Início");

            // xsd para envio da NFSE
            var xsdPath = AppDomain.CurrentDomain.BaseDirectory + "Business\\NfseGovBr\\Xsds\\";

            await ValidarXmlContraXsdProcessar(new List<string>()
            {
                xsdPath + "NFSe_v1.00.xsd",
                xsdPath + "tiposComplexos_v1.00.xsd",
                xsdPath + "tiposSimples_v1.00.xsd"
            });

            // log fim
            LogAtalho("ValidarXmlContraXsd()", "Fim");
        }


        /// <summary>
        /// Realizar o envio da nota fiscal para o servidor da receita federal
        /// </summary>
        private async Task EnviarNotaFiscal()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.IssNotaFiscal == null ||
                DadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("EnviarNotaFiscal()", "Início");

            // guardar o corpo da nfse antes de enviar para o servidor do gov.br
            DadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo = DadosOrigem.XmlParaEnvioAsString;

            // objeto que faz o envio para API da receita federal no módulo ADN.
            var adnExternal = new NfseGovBrAdnExternal();

            // enviar
            var respostaExternal = await adnExternal.DfeEnviar(DadosOrigem.XmlParaEnvioAsString);

            // verificar se não temos resposta?
            if (respostaExternal == null)
                throw new Exception("EnviarNotaFiscal() - método adnExternal.EnviarDfe() retornou uma resposta vazia **erro**");

            // guardar resposta na tabela de fila
            DadosOrigem.NotaFiscalFilaEntrada.EnvioMensagem = Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal);

            if (respostaExternal.Sucesso)
            {
                // completar os dados da tabela IssNotaFiscal com os dados retornados do servidor gov.br
                LogAtalho("EnviarNotaFiscal()", "Atualizar tabela ISSNotaFiscal com retorno do servidor gov.br");

                if (respostaExternal.Item == null ||
                    respostaExternal.Item.DfeRecepcaoLote == null ||
                    respostaExternal.Item.DfeRecepcaoLote.Lote == null ||
                    respostaExternal.Item.DfeRecepcaoLote.Lote.Count == 0)
                {
                    // log resposta com erro
                    throw new Exception("EnviarNotaFiscal().AdnExternal.EnviarDfe() - DfeRecepcaoLote com erro" + Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal));
                }

                var dfeResposta = respostaExternal.Item.DfeRecepcaoLote.Lote.FirstOrDefault();

                if (dfeResposta == null)
                {
                    // log resposta com erro
                    throw new Exception("EnviarNotaFiscal().AdnExternal.EnviarDfe() - DfeRecepcaoLote sem primeiro item do lote - **erro**" + Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal));
                }

                // completar a nota fiscal com os dados retornados do gov.br
                DadosOrigem.IssNotaFiscal.Govbr_ChaveAcesso = dfeResposta.ChaveAcesso;
                DadosOrigem.IssNotaFiscal.GovBr_NsuEnvio = dfeResposta.Nsu;
            }
            else
            {
                // log resposta com erro
                throw new Exception("EnviarNotaFiscal().AdnExternal.EnviarDfe() - Resposta do gov.br com erro" + Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal));
            }

            // log fim
            LogAtalho("EnviarNotaFiscal()", "Fim");
        }



        #region Auxiliares


        /// <summary>
        /// Limpar os objetos globais para processar uma nova NFSe
        /// </summary>
        private void LimparObjetosGlobais()
        {
            // objetos globais coma nota fiscal que será enviada
            _dadosOrigem = new NfseGovBrDfeEnviarBusDados();
        }


        #endregion
    }
}