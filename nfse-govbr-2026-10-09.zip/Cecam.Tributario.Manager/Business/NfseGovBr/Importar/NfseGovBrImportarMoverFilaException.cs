﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Cecam.Tributario.Database.Enumerado.NfseGovBr.NfseGovBrEnum;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar
{
    /// <summary>
    /// Exception usado no fluxo de importação de NFSe
    /// </summary>
    internal class NfseGovBrImportarMoverFilaException : Exception
    {
        #region Propriedades

        public enumFilaStatus FilaStatus { get; set; }

        #endregion


        public NfseGovBrImportarMoverFilaException(string mensagem, enumFilaStatus filaStatus) : base(mensagem) 
        {
            FilaStatus = filaStatus;
        }
    }
}
