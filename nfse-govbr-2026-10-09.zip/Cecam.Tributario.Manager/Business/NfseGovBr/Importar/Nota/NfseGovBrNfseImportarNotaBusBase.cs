﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Xml.Serialization;
using static Cecam.Tributario.Database.Enumerado.NfseGovBr.NfseGovBrEnum;


namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota
{
    public abstract class NfseGovBrNfseImportarNotaBusBase
    {
        #region Declarações


        /// <summary>
        /// repositorio para ler as NFSe baixadas e que serão importadas para base prefeitura/cecam
        /// </summary>
        protected readonly IIssNotaFiscalGovBrImportarEntradaRepository _filaEntradaRepository;


        /// <summary>
        /// Repositório para gravar as NFSe que foram importadas com sucesso
        /// </summary>
        protected readonly IIssNotaFiscalGovBrImportarSaidaRepository _filaSaidaRepository;


        /// <summary>
        /// log
        /// </summary>
        protected readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Informações da NFSe baixada do gov.br para gravar na base da prefeitura/cecam
        /// </summary>
        protected NfseGovBrNfseImportarNotaBusDados _dadosOrigem = new NfseGovBrNfseImportarNotaBusDados();


        /// <summary>
        /// NSU para carregar da base para ser processado ignorando a ordem da fila de entrada
        /// </summary>
        public long? NsuProcessar {  get; set; }

        
        /// <summary>
        /// Chave de Acesso para carregar da base para ser processado ignorando a ordem da fila de entrada
        /// </summary>
        public string? ChaveAcessoProcessar { get; set; }


        /// <summary>
        /// Ignorar a data hora do ultimo processamento
        /// </summary>
        public bool IgnorarDataHoraProcessamento { get; set; } = false;



        protected NfseGovBrNfseImportarNotaBusBase()
        {
            // logs
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;

            // repositorio para ler as nfse baixadas de gov.br para serem importadas
            _filaEntradaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarEntradaRepository>();

            // repositorio gravar as NFSe importadas com sucesso
            _filaSaidaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarSaidaRepository>();
        }


        #endregion


        #region Finalizar


        /// <summary>
        /// A importação da NFSe da fila para a base prefeitura/cecam na tabela ISSNotaFiscal foi com sucesso
        /// Mover uma nfse da fila de entrada para a fila de saída
        /// </summary>
        protected async Task FinalizarComSucessoNaImportacao()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null || _dadosOrigem.NotaFiscalImportada == null)
                return;

            // log inicial
            LogAtalho("NfseGovBrNfseImportarBusBase.FinalizarComSucessoNaImportacao()", $"Início - NfseId = {_dadosOrigem.NfseId()}");

            // sucesso absoluto em todos os aspectos da importação e gravação.
            // então preparar o registro de entrada para ser copiado para o registro de saída

            // status de sucesso
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Status = (int)enumFilaStatus.ProcessadoComSucesso;

            // limpar mensagem de qnd estava na fila de entrada
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem = null;

            // finalizar
            await FinalizarMoverEntradaSaida();

            // log final
            LogAtalho("NfseGovBrNfseImportarBusBase.FinalizarComSucessoNaImportacao()", $"Fim - NfseId = {_dadosOrigem.NfseId()}");
        }


        /// <summary>
        /// Mover NFSe da fila de entrada para a fila de saída
        /// </summary>
        protected async Task FinalizarMoverEntradaSaida()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
                return;

            // log inicial
            LogAtalho("NfseGovBrNfseImportarBusBase.FinalizarMoverEntradaSaida()", $"Início - NfseId = {_dadosOrigem.NfseId()}");

            var notaFiscalFilaSaida = new IssNotaFiscalGovBrImportarSaidaEntity()
            {
                Cd_Cecam = _dadosOrigem.NotaFiscalFilaImportarEntrada.Cd_Cecam,
                FilaTipo = _dadosOrigem.NotaFiscalFilaImportarEntrada.FilaTipo,
                Status = _dadosOrigem.NotaFiscalFilaImportarEntrada.Status,
                ChaveAcesso = _dadosOrigem.NotaFiscalFilaImportarEntrada.ChaveAcesso,
                Nsu = _dadosOrigem.NotaFiscalFilaImportarEntrada.Nsu,
                NfseId = _dadosOrigem.NfseId(),
                DpsId = _dadosOrigem.DpsId(),
                DataHoraDocumento = _dadosOrigem.NotaFiscalFilaImportarEntrada.DataHoraDocumento,
                TipoDocumento = _dadosOrigem.NotaFiscalFilaImportarEntrada.TipoDocumento,
                TipoEvento = _dadosOrigem.NotaFiscalFilaImportarEntrada.TipoEvento,
                DataHoraCriacao = _dadosOrigem.NotaFiscalFilaImportarEntrada.DataHoraCriacao,
                DataHoraProcessamento = DateTime.UtcNow.AddHours(-3),
                Corpo = _dadosOrigem.NotaFiscalFilaImportarEntrada.Corpo,
                Mensagem = _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem,
                Cd_Contribuinte = _dadosOrigem.NotaFiscalFilaImportarEntrada.Cd_Contribuinte,
                Nr_CGCCPF = _dadosOrigem.NotaFiscalFilaImportarEntrada.Nr_CGCCPF
            };

            // salvar fila saída
            _filaSaidaRepository.Add(notaFiscalFilaSaida);
            await _filaSaidaRepository.SaveChangesAsync();

            // apagar da fila de entrada
            _filaEntradaRepository.DbSetEntity.Remove(_dadosOrigem.NotaFiscalFilaImportarEntrada);
            await _filaEntradaRepository.SaveChangesAsync();

            // log final
            LogAtalho("NfseGovBrNfseImportarBusBase.FinalizarMoverEntradaSaida()", $"Fim - NfseId = {_dadosOrigem.NfseId()}");
        }


        /// <summary>
        /// Durante a importação de NFSe de XML para base prefeitura/cecam acontece um erro
        /// Então atualizar a fila de entrada com a mensagem de erro
        /// </summary>
        protected async Task FinalizarComErroNaImportacao(string mensagemErro, NfseGovBrEnum.enumFilaStatus novoStatus, string? motivo = null)
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
                return;

            // log inicial
            LogAtalho("NfseGovBrNfseImportarBusBase.FinalizarComErroNaImportacao()", $"Início - NfseId = {_dadosOrigem.NfseId()} novoStatus = {novoStatus} mensagemErro = {mensagemErro}");

            // atualizar a nota fiscal na fila de entrada
            _dadosOrigem.NotaFiscalFilaImportarEntrada.DataHoraProcessamento = DateTime.UtcNow.AddHours(-3);
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Status = (int)novoStatus;
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem = mensagemErro;
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Motivo = motivo;

            // atualizar na base
            await _filaEntradaRepository.SaveChangesAsync();

            // log inicial
            LogAtalho("NfseGovBrNfseImportarBusBase.FinalizarComErroNaImportacao()", $"Fim - NfseId = {_dadosOrigem.NfseId()}");
        }


        #endregion


        /// <summary>
        /// Carregar a partir da fila de entrada a próxima nota fiscal para ser importada para base prefeitura/cecam na tabela IssNotaFiscal
        /// IssNotaFiscalGovBrEnum.FilaTipo_EMISSAO_NF=1 | IssNotaFiscalGovBrEnum.FilaTipo_CANCELAMENTO_NF=2
        /// </summary>
        protected async Task<bool> CarregarProximaNotaFiscalParaImportacao(NfseGovBrEnum.enumFilaTipo filaTipo)
        {
            // log inicio
            LogAtalho("NfseGovBrNfseImportarNotaBusBase.CarregarProximaNotaFiscalParaImportacao()", $"Início - filaTipo = {filaTipo}");

            if (NsuProcessar != null)
            {
                // temos NSU para processar ignorando a ordem da fila.
                _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                    .Where(x => x.FilaTipo == (int)filaTipo && x.Nsu == NsuProcessar)
                    .FirstOrDefaultAsync();

                // limpar apos carregar
                NsuProcessar = null;
            }
            else if (!string.IsNullOrWhiteSpace(ChaveAcessoProcessar))
            {
                // temos Chave de Acesso para processar ignorando a ordem da fila.
                _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                    .Where(x => x.FilaTipo == (int)filaTipo && x.ChaveAcesso == ChaveAcessoProcessar)
                    .OrderBy(x => x.Nsu)
                    .FirstOrDefaultAsync();

                // limpar apos carregar
                ChaveAcessoProcessar = null;
            }
            else
            {
                int incrementarHoras = -4;
                if (IgnorarDataHoraProcessamento) incrementarHoras = 10;

                // carregar uma nota fiscal que foi emitida/cridada (filaTipo=1) na fila de entrada
                // carregar uma nota fiscal que foi cancelada (filaTipo=2) na fila de entrada
                // notas fiscais ainda não importadas status=0
                // notas fiscais já tentou importar anteriormente e deu erro status=1
                _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                        .Where(x => x.FilaTipo == (int)filaTipo &&
                        (
                            x.Status == (int)NfseGovBrEnum.enumFilaStatus.BaixadoAguardandoProcessar ||
                            (
                                x.Status == (int)NfseGovBrEnum.enumFilaStatus.ProcessadoComErro &&
                                x.DataHoraProcessamento.HasValue &&
                                x.DataHoraProcessamento.Value <= DateTime.UtcNow.AddHours(incrementarHoras)
                            )
                        ))
                        .OrderBy(x => x.Nsu)
                        .FirstOrDefaultAsync();
            }

            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
            {
                // log fim
                LogAtalho("NfseGovBrNfseImportarNotaBusBase.CarregarProximaNotaFiscalParaImportacao()", $"Fim - NÃO existem NFSe do tipo {filaTipo} na fila de entrada para importar da fila para prefeitura/cecam");
                return false;
            }

            // log fim
            LogAtalho("NfseGovBrNfseImportarNotaBusBase.CarregarProximaNotaFiscalParaImportacao()", $"Fim - filaTipo = {filaTipo}");

            // valor retornado pelo método qnd temos nota fiscal na fila 
            return true;
        }


        /// <summary>
        /// Converter a XML em formato string para objeto que representa a XML da NFSe
        /// </summary>
        protected void ConverterXmlStringParaClasse()
        {
            // objeto serializador
            var serializer = new XmlSerializer(typeof(NfseXml));

            using (StringReader reader = new StringReader("" + _dadosOrigem.NotaFiscalFilaImportarEntrada?.Corpo))
            {
                var nf = (NfseXml?)serializer.Deserialize(reader);

                if (nf != null)
                {
                    // informar objeto XML de origem
                    _dadosOrigem.NotaFiscalImportada = nf;
                }
            }
        }


        #region Auxiliares


        /// <summary>
        /// Somente um atalho para gravar o log.
        /// </summary>
        protected void LogAtalho(string metodo, string texto, LogLevel logLevel = LogLevel.Information)
        {
            _loggerHelper.PrefixoNomeArquivo = string.Empty;

            if (!string.IsNullOrWhiteSpace(_dadosOrigem.NfseId()))
            {
                _loggerHelper.PrefixoNomeArquivo = "nfse_importar_id_" + _dadosOrigem.NfseId() + "_";
            }

            _loggerHelper.GravarTexto(metodo + " " + texto, logLevel);
        }


        /// <summary>
        /// Limpar os objetos globais para importar uma NFSe
        /// </summary>
        protected void LimparObjetosGlobais()
        {
            // objetos globais com a nota fiscal que será baixada
            _dadosOrigem = new NfseGovBrNfseImportarNotaBusDados();
        }


        #endregion
    }
}
