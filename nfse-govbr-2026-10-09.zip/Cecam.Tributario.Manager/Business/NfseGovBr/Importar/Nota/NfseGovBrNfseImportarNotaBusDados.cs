﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Manager.Business.IssParametros;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota
{
    /// <summary>
    /// Informações da NFSe baixada do gov.br para gravar na base da prefeitura/cecam
    /// </summary>
    public class NfseGovBrNfseImportarNotaBusDados
    {
        #region Declarações

        
        /// <summary>
        /// Fila com notas fiscais para serem importadas
        /// </summary>
        public IssNotaFiscalGovBrImportarEntradaEntity? NotaFiscalFilaImportarEntrada;


        /// <summary>
        /// Lista com notas fiscais importadas com sucesso
        /// </summary>
        public IssNotaFiscalGovBrImportarSaidaEntity? NotaFiscalFilaImportarSaida;


        /// <summary>
        /// Xml no formato texto/string com o objeto de NFSe ou Evento baixado de gov.br
        /// </summary>
        public string XmlImportadaAsString = string.Empty;


        /// <summary>
        /// Classe raiz da XMl em formato objeto com a NFSe baixada de gov.br
        /// </summary>
        public NfseXml? NotaFiscalImportada;


        /// <summary>
        /// IssNotaFiscal (cabeça da NFSe)
        /// </summary>
        public IssNotaFiscalEntity? IssNotaFiscalEnty;


        /// <summary>
        /// Parametros da NFse configurados pelo VB
        /// </summary>
        public IssParametrosNfseEntity? IssParametrosNfse;


        /// <summary>
        /// Parametros de calculos para ISS do VB
        /// </summary>
        public IssParametrosCalcBus? IssParametrosCalculoBus;


        /// <summary>
        /// Contribuinte emissor da nota (prestador/emitente)
        /// </summary>
        public IssContribuinteEntity? IssContribuinte;


        #endregion


        /// <summary>
        /// NSU do documento gov.br
        /// </summary>
        public long Nsu()
        {
            return NotaFiscalFilaImportarEntrada?.Nsu ?? 0;
        }


        /// <summary>
        /// Retornar ID da NFSe (chave de acesso)
        /// </summary>
        public string NfseId()
        {
            return NotaFiscalImportada?.InfNFSe?.Id?.Trim() ?? string.Empty;
        }


        /// <summary>
        /// Retornar ID da DPS
        /// </summary>
        public string DpsId()
        {
            return NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.id?.Trim() ?? string.Empty;
        }
    }
}
