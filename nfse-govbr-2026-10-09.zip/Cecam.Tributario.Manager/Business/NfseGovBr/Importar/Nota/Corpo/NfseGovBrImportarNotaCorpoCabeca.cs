﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Enumerado.Iss;
using Cecam.Tributario.Database.Enumerado.IssNotaFiscal;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.Filter.Endereco;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.Iss;
using Cecam.Tributario.Manager.Business.Iss.Filter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota.Corpo
{
    internal class NfseGovBrImportarNotaCorpoCabeca
    {
        #region Declarações


        /// <summary>
        /// logs
        /// </summary>
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Dados para importação
        /// </summary>
        private NfseGovBrNfseImportarNotaBusDados _dadosOrigem;


        /// <summary>
        /// Parametros da NFSe na prefeitura/cecam
        /// </summary>
        private readonly IIssParametrosNfseQuery _issParametrosNfseQuery;


        /// <summary>
        /// Municipios do Brasil com respectivos IBGE 
        /// </summary>
        private readonly ICecamMunicipioQuery _cecamMunicipioQuery;


        public NfseGovBrImportarNotaCorpoCabeca(NfseGovBrNfseImportarNotaBusDados dadosOrigem, ILoggerHelper loggerHelper)
        {
            // dados durante a conversão
            _dadosOrigem = dadosOrigem;

            // logs
            _loggerHelper = loggerHelper;

            // parametros da NFSe na prefeitura/cecam
            _issParametrosNfseQuery = ServiceProviderGlobal.GetServico<IIssParametrosNfseQuery>();

            // Municipios do Brasil com respectivos IBGE 
            _cecamMunicipioQuery = ServiceProviderGlobal.GetServico<ICecamMunicipioQuery>();
        }


        #endregion


        /// <summary>
        /// Converter a cabeça da NFSe com origem do Gov.Br para prefeitura/cecam
        /// </summary>
        public async Task Processar()
        {
            if (_dadosOrigem == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfseGovBrImportarCorpoCabeca.Processar() NfseId={_dadosOrigem.NfseId()} - Início");

            // Validar se objeto xml contem os campos obrigatorios
            Validar();

            // criar IssNotaFiscal de saída no formato prefeitura/cecam
            _dadosOrigem.IssNotaFiscalEnty = new IssNotaFiscalEntity();

            // Carregar as várias entidades da base de dados para memória
            await CarregarDados();

            // Preencher com o prestador/contribuinte
            await ProcessarPrestador();

            // Preencher com o tomador
            await ProcessarTomador();

            // Preencher com o intermediario
            await ProcessarIntermediario();

            // Preencher a cabeça da NFSe da prefeitura/cecam
            ProcessarCabeca();

            // Processar local de Prestacao
            await ProcessarLocalPrestacao();

            // log fim
            _loggerHelper.GravarTexto($"NfseGovBrImportarCorpoCabeca.Processar() NfseId={_dadosOrigem.NfseId()} - Fim");
        }


        /// <summary>
        /// Converter a cabeça da NFSe com origem do Gov.Br para prefeitura/cecam
        /// </summary>
        private void ProcessarCabeca()
        {
            if (_dadosOrigem == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarCabeca() ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // codigo cecam
            nfse.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // objeto infDPS
            var infDps = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps;

            // validação
            if (infDps == null)
                return;

            if (DateTime.TryParse(infDps.dhEmi, out var dtEmissao))
            {
                /*---------------------------------------------------------------------------------------------*/
                /* se for prefeitura de JUQUIA recuperar a data de competência para gravar na REFERENCIA       */
                /* Cartão: 148563                                                                              */
                /* INICIO  - dentro do ELSE é o código para todas as outras prefeituras                        */
                /*---------------------------------------------------------------------------------------------*/
                if (nfse.Cd_Cecam==301)
                {
                    if (DateTime.TryParse(infDps.dCompet, out var dtCompetencia))
                    {
                        // ano/mes de referencia
                        if (int.TryParse(dtCompetencia.ToString("yyyyMM"), out var cdCompetenciaAnoMes))
                        {
                            nfse.Cd_Referencia = cdCompetenciaAnoMes;
                        }
                        else 
                        {
                            // não conseguiu converter a data de competencia em ano/mes de referencia
                            throw new Exception(exceptionMsg + "- ano/mes referencia não convertido da competencia");
                        }
                    }
                    else
                    {
                        // não conseguiu recuperar a data de competencia
                        throw new Exception(exceptionMsg + "- ano/mes/dia referencia não importado da competencia");
                    }
                }
                else
                {
                    /*---------------------------------------------------------------------------------------------*/
                    // Cartão: 148563                                                                              */
                    /* FIM  - dentro do ELSE é o código para todas as outras prefeituras                           */
                    /*---------------------------------------------------------------------------------------------*/

                    if (int.TryParse(dtEmissao.ToString("yyyyMM"), out var cdReferenciaAnoMes))
                    {
                        // ano/mes de referencia
                        nfse.Cd_Referencia = cdReferenciaAnoMes;
                    }
                    else
                    {
                        // não conseguiu converter a data de emissão em ano/mes de referencia
                        throw new Exception(exceptionMsg + "- ano/mes referencia não importado");
                    }
                }

            // data de emissão
            nfse.Dt_Emissao = dtEmissao;

            // data de criação
            nfse.Dt_Criacao = dtEmissao;

            // data de atualização
            nfse.Dt_Atualizacao = dtEmissao;
        }
        else
        {
            // não consegui converter a data de emissão da nfse em uma data válida
            throw new Exception(exceptionMsg + "- data emissão não importado");
        }

        // validar
        if (nfse.Cd_Referencia <= 0)
            throw new Exception(exceptionMsg + "- cd_referencia não importado");

        // validar
        if (nfse.Dt_Emissao == DateTime.MinValue)
            throw new Exception(exceptionMsg + "- dt_emissao não importado");

        // ----------------------------------------------

        // tipo de documento
        if (_dadosOrigem?.IssParametrosCalculoBus?.IssParametrosCalc != null)
            nfse.Cd_TipoDocumento = _dadosOrigem.IssParametrosCalculoBus.IssParametrosCalc.Cd_NFETipoDocto.GetValueOrDefault();

        // validar
        if (nfse.Cd_TipoDocumento <= 0)
            throw new Exception(exceptionMsg + "- cd_tipoDocumento não importado");

        // ----------------------------------------------

        // Nr_NotaFiscal
        if (decimal.TryParse(_dadosOrigem?.NotaFiscalImportada?.InfNFSe?.nNFSe, out var nrNF))
        {
            nfse.Nr_NotaFiscal = nrNF;
        }

        // validar
        if (nfse.Nr_NotaFiscal <= 0)
            throw new Exception(exceptionMsg + "- nr_notaFiscal não importado");

        // código da situação
        // 0 = ativa
        // 1 = cancelada
        nfse.Cd_Situacao = 0;

        // observação (sempre vazio)
        nfse.Ds_Observacao = string.Empty;

        // numero da nfse substituta
        nfse.Nr_NotaFiscalSubstituta = 0;

        // numero aviso (sempre vazio)
        nfse.Nr_Aviso = string.Empty;

        // flag web (sempre zero)
        nfse.Fl_Web = 0;

        // chave de validação (sempre vazio)
        // será gerado automaticamente pelo sistema no momento da gravação da NFSe na base prefeitura/cecam
        nfse.Nr_ChaveValidacao = string.Empty;

        // cd_rps
        // é gerado pela tela de wfGeracaoRPS.aspx
        nfse.Cd_RPS = null;

        // numero do lote
        // utilizado somente pelo webservice de importação da NFSe
        // então aqui no fluxo de importação do gov.br o valor padrão é sempre 0 (zero)
        nfse.Nr_Lote = 0;

        // sempre null para importação gov.br
        nfse.Cd_PreNota = null;

        // campos gov.br
        nfse.Govbr_ChaveAcesso = ("" + _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Id).Replace("NFS", string.Empty);
        nfse.GovBr_NsuEnvio = null;
        nfse.GovBr_NsuCancelamento = null;
        nfse.GovBr_NfseId = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Id;
        nfse.GovBr_DpsId = infDps?.id;
        nfse.Govbr_EventoUltimaConsulta = null;

        // guardar na NFSe cabeça o mesmo tipo de calculo existente no IssContribuinte
        nfse.Cd_TipoCalculo = _dadosOrigem?.IssContribuinte?.Cd_tipocalculo;

        // log fim
        _loggerHelper.GravarTexto(exceptionMsg + $"- NfseId={_dadosOrigem?.NfseId()} - Fim");
    }


    /// <summary>
    /// Tratamento do campo Fl_LocalPrestacao
    /// </summary>
    private async Task ProcessarLocalPrestacao()
    {
        /*
        (0) AINDA NÃO SABEMOS O QUE SIGNIFICA !
        (1) Na Sede do Prestador do Serviço (Mesmo local da emissão da NF) 
        (2) Em imóvel específico no município
        (3) Via pública
        (4) Fora do município

        0 = AINDA NÃO SABEMOS O QUE SIGNIFICA !

        1 = prestador e tomador são do mesmo municipio
        e local prestação na sede do prestador
        infDPS->cLocEmi == toma->cMun &&
        infDPS->cLocEmi == serv->locPrest->cLocPrestacao

        1 = prestador e tomador são municipios diferentes
        e local prestação na sede do prestador
        infDPS->cLocEmi != toma->cMun &&
        infDPS->cLocEmi == serv->locPrest->cLocPrestacao

        2 = TALVEZ:
        precisa ter a Insc Municipal do Imovel na NFSe e
        provavelmente local prestação na sede do prestador

        3 = TALVEZ:
        prestador e tomador são municipios diferentes e
        local prestação fora do municipio do prestador

        4 = (prestador e tomador são do mesmo municipio OU são municipios diferentes) e 
        local prestação fora do municipio do prestador
        nesse caso o campo 'pcd_CidadePrestacao' precisa ser informado.
        infDPS->cLocEmi == toma->cMun &&
        infDPS->cLocEmi != serv->locPrest->cLocPrestacao
        */

            // local de prestação
            if (_dadosOrigem == null || _dadosOrigem.IssParametrosNfse == null)
                return;

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // objeto infDPS
            var infDps = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps;

            // validação
            if (infDps == null)
                return;

            // codigo do imovel (sempre zero)
            nfse.Cd_Imovel = 0;

            // valores default para endereço do local de prestação
            nfse.Cd_CidadePrestacao = 0;
            nfse.Nm_Logradouro = string.Empty;
            nfse.Nr_Numero = string.Empty;
            nfse.Ds_Complemento = string.Empty;
            nfse.Nm_Bairro = string.Empty;
            nfse.Cd_CEP = string.Empty;

            // helper para campos string
            var stringHelp = new StringHelper();

            // municipio do tomador
            var tomadorMunicipio = "" + infDps.toma?.end?.endNac?.cMun;

            // muncipio aonde foi executado/prestado o serviço
            var localPrestacaoMunicipio = "" + infDps.serv?.locPrest?.cLocPrestacao;

            // pais aonde foi executado/prestado o serviço
            var paisPrestacao = ("" + infDps.serv?.locPrest?.cPaisPrestacao).Trim().ToUpper();

            // flag que indica se a prestação do servico foi realizada em outro pais estrangeiro?
            var hePrestacaoNoExterior = (!string.IsNullOrEmpty(paisPrestacao) && !string.Equals(paisPrestacao, "BR", StringComparison.InvariantCultureIgnoreCase));

            // municipio do prestador
            var prestadorMunicipio = "" + infDps.cLocEmi;

            // prestador e tomador são do mesmo municipio e local prestação na sede do prestador
            if (prestadorMunicipio == tomadorMunicipio && localPrestacaoMunicipio == prestadorMunicipio)
            {
                nfse.Fl_LocalPrestacao = (byte)IssNotaFiscalEnum.enumLocalPrestacao.NaSedeDoPrestador;
            }
            // prestador e tomador são municipios diferentes e local prestação na sede do prestador
            else if (prestadorMunicipio != tomadorMunicipio && localPrestacaoMunicipio == prestadorMunicipio)
            {
                nfse.Fl_LocalPrestacao = (byte)IssNotaFiscalEnum.enumLocalPrestacao.NaSedeDoPrestador;
            }
            // (prestador e tomador são do mesmo municipio OU são municipios diferentes) e local prestação fora do municipio do prestador
            else if (localPrestacaoMunicipio != prestadorMunicipio || hePrestacaoNoExterior)
            {
                // local prestação é fora do municipio do prestador que emitiu a nota
                nfse.Fl_LocalPrestacao = (byte)IssNotaFiscalEnum.enumLocalPrestacao.ForaDoMunicipioDoPrestador;

                // verificar se temos municipio do Brasil ?
                if (!string.IsNullOrWhiteSpace(localPrestacaoMunicipio))
                {
                    // prestação em algum município do Brasil
                    if (decimal.TryParse(localPrestacaoMunicipio, out var cdCidadePrestacao))
                    {
                        nfse.Cd_CidadePrestacao = cdCidadePrestacao;

                        var municipioEntity = await _cecamMunicipioQuery.PrimeiroOuNull(new CecamMunicipioFilter() { Cd_MunicipioIBGE = cdCidadePrestacao, AsNoTracking = true });

                        if (municipioEntity != null)
                        {
                            // nome do municipio + estado Brasileiro do municipio
                            nfse.Ds_LocalPrestacao = stringHelp.ReduzirTamanho(60, municipioEntity.Ds_NomeMunicipio + " / " + municipioEntity.Sg_UF, "...");
                        }
                    }
                } 
                else if (hePrestacaoNoExterior)
                {
                    // prestação é em outro pais estrangeiro (exterior)

                    // carregar o municipio que representa outro pais.
                    var outroPais = await _cecamMunicipioQuery.CarregarOutroPais();

                    // codigo do municipio no exterior
                    nfse.Cd_CidadePrestacao = outroPais.Cd_MunicipioIBGE;
                }

                // endereço do tomador
                var tomadorEndereco = infDps.toma?.end;

                if (tomadorEndereco != null)
                {
                    nfse.Nm_Logradouro = "" + stringHelp.ReduzirTamanho(60, tomadorEndereco.xLgr, "...");
                    nfse.Nr_Numero = "" + stringHelp.ReduzirTamanho(20, tomadorEndereco.nro, "...");
                    nfse.Ds_Complemento = "" + stringHelp.ReduzirTamanho(50, tomadorEndereco.xCpl, "...");
                    nfse.Nm_Bairro = "" + stringHelp.ReduzirTamanho(40, tomadorEndereco.xBairro, "...");
                    nfse.Cd_CEP = "" + stringHelp.ReduzirTamanho(8, tomadorEndereco.endNac?.CEP, "");
                }
            }
            else
            {
                // default
                nfse.Fl_LocalPrestacao = 0;
            }
        }


        /// <summary>
        /// Preencher prestador / contribuinte
        /// </summary>
        private async Task ProcessarPrestador()
        {
            if (_dadosOrigem == null || _dadosOrigem.NotaFiscalFilaImportarEntrada == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarPrestador() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // objeto prestador
            var prestador = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.prest;

            // validar
            if (prestador == null)
                throw new Exception(exceptionMsg + "prestador é obrigatório e não foi informado pelo gov.br");

            // cnpj ou cpf do emissor/prestador
            nfse.Nr_CGCCPF = "" + prestador.CNPJ + prestador.CPF;

            // validar
            if (string.IsNullOrWhiteSpace(nfse.Nr_CGCCPF))
                throw new Exception(exceptionMsg + "nr_cgccpf não importado pq não foi informado pelo gov.br");

            // cnpj ou cpf do usuario criador da nfse na base
            nfse.Nr_CGCCPFUsuarioCriacao = "" + nfse.Nr_CGCCPF;

            // cnpj ou cpf do usuario atualizador da nfse na base
            nfse.Nr_CGCCPFUsuarioAtualizacao = "" + nfse.Nr_CGCCPF;

            // completar os dados do contribuinte na NFSe da fila de entrada
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Nr_CGCCPF = "" + nfse.Nr_CGCCPF;

            // -------------------------------------------------------

            // Flag prestador não inscrito no municipio
            // 0 = quando prestador e tomador são do mesmo municipio que esta sendo importado/processado
            // 0 = se a NFSe estiver sendo gravada no municipio do prestador é sempre 0 (zero)
            // 1 = se a NFSe estiver sendo gravada no municipio do tomador e o prestador é de outro municipio
            // Como esse fluxo é somente importa NFSe de prestadores do municipio, então é sempre 0 (zero)
            nfse.Fl_PrestadorNaoInscrito = 0;

            // -------------------------------------------------------

            // atalho para inscrição municipal do prestador
            string? prestadorInscricaoMunicipal = prestador.IM;

            // verificar se não encontrou inscrição municipal do prestador?
            if (string.IsNullOrWhiteSpace(prestadorInscricaoMunicipal))
            {
                // não encontrou inscrição municipal no prestador,
                // então procurar a inscrição municipal no emitente
                prestadorInscricaoMunicipal = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Emit?.IM;
            }

            // verificar se temos Inscrição Municipal?
            if (!string.IsNullOrWhiteSpace(prestadorInscricaoMunicipal))
            {
                // atalho para codigo do municipio do prestador
                string? prestadorCodigoMunicipio = prestador.end?.endNac?.cMun;

                // verificar se NÃO temos codigo do muncipio informado pelo nó de prestador ?
                if (string.IsNullOrWhiteSpace(prestadorCodigoMunicipio))
                {
                    // não encontrou codigo do municipio no prestador,
                    // então procurar codigo do municipio no emitente
                    prestadorCodigoMunicipio = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Emit?.enderNac?.cMun;
                }

                // verificar se mesmo depois de procurar em dois lugares, ainda NÃO temos codigo do muncipio informados ?
                if (string.IsNullOrWhiteSpace(prestadorCodigoMunicipio))
                {
                    // como não tem codigo do municipio, então limpar a inscrição municipal que será utilizada na busca abaixo
                    // porque não tem como saber se esse contribuinte é desse municipio sendo processado.
                    prestadorInscricaoMunicipal = null;
                }
                else
                {
                    // verificar se codigo do municipio do prestador da xml da nota, 
                    // é diferente do código de municipio sendo processado
                    if (prestadorCodigoMunicipio.Trim() != _dadosOrigem.IssParametrosNfse?.Cd_IBGE.GetValueOrDefault().ToString())
                    {
                        // codigo do municipio do prestador na xml da nota, é diferente do código do municipio sendo processado,
                        // então limpar a inscrição municipal que será utilizada na busca abaixo
                        // pq esse contribuinte é de outra prefeitura, logo essa inscrição municipal não será encontrada aqui
                        prestadorInscricaoMunicipal = null;
                    }
                }
            }

            // -------------------------------------------------------

            // contribuinte emitente/emissor da nota fiscal (prestador)
            var issContribuinteBus = new IssContribuinteBus();

            // carregar contribuinte usando cnpj e inscrição municipal (caso esteja preenchida)
            _dadosOrigem.IssContribuinte = await issContribuinteBus.CarregarContribuinteEmAtividade(
                new IssContribuinteBusFilter() 
                { 
                    Ds_InscricaoMunicipal = prestadorInscricaoMunicipal,
                    Nr_CnpjCpf = nfse.Nr_CGCCPF,
                    IncluirBairro = true, 
                    IncluirLogradouro = true 
                });

            // se não achou o contribuinte e a inscrição municipal foi informada,
            // então procurar usando somente o CNPJ, sem usar a inscrição municipal
            if (_dadosOrigem.IssContribuinte == null && !string.IsNullOrWhiteSpace(prestadorInscricaoMunicipal))
            {
                // carregar contribuinte, somente com CNPJ sem inscrição municipal
                _dadosOrigem.IssContribuinte = await issContribuinteBus.CarregarContribuinteEmAtividade(
                    new IssContribuinteBusFilter()
                    {
                        Nr_CnpjCpf = nfse.Nr_CGCCPF,
                        IncluirBairro = true,
                        IncluirLogradouro = true
                    });
            }

            // validar se IssContribuinte foi carregado a partir do prestador informado na XML?
            if (_dadosOrigem.IssContribuinte != null)
            {
                // código do contribuinte na prefeitura/cecam
                nfse.Cd_Contribuinte = _dadosOrigem.IssContribuinte.Cd_Contribuinte;
            }
            else
            {
                // não encontrou o IssContribuinte,
                // então o emitente/prestador será um eventual
                await ProcessarEventual();
            }

            // todo contribuinte que criar um nota precisa ter seu respectivo usuarioWeb criado na base.
            // fica fora dos IFs acima, porque tanto o IssContribuinte quanto o IssEventual precisam dessa linha criada na base
            await ProcessarUsuarioWeb();

            // completar os dados do contribuinte na NFSe da fila de entrada
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Cd_Contribuinte = nfse.Cd_Contribuinte;

            // -------------------------------------------------------

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Fim");
        }



        /// <summary>
        /// Criar ou recuperar o usuario web que representa um prestador para acessar o site IssWeb
        /// Esse método não é utilizado quando o prestador é contribuinte ou eventual
        /// </summary>
        private async Task ProcessarUsuarioWeb()
        {
            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarlUsuarioWeb() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // objeto prestador
            var prestador = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.prest;

            // validar
            if (prestador == null)
                throw new Exception(exceptionMsg + "prestador é obrigatório e não foi informado pelo gov.br");

            // criar novo usuario web
            var usuarioWebEntity = new IssUsuarioWebEntity
            {
                Nr_CGCCPF = "" + prestador.CNPJ + prestador.CPF,
                Nm_Usuario = "" + prestador.xNome,
                Nm_Login = "" + prestador.CNPJ + prestador.CPF,
                Pw_Login = "",
                Ds_email = "" + prestador.email,
                Fl_Tipo = 2,
                Nr_Acesso = 0,
                Cd_Contribuinte = _dadosOrigem.IssNotaFiscalEnty?.Cd_Contribuinte,
                Dt_Cadastro = DateTime.UtcNow.AddHours(-3),
                Ds_Usuario = "" + prestador.CNPJ + prestador.CPF
            };

            // se não achou algumas informações dentro do node prestador,
            // então vamos tentar procurar dentro do node emitente.

            // objeto emitente
            var emitente = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Emit;

            // validar 
            if (emitente != null)
            {
                // verificar se cnpj/cpf do usuario é igual ao do emitente?
                if (usuarioWebEntity.Nr_CGCCPF == emitente.CNPJ + emitente.CPF)
                {
                    if (string.IsNullOrWhiteSpace(usuarioWebEntity.Nm_Usuario))
                        usuarioWebEntity.Nm_Usuario = emitente.xNome;

                    if (string.IsNullOrWhiteSpace(usuarioWebEntity.Ds_email))
                        usuarioWebEntity.Ds_email = emitente.email;
                }
            }

            // usuario web business
            var usuarioWebBus = new IssUsuarioWebBus();

            // tratar o tamanho dos campos string.
            usuarioWebBus.TratarTamanhoCampos(usuarioWebEntity);

            // criar o usuario web caso ele não exista na base
            await usuarioWebBus.CriarSeNaoExistir(usuarioWebEntity);

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Fim");
        }



        /// <summary>
        /// Criar ou recuperar o contribuinte eventual
        /// </summary>
        private async Task ProcessarEventual()
        {
            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarEventual() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // objeto prestador
            var prestador = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.prest;

            // validar
            if (prestador == null)
                throw new Exception(exceptionMsg + "prestador é obrigatório e não foi informado pelo gov.br");

            // criar novo eventual com os dados da xml
            var eventualEntity = new IssEventualEntity
            {
                Nr_CGCCPF = "" + prestador.CNPJ + prestador.CPF,
                Ds_Razaosocial = prestador.xNome,
                Ds_Inscricao_Municipal = prestador.IM,
                // dados de contato
                Ds_Email = prestador.email,
                Ds_EmailTributario = prestador.email,
                Ds_EmailCorr = prestador.email,
                Cd_TelefoneTributario = prestador.fone,
                // endereço
                Ds_EnderTributario = prestador.end?.xLgr,
                Cd_NumeroTributario = prestador.end?.nro,
                Ds_BairroTributario = prestador.end?.xBairro,
                Sg_EstadoTributario = null,
                Cd_CepTributario = prestador.end?.endNac?.CEP
            };

            // procurar o estado, atraves do código de município informado na xml
            var codigoMunicipio = prestador.end?.endNac?.cMun;

            if (!string.IsNullOrWhiteSpace(codigoMunicipio))
            {
                if (decimal.TryParse(codigoMunicipio, out var codigoMunicipioDecimal))
                {
                    var municipioEntity = await _cecamMunicipioQuery.PrimeiroOuNull(new CecamMunicipioFilter() { Cd_MunicipioIBGE = codigoMunicipioDecimal, AsNoTracking = true });

                    if (municipioEntity != null)
                    {
                        // estado Brasileiro do municipio
                        eventualEntity.Sg_EstadoTributario = municipioEntity.Sg_UF;
                    }
                }
            }

            // se não achou algumas informações dentro do node prestador,
            // então vamos tentar procurar dentro do node emitente.

            // objeto emitente
            var emitente = _dadosOrigem.NotaFiscalImportada?.InfNFSe?.Emit;

            // validar 
            if (emitente != null)
            {
                // verificar se cnpj/cpf do emitente é igual ao do prestador?
                if (eventualEntity.Nr_CGCCPF == emitente.CNPJ + emitente.CPF)
                {
                    if (string.IsNullOrWhiteSpace(eventualEntity.Ds_Razaosocial))
                        eventualEntity.Ds_Razaosocial = emitente.xNome;

                    if (string.IsNullOrWhiteSpace(eventualEntity.Ds_Email))
                        eventualEntity.Ds_Email = emitente.email;

                    if (string.IsNullOrWhiteSpace(eventualEntity.Ds_EmailTributario))
                        eventualEntity.Ds_EmailTributario = emitente.email;

                    if (string.IsNullOrWhiteSpace(eventualEntity.Ds_EmailCorr))
                        eventualEntity.Ds_EmailCorr = emitente.email;

                    // endereço
                    if (prestador.end == null && emitente.enderNac != null)
                    {
                        eventualEntity.Ds_EnderTributario = emitente.enderNac.xLgr;
                        eventualEntity.Cd_NumeroTributario = emitente.enderNac.nro;
                        eventualEntity.Ds_BairroTributario = emitente.enderNac.xBairro;
                        eventualEntity.Sg_EstadoTributario = emitente.enderNac.UF;
                        eventualEntity.Cd_CepTributario = emitente.enderNac.CEP;
                    }
                }
            }

            // eventual business
            var eventualBus = new IssEventualBus();

            // tratar tamanho dos campos tring
            eventualBus.TratarTamanhoCampos(eventualEntity);

            // criar ou editar o eventual
            await eventualBus.CriarOuEditar(eventualEntity);

            if (_dadosOrigem.IssNotaFiscalEnty != null)
            {
                // guardar o código do eventual no campo cd_contribuinte.
                _dadosOrigem.IssNotaFiscalEnty.Cd_Contribuinte = eventualEntity.Cd_Eventual;
            }

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Fim");
        }


        /// <summary>
        /// Preencher tomador
        /// Pode ser não informado, Brasil PJ mesmo município, Brasil PJ outro município, Brasil PF ou Exterior (outro pais)
        /// </summary>
        private async Task ProcessarTomador()
        {
            if (_dadosOrigem == null || _dadosOrigem.IssNotaFiscalEnty == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarTomador() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // ----------------------------------------------

            // valores default para SEM tomador informado.

            // cnpj/cpf do tomador (default)
            nfse.Nr_CGCCPFTomador = null;

            // Flag se foi o tomador quem escriturou a NFSe?
            // 0 = NFSe emitida pelo prestador.
            // 1 = NFSe escriturada pelo tomador 
            // nesse fluxo sempre estamos importando NFSe emitidas pelo tomador, então o valor é sempre 0 (zero)
            nfse.Fl_Tomador = 0;

            // codigo do tomador (default=0)
            // o cd_tomador será preenchido no momento da gravação do tomador na base cecam
            nfse.Cd_Tomador = null;

            // ----------------------------------------------

            // objeto tomador
            var tomador = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.toma;

            // validar
            if (tomador == null)
            {
                // o tomador NÃO foi informado na NFSe, então criar um default vazio.

                // associar o novo tomador com a NFSe
                nfse.Tomador = new Database.Entity.Iss.IssTomadorEntity()
                {
                    //Nr_CGCCPF = "SEM-TOMADOR",
                    Nr_CGCCPF = "00000000000000", // tem que ser numero, pq letras da errro
                    Ds_RazaoSocial = "TOMADOR DO SERVIÇO NÃO IDENTIFICADO NA NFS-e",
                    Dt_Atualizacao = DateTime.UtcNow.AddHours(-3),
                    Cd_Usuario = nfse.Nr_CGCCPF
                };

                // cnpj/cpf do tomador
                nfse.Nr_CGCCPFTomador = nfse.Tomador.Nr_CGCCPF;

                // log fim
                _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - tomador não informado na NFSe, então criou um tomador default vazio");

                // sair
                return;
            }

            // ----------------------------------------------

            // string helper para tratar textos.
            var stringHelp = new StringHelper();

            // verificar se tomador é do Exterior ?
            var heExterior = (tomador.end?.endExt != null) || !string.IsNullOrWhiteSpace(tomador.cNaoNIF) || !string.IsNullOrWhiteSpace(tomador.NIF);

            // se é no Exterior, preencher os respectivos campos 
            if (heExterior)
            {
                // criar um tomador de outro pais estrangeiro com os vários campos obrigatórios já preenchidos
                var tomadorBus = new IssTomadorBus();
                var tomadorEntity = await tomadorBus.CriarTomadorOutroPaisEstrangeiro();

                // associar o novo tomador com a NFSe
                nfse.Tomador = tomadorEntity;

                // nome do tomador
                tomadorEntity.Ds_RazaoSocial = "" + stringHelp.ReduzirTamanho(200, tomador.xNome, "...");

                // contribuinte criador do tomador
                tomadorEntity.Cd_Usuario = nfse.Nr_CGCCPF;

                // cnpj/cpf do tomador precisa ser informado na nota fiscal
                nfse.Nr_CGCCPFTomador = tomadorEntity.Nr_CGCCPF;

                // codigo do municipio no exterior precisa ser informado na nota fiscal
                nfse.Cd_CidadePrestacao = tomadorEntity.Cd_MunicipioTomador;

                // email
                tomadorEntity.Ds_Email = stringHelp.ReduzirTamanho(50, tomador.email, "");

                // endereço
                tomadorEntity.Ds_Logradouro = "" + stringHelp.ReduzirTamanho(60, tomador.end?.xLgr, "...");
                tomadorEntity.Cd_Numero = "" + stringHelp.ReduzirTamanho(10, tomador.end?.nro, "...");
                tomadorEntity.Ds_Bairro = "" + stringHelp.ReduzirTamanho(40, tomador.end?.xBairro, "...");

                // endereço no exterior
                tomadorEntity.Sg_Pais_ISO2 = stringHelp.ReduzirTamanho(2, tomador.end?.endExt?.cPais, "...");
                tomadorEntity.Ds_EnderecoExt = stringHelp.ReduzirTamanho(100, tomador.end?.endExt?.cEndPost, "...");
                tomadorEntity.Ds_CidadeExt = stringHelp.ReduzirTamanho(60, tomador.end?.endExt?.xCidade, "...");
                tomadorEntity.Ds_EstadoExt = stringHelp.ReduzirTamanho(60, tomador.end?.endExt?.xEstProvReg, "...");
            }

            // ----------------------------------------------

            // verificar se o tomador é do Brasil ?
            var heBrasil = (tomador.end?.endNac != null) || !string.IsNullOrWhiteSpace(tomador.CNPJ) || !string.IsNullOrWhiteSpace(tomador.CPF);

            if (heBrasil)
            {
                // criar novo tomador em branco
                var tomadorEntity = new Database.Entity.Iss.IssTomadorEntity()
                {
                    Dt_Atualizacao = DateTime.UtcNow.AddHours(-3),
                };

                // associar o novo tomador com a NFSe
                nfse.Tomador = tomadorEntity;

                // nome do tomador
                tomadorEntity.Ds_RazaoSocial = stringHelp.ReduzirTamanho(200, tomador.xNome, "...");

                // contribuinte criador do tomador
                tomadorEntity.Cd_Usuario = nfse.Nr_CGCCPF;

                // recuperar o cnpj ou cpf.
                // como são exclusivos, pelo menos um deles vira preenchido
                // nunca tera ambos preenchidos.
                string cnpjCpf = tomador.CNPJ + tomador.CPF;

                // cnpj/cpf do tomador
                // pode ser NULL quando é do Exterior
                nfse.Nr_CGCCPFTomador = cnpjCpf;
                tomadorEntity.Nr_CGCCPF = cnpjCpf;

                if (!string.IsNullOrWhiteSpace(tomador.CNPJ))
                    tomadorEntity.Fl_TipoPessoa = (byte)IssTomadorEnum.enumFlTipoPessoa.PessoaJuridica;
                else
                    tomadorEntity.Fl_TipoPessoa = (byte)IssTomadorEnum.enumFlTipoPessoa.PessoaFisica;

                // -------------------------------------------

                // tenta recuperar o código do municipio do endereco nacional do tomador.
                string cdMunTomadorString = "" + tomador.end?.endNac?.cMun;

                // se não existir, então usar o municipio de incidencia da NFSe
                if (string.IsNullOrEmpty(cdMunTomadorString))
                    cdMunTomadorString = "" + _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.cLocIncid;

                // converter string para decimal
                decimal cdMunTomadorDecimal = 0;

                if (!string.IsNullOrEmpty(cdMunTomadorString))
                    decimal.TryParse(cdMunTomadorString, out cdMunTomadorDecimal);

                // código do municipio no Brasil
                tomadorEntity.Cd_MunicipioTomador = cdMunTomadorDecimal;

                // ----------------------------------------

                //verificar se temos código do municipio Brasil?
                if (cdMunTomadorDecimal > 0)
                {
                    // carregar o municipio pelo código do municipio do IBGE.
                    var municipioTomadorEntity = await _cecamMunicipioQuery.PrimeiroOuNull(new CecamMunicipioFilter() { AsNoTracking = true, Cd_MunicipioIBGE = cdMunTomadorDecimal });

                    // verificar se encontramos o municipio pelo código do IBGE ?
                    if (municipioTomadorEntity != null)
                    {
                        // municipio encontrado
                        // guardar o estado Brasileiro do municipio
                        tomadorEntity.Sg_UF = municipioTomadorEntity.Sg_UF;
                    }
                    else
                    {
                        // municipio não encotnrado, 
                        // então deixar vazio
                        tomadorEntity.Sg_UF = string.Empty;
                    }
                }

                // ----------------------------------------

                // outros dados:
                tomadorEntity.Ds_Email = stringHelp.ReduzirTamanho(50, tomador.email,"");
                tomadorEntity.Ds_inscricao_municipal = stringHelp.ReduzirTamanho(20, tomador.IM,"");

                // endereço:
                tomadorEntity.Ds_Logradouro = "" + stringHelp.ReduzirTamanho(60, tomador.end?.xLgr, "...");
                tomadorEntity.Cd_Numero = "" + stringHelp.ReduzirTamanho(10, tomador.end?.nro, "");
                tomadorEntity.Ds_Bairro = "" + stringHelp.ReduzirTamanho(40, tomador.end?.xBairro, "...");
                tomadorEntity.Ds_Complemento = "" + stringHelp.ReduzirTamanho(30, tomador.end?.xCpl, "...");
                tomadorEntity.Cd_CEP = stringHelp.ReduzirTamanho(9, tomador.end?.endNac?.CEP, "");
            }

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim");
        }


        /// <summary>
        /// Preencher intermediario
        /// Pode ser não informado, Brasil PJ mesmo município, Brasil PJ outro município, Brasil PF ou Exterior (outro pais)
        /// </summary>
        private async Task ProcessarIntermediario()
        {
            if (_dadosOrigem == null || _dadosOrigem.IssNotaFiscalEnty == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarIntermediario() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // ----------------------------------------------

            // valores default para SEM intermediario informado.

            // cnpj/cpf do intermediario (default)
            nfse.Nr_CGCCPFTomadorIntermediario = null;

            // codigo do intermediario (default)
            nfse.Cd_TomadorIntermediario = null;

            // ----------------------------------------------

            // objeto intermediario
            var intermediario = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.interm;

            // validar
            if (intermediario == null)
            {
                // o intermediario NÃO foi informado na NFSe, então sair com sucesso.
                // pq o intermediário NÃO tem obrigação de existir nos campos da base, pq null ou vazio o ISSWeb não gera erro, 
                // pq o conceito de intermediário foi criado somente com a integração do gov.br

                // log fim
                _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - intermediario não informado na NFSe");
                return;
            }

            // ----------------------------------------------

            // string helper para tratar textos.
            var stringHelp = new StringHelper();

            // verificar se intermediario é do Exterior ?
            var heExterior = (intermediario.end?.endExt != null) || !string.IsNullOrWhiteSpace(intermediario.cNaoNIF) || !string.IsNullOrWhiteSpace(intermediario.NIF);

            // se é no Exterior, preencher os respectivos campos 
            if (heExterior)
            {
                // criar um tomador de outro pais estrangeiro com os vários campos obrigatórios já preenchidos
                var tomadorBus = new IssTomadorBus();
                var intermediarioEntity = await tomadorBus.CriarTomadorOutroPaisEstrangeiro();

                // associar o novo intermediario com a NFSe
                nfse.Intermediario = intermediarioEntity;

                // nome do intermediario
                intermediarioEntity.Ds_RazaoSocial = stringHelp.ReduzirTamanho(200, intermediario.xNome, "...");

                // contribuinte criador do intermediario
                intermediarioEntity.Cd_Usuario = nfse.Nr_CGCCPF;

                // cnpj/cpf do intermediario precisa ser informado na nota fiscal
                nfse.Nr_CGCCPFTomadorIntermediario = intermediarioEntity.Nr_CGCCPF;

                // email
                intermediarioEntity.Ds_Email = stringHelp.ReduzirTamanho(50, intermediario.email, "");

                // endereço
                intermediarioEntity.Ds_Logradouro = "" + stringHelp.ReduzirTamanho(60, intermediario.end?.xLgr, "...");
                intermediarioEntity.Cd_Numero = "" + stringHelp.ReduzirTamanho(10, intermediario.end?.nro, "...");
                intermediarioEntity.Ds_Bairro = "" + stringHelp.ReduzirTamanho(40, intermediario.end?.xBairro, "...");

                // endereço no exterior
                intermediarioEntity.Sg_Pais_ISO2 = stringHelp.ReduzirTamanho(2, intermediario.end?.endExt?.cPais, "");
                intermediarioEntity.Ds_EnderecoExt = stringHelp.ReduzirTamanho(100, intermediario.end?.endExt?.cEndPost, "...");
                intermediarioEntity.Ds_CidadeExt = stringHelp.ReduzirTamanho(60, intermediario.end?.endExt?.xCidade, "...");
                intermediarioEntity.Ds_EstadoExt = stringHelp.ReduzirTamanho(60, intermediario.end?.endExt?.xEstProvReg, "...");
            }

            // ----------------------------------------------

            // verificar se o intermediario é do Brasil ?
            var heBrasil = (intermediario.end?.endNac != null) || !string.IsNullOrWhiteSpace(intermediario.CNPJ) || !string.IsNullOrWhiteSpace(intermediario.CPF);

            if (heBrasil)
            {
                // criar novo intermediario em branco
                var intermediarioEntity = new Database.Entity.Iss.IssTomadorEntity()
                {
                    Dt_Atualizacao = DateTime.UtcNow.AddHours(-3),
                };

                // associar o novo intermediario com a NFSe
                nfse.Intermediario = intermediarioEntity;

                // nome do intermediario
                intermediarioEntity.Ds_RazaoSocial = stringHelp.ReduzirTamanho(200, intermediario.xNome, "...");

                // contribuinte criador do intermediario
                intermediarioEntity.Cd_Usuario = nfse.Nr_CGCCPF;

                // recuperar o cnpj ou cpf.
                // como são exclusivos, pelo menos um deles vira preenchido
                // nunca tera ambos preenchidos.
                string cnpjCpf = intermediario.CNPJ + intermediario.CPF;

                // cnpj/cpf do intermediario
                // pode ser NULL quando é do Exterior
                nfse.Nr_CGCCPFTomadorIntermediario = cnpjCpf;
                intermediarioEntity.Nr_CGCCPF = cnpjCpf;

                if (!string.IsNullOrWhiteSpace(intermediario.CNPJ))
                    intermediarioEntity.Fl_TipoPessoa = (byte)IssTomadorEnum.enumFlTipoPessoa.PessoaJuridica;
                else
                    intermediarioEntity.Fl_TipoPessoa = (byte)IssTomadorEnum.enumFlTipoPessoa.PessoaFisica;

                // -------------------------------------------

                    // tenta recuperar o código do municipio do endereco nacional do intermediario.
                string cdMunIntermediarioString = "" + intermediario.end?.endNac?.cMun;

                // se não existir, então usar o municipio de incidencia da NFSe
                if (string.IsNullOrEmpty(cdMunIntermediarioString))
                    cdMunIntermediarioString = "" + _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.cLocIncid;

                // converter string para decimal
                decimal cdMunIntermediarioDecimal = 0;

                if (string.IsNullOrEmpty(cdMunIntermediarioString))
                    decimal.TryParse(cdMunIntermediarioString, out cdMunIntermediarioDecimal);

                // código do municipio no Brasil
                intermediarioEntity.Cd_MunicipioTomador = cdMunIntermediarioDecimal;

                // ----------------------------------------

                //verificar se temos código do municipio Brasil?
                if (cdMunIntermediarioDecimal > 0)
                {
                    // carregar o municipio pelo código do municipio do IBGE.
                    var municipioIntermediarioEntity = await _cecamMunicipioQuery.PrimeiroOuNull(new CecamMunicipioFilter() { AsNoTracking = true, Cd_MunicipioIBGE = cdMunIntermediarioDecimal });

                    // verificar se encontramos o municipio pelo código do IBGE ?
                    if (municipioIntermediarioEntity != null)
                    {
                        // municipio encontrado
                        // guardar o estado Brasileiro do municipio
                        intermediarioEntity.Sg_UF = municipioIntermediarioEntity.Sg_UF;
                    }
                    else
                    {
                        // municipio não encotnrado, 
                        // então deixar vazio
                        intermediarioEntity.Sg_UF = string.Empty;
                    }
                }

                // ----------------------------------------

                // outros dados:
                intermediarioEntity.Ds_Email = stringHelp.ReduzirTamanho(50, intermediario.email, "");
                intermediarioEntity.Ds_inscricao_municipal = stringHelp.ReduzirTamanho(20, intermediario.IM, "...");

                // endereço:
                intermediarioEntity.Ds_Logradouro = "" + stringHelp.ReduzirTamanho(60, intermediario.end?.xLgr, "...");
                intermediarioEntity.Cd_Numero = "" + stringHelp.ReduzirTamanho(10, intermediario.end?.nro, "");
                intermediarioEntity.Ds_Bairro = "" + stringHelp.ReduzirTamanho(40, intermediario.end?.xBairro, "...");
                intermediarioEntity.Ds_Complemento = "" + stringHelp.ReduzirTamanho(30, intermediario.end?.xCpl, "...");
                intermediarioEntity.Cd_CEP = stringHelp.ReduzirTamanho(9, intermediario.end?.endNac?.CEP, "");
            }

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim");
        }



        #region Auxiliares


        /// <summary>
        /// Validar se objeto xml contem os campos obrigatorios
        /// </summary>
        private void Validar()
        {
            if (_dadosOrigem.NotaFiscalImportada == null ||
                _dadosOrigem.NotaFiscalImportada.InfNFSe == null ||
                string.IsNullOrWhiteSpace(_dadosOrigem.NotaFiscalImportada.InfNFSe.Id) ||
                _dadosOrigem.NotaFiscalImportada.InfNFSe.Dps == null ||
                _dadosOrigem.NotaFiscalImportada.InfNFSe.Dps.InfDps == null)
            {
                throw new Exception("NfseGovBrImportarCorpoCabeca.Validar() campos obrigatórios na XML da NFSe não preenchidos");
            }

            // NFSe com exercicio anterior a janeiro/2026 não podem ser importadas.
            var dhEmissaoString = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.dhEmi;

            if (DateTime.TryParse(dhEmissaoString, out var dtEmissao))
            {
                if (dtEmissao.Year < 2026)
                {
                    throw new NfseGovBrImportarMoverFilaException($"Data emissão NFSe anterior a 2026. Não pode ser importada. Emissão={dhEmissaoString}", NfseGovBrEnum.enumFilaStatus.ExercicioAntes2026);
                }
            }
        }


        /// <summary>
        /// Carregar as várias entidades da base de dados para memória
        /// </summary>
        private async Task CarregarDados()
        {
            if (_dadosOrigem == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfseGovBrImportarCorpoCabeca.CarregarDados() NfseId={_dadosOrigem.NfseId()} - Início");

            // iss parametros da nota fiscal gov.br
            _dadosOrigem.IssParametrosNfse = await _issParametrosNfseQuery.Carregar();

            if (_dadosOrigem.IssParametrosNfse == null ||
                !_dadosOrigem.IssParametrosNfse.Cd_IBGE.HasValue ||
                string.IsNullOrWhiteSpace(_dadosOrigem.IssParametrosNfse.Nr_CNPJMunicipio))
            {
                throw new Exception("IssParametrosNfse não preenchida, por favor informar a CECAM", new Exception("NfseGovBrImportarCorpoCabeca.CarregarDados() - Não foi possível carregar IssParametrosNfse"));
            }

            // -----------------------------------------------

            // parametros de calculo do vb para o ISS
            _dadosOrigem.IssParametrosCalculoBus = new IssParametros.IssParametrosCalcBus();
            await _dadosOrigem.IssParametrosCalculoBus.Carregar();

            // validar
            if (_dadosOrigem.IssParametrosCalculoBus.IssParametrosCalc == null)
                throw new Exception("IssParametrosCalc não preenchida, por favor informar a CECAM", new Exception("NfseGovBrImportarCorpoCabeca.CarregarDados() - IssParametrosCalc não foi encontrado na base prefeitura/cecam"));

            if (!_dadosOrigem.IssParametrosCalculoBus.IssParametrosCalc.Cd_NFETipoDocto.HasValue)
                throw new Exception("IssParametrosCalc não preenchida, por favor informar a CECAM", new Exception("NfseGovBrImportarCorpoCabeca.CarregarDados() - Código tipo documento de NFSe não encontrado na IssParametrosCalc"));

            // log fim
            _loggerHelper.GravarTexto($"NfseGovBrImportarCorpoCabeca.CarregarDados() NfseId={_dadosOrigem.NfseId()} - Fim");
        }


        #endregion
    }
}
