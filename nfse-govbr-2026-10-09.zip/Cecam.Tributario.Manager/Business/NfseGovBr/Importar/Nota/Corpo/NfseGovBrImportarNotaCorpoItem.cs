﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Enumerado.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.Query.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores.Tributo.Federal;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota.Corpo
{
    internal class NfseGovBrImportarNotaCorpoItem
    {
        #region Declarações


        /// <summary>
        /// logs
        /// </summary>
        private readonly ILoggerHelper _loggerHelper;

        /// <summary>
        /// Dados para importação
        /// </summary>
        private NfseGovBrNfseImportarNotaBusDados _dadosOrigem;

        /// <summary>
        /// Servicos vinculos (de-para lista de servico nacional do gov.br X lista da prefeitura/cecam)
        /// </summary>
        private readonly IIssNotaFiscalServicoVinculoQuery _issNotaFiscalServicoVinculoQuery;

        /// <summary>
        /// Serviço Item de atividade da prefeitura/cecam
        /// </summary>
        private readonly IIssItensAtividadesQuery _issItensAtividadesQuery;


        /// <summary>
        /// Serviço executado/prestado na NFse
        /// </summary>
        private readonly IIssServicoQuery _issServicoQuery;



        public NfseGovBrImportarNotaCorpoItem(NfseGovBrNfseImportarNotaBusDados dadosOrigem, ILoggerHelper loggerHelper)
        {
            // dados durante a conversão
            _dadosOrigem = dadosOrigem;

            // logs
            _loggerHelper = loggerHelper;

            // Servicos vinculos
            _issNotaFiscalServicoVinculoQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalServicoVinculoQuery>();

            // Serviço Item de atividade da prefeitura/cecam
            _issItensAtividadesQuery = ServiceProviderGlobal.GetServico<IIssItensAtividadesQuery>();

            // servico executado/prestado na NFSe
            _issServicoQuery = ServiceProviderGlobal.GetServico<IIssServicoQuery>();
        }


        #endregion


        /// <summary>
        /// Converter o item da NFSe com origem Gov.Br para prefeitura/cecam
        /// </summary>
        /// <returns></returns>
        public async Task Processar()
        {
            if (_dadosOrigem == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfseGovBrImportarCorpoItem.Processar() NfseId={_dadosOrigem.NfseId()} - Início");

            // Preencher Item filho da nota fiscal
             await ProcessarItem();

            // Preencher Item filho com o Servico do gov.br convertido para codigo servico da prefeitura/cecam
            await ProcessarServico();

            // Preencher Item filho com os valores do servico
            await ProcessarValores();

            // Preencher os Impostos filhos da NFse
            await ProcessarImpostos();

            // log fim
            _loggerHelper.GravarTexto($"NfseGovBrImportarCorpoItem.Processar() NfseId={_dadosOrigem.NfseId()} - Fim");
        }


        /// <summary>
        /// Preencher Item filho da nota fiscal
        /// </summary>
        private async Task ProcessarItem()
        {
            if (_dadosOrigem == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarItem() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // novo item
            var nfseItem = new IssNotaFiscalItemEntity();

            // inicializar lista com o novo item
            nfse.Itens = new List<IssNotaFiscalItemEntity>() { nfseItem };

            // codigo da prefeitura na cecam
            nfseItem.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // codigo da nota fiscal pai
            nfseItem.Cd_NotaFiscal = nfse.Cd_NotaFiscal;

            // descrição do servico
            nfseItem.Ds_ItemServico = "" + _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.serv?.cServ?.xDescServ;

            // -------------------------------

            // flag default como NÃO exportado
            nfseItem.Fl_Exportado = 0;

            // cd pais default como vazio
            nfseItem.Cd_Pais = 0;

            // verificar se temos tomador no exterior?
            if (nfse.Tomador?.HeOutroPais() == true)
            {
                // flag default como SIM exportado
                nfseItem.Fl_Exportado = 1;
            }

            // -------------------------------

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim");

            await Task.CompletedTask;
        }


        /// <summary>
        /// Preencher Item filho com o Servico do gov.br convertido para codigo servico da prefeitura/cecam
        /// </summary>
        private async Task ProcessarServico()
        {
            if (_dadosOrigem == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarItem() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // atalho para item
            var nfseItem = nfse.Itens?.FirstOrDefault();

            // validar
            if (nfseItem == null)
                return;

            // objeto 'servico nacional'
            var servico = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.serv;

            // validar
            if (servico == null || string.IsNullOrWhiteSpace(servico.cServ?.cTribNac))
                throw new Exception(exceptionMsg + "servico nacional não informado na XML do gov.br em servico.cServ.cTribNac");

            // recuperar o exercicio dessa nota fiscal
            var cdExercicio = new EntityPropertyHelper().GetCdReferenciaAno(nfse.Cd_Referencia);
           
            // recuperar o primeiro vinculos desse tributo nacional
            var servicoVinculo = await _issNotaFiscalServicoVinculoQuery.PrimeiroOuNull(new IssNotaFiscalServicoVinculoFilter()
            {
                Cd_Exercicio = cdExercicio,
                Cd_tributacaoNacional = servico.cServ?.cTribNac
            });

            // validar
            if (servicoVinculo == null)
                throw new Exception($"Cadastre o Serviço Nacional = {servico.cServ?.cTribNac} para seguir com a importação", new Exception($"SELECT TOP 1 * FROM ISSServicos_Vinculos WITH(NOLOCK) WHERE cd_Exercicio={cdExercicio} AND cd_tributacaoNacional = '{servico.cServ?.cTribNac}';  -  " + exceptionMsg + $"servico nacional cTribNac={servico.cServ?.cTribNac} não encontrado na base"));

            // código da tributacao nacional
            nfseItem.Cd_TributacaoNacional = servicoVinculo.Cd_tributacaoNacional;

            // código do NBS 
            nfseItem.Cd_Nbs = servicoVinculo.Cd_nbs;

            // --------------------------------------------------------------------

            // Serviço Item de atividade da prefeitura/cecam
            var itemAtividade = await _issItensAtividadesQuery.PrimeiroOuNull(new IssItensAtividadesFilter()
            {
                Cd_Exercicio = cdExercicio,
                Cd_Servico = servicoVinculo.Cd_Servico
            });

            // validar
            if (itemAtividade == null)
            {
                // se não achou, tentar fazer a mesma busca usando o 0 (zero) na frente porque o campo 'cd_servico' é string/texto.
                // Serviço Item de atividade da prefeitura/cecam
                itemAtividade = await _issItensAtividadesQuery.PrimeiroOuNull(new IssItensAtividadesFilter()
                {
                    Cd_Exercicio = cdExercicio,
                    Cd_Servico = "0" + servicoVinculo.Cd_Servico.Trim()
                });

                // validar
                if (itemAtividade == null)
                {
                    throw new Exception($"Cadastre o Serviço {servicoVinculo.Cd_Servico} para seguir com a importação", new Exception($"SELECT TOP 1 * FROM ISSItensAtividades WITH(NOLOCK) WHERE cd_exercicio={cdExercicio} AND REPLACE(REPLACE(ISNULL(cd_Servico,''),'-',''),'.','') = '{servicoVinculo.Cd_Servico}';  -  " + exceptionMsg + $"servico item atividade Cd_Servico={servicoVinculo.Cd_Servico} não encontrado na base"));
                }
            }

            // codigo do servico
            nfseItem.Cd_Servico = "" + itemAtividade.Cd_Servico;

            // --------------------------------------------------------------------

            if (int.TryParse("" + itemAtividade.Cd_grupo_atividade, out var cdGupoAtividade))
            {
                // codigo do grupo de atividade
                nfseItem.Cd_GrupoAtividade = cdGupoAtividade;
            }

            // validar
            if (nfseItem.Cd_GrupoAtividade == 0)
                throw new Exception($"Cadastre o grupo de atividade {itemAtividade.Cd_grupo_atividade} para seguir com a importação", new Exception(exceptionMsg + $"código de grupo de atividade Cd_Grupo_Atividade={itemAtividade.Cd_grupo_atividade} não convertido da base para tipo inteiro"));

            // --------------------------------------------------------------------

            if (int.TryParse("" + itemAtividade.Cd_sub_grupo_atividade, out var cdSubGupoAtividade))
            {
                // codigo do sub-grupo de atividade
                nfseItem.Cd_SubGrupoAtividade = cdSubGupoAtividade;
            }

            // validar
            if (nfseItem.Cd_SubGrupoAtividade == 0)
                throw new Exception(exceptionMsg + $"código do sub grupo de atividade Cd_Sub_Grupo_Atividade={itemAtividade.Cd_sub_grupo_atividade} não convertido da base para inteiro. cd_grupo_atividade={itemAtividade.Cd_grupo_atividade} cd_servico={itemAtividade.Cd_Servico} cd_tributoNacional={servico.cServ?.cTribNac}");

            // --------------------------------------------------------------------

            if (int.TryParse("" + itemAtividade.Cd_item_atividade, out var cdItemAtividade))
            {
                // codigo do item de atividade
                nfseItem.Cd_ItemAtividade = cdItemAtividade;
            }

            // validar
            if (nfseItem.Cd_ItemAtividade == 0)
                throw new Exception(exceptionMsg + $"código do item de atividade Cd_Item_Atividade={itemAtividade.Cd_item_atividade} no cd_servico={itemAtividade.Cd_Servico} não convertido da base para inteiro - SELECT Cd_Item_Atividade FROM issItensAtividades WHERE cd_Servico='{itemAtividade.Cd_Servico}'");

            // ------------------------------------------

            var servicoEntity = await _issServicoQuery.PrimeiroOuNull(new IssServicoFilter
            {
                Cd_Exercicio = cdExercicio,
                Cd_Servico = servicoVinculo.Cd_Servico
            });

            // validar
            if (servicoEntity == null)
            {
                // se não achou, tentar fazer a mesma busca usando o 0 (zero) na frente porque o campo 'cd_servico' é string/texto.
                // Serviço Item de atividade da prefeitura/cecam
                servicoEntity = await _issServicoQuery.PrimeiroOuNull(new IssServicoFilter
                {
                    Cd_Exercicio = cdExercicio,
                    Cd_Servico = "0" + servicoVinculo.Cd_Servico
                });

                // validar
                if (servicoEntity == null)
                {
                    throw new Exception($"Cadastre o serviço {servicoVinculo.Cd_Servico} para seguir com a importação", new Exception($"SELECT TOP 1 * FROM IssServicos WITH(NOLOCK) WHERE cd_Exercicio={cdExercicio} AND cd_Servico = '{servicoVinculo.Cd_Servico}';  -  " + exceptionMsg + $"issServico com Cd_Servico={servicoVinculo.Cd_Servico} não encontrado na base"));
                }
            }

            // se nota fiscal é de exportação?
            if (nfse.Tomador?.HeOutroPais() == true)
            {
                // é exportação, então forçar como 1.
                nfse.Fl_AliquotaLocalPrestacao = 1;
            }
            else
            {
                // definir se a aliquota é do local de prestação ou do local do emissor, 
                // utilizando a configuração do local no servico que esta sendo prestado.
                nfse.Fl_AliquotaLocalPrestacao = (byte)(servicoEntity.Fl_Local.GetValueOrDefault() == 0 ? 1 : 0);
            }

            // ------------------------------------------

            // aliquota do beneficio valor default 0 (zero)
            nfse.Nr_AliquotaBeneficio = 0;

            // verificar se temos parametros de calc da NFSe carregado?
            if (_dadosOrigem?.IssParametrosCalculoBus != null)
            {
                // verificar se o servico informado tem beneficio fiscal ?
                var beneficio = _dadosOrigem.IssParametrosCalculoBus.VerificarServicoTemBeneficioFiscal(servicoEntity.Cd_Servico);

                // tem beneficio?
                if (beneficio.TemBeneficio)
                {
                    // sim tem beneficio,
                    // então atribuir a aliquota do beneficio n NFSe
                    nfse.Nr_AliquotaBeneficio = beneficio.Aliquota;
                }
            }

            // ------------------------------------------

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim");
        }


        /// <summary>
        /// Preencher Item filho com os valores do servico
        /// </summary>
        private async Task ProcessarValores()
        {
            if (_dadosOrigem == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarValores() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // atalho para item
            var nfseItem = nfse.Itens?.FirstOrDefault();

            // validar
            if (nfseItem == null)
                return;

            // objeto 'valores'
            var valores = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.valores;

            // validar
            if (valores == null)
                throw new Exception("Valor da NFSe não informado, informe a CECAM", new Exception(exceptionMsg + "valor da prestação do serviço não encontrado na xml de origem do gov.br"));

            // -----------------------------------------------

            if (decimal.TryParse(valores.vServPrest?.vServ, NumberStyles.Number, new CultureInfo("en-US"), out var vlItem))
            {
                // valor da prestação do servico
                nfseItem.Vl_Item = vlItem;
            }

            // validar
            if (nfseItem.Vl_Item <= 0 && valores.vServPrest?.vServ != "0.00")
                throw new Exception(exceptionMsg + $"valor da prestação do serviço valores.vServPrest.vServ={valores.vServPrest?.vServ} não convertido");

            // logar o valor com suas casas decimais antes e depois da conversão,
            // pq em algumas prefeituras da erro na conversão do ponto em virgual.
            _loggerHelper.GravarTexto(exceptionMsg + $"valores.vServPrest.vServ = {valores.vServPrest?.vServ} -> vlItem {vlItem}");

            // --------------------------------------------------------------------

            // atalho para os valores guardados no resumo da nota
            var valorResumo = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Valores;

            decimal vDescIncond = 0;
            decimal vDescCond = 0;
            decimal vCalculoDeducaoReducao = 0;

            // descontos
            decimal.TryParse(valores.vDescCondIncond?.vDescIncond, NumberStyles.Number, new CultureInfo("en-US"), out vDescIncond);
            decimal.TryParse(valores.vDescCondIncond?.vDescCond, NumberStyles.Number, new CultureInfo("en-US"), out vDescCond);

            // dedução e redução (principalmente usado quando é OBRAS)
            if (valorResumo != null)
            {
                decimal.TryParse(valorResumo.vCalcDR, NumberStyles.Number, new CultureInfo("en-US"), out vCalculoDeducaoReducao);
            }

            nfseItem.vl_DescontoIncondicionado = vDescIncond;
            nfseItem.vl_DescontoCondicionado = vDescCond;
            nfseItem.Vl_Deducao = vDescIncond + vDescCond + vCalculoDeducaoReducao;

            // --------------------------------------------------------------------

            // valor para base de calculo do imposto
            nfseItem.Vl_BaseCalculo = nfseItem.Vl_Item - nfseItem.Vl_Deducao;

            // --------------------------------------------------------------------

            // verificar se essa nota NÃO é tributavel ?
            if (("" + valores.trib?.tribMun?.tribISSQN).Trim() != "1")
            {
                // essa nota não é tributavel, então todos os campos de desconto, percentual, tomado, etc
                // devem ficar vazios com valor 0.00 (Zero)
                _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - tribISSQN != 1 então não é tributavel - FIM");

                // zerar alguns campos antes de sair
                nfseItem.Vl_Devido = 0;
                nfseItem.Vl_DevidoItem = 0;

                // nenhum calculo precisa ser feito, então sair
                return;
            }


            // --------------------------------------------------------------------


            // aliquota em percentual 
            decimal pcAliquota;

            // temos node de resumo de valores e temos percentual dentro do node resumo de valores?
            if (valorResumo != null && decimal.TryParse(valorResumo.pAliqAplic, NumberStyles.Number, new CultureInfo("en-US"), out pcAliquota))
            {
                // primeiro tenta carregar do resumo de valores
                // percentual da aliquota
                nfseItem.Pc_Aliquota = pcAliquota;

                // logar o valor com suas casas decimais antes e depois da conversão,
                // pq em algumas prefeituras da erro na conversão do ponto em virgual.
                _loggerHelper.GravarTexto(exceptionMsg + $"valorResumo.pAliqAplic = {valorResumo.pAliqAplic.ToString(CultureInfo.InvariantCulture)} -> pcAliquota = {pcAliquota.ToString(CultureInfo.InvariantCulture)}");
            }
            else if (decimal.TryParse(valores.trib?.totTrib?.pTotTribSN, NumberStyles.Number, new CultureInfo("en-US"), out pcAliquota))
            {
                // primeiro tenta carregar quando é simples nacional
                // percentual da aliquota
                nfseItem.Pc_Aliquota = pcAliquota;

                // logar o valor com suas casas decimais antes e depois da conversão,
                // pq em algumas prefeituras da erro na conversão do ponto em virgual.
                _loggerHelper.GravarTexto(exceptionMsg + $"valores.trib?.totTrib?.pTotTribSN = {valores.trib?.totTrib?.pTotTribSN.ToString(CultureInfo.InvariantCulture)} ->  pcAliquota = {pcAliquota.ToString(CultureInfo.InvariantCulture)}");
            }
            else if (pcAliquota == 0 && decimal.TryParse(valores.trib?.tribMun?.pAliq, NumberStyles.Number, new CultureInfo("en-US"), out pcAliquota))
            {
                // depois tenta carregar do tibuto municipal
                // percentual da aliquota
                nfseItem.Pc_Aliquota = pcAliquota;

                // logar o valor com suas casas decimais antes e depois da conversão,
                // pq em algumas prefeituras da erro na conversão do ponto em virgual.
                _loggerHelper.GravarTexto(exceptionMsg + $"valores.trib?.tribMun?.pAliq = {valores.trib?.tribMun?.pAliq.ToString(CultureInfo.InvariantCulture)} -> pcAliquota = {pcAliquota.ToString(CultureInfo.InvariantCulture)}");
            }
            else if (pcAliquota == 0 && decimal.TryParse(valores.trib?.totTrib?.pTotTrib?.pTotTribMun, NumberStyles.Number, new CultureInfo("en-US"), out pcAliquota))
            {
                // depois tenta carregar do total de tributos mas ainda como percentual
                // percentual da aliquota
                nfseItem.Pc_Aliquota = pcAliquota;

                // logar o valor com suas casas decimais antes e depois da conversão,
                // pq em algumas prefeituras da erro na conversão do ponto em virgual.
                _loggerHelper.GravarTexto(exceptionMsg + $"valores.trib?.totTrib?.pTotTrib?.pTotTribMun = {valores.trib?.totTrib?.pTotTrib?.pTotTribMun.ToString(CultureInfo.InvariantCulture)} -> pcAliquota = {pcAliquota.ToString(CultureInfo.InvariantCulture)}");
            }
            else if (pcAliquota == 0 && decimal.TryParse(valores.trib?.totTrib?.vTotTrib?.vTotTribMun, NumberStyles.Number, new CultureInfo("en-US"), out var vTotTribMun))
            {
                // depois tenta carregar do total de tributos mas agora como valor moeda
                // para em seguida fazer a conta da aliquota aplicada.

                // não temos percentual, mas temos o valor do tributo para calcular o percentual
                nfseItem.Pc_Aliquota = 0;

                // verificar se temos base de calculo maior que zero para não dar erro de divisão por zero?
                if (nfseItem.Vl_BaseCalculo.GetValueOrDefault() > 0)
                {
                    nfseItem.Pc_Aliquota = vTotTribMun * 100.00M / nfseItem.Vl_BaseCalculo.GetValueOrDefault();
                }

                // logar o valor com suas casas decimais antes e depois da conversão,
                // pq em algumas prefeituras da erro na conversão do ponto em virgual.
                _loggerHelper.GravarTexto(exceptionMsg + $"valores.trib?.totTrib?.vTotTrib?.vTotTribMun = {valores.trib?.totTrib?.vTotTrib?.vTotTribMun.ToString(CultureInfo.InvariantCulture)} -> nfseItem.Pc_Aliquota = {nfseItem.Pc_Aliquota.ToString(CultureInfo.InvariantCulture)}");
            }

            // validar
            if (nfseItem.Pc_Aliquota < 0)
                throw new Exception("Aliquota não informada, informe a CECAM", new Exception(exceptionMsg + $"percentual da aliquota simples nacional Pc_Aliquota = {nfseItem.Pc_Aliquota} não convertido"));

            if (nfseItem.Pc_Aliquota >= 100)
                throw new Exception("Aliquota maior que 100%, informe a CECAM", new Exception(exceptionMsg + $"percentual da aliquota simples nacional Pc_Aliquota = {nfseItem.Pc_Aliquota} convertido com erro"));

            // logar o valor com suas casas decimais antes e depois da conversão,
            // pq em algumas prefeituras da erro na conversão do ponto em virgual.
            _loggerHelper.GravarTexto(exceptionMsg + $"nfseItem.Pc_Aliquota em mémoria = {nfseItem.Pc_Aliquota}");

            // --------------------------------------------------------------------

            // tipo de retenção do ISSQN
            // 1 = não retido
            // 2 = retido pelo tomador
            // 3 = retido pelo intermediario
            var tpRetISSQN = ("" + valores.trib?.tribMun?.tpRetISSQN).Trim();

            if (tpRetISSQN == "" || tpRetISSQN == "1")
            {
                // tpRetISSQN = 1 = imposto ISSQN NÃO é retido pelo tomador, então é pago pelo prestador
                nfseItem.Fl_Retido = (byte)IssNotaFiscalItemEnum.enumFlRetido.RetidoPeloPrestador;
                nfseItem.Vl_DevidoItem = 0;
                nfseItem.Vl_Devido = nfseItem.Vl_BaseCalculo.GetValueOrDefault() * nfseItem.Pc_Aliquota / 100.0M;
                nfseItem.Vl_Tomado = 0;
            }
            else
            {
                // tpRetISSQN = 2 = retido pelo tomador
                // tpRetISSQN = 3 = retido pelo intermediario
                nfseItem.Fl_Retido = (byte)IssNotaFiscalItemEnum.enumFlRetido.RetidoPeloTomador;
                nfseItem.Vl_DevidoItem = 0;
                nfseItem.Vl_Devido = 0;

                // qnd ISSQN for retido e local da prestação for em outro municipio, então o valor tomado precisa ser igual a 0.00 (zero)
                if (nfse.Fl_LocalPrestacao == (byte)IssNotaFiscalEnum.enumLocalPrestacao.ForaDoMunicipioDoPrestador)
                {
                    // issqn retido e local de prestação é fora do municipio do prestador.
                    nfseItem.Vl_Tomado = 0;
                }
                else
                {
                    // issqn retido e local de prestação é no mesmo município do prestador
                    nfseItem.Vl_Tomado = Decimal.Round(nfseItem.Vl_BaseCalculo.GetValueOrDefault() * nfseItem.Pc_Aliquota / 100.0M, 2);
                }
            }

            // validar
            if (nfseItem.Vl_Tomado < 0 || nfseItem.Vl_DevidoItem < 0)
                throw new Exception(exceptionMsg + $"valor devido do imposto Vl_Tomado = {nfseItem.Vl_Tomado} ou Vl_DevidoItem = {nfseItem.Vl_DevidoItem} não convertido");

            // --------------------------------------------------------------------

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim");

            await Task.CompletedTask;
        }


        /// <summary>
        /// Processar os Impostos filhos da NFse
        /// </summary>
        private async Task ProcessarImpostos()
        {
            if (_dadosOrigem == null)
                return;

            // inicio da mensagem de exception
            var exceptionMsg = "NfseGovBrImportarCorpoCabeca.ProcessarImpostos() - ";

            // log início
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem.NfseId()} - Início");

            // atalho
            var nfse = _dadosOrigem?.IssNotaFiscalEnty;

            // validar
            if (nfse == null)
                return;

            // carregar todos os Impostos que devem ser preenchidos
            var cecamImpostoQuery = ServiceProviderGlobal.GetServico<ICecamImpostoQuery>();
            var impostoLista = await cecamImpostoQuery.Listar(new CecamImpostoFilter());

            // verificar se temos impostos para serem importados?
            if (impostoLista == null || impostoLista.Count == 0)
            {
                _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim - tabela CecamImpostos não contem registros para serem importados");
                return;
            }

            // criar a lista vazia de impostos filhos da NFSe
            nfse.Impostos = new List<IssNotaFiscalImpostoEntity>();

            // atalho
            InfDpsValoresTributoFederalXml tribFed = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Dps?.InfDps?.valores?.trib?.tribFed ?? new InfDpsValoresTributoFederalXml();

            // valor do imposto recuperado da xml
            var valorImpostoTexto = string.Empty;
            decimal valorImpostoDecimal = 0;

            // percorrer todos os impostos
            foreach (var impostoItem in impostoLista)
            {
                switch (impostoItem.Sg_Imposto.Trim().ToUpper())
                {
                    case "ISSQN":
                        valorImpostoTexto = "" + _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Valores?.vISSQN;
                        break;

                    case "PIS":
                        valorImpostoTexto = "" + tribFed.piscofins?.vPis;
                        break;

                    case "COFINS":
                        valorImpostoTexto = "" + tribFed.piscofins?.vCofins;
                        break;

                    case "IRRF":
                        valorImpostoTexto = "" + tribFed.vRetIRRF;
                        break;

                    case "CSLL":
                        valorImpostoTexto = "" + tribFed.vRetCSLL;
                        break;

                    default:
                        valorImpostoTexto = "0";
                        break;
                }

                // converter texto para decimal
                if (!decimal.TryParse(valorImpostoTexto, NumberStyles.Number, new CultureInfo("en-US"), out valorImpostoDecimal))
                    valorImpostoDecimal = 0;

                // incluir imposto na NFSe
                nfse.Impostos.Add(new IssNotaFiscalImpostoEntity
                {
                    Cd_Imposto = impostoItem.Cd_Imposto,
                    Vl_Imposto = valorImpostoDecimal
                });
            }

            // log fim
            _loggerHelper.GravarTexto(exceptionMsg + $"NfseId={_dadosOrigem?.NfseId()} - Fim");
        }
    }
}
