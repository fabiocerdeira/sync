﻿using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota.Corpo;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota
{
    public class NfseGovBrNfseImportarNotaBus : NfseGovBrNfseImportarNotaBusBase
    {
        #region Declarações


        /// <summary>
        /// log
        /// </summary>
        private readonly ILogger<NfseGovBrNfseImportarNotaBus> _logger;


        public NfseGovBrNfseImportarNotaBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrNfseImportarNotaBus>();
            _loggerHelper.Logger = _logger;
        }


        #endregion


        /// <summary>
        /// Importar uma DFE de NFSe já baixada/download do gov.br e salvar na base prefeitura/cecam
        /// </summary>
        /// <returns>
        /// True se encontrou alguma NFSe para ser importada (independe de sucesso ou erro na importação)
        /// False se não encontrou NFSe para ser importada
        /// </returns>
        public async Task<bool> Importar()
        {
            // log inicial
            LogAtalho("NfseGovBrNfseImportarBus.Importar()", "Início");

            try
            {
                // limpar os objetos dessa classe para próxima NFSe.
                LimparObjetosGlobais();

                // Carregar a partir da fila de entrada a próxima nota fiscal para ser importada
                if (!await CarregarProximaNotaFiscalParaImportacao(NfseGovBrEnum.enumFilaTipo.NFSe))
                    return false;

                // verificar se essa nota fiscal já foi importada na base prefeitura/cecam
                await VerificarNotaFiscalJaFoiImportada();

                // importar da fila para a tabela de ISSNotaFiscal
                await ImportarProcessar();

                // finalizar a importação da nfse com sucesso gravando na fila de saída
                await FinalizarComSucessoNaImportacao();
            }
            catch (NfseGovBrImportarMoverFilaException nfseEx)
            {
                // logar erro
                LogAtalho("NfseGovBrNfseImportarBus.Importar().NfseGovBrImportarException", nfseEx.ToString(), LogLevel.Error);

                if (_dadosOrigem?.NotaFiscalFilaImportarEntrada != null)
                {
                    // status do erro
                    _dadosOrigem.NotaFiscalFilaImportarEntrada.Status = (int)nfseEx.FilaStatus;

                    // mensagem do erro
                    _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem = nfseEx.Message;

                    // mover NFSe da fila de entrada para fila de saída
                    await FinalizarMoverEntradaSaida();
                }
            }
            catch (Exception ex)
            {
                // logar erro
                LogAtalho("NfseGovBrNfseImportarBus.Importar().Exception", ex.ToString(), LogLevel.Error);

                // marcar Nota Fiscal na fila de entrada como erro e gravar o respectivo erro
                await FinalizarComErroNaImportacao(ex.ToString(), NfseGovBrEnum.enumFilaStatus.ProcessadoComErro, ex.Message);
            }

            // limpar os objetos dessa classe para próxima NFSe.
            LimparObjetosGlobais();

            // log fim
            LogAtalho("NfseGovBrNfseImportarBus.Importar()", "Fim");

            // retorna indicando que houve uma NFSe processada.
            // independente de sucesso ou erro na importação
            // utilizado para o loop de fazer importação de várias NFSe
            return true;
        }




        /// <summary>
        /// Converter uma XML de DFe para uma IISNotaFiscal na base Cecam
        /// </summary>
        private async Task ImportarProcessar()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null ||
                string.IsNullOrWhiteSpace(_dadosOrigem.NotaFiscalFilaImportarEntrada.Corpo))
                return;

            // log inicio
            LogAtalho("ImportarProcessar()", "Início");

            // gravar xm no arquivo em disco
            _loggerHelper.GravarArquivoDisco(_dadosOrigem.NotaFiscalFilaImportarEntrada.Corpo, "nfse_importar_original_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".xml");

            // converter string/texto em objeto que representa a XML
            ConverterXmlStringParaClasse();

            // verificar se foi convertido com sucesso?
            if (_dadosOrigem.NotaFiscalImportada == null)
                throw new Exception("ImportarProcessar().ConverterXmlStringParaClasse() não funcionou corretamente");

            // completar o nome arquivo de log com o ID da NFSe
            _loggerHelper.PrefixoNomeArquivo = $"nfse_importar_nsu_{_dadosOrigem.Nsu()}_chave_{_dadosOrigem.NfseId()}";

            // converter cabeça da nota fiscal
            var cabeca = new NfseGovBrImportarNotaCorpoCabeca(_dadosOrigem, _loggerHelper);
            await cabeca.Processar();

            // converter item da nota fiscal
            var item = new NfseGovBrImportarNotaCorpoItem(_dadosOrigem, _loggerHelper);
            await item.Processar();

            // verificando null
            if (_dadosOrigem.IssNotaFiscalEnty == null)
                throw new Exception("ImportarProcessar() IssNotaFiscalEnty não pode ser null, a conversão da XML para Entity não funcionou corretamente");
            
            // gravar a nova NFSe na base da prefeitura/cecam
            var issNotaFiscalCriarBus = new IssNotaFiscalCriarBus();

            if (_dadosOrigem.IssContribuinte != null)
            {
                // se tiver contribuinte então é uma nota fiscal que deve ser emitida
                await issNotaFiscalCriarBus.Emitir(_dadosOrigem.IssNotaFiscalEnty);
            }
            else
            {
                // se não tiver contribuinte então tem um eventual, logo é escrituração da nota
                await issNotaFiscalCriarBus.Escriturar(_dadosOrigem.IssNotaFiscalEnty);
            }

            // log fim
            LogAtalho("ImportarProcessar()", $"Fim - NfseId = {_dadosOrigem.NfseId()}");
        }





        /// <summary>
        /// Verificar se essa nota fiscal já foi importada na base prefeitura/cecam
        /// </summary>
        private async Task VerificarNotaFiscalJaFoiImportada()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null || _dadosOrigem.Nsu() == 0)
                return;

            // log início
            LogAtalho("VerificarNotaFiscalJaFoiImportada()", $"Início - Nsu {_dadosOrigem.Nsu()} NfseId {_dadosOrigem.NfseId()}");

            // consultar tabela fila de saída com documentos já processados anteriormente
            if (await _filaSaidaRepository.GetIQueryable().AnyAsync(x => x.Nsu == _dadosOrigem.Nsu()))
            {
                // nota fiscal já foi importada

                // marcar Nota Fiscal na fila de entrada como importação duplicada
                await FinalizarComErroNaImportacao("NFSE já foi importada pq NSU já existe na fila de saída da importação", NfseGovBrEnum.enumFilaStatus.DuplicadoNaoPodeProcessar, "NFSe já foi importada, informe a CECAM");

                // log duplicada
                LogAtalho("VerificarNotaFiscalJaFoiImportada()", $"NFSe já foi importada anteriormente - Nsu {_dadosOrigem.Nsu()} NfseId {_dadosOrigem.NfseId()}");

                // então limpar a xml de origem dos dados
                _dadosOrigem.NotaFiscalImportada = null;
                _dadosOrigem.NotaFiscalFilaImportarEntrada = null;
            }

            // log fim
            LogAtalho("VerificarNotaFiscalJaFoiImportada()", $"Fim - Nsu {_dadosOrigem.Nsu()} NfseId {_dadosOrigem.NfseId()}");
        }
    }
}
