﻿using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.Business.IssNotaFiscal.Filter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Cecam.Tributario.Database.Enumerado.IssNotaFiscal.IssNotaFiscalEnum;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Evento
{
    public class NfseGovBrNfseImportarEventoAceiteBus
    {
        #region Declarações


        /// <summary>
        /// logs
        /// </summary>
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Dados para importação
        /// </summary>
        private NfseGovBrNfseImportarEventoBusDados _dadosOrigem;


        public NfseGovBrNfseImportarEventoAceiteBus(NfseGovBrNfseImportarEventoBusDados dadosOrigem, ILoggerHelper loggerHelper)
        {
            // dados durante a conversão
            _dadosOrigem = dadosOrigem;

            // logs
            _loggerHelper = loggerHelper;
        }


        #endregion


        /// <summary>
        /// Realizar o aceite da nota fiscal informada
        /// </summary>
        public async Task AceitarNfse()
        {
            // log inicio
            _loggerHelper.GravarTexto("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() - início");

            // recuperar o evento
            var evento = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento;

            // validar
            if (evento == null)
                throw new Exception("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() * erro * xml sem evento informado");

            // recuperar o CNPJ ou CPF da entidade que aceitou a nota fisca.
            var cpfCnpjAceitador = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.CNPJAutor + _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.CPFAutor;

            // validar
            if (string.IsNullOrWhiteSpace(cpfCnpjAceitador))
                throw new Exception("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() * erro * xml sem cnpj/cpf do aceitador da nota fiscal");

            // filtro para carregar a nota fiscal
            var busFiltro = new IssNotaFiscalBusFilter()
            {
                Govbr_ChaveAcesso = _dadosOrigem.NfseChaveAcesso(),
                IncluirItens = true,
                IncluirTomador = true,
                IncluirIntermediario = true,
                IncluirImpostos = true,
                IncluirServico = true
            };

            // aceitador default da nota fiscal
            var aceitador = enumAceitadorNotaFiscal.Tomador;

            // aceite de nota pelo prestador
            if (evento.ItemConfirmacaoPrestador202201 != null || evento.ItemConfirmacaoPrestador202211 != null)
                throw new Exception("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() * erro * aceite de nota pelo prestador não esta programa para funcionar no sistema de importação de nfse gov.br");

            // aceite de nota pelo tomador
            else if (evento.ItemConfirmacaoTomador203202 != null || evento.ItemConfirmacaoTomador203212 != null)
            {
                busFiltro.Nr_CGCCPFTomador = cpfCnpjAceitador;
                aceitador = enumAceitadorNotaFiscal.Tomador;
            }

            // aceite de nota pelo intermediario
            else if (evento.ItemConfirmacaoIntermediario204203 != null || evento.ItemConfirmacaoIntermediario204213 != null)
            {
                busFiltro.nr_CGCCPFTomadorIntermediario = cpfCnpjAceitador;
                aceitador = enumAceitadorNotaFiscal.Intermediario;
            }

            // aceite de nota tácita (pela prefeitura)
            else if (evento.ItemConfirmacaoTacita205204 != null || evento.ItemConfirmacaoTacita205214 != null)
                throw new Exception("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() * erro * aceite de nota tácita não esta programa para funcionar no sistema de importação de nfse gov.br");

            else
                throw new Exception("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() * erro * xml com evento de aceite de nota não reconhecida no sistema de importação de notas gov.br");

            // objeto de negocio
            var notaFiscalBus = new IssNotaFiscalBus();

            // carregar a nota fiscal completa com todos os seus dados
            var notaFiscalOriginaria = await notaFiscalBus.Carregar(busFiltro);

            // validar
            if (notaFiscalOriginaria == null)
                throw new Exception("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() * erro * nota fiscal originária para ser aceita não foi encontrada na base prefeitura/cecam");

            // aceitar a nota fiscal
            var notaFiscalAceitarBus = new IssNotaFiscalAceitarBus();
            await notaFiscalAceitarBus.AceitarNotaFiscal(notaFiscalOriginaria, aceitador, cpfCnpjAceitador);

            // log fim
            _loggerHelper.GravarTexto("NfseGovBrNfseImportarEventoAceiteBus.AceitarNfse() - fim");
        }
    }
}
