﻿using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.Business.NfseGovBr.Download;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Evento
{
    public class NfseGovBrNfseImportarEventoBus: NfseGovBrNfseImportarEventoBusBase
    {
        #region Declarações


        /// <summary>
        /// log
        /// </summary>
        private readonly ILogger<NfseGovBrNfseImportarEventoBus> _logger;


        /// <summary>
        /// query da IssNotaFiscal
        /// </summary>
        private readonly IIssNotaFiscalQuery _notaFiscalQuery;


        public NfseGovBrNfseImportarEventoBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrNfseImportarEventoBus>();
            _loggerHelper.Logger = _logger;

            // repositorios
            _notaFiscalQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalQuery>();
        }


        #endregion


        /// <summary>
        /// Importar um Evento de NFSe já baixada/download do gov.br e salvar na base prefeitura/cecam
        /// </summary>
        /// <returns>
        /// True se encontrou algum Evento NFSe para ser importada (independe de sucesso ou erro na importação)
        /// False se não encontrou Evento de NFSe para ser importada
        /// </returns>
        public async Task<bool> Importar()
        {
            // log inicial
            LogAtalho("NfseGovBrNfseImportarEventoBus.Importar()", "Início");

            try
            {
                // limpar os objetos dessa classe para próxima NFSe.
                LimparObjetosGlobais();

                // Carregar a partir da fila de entrada o próximo evento de cancelamento de nota fiscal para ser importada
                if (!await CarregarProximoEventoParaImportacao())
                    return false;

                // verificar se esse evento de nota fiscal já foi importada na base prefeitura/cecam
                await VerificarEventoJaFoiImportado();

                // importar da fila e realizar o cancelamento da NFSe
                await ImportarProcessar();

                // finalizar a importação da nfse com sucesso gravando na fila de saída
                await FinalizarComSucessoNaImportacao();
            }
            catch (NfseGovBrImportarMoverFilaException nfseEx)
            {
                // logar erro
                LogAtalho("NfseGovBrNfseImportarEventoBus.Importar().NfseGovBrImportarException", nfseEx.ToString(), LogLevel.Error);

                if (_dadosOrigem?.NotaFiscalFilaImportarEntrada != null)
                {
                    // status do erro
                    _dadosOrigem.NotaFiscalFilaImportarEntrada.Status = (int)nfseEx.FilaStatus;

                    // mensagem do erro
                    _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem = nfseEx.Message;

                    // mover NFSe da fila de entrada para fila de saída
                    await FinalizarMoverEntradaSaida();
                }
            }
            catch (Exception ex)
            {
                // logar erro
                LogAtalho("NfseGovBrNfseImportarEventoBus.Importar().Exception", ex.ToString(), LogLevel.Error);

                // marcar Nota Fiscal na fila de entrada como erro e gravar o respectivo erro
                await FinalizarComErroNaImportacao(ex.ToString(), NfseGovBrEnum.enumFilaStatus.ProcessadoComErro, ex.Message);
            }

            // limpar os objetos dessa classe para próxima NFSe.
            LimparObjetosGlobais();

            // log fim
            LogAtalho("NfseGovBrNfseImportarEventoBus.Importar()", "Fim");

            // retorna indicando que houve uma NFSe processada.
            // independente de sucesso ou erro na importação
            // utilizado para o loop de fazer importação de várias NFSe
            return true;
        }


        /// <summary>
        /// Ler a XML de Evento para cancelar uma IssNotaFiscal na base Cecam
        /// </summary>
        private async Task ImportarProcessar()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null ||
                string.IsNullOrWhiteSpace(_dadosOrigem.NotaFiscalFilaImportarEntrada.Corpo))
                return;

            // log inicio
            LogAtalho("NfseGovBrNfseImportarEventoBus.ImportarProcessar()", "Início");

            // gravar xm no arquivo em disco
            _loggerHelper.GravarArquivoDisco(_dadosOrigem.NotaFiscalFilaImportarEntrada.Corpo, "evento_importar_original_" + DateTime.Now.ToString("yyyyMMdd_HHmm") + ".xml");

            // converter string/texto em objeto que representa a XML
            ConverterXmlStringParaClasse();

            // verificar se foi convertido com sucesso?
            if (_dadosOrigem.EventoImportado == null)
                throw new Exception("Conversão de XML não funcionou por favor informar a CECAM", new Exception("NfseGovBrNfseImportarEventoBus.ImportarProcessar().ConverterXmlStringParaClasse() não funcionou corretamente"));

            // completar o nome arquivo de log com o ID da NFSe
            _loggerHelper.PrefixoNomeArquivo = $"evento_importar_nsu_{_dadosOrigem.Nsu()}_chave_{_dadosOrigem.EventoId()}";

            // --------------------------------

            // Validar campos e regras antes de processar o evento
            await Validar();

            // Verificar se a nota fiscal que será manipulada por esse evento ainda esta na fila de entrada
            await VerificarNotaAindaExisteFilaEntrada();

            // Verificar na fila de saída/processados se a nota fiscal manipulada por esse evento existe ou se tem data anterior a implantação do gov.br
            await VerificarNotaExisteFilaSaida();

            // verificar se o tipo da fila é de cancelamento ?
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.Cancelamento)
            {
                // manager para importação de cancelamento de nota fiscal
                var cancelamentoBus = new NfseGovBrNfseImportarEventoCancelamentoBus(_dadosOrigem, _loggerHelper);

                // importar o cancelamento da nota fiscal
                await cancelamentoBus.CancelarNfse();
            }

            // verificar se o tipo da fila é de aceite de notas ?
            else if (_dadosOrigem.NotaFiscalFilaImportarEntrada.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.AceiteNotaFiscal)
            {
                // manager para importação de aceite de nota fiscal
                var aceiteBus = new NfseGovBrNfseImportarEventoAceiteBus(_dadosOrigem, _loggerHelper);

                // realizar o aceite da nota fiscal informada
                await aceiteBus.AceitarNfse();
            }

            // verificar se o tipo da fila é desconhecido ?
            else 
            {
                // tipo de fila ainda não é tratado pelo sistema de importação
                throw new Exception("Tipo de fila não reconhecido, por favor informar a CECAM", new Exception($"NfseGovBrNfseImportarEventoBus.ImportarProcessar() - erro - FilaTipo {_dadosOrigem.NotaFiscalFilaImportarEntrada.FilaTipo} não é reconhecido/esperado pelo sistema de importação"));
            }

            // log fim
            LogAtalho("ImportarProcessar()", $"Fim - EventoId = {_dadosOrigem.EventoId()}");
        }


        /// <summary>
        /// Validar campos e regras antes de processar o evento
        /// </summary>
        private async Task Validar()
        {
            // eventos que chegam com fila tipo 'ignorado' devem ser simplismente ignorados
            // então é um passo intermediario do gov.br que NÃO precisa de ação no ISSWEB/cecam/prefeitura.
            // basta mover da fila de entrada para a fila de saída
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada?.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.Ignorado)
            {
                // mover para fila de saída como ignorado
                throw new NfseGovBrImportarMoverFilaException($"Evento ignorado, então não precisa ser importado", NfseGovBrEnum.enumFilaStatus.Ignorado);
            }

            // -----------------

            var dhEmissaoString = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.dhEvento;

            if (DateTime.TryParse(dhEmissaoString, out var dtEmissao))
            {
                // dia 01/01/2026 foi o inicio/lançamento do emissor nacional pelo gov.br
                // todas as notas e eventos anteriores não podem ser tratados pelo importador.
                if (dtEmissao.Year < 2026)
                {
                    // recuperar a chave da nota fiscal que será manipulada com o evento atual
                    string? chaveAcessoNotaDestino = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.chNFSe;

                    if (!string.IsNullOrWhiteSpace(chaveAcessoNotaDestino))
                    {
                        // recuperar a nota da tabela IssNotaFiscal para verificar se a data de emissão é maior que ano de inicio de importação do gov.br?
                        var notaFiscalEntity = await _notaFiscalQuery.PrimeiroOuNull(new IssNotaFiscalFilter()
                        {
                            Govbr_ChaveAcesso = chaveAcessoNotaDestino
                        });

                        // se achou nota então verificar data de emissão é maior que inicio do gov.br
                        // se não achou nota então não tem problema, nos próximos passos ele vai baixar a nota do gov.br e vai retornar aqui na proxima execução do programa.
                        if (notaFiscalEntity != null && notaFiscalEntity.Dt_Emissao.Year < 2026)
                            throw new NfseGovBrImportarMoverFilaException($"Data emissão da NFSe anterior a 2026. Evento não pode ser processado pelo importador. Data emissão NFSE={notaFiscalEntity.Dt_Emissao}", NfseGovBrEnum.enumFilaStatus.ExercicioAntes2026);
                    }
                }
            }
        }


        /// <summary>
        /// Verificar se esse evento de nota fiscal já foi importada na base prefeitura/cecam<br/>
        /// Utiliza o campo NSU para fazer a verificação
        /// </summary>
        private async Task VerificarEventoJaFoiImportado()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
                return;

            // log início
            LogAtalho("VerificarEventoJaFoiImportado()", $"Início - Nsu={_dadosOrigem.Nsu()} EventoId={_dadosOrigem.EventoId()}");

            bool eventoEncontrado = false;

            // verificar se temos nsu informado ?
            if (_dadosOrigem.Nsu() > 0)
            {
                // temos nsu, então usar nsu porque ele é unique
                eventoEncontrado = await _filaSaidaRepository.GetIQueryable().AnyAsync(x => x.Nsu == _dadosOrigem.Nsu());
            }
            else
            {
                // não temos nsu, então procurar por chave acesso + tipo documento + tipo evento
                eventoEncontrado = await _filaSaidaRepository.GetIQueryable().AnyAsync(x => x.ChaveAcesso == _dadosOrigem.NotaFiscalFilaImportarEntrada.ChaveAcesso && x.TipoDocumento == _dadosOrigem.NotaFiscalFilaImportarEntrada.TipoDocumento && x.TipoEvento == _dadosOrigem.NotaFiscalFilaImportarEntrada.TipoEvento);
            }

            // consultar tabela fila de saída com documentos já processados anteriormente
            if (eventoEncontrado)
            {
                // nota fiscal já foi importada

                // marcar Nota Fiscal na fila de entrada como importação duplicada
                await FinalizarComErroNaImportacao("Evento de NFSe já foi importado pq NSU já existe na fila de saída da importação", NfseGovBrEnum.enumFilaStatus.DuplicadoNaoPodeProcessar, "Evento duplicado, por favor informar para CECAM");

                // log duplicada
                LogAtalho("VerificarEventoJaFoiImportado()", $"NFSe já foi importada anteriormente - Nsu {_dadosOrigem.Nsu()} chave acesso={_dadosOrigem.NfseChaveAcesso()}  EventoId {_dadosOrigem.EventoId()}");

                // então limpar a xml de origem dos dados
                _dadosOrigem.EventoImportado = null;
                _dadosOrigem.NotaFiscalFilaImportarEntrada = null;
            }

            // log fim
            LogAtalho("VerificarEventoJaFoiImportado()", $"Fim - Nsu {_dadosOrigem.Nsu()} chave acesso {_dadosOrigem.NfseChaveAcesso()} EventoId {_dadosOrigem.EventoId()}");
        }


        /// <summary>
        /// Verificar se a nota fiscal que será manipulada por esse evento ainda esta na fila de entrada
        /// </summary>
        private async Task VerificarNotaAindaExisteFilaEntrada()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null || string.IsNullOrWhiteSpace(_dadosOrigem.NfseChaveAcesso()))
                return;

            // log início
            LogAtalho("VerificarNotaAindaExisteFilaEntrada()", $"Início - Nsu={_dadosOrigem.Nsu()} chave acesso={_dadosOrigem.NfseChaveAcesso()} EventoId={_dadosOrigem.EventoId()}");

            // consultar tabela fila de entrada se a nota ainda existe (porque ainda não foi processada ou pq esta com erro)
            if (await _filaEntradaRepository.GetIQueryable().AnyAsync(x => x.ChaveAcesso == _dadosOrigem.NfseChaveAcesso() && x.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.NFSe))
            {
                // tipo de fila ainda não é tratado pelo sistema de importação
                throw new Exception("Aguarde, o evento será processado depois da NFSe ser processada", new Exception("NfseGovBrNfseImportarEventoBus.VerificarNotaAindaExisteFilaEntrada() - Erro - evento não pode ser processado antes da nota ser processada"));
            }

            // log fim
            LogAtalho("VerificarNotaAindaExisteFilaEntrada()", $"Fim - Nsu={_dadosOrigem.Nsu()} chave acesso={_dadosOrigem.NfseChaveAcesso()} EventoId={_dadosOrigem.EventoId()}");
        }


        /// <summary>
        /// Verificar na fila de saída/processados se a nota fiscal manipulada por esse evento existe ou se tem data anterior a implantação do gov.br
        /// </summary>
        private async Task VerificarNotaExisteFilaSaida()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null || string.IsNullOrWhiteSpace(_dadosOrigem.NfseChaveAcesso()))
                return;

            // log início
            LogAtalho("VerificarNotaExisteFilaSaida()", $"Início - Nsu={_dadosOrigem.Nsu()} chave acesso={_dadosOrigem.NfseChaveAcesso()} EventoId={_dadosOrigem.EventoId()}");

            // tentar recuperar a nota fiscal manipulada por esse evento
            var nfseOriginal = await _filaSaidaRepository.GetIQueryable().FirstOrDefaultAsync(x => x.ChaveAcesso == _dadosOrigem.NfseChaveAcesso() && x.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.NFSe);

            if (nfseOriginal == null)
            {
                // nota fiscal original não foi encontrada na fila de saída/processados.

                // então tem que baixar novamente essa nota
                var dwEventos = new NfseGovBrNfseDownloadEventoBus();
                await dwEventos.DownloadEventos(new List<string> { _dadosOrigem.NfseChaveAcesso() });

                // marcar esse evento como erro para ser processado novamente na próxima vez.
                throw new Exception("Aguarde, o evento será processado depois da NFSe ser processada", new Exception("NfseGovBrNfseImportarEventoBus.VerificarNotaExisteFilaSaida() - Erro - evento não pode ser processado antes da nota ser processada"));
            }
            else
            {
                // nota fiscal original foi encontrada na fila de saída/processamento porque já foi processada em algum momento no passado
                // verificar se o status é de 'Exercicio antes de 2026' ?
                if (nfseOriginal.Status == (int)NfseGovBrEnum.enumFilaStatus.ExercicioAntes2026)
                {
                    // nota fiscal original é anterior ao inicio da importação do gov.br em janeiro/2026, então esse evento não precisa ser processado.
                    throw new NfseGovBrImportarMoverFilaException($"Data emissão da NFSe anterior a 2026. Evento não pode ser importado.", NfseGovBrEnum.enumFilaStatus.ExercicioAntes2026);
                }
            }

            // log fim
            LogAtalho("VerificarNotaExisteFilaSaida()", $"Fim - Nsu={_dadosOrigem.Nsu()} chave acesso={_dadosOrigem.NfseChaveAcesso()} EventoId={_dadosOrigem.EventoId()}");
        }
    }
}
