﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Cecam.Tributario.Manager.View.NfseGovBr.Evento;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using static Cecam.Tributario.Database.Enumerado.NfseGovBr.NfseGovBrEnum;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Evento
{
    public abstract class NfseGovBrNfseImportarEventoBusBase
    {
        #region Declarações


        /// <summary>
        /// repositorio para ler os Eventos das NFSe baixadas e que serão importadas para base prefeitura/cecam
        /// </summary>
        protected readonly IIssNotaFiscalGovBrImportarEntradaRepository _filaEntradaRepository;


        /// <summary>
        /// Repositório para gravar os Eventos da NFSe que foram importadas com sucesso
        /// </summary>
        protected readonly IIssNotaFiscalGovBrImportarSaidaRepository _filaSaidaRepository;


        /// <summary>
        /// log
        /// </summary>
        protected readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Informações do Evento da NFSe baixada do gov.br para gravar na base da prefeitura/cecam
        /// </summary>
        protected NfseGovBrNfseImportarEventoBusDados _dadosOrigem = new NfseGovBrNfseImportarEventoBusDados();


        /// <summary>
        /// NSU para carregar da base para ser processado ignorando a ordem da fila de entrada
        /// </summary>
        public long? NsuProcessar { get; set; }


        /// <summary>
        /// Chave de Acesso para carregar da base para ser processado ignorando a ordem da fila de entrada
        /// </summary>
        public string? ChaveAcessoProcessar { get; set; }


        /// <summary>
        /// Ignorar a data hora do ultimo processamento
        /// </summary>
        public bool IgnorarDataHoraProcessamento { get; set; } = false;



        protected NfseGovBrNfseImportarEventoBusBase()
        {
            // logs
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;

            // repositorio para ler as nfse baixadas de gov.br para serem importadas
            _filaEntradaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarEntradaRepository>();

            // repositorio gravar as NFSe importadas com sucesso
            _filaSaidaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarSaidaRepository>();
        }


        #endregion


        #region Finalizar


        /// <summary>
        /// A importação do Evento da NFSe da fila para a base prefeitura/cecam na tabela ISSNotaFiscal foi com sucesso
        /// Mover o evento da nfse da fila de entrada para a fila de saída
        /// </summary>
        protected async Task FinalizarComSucessoNaImportacao()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null || _dadosOrigem.EventoImportado == null)
                return;

            // log inicial
            LogAtalho("NfseGovBrNfseImportarEventoBusBase.FinalizarComSucessoNaImportacao()", $"Início - EventoId = {_dadosOrigem.EventoId()}");

            // sucesso absoluto em todos os aspectos da importação e gravação.
            // então preparar o registro de entrada para ser copiado para o registro de saída

            // status de sucesso
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Status = (int)enumFilaStatus.ProcessadoComSucesso;

            // limpar mensagem de qnd estava na fila de entrada
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem = null;

            // finalizar
            await FinalizarMoverEntradaSaida();

            // log final
            LogAtalho("NfseGovBrNfseImportarEventoBusBase.FinalizarComSucessoNaImportacao()", $"Fim - EventoId = {_dadosOrigem.EventoId()}");
        }


        /// <summary>
        /// Mover Evento de NFSe da fila de entrada para a fila de saída
        /// </summary>
        protected async Task FinalizarMoverEntradaSaida()
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
                return;

            // log inicial
            LogAtalho("NfseGovBrNfseImportarEventoBusBase.FinalizarMoverEntradaSaida()", $"Início - EventoId = {_dadosOrigem.EventoId()}");

            var notaFiscalFilaSaida = new IssNotaFiscalGovBrImportarSaidaEntity()
            {
                Cd_Cecam = _dadosOrigem.NotaFiscalFilaImportarEntrada.Cd_Cecam,
                FilaTipo = _dadosOrigem.NotaFiscalFilaImportarEntrada.FilaTipo,
                Status = _dadosOrigem.NotaFiscalFilaImportarEntrada.Status,
                ChaveAcesso = _dadosOrigem.NotaFiscalFilaImportarEntrada.ChaveAcesso,
                Nsu = _dadosOrigem.NotaFiscalFilaImportarEntrada.Nsu,
                NfseId = _dadosOrigem.EventoId(),
                DpsId = null,
                DataHoraDocumento = _dadosOrigem.NotaFiscalFilaImportarEntrada.DataHoraDocumento,
                TipoDocumento = _dadosOrigem.NotaFiscalFilaImportarEntrada.TipoDocumento,
                TipoEvento = _dadosOrigem.NotaFiscalFilaImportarEntrada.TipoEvento,
                DataHoraCriacao = _dadosOrigem.NotaFiscalFilaImportarEntrada.DataHoraCriacao,
                DataHoraProcessamento = DateTime.UtcNow.AddHours(-3),
                Corpo = _dadosOrigem.NotaFiscalFilaImportarEntrada.Corpo,
                Mensagem = _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem,
                Cd_Contribuinte = _dadosOrigem.NotaFiscalFilaImportarEntrada.Cd_Contribuinte,
                Nr_CGCCPF = _dadosOrigem.NotaFiscalFilaImportarEntrada.Nr_CGCCPF
            };

            // salvar fila saída
            _filaSaidaRepository.Add(notaFiscalFilaSaida);
            await _filaSaidaRepository.SaveChangesAsync();

            // apagar da fila de entrada
            _filaEntradaRepository.DbSetEntity.Remove(_dadosOrigem.NotaFiscalFilaImportarEntrada);
            await _filaEntradaRepository.SaveChangesAsync();

            // log final
            LogAtalho("NfseGovBrNfseImportarEventoBusBase.FinalizarMoverEntradaSaida()", $"Fim - EventoId = {_dadosOrigem.EventoId()}");
        }


        /// <summary>
        /// Durante a importação do Evento da NFSe de XML para base prefeitura/cecam acontece um erro
        /// Então atualizar a fila de entrada com a mensagem de erro
        /// </summary>
        protected async Task FinalizarComErroNaImportacao(string mensagemErro, NfseGovBrEnum.enumFilaStatus novoStatus, string? motivo = null)
        {
            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
                return;

            // log inicial
            LogAtalho("NfseGovBrNfseImportarEventoBusBase.FinalizarComErroNaImportacao()", $"Início - EventoId = {_dadosOrigem.EventoId()} novoStatus = {novoStatus} mensagemErro = {mensagemErro}");

            // atualizar a nota fiscal na fila de entrada
            _dadosOrigem.NotaFiscalFilaImportarEntrada.DataHoraProcessamento = DateTime.UtcNow.AddHours(-3);
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Status = (int)novoStatus;
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Mensagem = mensagemErro;
            _dadosOrigem.NotaFiscalFilaImportarEntrada.Motivo = motivo;

            // atualizar na base
            await _filaEntradaRepository.SaveChangesAsync();

            // log inicial
            LogAtalho("NfseGovBrNfseImportarEventoBusBase.FinalizarComErroNaImportacao()", $"Fim - EventoId = {_dadosOrigem.EventoId()}");
        }


        #endregion


        /// <summary>
        /// Carregar a partir da fila de entrada o próximo Evento da nota fiscal para ser importada para base prefeitura/cecam na tabela IssNotaFiscal<br/>
        /// 2 = IssNotaFiscalGovBrEnum.enumFilaTipo.Cancelamento<br/>
        /// 3 = IssNotaFiscalGovBrEnum.enumFilaTipo.AceiteNotaFiscal
        /// </summary>
        protected async Task<bool> CarregarProximoEventoParaImportacao()
        {
            // log inicio
            LogAtalho("CarregarProximoEventoParaImportacao()", "Início - filaTipo = cancelamento=2 e [aceite de nota]=3");

            // tipos de fila esperados na consulta ao banco
            var filaTipo = new List<int>() { (int)enumFilaTipo.Cancelamento, (int)enumFilaTipo.AceiteNotaFiscal, (int)enumFilaTipo.Ignorado };

            if (NsuProcessar != null)
            {
                // temos NSU para processar ignorando a ordem da fila.
                _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                    .Where(x => filaTipo.Contains(x.FilaTipo) && x.Nsu == NsuProcessar)
                    .FirstOrDefaultAsync();

                // limpar apos carregar
                NsuProcessar = null;
            }
            else if (!string.IsNullOrWhiteSpace(ChaveAcessoProcessar))
            {
                // temos Chave de Acesso para processar ignorando a ordem da fila.
                _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                    .Where(x => filaTipo.Contains(x.FilaTipo) && x.ChaveAcesso == ChaveAcessoProcessar)
                    .OrderBy(x => x.Nsu)
                    .FirstOrDefaultAsync();

                // limpar apos carregar
                ChaveAcessoProcessar = null;
            }
            else
            {
                int incrementarHoras = -4;
                if (IgnorarDataHoraProcessamento) incrementarHoras = 10;

                // carregar uma nota fiscal que foi cancelada (filaTipo=2) na fila de entrada
                // carregar uma nota fiscal que foi aceita (filaTipo=3) na fila de entrada
                // evento de notas fiscais ainda não importadas status=0
                // evento de notas fiscais já tentou importar anteriormente e deu erro status=1
                _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                    .Where(x => filaTipo.Contains(x.FilaTipo) &&
                    (
                        x.Status == (int)NfseGovBrEnum.enumFilaStatus.BaixadoAguardandoProcessar ||
                        (
                            x.Status == (int)NfseGovBrEnum.enumFilaStatus.ProcessadoComErro &&
                            x.DataHoraProcessamento.HasValue &&
                            x.DataHoraProcessamento.Value <= DateTime.UtcNow.AddHours(incrementarHoras)
                        )
                    ))
                    .OrderBy(x => x.Nsu)
                    .FirstOrDefaultAsync();
            }

            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
            {
                // log fim
                LogAtalho("CarregarProximoEventoParaImportacao()", "Fim - NÃO existem Eventos de NFSe do tipo Cancelamento=2 e [aceite de nota]=3 na fila de entrada para importar da fila para prefeitura/cecam");
                return false;
            }

            // log fim
            LogAtalho("CarregarProximoEventoParaImportacao()", "Fim - filaTipo = Cancelamento=2 e [aceite de nota]=3");

            // valor retornado pelo método qnd temos nota fiscal na fila 
            return true;
        }


        /// <summary>
        /// Converter a XML em formato string para objeto que representa a XML de Evento da NFSe
        /// </summary>
        protected void ConverterXmlStringParaClasse()
        {
            // objeto serializador
            var serializer = new XmlSerializer(typeof(NfseEventoXml));

            using (StringReader reader = new StringReader("" + _dadosOrigem.NotaFiscalFilaImportarEntrada?.Corpo))
            {
                var nf = (NfseEventoXml?)serializer.Deserialize(reader);

                if (nf != null)
                {
                    // informar objeto XML de origem
                    _dadosOrigem.EventoImportado = nf;
                }
            }
        }


        #region Auxiliares


        /// <summary>
        /// Somente um atalho para gravar o log.
        /// </summary>
        protected void LogAtalho(string metodo, string texto, LogLevel logLevel = LogLevel.Information)
        {
            _loggerHelper.PrefixoNomeArquivo = string.Empty;

            if (!string.IsNullOrWhiteSpace(_dadosOrigem.EventoId()))
            {
                _loggerHelper.PrefixoNomeArquivo = "evento_importar_id_" + _dadosOrigem.EventoId() + "_";
            }

            _loggerHelper.GravarTexto(metodo + " " + texto, logLevel);
        }


        /// <summary>
        /// Limpar os objetos globais para importar um Evento de NFSe
        /// </summary>
        protected void LimparObjetosGlobais()
        {
            // objetos globais com a nota fiscal que será baixada
            _dadosOrigem = new NfseGovBrNfseImportarEventoBusDados();
        }


        #endregion
    }
}
