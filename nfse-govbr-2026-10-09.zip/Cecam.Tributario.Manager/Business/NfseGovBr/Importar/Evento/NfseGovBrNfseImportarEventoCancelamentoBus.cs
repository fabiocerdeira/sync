﻿using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Evento
{
    public class NfseGovBrNfseImportarEventoCancelamentoBus
    {
        #region Declarações


        /// <summary>
        /// logs
        /// </summary>
        private readonly ILoggerHelper _loggerHelper;


        /// <summary>
        /// Dados para importação
        /// </summary>
        private NfseGovBrNfseImportarEventoBusDados _dadosOrigem;


        public NfseGovBrNfseImportarEventoCancelamentoBus(NfseGovBrNfseImportarEventoBusDados dadosOrigem, ILoggerHelper loggerHelper)
        {
            // dados durante a conversão
            _dadosOrigem = dadosOrigem;

            // logs
            _loggerHelper = loggerHelper;
        }


        #endregion


        /// <summary>
        /// Cancelar a Nota Fiscal 
        /// </summary>
        public async Task CancelarNfse()
        {
            // log inicio
            _loggerHelper.GravarTexto("NfseGovBrNfseImportarEventoCancelamentoBus.CancelarNfse() - início");

            // recuperar chave de acesso
            var chaveAcesso = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.chNFSe;

            if (string.IsNullOrEmpty(chaveAcesso))
                throw new Exception("NfseGovBrNfseImportarEventoCancelamentoBus.CancelarNfse() ** erro ** chave de acesso não informada na xml");

            // texto com o motivo do cancelamento
            var motivoCancelamento = RecuperarMotivo();

            // recuperar numero da nota fiscal que substitui essa sendo cancelada
            var nrNotaFiscalSubstituta = await RecuperarNrNotaFiscalSubstituida();

            // business da nota fiscal
            var notaFiscalCancelarBus = new IssNotaFiscalCancelarBus();

            // cancelar a nota fiscal usando a chave de acesso da nfse
            await notaFiscalCancelarBus.CancelarNfse(motivoCancelamento, null, chaveAcesso, nrNotaFiscalSubstituta);

            // log fim
            _loggerHelper.GravarTexto("NfseGovBrNfseImportarEventoCancelamentoBus.CancelarNfse() - fim");
        }


        /// <summary>
        /// Verificar se é um cancelamento por substituição de nfse
        /// Se for, então retornar o nr da nota fiscal que foi criada para ser a nova substituindo essa cancelada
        /// Se retornar 0 (zero) então não é substituição
        /// </summary>
        private async Task<decimal> RecuperarNrNotaFiscalSubstituida()
        {
            var chaveSubstituta = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.ItemCancelamentoPorSubstituicao?.chSubstituta;

            if (string.IsNullOrWhiteSpace(chaveSubstituta))
                return 0;

            // query de nota fiscal
            var notaFiscalQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalQuery>();

            // recuperar a nota fiscal com essa chave
            var notaEntity = await notaFiscalQuery.PrimeiroOuNull(new Database.Filter.IssNotaFiscal.IssNotaFiscalFilter { Govbr_ChaveAcesso = chaveSubstituta });

            if (notaEntity != null)
                return notaEntity.Nr_NotaFiscal;

            return 0;
        }


        /// <summary>
        /// Percorrer os vários tipos de cancelamento para recuperar o texto com o motivo do cancelamento
        /// </summary>
        private string? RecuperarMotivo()
        {
            // atalho para o evento pai com os possíveis tipos de cancelamento
            var evento = _dadosOrigem.EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento;

            if (evento == null)
                return null;

            // verificar se temos cancelamento pelo prestador? (e101101)
            if (evento.ItemCancelamento != null)
            {
                // concatenar o motivo do cancelamento
                return (evento.ItemCancelamento.xMotivo + " " + evento.ItemCancelamento.xDesc + " " + evento.ItemCancelamento.CMotivoPorExtenso()).Trim();
            }

            // verificar se temos cancelamento por substituição (e105102)
            if (evento.ItemCancelamentoPorSubstituicao != null)
            {
                // concatenar o motivo do cancelamento
                return (evento.ItemCancelamentoPorSubstituicao.xMotivo + " " + evento.ItemCancelamentoPorSubstituicao.CMotivoPorExtenso() + " " + evento.ItemCancelamentoPorSubstituicao.chSubstituta + " " + evento.ItemCancelamentoPorSubstituicao.xDesc).Trim();
            }

            // verificar se temos cancelamento por analise fiscal (e105104)
            if (evento.ItemCancelamentoDeferidoAnaliseFiscal != null)
            {
                // concatenar o motivo do cancelamento
                return (evento.ItemCancelamentoDeferidoAnaliseFiscal.xMotivo + " " + evento.ItemCancelamentoDeferidoAnaliseFiscal.CMotivoPorExtenso() + " " + evento.ItemCancelamentoDeferidoAnaliseFiscal.NProcAdm + " " + evento.ItemCancelamentoDeferidoAnaliseFiscal.xDesc).Trim();
            }

            // verificar se temos cancelamento por oficio (e305110)
            if (evento.ItemCancelamentoPorOficio != null)
            {
                // concatenar o motivo do cancelamento
                return (evento.ItemCancelamentoPorOficio.xDesc + " " + evento.ItemCancelamentoPorOficio.NProcAdm + " " + evento.ItemCancelamentoPorOficio.XProcAdm).Trim();
            }

            // valor default retornado
            return null;
        }
    }
}
