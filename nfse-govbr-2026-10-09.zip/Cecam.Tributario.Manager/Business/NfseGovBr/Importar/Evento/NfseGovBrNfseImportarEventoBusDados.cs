﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Manager.View.NfseGovBr.Evento;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Evento
{
    /// <summary>
    /// Informações do Evento da NFSe baixada do gov.br para gravar na base da prefeitura/cecam
    /// </summary>
    public class NfseGovBrNfseImportarEventoBusDados
    {
        #region Declarações


        /// <summary>
        /// Fila com notas fiscais para serem importadas
        /// </summary>
        public IssNotaFiscalGovBrImportarEntradaEntity? NotaFiscalFilaImportarEntrada;


        /// <summary>
        /// Lista com notas fiscais importadas com sucesso
        /// </summary>
        public IssNotaFiscalGovBrImportarSaidaEntity? NotaFiscalFilaImportarSaida;


        /// <summary>
        /// Xml no formato texto/string com o objeto de NFSe ou Evento baixado de gov.br
        /// </summary>
        public string XmlImportadaAsString = string.Empty;

        /// <summary>
        /// Classe raiz da XMl em formato objeto com o Evento da NFSe baixada de gov.br
        /// </summary>
        public NfseEventoXml? EventoImportado;


        #endregion

        /// <summary>
        /// NSU do documento gov.br
        /// </summary>
        public long Nsu()
        {
            return NotaFiscalFilaImportarEntrada?.Nsu ?? 0;
        }


        /// <summary>
        /// Retornar ID da Evento
        /// </summary>
        public string EventoId()
        {
            return EventoImportado?.InfNFSeEvento?.Id ?? string.Empty;
        }


        /// <summary>
        /// Retornar chave de acesso da NFSe que esse evento esta associado
        /// </summary>
        public string NfseChaveAcesso()
        {
            return EventoImportado?.InfNFSeEvento?.PedRegEvento?.InfPedRegEvento?.chNFSe ?? string.Empty;
        }
    }
}
