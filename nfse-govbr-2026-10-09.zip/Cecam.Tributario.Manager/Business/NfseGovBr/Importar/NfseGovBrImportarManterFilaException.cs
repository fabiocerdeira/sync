﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Importar
{
    public class NfseGovBrImportarManterFilaException : Exception
    {
        /*
        public NfseGovBrImportarManterFilaException(string motivo, string? erro, Exception? ex) : base(motivo,)
        {
            if (!string.IsNullOrWhiteSpace(erro))
                this.InnerException = new Exception(erro);
        }
        */
    }
}
