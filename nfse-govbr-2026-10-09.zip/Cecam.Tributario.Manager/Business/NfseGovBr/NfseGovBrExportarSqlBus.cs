﻿using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr
{
    public class NfseGovBrExportarSqlBus
    {
        // Repositorios
        protected readonly IIssNotaFiscalGovBrImportarEntradaQuery _importarEntradaQuery;
        protected readonly IIssNotaFiscalGovBrImportarSaidaQuery _importarSaidaQuery;


        public NfseGovBrExportarSqlBus()
        {
            // repo gravar as nfse baixadas
            _importarEntradaQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarEntradaQuery>();

            // repo consultar as nfse já processadas
            _importarSaidaQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarSaidaQuery>();
        }


        public async Task Exportar(string parametro)
        {
            await ExportarEntrada(parametro);
            await ExportarSaida(parametro);
        }


        public async Task ExportarEntrada(string parametro)
        {
            if (string.IsNullOrWhiteSpace(parametro))
                return;

            var filtro = new Database.Filter.IssNotaFiscalGovBr.IssNotaFiscalGovBrImportarEntradaFilter();

            if (parametro.Length <= 15)
                filtro.Nsu = long.Parse(parametro);
            else
                filtro.ChaveAcesso = parametro;

            var lista = await _importarEntradaQuery.Listar(filtro);

            if (lista == null || lista.Count == 0)
                return;

            var SQL = @"INSERT INTO ISSNotaFiscal_GovBr_ImportarEntrada (Cd_Cecam, FilaTipo, Status, ChaveAcesso, Nsu, 
                            DataHoraDocumento, TipoDocumento, TipoEvento, DataHoraProcessamento, cd_Contribuinte, nr_CGCCPF, 
                            DataHoraCriacao, Corpo, Mensagem, Motivo) VALUES ";

            foreach (var item in lista)
            {
                SQL = SQL + @$"({item.Cd_Cecam},
                    {item.FilaTipo},
                    {item.Status},
                    '{item.ChaveAcesso}',
                    {item.Nsu},
                    '{item.DataHoraDocumento.GetValueOrDefault().ToString("yyyy-MM-dd HH:mm:ss")}',
                    '{item.TipoDocumento}',";

                if (string.IsNullOrWhiteSpace(item.TipoEvento))
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + "'{item.TipoEvento}',";

                if (item.DataHoraProcessamento == null)
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + $"'{item.DataHoraProcessamento.GetValueOrDefault().ToString("yyyy-MM-dd HH:mm:ss")}',";

                if (item.Cd_Contribuinte == null)
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + $"{item.Cd_Contribuinte.Value},";

                if (string.IsNullOrWhiteSpace(item.Nr_CGCCPF))
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + $"'{item.Nr_CGCCPF}',";

                SQL = SQL + @$"'{item.DataHoraCriacao.ToString("yyyy-MM-dd HH:mm:ss")}',
                    '{("" + item.Corpo).Replace("\'", "''")}',
                    '{("" + item.Mensagem).Replace("\'", "''")}',
                    '{("" + item.Motivo).Replace("\'", "''")}'),";
            }

            // gravar sql no disco.
            await GravarSqlDisco(SQL, parametro + "_entrada");
        }



        public async Task ExportarSaida(string parametro)
        {
            if (string.IsNullOrWhiteSpace(parametro))
                return;

            var filtro = new Database.Filter.IssNotaFiscalGovBr.IssNotaFiscalGovBrImportarSaidaFilter();

            if (parametro.Length <= 15)
                filtro.Nsu = long.Parse(parametro);
            else
                filtro.ChaveAcesso = parametro;

            var lista = await _importarSaidaQuery.Listar(filtro);

            if (lista == null || lista.Count == 0)
                return;

            var SQL = @"INSERT INTO ISSNotaFiscal_GovBr_ImportarSaida (Cd_Cecam, FilaTipo, Status, ChaveAcesso, Nsu, 
                            DataHoraDocumento, TipoDocumento, TipoEvento, DataHoraProcessamento, cd_Contribuinte, nr_CGCCPF, 
                            DataHoraCriacao, Corpo, Mensagem) VALUES ";

            foreach (var item in lista)
            {
                SQL = SQL + @$"({item.Cd_Cecam},
                    {item.FilaTipo},
                    {item.Status},
                    '{item.ChaveAcesso}',
                    {item.Nsu},
                    '{item.DataHoraDocumento.GetValueOrDefault().ToString("yyyy-MM-dd HH:mm:ss")}',
                    '{item.TipoDocumento}',";

                if (string.IsNullOrWhiteSpace(item.TipoEvento))
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + "'{item.TipoEvento}',";

                if (item.DataHoraProcessamento == null)
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + $"'{item.DataHoraProcessamento.GetValueOrDefault().ToString("yyyy-MM-dd HH:mm:ss")}',";

                if (item.Cd_Contribuinte == null)
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + $"{item.Cd_Contribuinte.Value},";

                if (string.IsNullOrWhiteSpace(item.Nr_CGCCPF))
                    SQL = SQL + "NULL,";
                else
                    SQL = SQL + $"'{item.Nr_CGCCPF}',";

                SQL = SQL + @$"'{item.DataHoraCriacao.ToString("yyyy-MM-dd HH:mm:ss")}',
                    '{("" + item.Corpo).Replace("\'", "''")}',
                    '{("" + item.Mensagem).Replace("\'", "''")}'),";
            }

            // gravar sql no disco.
            await GravarSqlDisco(SQL, parametro + "_saida");
        }


        protected async Task GravarSqlDisco(string conteudo, string parametro)
        {
            try
            {
                // pasta destino
                var logPath = AppDomain.CurrentDomain.BaseDirectory + "SQL_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + DateTime.UtcNow.AddHours(-3).Year + "\\" + DateTime.UtcNow.AddHours(-3).ToString("MM") + "\\" + DateTime.UtcNow.AddHours(-3).ToString("dd");

                // criar todas as pastas se não existirem
                Directory.CreateDirectory(logPath);

                // append
                await File.WriteAllTextAsync(logPath + $"\\sql_{parametro}_" + DateTime.UtcNow.AddHours(-3).ToString("yyyyMMdd_HHmmss") + ".sql", conteudo, Encoding.UTF8);
            }
            catch (Exception)
            {
            }
        }


    }
}
