﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Relatorio
{
    public class NfseGovBrRelatorioBus
    {
        #region Declarações


        /// <summary>
        /// Conteudo do arquivo de relatório
        /// </summary>
        private StringBuilder _stringBuilder = new StringBuilder();


        /// <summary>
        /// repositorio para ler as NFSe baixadas e que serão importadas para base prefeitura/cecam
        /// </summary>
        private readonly IIssNotaFiscalGovBrImportarEntradaRepository _filaEntradaRepository;


        /// <summary>
        /// query para iss notas fiscais
        /// </summary>
        private readonly IIssNotaFiscalQuery _issNotaFiscalQuery;


        public NfseGovBrRelatorioBus()
        {
            // repositorio para ler as nfse baixadas de gov.br para serem importadas
            _filaEntradaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarEntradaRepository>();

            // query para iss notas fiscais
            _issNotaFiscalQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalQuery>();
        }


        #endregion


        /// <summary>
        /// Criar relatorio de monitor da fila de entrada
        /// </summary>
        public async Task CriarRelatorioFilaEntrada()
        {
            await Cabeca();
            await TopAsc();
            await TopDesc();
            await NotasEmitidasIssWeb();

            // gravar arquivo em disco
            await GravarArquivoDisco("NfseGovBr.aspx");
        }


        private async Task Cabeca()
        {
            // qtd de linhas na tabela
            var qtd = await _filaEntradaRepository.GetIQueryable().CountAsync();

            _stringBuilder.AppendLine("<%@ Page Language=\"C#\" MasterPageFile=\"\" Title=\"Monitor\" EnableTheming=\"false\" Theme=\"\" StylesheetTheme=\"\" %>");
            
            _stringBuilder.AppendLine($"<p>Versão {ParametrosGlobal.Versao} - Relatorio criado em {DateTime.UtcNow.AddHours(-3).ToString("dd/MM/yyyy HH:mm")} </p>");

            _stringBuilder.AppendLine($"<p>Qtd notas fila entrada : {qtd}</p>");
        }


        private async Task TopAsc()
        {
            var lista = await _filaEntradaRepository.GetIQueryable()
                 .OrderBy(x => x.Id)
                 .Take(100)
                 .Select(x => new IssNotaFiscalGovBrImportarEntradaEntity
                 {
                     ChaveAcesso = x.ChaveAcesso,
                     Nsu = x.Nsu,
                     DataHoraDocumento = x.DataHoraDocumento,
                     TipoDocumento = x.TipoDocumento,
                     FilaTipo = x.FilaTipo,
                     Status = x.Status,
                     TipoEvento = x.TipoEvento,
                     DataHoraCriacao = x.DataHoraCriacao,
                     DataHoraProcessamento = x.DataHoraProcessamento,
                     Cd_Contribuinte = x.Cd_Contribuinte,
                     Motivo = x.Motivo,
                     Mensagem = x.Mensagem
                 })
                 .ToListAsync();

            MontarTabela(lista, "Primeiras notas da fila");
        }


        private async Task TopDesc()
        {
            var lista = await _filaEntradaRepository.GetIQueryable()
                 .OrderByDescending(x => x.Id)
                 .Take(100)
                 .Select(x => new IssNotaFiscalGovBrImportarEntradaEntity
                 {
                     ChaveAcesso = x.ChaveAcesso,
                     Nsu = x.Nsu,
                     DataHoraDocumento = x.DataHoraDocumento,
                     TipoDocumento = x.TipoDocumento,
                     FilaTipo = x.FilaTipo,
                     Status = x.Status,
                     TipoEvento = x.TipoEvento,
                     DataHoraCriacao = x.DataHoraCriacao,
                     DataHoraProcessamento = x.DataHoraProcessamento,
                     Cd_Contribuinte = x.Cd_Contribuinte,
                     Motivo = x.Motivo,
                     Mensagem = x.Mensagem
                 })
                 .ToListAsync();

            MontarTabela(lista.OrderBy(x => x.Nsu).ToList(), "Ultimas notas da fila");
        }



        private void MontarTabela(List<IssNotaFiscalGovBrImportarEntradaEntity> lista, string titulo)
        {
            if (lista == null || lista.Count == 0)
            {
                _stringBuilder.AppendLine("<h3>NENHUMA nfse encontrada n fila de entrada</h3>");
                return;
            }

            _stringBuilder.AppendLine("<h2>" + titulo + "</h2>");

            // tabela
            _stringBuilder.AppendLine("<table border=\"1px\">");
            _stringBuilder.AppendLine("<tr><td>Chave</td><td>Nsu</td><td>Data Hora Documento</td><td>Tipo Documento</td><td>FilaTipo</td><td>Status</td><td>Tipo Evento</td>" +
                "<td>Data Hora Criacao</td><td>Data Hora Processamento</td><td>Contribuinte</td><td>Motivo</td><td>Mensagem</td></tr>");

            foreach (var item in lista)
            {
                _stringBuilder.AppendLine("<tr>" +
                    "<td>" + item.ChaveAcesso + "</td>" +
                    "<td>" + item.Nsu + "</td>" +
                    "<td>" + item.DataHoraDocumento + "</td>" +
                    "<td>" + item.TipoDocumento + "</td>" +
                    "<td>" + item.FilaTipo + "</td>" +
                    "<td>" + item.Status + "</td>" +
                    "<td>" + item.TipoEvento + "</td>" +
                    "<td>" + item.DataHoraCriacao + "</td>" +
                    "<td>" + item.DataHoraProcessamento + "</td>" +
                    "<td>" + item.Cd_Contribuinte + "</td>" +
                    "<td>" + item.Motivo + "</td>" +
                    "<td>" + item.Mensagem + "</td>" +
                    "</tr>");
            }

            _stringBuilder.AppendLine("</table><br/><br/><br/>");
        }


        private async Task NotasEmitidasIssWeb()
        {
            var dicReferenciaQtd = await _issNotaFiscalQuery.ListarNfseEmitidasErradamentePeloIssWeb();

            if (dicReferenciaQtd == null || dicReferenciaQtd.Count == 0)
            {
                _stringBuilder.AppendLine("<h2>NENHUMA NFSe emitidas erradamente pelo IssWeb</h2>");
                _stringBuilder.AppendLine("<br/><br/><br/>");
                return;
            }

            _stringBuilder.AppendLine("<h2>NFSe emitidas erradamente pelo IssWeb</h2>");

            foreach (var item in dicReferenciaQtd)
            {
                _stringBuilder.AppendLine("<p>" + item.Key + " = " + item.Value + "</p>");
            }

            _stringBuilder.AppendLine("<br/><br/><br/>");
        }



        /// <summary>
        /// Gravar arquivo em disco
        /// </summary>
        private async Task GravarArquivoDisco(string nomeArquivo)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(ParametrosGlobal.MonitorPasta))
                    ParametrosGlobal.MonitorPasta = AppDomain.CurrentDomain.BaseDirectory + "Monitor_" + ParametrosGlobal.Cd_Cecam.ToString();

                // criar a pasta caso não exista.
                Directory.CreateDirectory(ParametrosGlobal.MonitorPasta);

                // gravar
                await File.WriteAllTextAsync(ParametrosGlobal.MonitorPasta + "\\" + nomeArquivo, _stringBuilder.ToString(), Encoding.UTF8);
            }
            catch (Exception)
            {
            }
        }

    }
}
