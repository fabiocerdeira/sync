﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Download
{
    /// <summary>
    /// Realiza o download de várias notas fiscais do gov.br para a base da prefeitura/cecam
    /// Para futuramente ser importada da XML baixada para as tabelas de IssNotaFiscal
    /// </summary>
    public class NfseGovBrNfseDownloadNotaBus : NfseGovBrNfseDownloadBusBase
    {
        #region Declarações

        /// <summary>
        /// Parametros da NFSe em relação ao Gov.br
        /// </summary>
        private readonly IIssParametrosNfseQuery _issParametrosNfseQuery;


        public NfseGovBrNfseDownloadNotaBus() : base()
        {
            // log
            _loggerHelper.Inicializar<NfseGovBrNfseDownloadNotaBus>();

            // parametros da NFSe em relação ao gov.br
            _issParametrosNfseQuery = ServiceProviderGlobal.GetServico<IIssParametrosNfseQuery>();
        }

        #endregion


        /// <summary>
        /// Realizar download de várias NFSe do gov.br para a base prefeitura/cecam
        /// </summary>
        public async Task<bool> DownloadLote()
        {
            // log inicial
            _loggerHelper.GravarTexto("NfseGovBrNfseDownloadNotaBus.DownloadLote() - Início");

            // carregar o último nsu processado que será usado como inicial da proxima consulta ao gov.br
            var nsuInicial = await CarregarNsuInicial();

            // nada para fazer então sair sem erro.
            if (nsuInicial == null)
                return false;

            // valor retornado pelo método
            var retornoTeveNotasBaixadas = false;

            // log
            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.DownloadLote() - nsu inicial =  {nsuInicial}");

            // objeto que faz a consulta para API da receita federal no módulo ADN.
            // acessa um servico 'externo' ao sistema
            var adnExternal = new NfseGovBrAdnExternal();

            // retorno da consulta ao gov.br com a NFSe de vários contribuintes
            var respostaExternal = await adnExternal.MunicipiosDfeConsultar(nsuInicial.Value, NfseGovBrAdnExternal.eTipoNsu.Distribuicao, true);

            // verificar se teve sucesso na consulta gov.br?
            if (respostaExternal.Sucesso)
            {
                if (respostaExternal.Item != null && respostaExternal.Item.Erros != null && respostaExternal.Item.Erros.Count > 0)
                {
                    foreach (var erroItem in respostaExternal.Item.Erros)
                    {
                        // logar erros
                        _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.DownloadLote() ** ERRO retornado pelo gov.br ** nsu inicial = {nsuInicial} - {erroItem}");
                    }
                }

                // verificar se temos itens de NFSe para gravar na base prefeitura/cecam ?
                if (respostaExternal.Item != null && respostaExternal.Item.LoteDFe != null && respostaExternal.Item.LoteDFe.Count > 0)
                {
                    // Gravar o lote de NFSe baixado do gov.br para a fila de entrada
                    await ConverterLoteDFeParaEntrada(respostaExternal.Item.LoteDFe);

                    // retornar que teve notas baixadas
                    retornoTeveNotasBaixadas = true;
                }
                else
                {
                    // não teve notas baixadas, então gravar o próximo horario de download
                    int minutos = 70;

                    #if DEBUG
                        minutos = 5;
                    #endif

                    await _issParametrosNfseQuery.AtualizarNsuBaixadoHorario(DateTime.UtcNow.AddHours(-3).AddMinutes(minutos));
                }
            }
            else
            {
                // sem sucesso na consulta gov.br
                _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.DownloadLote() - fim - nsu inicial = {nsuInicial}");
                _loggerHelper.GravarObjeto(respostaExternal);

                // deu erro na chamada web/api, então gravar o próximo horario de download
                await _issParametrosNfseQuery.AtualizarNsuBaixadoHorario(DateTime.UtcNow.AddHours(-3).AddMinutes(10));
            }

            // log final
            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.DownloadLote() - final - nsu inicial =  {nsuInicial}");

            // retornar se teve ou não teve notas baixadas
            return retornoTeveNotasBaixadas;
        }


        /// <summary>
        /// Carregar e retornar o NsuInicial para download das próximas NFSe
        /// Leva em consideração o último nsu baixado do gov.br e a data e hora da última vez que realizou o baixar
        /// Se retornar NULL então ainda não esta em condição de baixar, provavelmente por data e hora precisa esperar 1 horas para cada chamada
        /// </summary>
        private async Task<long?> CarregarNsuInicial()
        {
            // carregar o iss parametros da nota fiscal gov.br
            var issParametrosNfse = await _issParametrosNfseQuery.Carregar();

            // validar
            if (issParametrosNfse == null)
                throw new Exception("NfseGovBrNfseDownloadNotaBus.CarregarNsuInicial() - **erro** issParametrosNfse não foi carregado");

            /*
            // para diferenciar entre produção e desenvolvimento
            // tempo de espera da proxima execução
            int intervaloEsperaEntreProcessamentoMinutos = 70;

            #if DEBUG
            // em desenvolvimento quero que execute toda vez que eu testar
            intervaloEsperaEntreProcessamentoMinutos = 1;
            #endif

            // verificar se do último horário baixado já se passaram mais de 1 hora e 10 minutos
            // a regra é 1 hora exatamente, mas precisei colocar os 10 minutos como margem de segurança pq gov.br tem uma política de bloqueio de chamadas por spoffing
            if (issParametrosNfse.Govbr_nsuBaixadoHorario.HasValue && DateTime.UtcNow.AddHours(-3) < issParametrosNfse.Govbr_nsuBaixadoHorario.Value.AddMinutes(intervaloEsperaEntreProcessamentoMinutos))
            {
                // ainda não passou 1 hora da última execução,
                // então retornar que não tem NsuInicial
                return null;
            }
            */

            // não lembro pq estou atualizando isso aqui nessa parte do código??????
            // atualizar o último NSU baixado e data/hora do último processamento
            // await _issParametrosNfseQuery.AtualizarNsuBaixadoUltimo(issParametrosNfse.Govbr_nsuBaixadoUltimo.GetValueOrDefault());



            // verificar se agora ainda não passou do último horário baixado já com o respectivo incremento de tempo?
            // originalmente o campo era para ser último horario baixado, agora ele se tornou o 'proximo horario que permite baixar novamente'
            if (issParametrosNfse.Govbr_nsuBaixadoHorario.HasValue && DateTime.UtcNow.AddHours(-3) < issParametrosNfse.Govbr_nsuBaixadoHorario.Value)
            {
                // ainda não esta na hora de baixar novamente
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"NfseGovBrNfseDownloadNotaBus.CarregarNsuInicial() -- Ainda não chegou o próximo horário de consultar gov.br as {issParametrosNfse.Govbr_nsuBaixadoHorario.Value.ToString("dd/MM/yyy hh:mm")}");
                Console.ResetColor();

                // então retornar que não tem NsuInicial
                return null;
            }

            // retornar o valor do último NSU baixado que esta gravado na base
            return issParametrosNfse.Govbr_nsuBaixadoUltimo.GetValueOrDefault();
        }


        /// <summary>
        /// validar se os campos obrigatórios estão preenchidos antes de gravar na base
        /// e verificar se o NSU ainda não foi gravado na base para não entrar repetido no sistema.
        /// </summary>
        private async Task ValidarAntesGravar(NfseGovBrDfeDocumentoResponse itemDfe)
        {
            // chave de acesso não pode ser vazia
            if (string.IsNullOrWhiteSpace(itemDfe.ChaveAcesso))
                throw new Exception($"NfseGovBrNfseDownloadNotaBus.ValidarAntesGravar() - Chave de acesso recebida de gov.br esta erradamente vazia");

            // nsu não pode ser vazio
            if (itemDfe.Nsu.GetValueOrDefault() <= 0)
                throw new Exception($"NfseGovBrNfseDownloadNotaBus.ValidarAntesGravar() - NSU recebido de gov.br esta erradamente vazio");

            // verificar se esse NSU já existe na base na fila de entrada de nfse ?
            if (await _importarEntradaRepository.GetIQueryable().AnyAsync(x => x.Nsu == itemDfe.Nsu.GetValueOrDefault()))
                throw new Exception($"NfseGovBrNfseDownloadNotaBus.ValidarAntesGravar() - nsu {itemDfe.Nsu} já existe na fila de entrada");

            // verificar se esse NSU já existe na base na fila de saída com xmls já baixas e processadas ?
            if (await _importarSaidaRepository.GetIQueryable().AnyAsync(x => x.Nsu == itemDfe.Nsu.GetValueOrDefault()))
                throw new Exception($"NfseGovBrNfseDownloadNotaBus.ValidarAntesGravar() - nsu {itemDfe.Nsu} já existe na fila de saída/processada");

            /*
            // verificar se essa chave já existe na base na fila de entrada de nfse ?
            if (await _importarEntradaRepository.GetIQueryable().AnyAsync(x => x.FilaTipo == (int)IssNotaFiscalGovBrImportarEntradaEntity.enumFilaTipo.NFSe && x.ChaveAcesso == itemDfe.ChaveAcesso))
                throw new Exception($"NfseGovBrNfseDownloadNotaBus.ValidarAntesGravar() - chave de acesso {itemDfe.ChaveAcesso} já existe na fila de entrada");

            // verificar se essa chave já existe na base na fila de saída com xmls já baixas e processadas ?
            if (await _importarSaidaRepository.GetIQueryable().AnyAsync(x => x.FilaTipo == (int)IssNotaFiscalGovBrImportarEntradaEntity.enumFilaTipo.NFSe && x.ChaveAcesso == itemDfe.ChaveAcesso))
                throw new Exception($"NfseGovBrNfseDownloadNotaBus.ValidarAntesGravar() - chave de acesso {itemDfe.ChaveAcesso} já existe na fila de saída/processada");
            */
        }


        /// <summary>
        /// Atualizar com o último NSU baixado na tabela de parametrosNFSE
        /// </summary>
        private async Task AtualizarNsuBaixadoUltimo(long nsu, string chaveAcesso)
        {
            // log 
            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.AtualizarNsuBaixadoUltimo() - itemDfe nsu = {nsu} chave acesso = {chaveAcesso} -- atualizar nsu baixado ultimo + horario");

            // atualizar o último NSU baixado e data/hora do último processamento
            await _issParametrosNfseQuery.AtualizarNsuBaixadoUltimo(nsu);
        }


        /// <summary>
        /// Gravar o lote de NFSe baixado do gov.br para a fila de entrada
        /// </summary>
        private async Task ConverterLoteDFeParaEntrada(List<NfseGovBrDfeDocumentoResponse> listaDFe)
        {
            // log inicio
            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.ConverterLoteDFeParaEntrada() - inicio - listaDFe.count {listaDFe.Count}");

            if (listaDFe.Count == 0)
                return;

            // gzip e base64 para descompactar XML da Nfse
            var gzip = new GZipHelper();

            // percorrer todas as NFSe para serem gravadas na fila de entrada
            // precisa ser na ordem ed NSU obrigatoriamente
            foreach (var itemDfe in listaDFe.OrderBy(x => x.Nsu))
            {
                try
                {
                    // tratamento null
                    if (itemDfe == null)
                        continue;

                    // log de cada item
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.ConverterLoteDFeParaEntrada() - itemDfe nsu = {itemDfe.Nsu} chave acesso = {itemDfe.ChaveAcesso}");

                    // validar campos e se já foi baixado antes de seguir para gravação na base.
                    await ValidarAntesGravar(itemDfe);

                    // data da geração
                    DateTime dtHoraGeracao = DateTime.UtcNow.AddHours(-3);
                    DateTime.TryParse("" + itemDfe.DataHoraGeracao, out dtHoraGeracao);

                    // criar nova entrada na fila
                    var entradaEntity = new IssNotaFiscalGovBrImportarEntradaEntity()
                    {
                        Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                        FilaTipo = (int)DescobrirFilaTipo(itemDfe.TipoDocumento, itemDfe.TipoEvento),
                        Status = (int)NfseGovBrEnum.enumFilaStatus.BaixadoAguardandoProcessar, // baixado mas nunca processado
                        ChaveAcesso = itemDfe.ChaveAcesso,
                        Nsu = itemDfe.Nsu != null ? itemDfe.Nsu.Value : 0,
                        DataHoraDocumento = dtHoraGeracao,
                        TipoDocumento = itemDfe.TipoDocumento,
                        TipoEvento = itemDfe.TipoEvento,
                        DataHoraCriacao = DateTime.UtcNow.AddHours(-3),
                        Corpo = gzip.DescompactarBase64ToString("" + itemDfe.ArquivoXml)
                    };

                    // gravar xml no disco para acompanhamento
                    await GravarArquivoXmlDisco(itemDfe.Nsu.GetValueOrDefault(), itemDfe.ChaveAcesso + "", itemDfe.TipoDocumento + "", itemDfe.TipoEvento + "", entradaEntity.Corpo);

                    // log 
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.ConverterLoteDFeParaEntrada() - itemDfe nsu = {itemDfe.Nsu} chave acesso = {itemDfe.ChaveAcesso} -- salvar fila entrada");

                    // salvar nfse ou evento na fila de entrada
                    _importarEntradaRepository.Add(entradaEntity);
                    await _importarEntradaRepository.SaveChangesAsync();

                    // convertido com sucesso,
                    // atualizar o último NSU baixado e data/hora do último processamento
                    await AtualizarNsuBaixadoUltimo(itemDfe.Nsu.GetValueOrDefault(), "" + itemDfe.ChaveAcesso);
                }
                catch (Exception ex)
                {
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadNotaBus.ConverterLoteDFeParaEntrada() - fim com erro");
                    _loggerHelper.GravarObjeto(ex);
                    _loggerHelper.GravarObjeto(itemDfe);
                }
            }

            // log fim
            _loggerHelper.GravarTexto("NfseGovBrNfseDownloadNotaBus.ConverterLoteDFeParaEntrada() - Fim com sucesso");
        }

    }
}
