﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Download
{
    /// <summary>
    /// Realiza o download de vários eventos da nota fiscai informada lendo do gov.br para a base da prefeitura/cecam
    /// Para futuramente ser importada da XML baixada para as tabelas de IssNotaFiscal
    /// </summary>
    public class NfseGovBrNfseDownloadEventoBus : NfseGovBrNfseDownloadBusBase
    {
        #region Declarações

        public NfseGovBrNfseDownloadEventoBus() : base()
        {
            // log
            _loggerHelper.Inicializar<NfseGovBrNfseDownloadNotaBus>();
        }

        #endregion


        /// <summary>
        /// Realizar download de várias eventos de várias NFSe do gov.br para a base prefeitura/cecam
        /// </summary>
        public async Task DownloadEventos(List<string> listaChaveAcesso)
        {
            // log inicial
            _loggerHelper.GravarTexto("NfseGovBrNfseDownloadEventoBus.DownloadEventos() - Início");

            if (listaChaveAcesso == null || listaChaveAcesso.Count == 0)
            {
                // log sem chaves para buscar eventos.
                _loggerHelper.GravarTexto("NfseGovBrNfseDownloadEventoBus.DownloadEventos() - Nenhuma chave de acesso foi informada para fazer download de eventos");

                // sair
                return;
            }

            // log com a qtd de chaves informadas para buscar eventos.
            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.DownloadEventos() - Foram informadas {listaChaveAcesso.Count()} chave de acesso para buscar eventos");

            // objeto que faz a consulta para API da receita federal no módulo ADN.
            // acessa um servico 'externo' ao sistema
            var adnExternal = new NfseGovBrAdnExternal();

            // percorrer todas as chaves encontradas
            foreach (var itemChave in listaChaveAcesso)
            {
                // se não tiver a chave de acesso então passar para o próximo item da coleção
                if (string.IsNullOrWhiteSpace(itemChave))
                    continue;

                // retorno da consulta ao gov.br com a NFSe de vários contribuintes
                var respostaExternal = await adnExternal.MunicipiosNfseEventosConsultar(itemChave);

                // verificar se teve sucesso na consulta gov.br?
                if (respostaExternal.Sucesso)
                {
                    if (respostaExternal.Item != null && respostaExternal.Item.Erros != null && respostaExternal.Item.Erros.Count > 0)
                    {
                        foreach (var erroItem in respostaExternal.Item.Erros)
                        {
                            // logar erros
                            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.DownloadEventos() ** ERRO retornado pelo gov.br ** chave de acesso = {itemChave} - {erroItem}");
                        }
                    }

                    // verificar se temos itens de NFSe para gravar na base prefeitura/cecam ?
                    if (respostaExternal.Item != null && respostaExternal.Item.LoteDFe != null && respostaExternal.Item.LoteDFe.Count > 0)
                    {
                        // Gravar o lote de eventos da NFSe baixado do gov.br para a fila de entrada
                        await ConverterLoteDFeParaEntrada(respostaExternal.Item.LoteDFe);
                    }
                }
                else
                {
                    // sem sucesso na consulta gov.br
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.DownloadEventos() - falha ao consultar evento em gov.br para a chave de acesso {itemChave}");
                    _loggerHelper.GravarObjeto(respostaExternal);
                }
            }

            // log final
            _loggerHelper.GravarTexto("NfseGovBrNfseDownloadEventoBus.DownloadEventos() - Fim");
        }


        /// <summary>
        /// validar se os campos obrigatórios estão preenchidos antes de gravar na base
        /// e verificar se o NSU ainda não foi gravado na base para não entrar repetido no sistema.
        /// </summary>
        private async Task ValidarAntesGravar(IssNotaFiscalGovBrImportarEntradaEntity entradaEntity)
        {
            // chave de acesso não pode ser vazia
            if (string.IsNullOrWhiteSpace(entradaEntity.ChaveAcesso))
                throw new Exception($"NfseGovBrNfseDownloadEventoBus.ValidarAntesGravar() - Chave de acesso recebida de gov.br esta erradamente vazia");

            // tipo de documento não pode ser vazio
            if (string.IsNullOrWhiteSpace(entradaEntity.TipoDocumento))
                throw new Exception($"NfseGovBrNfseDownloadEventoBus.ValidarAntesGravar() - Tipo de documento recebido de gov.br esta erradamente vazio");

            // verificar se essa chave de acesso + tipo documento + tipo evento já existe na base na fila de entrada de nfse ?
            if (await _importarEntradaRepository.GetIQueryable().AnyAsync(x => x.ChaveAcesso == entradaEntity.ChaveAcesso && x.TipoDocumento == entradaEntity.TipoDocumento && x.TipoEvento == entradaEntity.TipoEvento))
                throw new Exception($"NfseGovBrNfseDownloadEventoBus.ValidarAntesGravar() - chave de acesso {entradaEntity.ChaveAcesso} + {entradaEntity.TipoDocumento} + {entradaEntity.TipoEvento} já existe na fila de entrada");

            // verificar se essa chave de acesso + tipo documento + tipo evento já existe na base na fila de saída/processada de nfse ?
            if (await _importarSaidaRepository.GetIQueryable().AnyAsync(x => x.ChaveAcesso == entradaEntity.ChaveAcesso && x.TipoDocumento == entradaEntity.TipoDocumento && x.TipoEvento == entradaEntity.TipoEvento))
                throw new Exception($"NfseGovBrNfseDownloadEventoBus.ValidarAntesGravar() - chave de acesso {entradaEntity.ChaveAcesso} + {entradaEntity.TipoDocumento} + {entradaEntity.TipoEvento} já existe na fila de saída/processada");
        }


        /// <summary>
        /// Gravar o lote de NFSe baixado do gov.br para a fila de entrada
        /// </summary>
        private async Task ConverterLoteDFeParaEntrada(List<NfseGovBrDfeDocumentoResponse> listaDFe)
        {
            // log inicio
            _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.ConverterLoteDFeParaEntrada() - inicio - listaDFe.count {listaDFe.Count}");

            if (listaDFe.Count == 0)
                return;

            // percorrer todas as NFSe para serem gravadas na fila de entrada
            // precisa ser na ordem ed NSU obrigatoriamente
            foreach (var itemDfe in listaDFe.OrderBy(x => x.Nsu))
            {
                try
                {
                    // tratamento null
                    if (itemDfe == null)
                        continue;

                    // log de cada item
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.ConverterLoteDFeParaEntrada() - itemDfe nsu = {itemDfe.Nsu} chave acesso = {itemDfe.ChaveAcesso}");

                    // criar nova entrada na fila
                    var entradaEntity = new IssNotaFiscalGovBrImportarEntradaEntity()
                    {
                        Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                        FilaTipo = (int)DescobrirFilaTipo(itemDfe.TipoDocumento, itemDfe.TipoEvento),
                        Status = (int)NfseGovBrEnum.enumFilaStatus.BaixadoAguardandoProcessar, // baixado mas nunca processado
                        ChaveAcesso = itemDfe.ChaveAcesso,
                        Nsu = itemDfe.Nsu,
                        DataHoraDocumento = null,
                        TipoDocumento = itemDfe.TipoDocumento,
                        TipoEvento = itemDfe.TipoEvento,
                        DataHoraCriacao = DateTime.UtcNow.AddHours(-3),
                        Corpo = "" + itemDfe.ArquivoXml
                    };

                    // validar campos e se já foi baixado antes de seguir para gravação na base.
                    await ValidarAntesGravar(entradaEntity);

                    // gravar xml no disco para acompanhamento
                    await GravarArquivoXmlDisco(itemDfe.Nsu.GetValueOrDefault(), itemDfe.ChaveAcesso + "", itemDfe.TipoDocumento + "", itemDfe.TipoEvento + "", entradaEntity.Corpo);

                    // log 
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.ConverterLoteDFeParaEntrada() - itemDfe nsu = {itemDfe.Nsu} chave acesso = {itemDfe.ChaveAcesso} -- salvar fila entrada");

                    // salvar nfse ou evento na fila de entrada
                    _importarEntradaRepository.Add(entradaEntity);
                    await _importarEntradaRepository.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadEventoBus.ConverterLoteDFeParaEntrada() - fim com erro");
                    _loggerHelper.GravarObjeto(ex);
                    _loggerHelper.GravarObjeto(itemDfe);
                }
            }

            // log fim
            _loggerHelper.GravarTexto("NfseGovBrNfseDownloadEventoBus.ConverterLoteDFeParaEntrada() - Fim com sucesso");
        }
    }
}
