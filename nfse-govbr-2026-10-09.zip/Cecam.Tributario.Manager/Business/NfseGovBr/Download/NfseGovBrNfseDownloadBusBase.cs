﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Download
{
    public abstract class NfseGovBrNfseDownloadBusBase
    {
        #region Declarações

        /// <summary>
        /// log
        /// </summary>
        protected readonly ILoggerHelper _loggerHelper;

        /// <summary>
        /// repositorio para gravar as NFSe baixadas.
        /// </summary>
        protected readonly IIssNotaFiscalGovBrImportarEntradaRepository _importarEntradaRepository;

        /// <summary>
        /// Repositorio com as várias NFSe já processadas com sucesso depois de baixadas.
        /// </summary>
        protected readonly IIssNotaFiscalGovBrImportarSaidaRepository _importarSaidaRepository;


        public NfseGovBrNfseDownloadBusBase()
        {
            // log
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();

            // repo gravar as nfse baixadas
            _importarEntradaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarEntradaRepository>();

            // repo consultar as nfse já processadas
            _importarSaidaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrImportarSaidaRepository>();
        }

        #endregion



        /*
        #region Métodos abstratos

        /// <summary>
        /// Validar campos durante o processo de conversão
        /// </summary>
        protected abstract Task ValidarAntesGravar(NfseGovBrDfeDocumentoResponse itemDfe);


        /// <summary>
        /// Atualizar com o último NSU baixado na tabela de parametrosNFSE
        /// </summary>
        protected abstract Task AtualizarNsuBaixadoUltimo(long nsu, string chaveAcesso);

        #endregion
        */

        




        /// <summary>
        /// Descobrir o tipo de fila (usado na base da prefeitura) usando vários campos do item baixado
        /// </summary>
        protected NfseGovBrEnum.enumFilaTipo DescobrirFilaTipo(string? tipoDocumento, string? tipoEvento)
        {
            // valor retornado pelo método
            var filaTipo = NfseGovBrEnum.enumFilaTipo.OutroNaoIdentificado;

            // tratar texto entrado
            tipoDocumento = (tipoDocumento + "").Trim().ToUpper();

            if (tipoDocumento == "NFSE")
            {
                filaTipo = NfseGovBrEnum.enumFilaTipo.NFSe;
            }
            else if (tipoDocumento == "EVENTO")
            {
                // tipo de evento
                switch ((tipoEvento + "").Trim().ToUpper())
                {
                    // cancelamento de nota fisca (e suas variações)
                    case "CANCELAMENTO":
                    case "CANCELAMENTO_POR_SUBSTITUICAO":
                    case "CANCELAMENTO_DEFERIDO_ANALISE_FISCAL":
                    case "CANCELAMENTO_POR_OFICIO":
                        filaTipo = NfseGovBrEnum.enumFilaTipo.Cancelamento;
                        break;

                    // 'confirmação do tomador', é quando prestador emite uma NFSe informando com retenção pelo tomador.
                    // mas o tomador ao ver a nota no sistema gov.br escolhe 'confirmar'.
                    // o tomador precisa ir no sistema gov.br e 'confirmar' a respectiva NFSe
                    case "CONFIRMACAO_TOMADOR":
                    // 'confirmação do prestador', funciona igual a 'confirmação do tomador'
                    case "CONFIRMACAO_PRESTADOR":
                    // 'confirmação do intermediario', funciona igual a 'confirmação do tomador'
                    case "CONFIRMACAO_INTERMEDIARIO":
                    // 'confirmação tácita', é a aprovação da nota pelo municipio, funciona igual a 'confirmação do tomador'
                    case "CONFIRMACAO_TACITA":
                        filaTipo = NfseGovBrEnum.enumFilaTipo.AceiteNotaFiscal;
                        break;

                    // no momento nada para fazer com esses eventos
                    // mas deixei aqui porque em algum momento vou precisar escrever código para eles.
                    case "SOLICITACAO_CANCELAMENTO_ANALISE_FISCAL":
                    case "CANCELAMENTO_INDEFERIDO_ANALISE_FISCAL":

                    // confirmação e rejeição do prestador, quando o tomador emite a NFSe informando com retenção pelo prestador.
                    case "REJEICAO_PRESTADOR":

                    // 'rejeição do tomador', é quando prestador emite uma NFSe informando com retenção pelo tomador.
                    // mas o tomador ao ver a nota no sistema gov.br escolhe 'rejeitar'.
                    // o tomador precisa ir no sistema gov.br e 'rejeitar' a respectiva NFSe
                    case "REJEICAO_TOMADOR":

                    // confirmação e rejeição do intermediário, quando o prestador emite a NFSe informando com retenção pelo intermediario.
                    case "REJEICAO_INTERMEDIARIO":

                    case "ANULACAO_REJEICAO":
                    case "BLOQUEIO_POR_OFICIO":
                    case "DESBLOQUEIO_POR_OFICIO":

                    // INCLUSAO_NFSE_DAN - qnd contribuinte no govbr emite guia de recolhimento (chamada DNA) mas ainda não pagou
                    case "INCLUSAO_NFSE_DAN":
                    // TRIBUTOS_NFSE_RECOLHIDOS - qnd govbr (MAM) encontra o pagamento da guia de recolhimento (DNA) pelo contribuinte
                    case "TRIBUTOS_NFSE_RECOLHIDOS":
                        filaTipo = NfseGovBrEnum.enumFilaTipo.Ignorado;
                        break;
                }
            }

            // valor retornado pelo método
            return filaTipo;
        }


        /// <summary>
        /// Gravar a XMl com o documento NFSe em disco para facilitar debugar no dia-a-dia
        /// </summary>
        protected async Task GravarArquivoXmlDisco(long nsu, string chaveAcesso, string tipoDocumento, string tipoEvento, string conteudo)
        {
            try
            {
                // log 
                _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadBusBase.GravarArquivoXmlDisco() - itemDfe nsu = {nsu} chave acesso = {chaveAcesso} tipo = {tipoDocumento} evento = {tipoEvento} -- gravar aquivo xml em disco");

                // pasta destino
                var logPath = AppDomain.CurrentDomain.BaseDirectory + "Baixado_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + DateTime.UtcNow.AddHours(-3).Year + "\\" + DateTime.UtcNow.AddHours(-3).ToString("MM") + "\\" + DateTime.UtcNow.AddHours(-3).ToString("dd");

                // criar todas as pastas se não existirem
                Directory.CreateDirectory(logPath);
                
                // se temos tipo de evento então completar o nome do arquivo com "_"
                if (!string.IsNullOrWhiteSpace(tipoEvento))
                    tipoEvento = "_" + tipoEvento;

                // append
                await File.WriteAllTextAsync(logPath + $"\\nsu_{nsu}_{chaveAcesso}_{tipoDocumento}{tipoEvento}_" + DateTime.UtcNow.AddHours(-3).ToString("yyyyMMdd_HH") + ".xml", conteudo, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                _loggerHelper.GravarTexto($"NfseGovBrNfseDownloadBusBase.GravarArquivoXmlDisco() - fim com erro");
                _loggerHelper.GravarObjeto(ex);
                _loggerHelper.GravarObjeto(conteudo);
            }
        }

    }
}
