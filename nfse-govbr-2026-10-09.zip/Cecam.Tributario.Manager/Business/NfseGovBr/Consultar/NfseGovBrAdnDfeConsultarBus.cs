﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Consultar
{
    public class NfseGovBrAdnDfeConsultarBus
    {
        #region Declarações


        private readonly ILogger<NfseGovBrAdnDfeConsultarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;


        public NfseGovBrAdnDfeConsultarBus()
        {
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrAdnDfeConsultarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
        }


        #endregion


        /// <summary>
        /// Consultar um lote de NFSe a partir da Nsu inicial informada
        /// </summary>
        public async Task ConsultarLotePorNsuInicial__NOT_IMPLEMENTED(long nsuInicial)
        {
            // log inicial
            _logger.LogInformation($"NfseGovBrAdnDfeConsultarBus.ConsultarLotePorNsuInicial() - início - nsu inicial = {nsuInicial}");

            throw new NotImplementedException();

            // objeto que faz a consulta para API da receita federal no módulo ADN.
            // acessa um servico 'externo' ao sistema
            var adnExternal = new NfseGovBrAdnExternal();

            // retorno da consulta ao gov.br
            var respostaExternal = await adnExternal.MunicipiosDfeConsultar(nsuInicial, NfseGovBrAdnExternal.eTipoNsu.Distribuicao, true);

            if (respostaExternal.Sucesso)
            {
            }
            else
            {
                // sem sucesso na consulta
                _loggerHelper.GravarTexto($"NfseGovBrAdnDfeConsultarBus.ConsultarLotePorNsuInicial() - fim - nsu inicial = {nsuInicial}");
                _loggerHelper.GravarObjeto(respostaExternal);
            }

            // log final
            _logger.LogInformation($"NfseGovBrAdnDfeConsultarBus.ConsultarLotePorNsuInicial() - fim - nsu inicial = {nsuInicial}");
        }



        public async Task TemporarioParaDesenvovler()
        {

            // objeto que faz o envio para API da receita federal no módulo ADN.
            var adnExternal = new NfseGovBrAdnExternal();

            // consultar
            var resposta = await adnExternal.MunicipiosDfeConsultar(0, NfseGovBrAdnExternal.eTipoNsu.Distribuicao, true);

            // coonverter o lote recebido em qq coisa
            var x1 = resposta.Sucesso;
            var x2 = resposta.Item;
            var x3 = resposta.ErroMensagens;
            var x4 = resposta.Lista;
            var x5 = resposta.StatusCode;


            await Task.CompletedTask;

        }
    }
}
