﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Consultar
{
    public class NfseGovBrNfseConsultarBus
    {
        #region Declarações


        private readonly ILogger<NfseGovBrNfseConsultarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;



        public NfseGovBrNfseConsultarBus()
        {
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrNfseConsultarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
        }


        #endregion


        /// <summary>
        /// Consultar a NFSe no site gov.br e retornar o objeto NfseXml que representa a DPS completa. 
        /// </summary>
        public async Task<NfseXml?> ConsultarNfseAsView(string chaveAcesso)
        {
            // recuperar a nfse em xml em formato de string
            var xmlString = await ConsultarNfse(chaveAcesso);

            if (string.IsNullOrWhiteSpace(xmlString))
                throw new Exception("xmlString não pode ficar vazia");

            // não deve ser usado, mas deixei aqui pq qnd for para produção talvez isso seja necessário/obrigatório
            // remover caracteres especiais
            // xmlString = xmlString.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?><NFSe versao=\"1.00\" xmlns=\"http://www.sped.fazenda.gov.br/nfse\">", "");

            var serializer = new XmlSerializer(typeof(NfseXml));

            using (var reader = new StringReader(xmlString))
            {
                if (reader != null)
                {
                    var xmlNfse = (NfseXml?)serializer.Deserialize(reader);
                    return xmlNfse;
                }
            }

            return null;
        }


        /// <summary>
        /// Consultar a NFSe no site gov.br e retornar a XML em string 
        /// Com essa string é possível converter para o objeto NfseXml que representa a DPS completa.
        /// </summary>
        public async Task<string> ConsultarNfse(string chaveAcesso)
        {
            // log inicial
            _logger.LogInformation($"NfseGovBrNfseConsultarBus.ConsultarNfse() - inicio - chave de acesso = {chaveAcesso}");

            if (string.IsNullOrWhiteSpace(chaveAcesso))
                throw new Exception("Chave de acesso precisa ser informada para ser consultada");

            // objeto que faz a consulta na API da receita federal no módulo sefin nacional.
            var sefinExternal = new NfseGovBrSefinNacionalExternal();

            // consultar api gov.br
            var retornoExternal = await sefinExternal.NfseConsultar(chaveAcesso);

            if (retornoExternal == null)
                throw new Exception("External do Sefin Nacional Gov.Br não retornou dados.");

            if (!retornoExternal.Sucesso ||
                retornoExternal.Item == null ||
                string.IsNullOrWhiteSpace(retornoExternal.Item.NfseFormatoXmlString))
                throw new Exception(retornoExternal.ErroMensagensToString() + " | External do Sefin Nacional Gov.Br sem sucesso ou sem dados.");

            // log final
            _logger.LogInformation($"NfseGovBrNfseConsultarBus.ConsultarNfse() - fim - chave de acesso = {chaveAcesso}");

            // valor retornado pelo método
            return retornoExternal.Item.NfseFormatoXmlString;
        }


        /// <summary>
        /// Consultar a NFSe no site gov.br e retornar string Base64 de um PDF
        /// Com essa string é possível converter para o objeto NfseXml que representa a DPS completa.
        /// </summary>
        public async Task<string> DanfseConsultar(string chaveAcesso)
        {
            // log inicial
            _logger.LogInformation($"NfseGovBrNfseConsultarBus.ConsultarNfseAsBase64Pdf() - inicio - chave de acesso = {chaveAcesso}");

            if (string.IsNullOrWhiteSpace(chaveAcesso))
                throw new Exception("Chave de acesso precisa ser informada para ser consultada");

            // objeto que faz a consulta na API da receita federal no módulo SEFIN.
            var sefinExternal = new NfseGovBrSefinNacionalExternal();

            // consultar api gov.br
            var retornoExternal = await sefinExternal.DanfseConsultar(chaveAcesso);

            if (retornoExternal == null)
                throw new Exception("External do Sefin Nacional Gov.Br não retornou dados.");

            if (!retornoExternal.Sucesso || string.IsNullOrWhiteSpace(retornoExternal.Item))
                throw new Exception(retornoExternal.ErroMensagensToString() + " | External do Sefin Nacional Gov.Br sem sucesso ou sem dados.");

            // log final
            _logger.LogInformation($"NfseGovBrNfseConsultarBus.ConsultarNfseAsBase64Pdf() - fim - chave de acesso = {chaveAcesso}");

            // valor retornado pelo método
            return string.Empty + retornoExternal.Item;
        }
    }
}
