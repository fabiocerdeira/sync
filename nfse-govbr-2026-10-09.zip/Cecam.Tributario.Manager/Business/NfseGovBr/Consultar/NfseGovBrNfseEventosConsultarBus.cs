﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Consultar
{
    public class NfseGovBrNfseEventosConsultarBus
    {
        #region Declarações


        private readonly ILogger<NfseGovBrNfseEventosConsultarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;



        public NfseGovBrNfseEventosConsultarBus()
        {
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrNfseEventosConsultarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
        }


        #endregion


        /// <summary>
        /// Consultar um evento de uma deterinada NFSe
        /// </summary>
        /// <param name="chaveAcesso"></param>
        public async Task<List<NfseGovBrDfeDocumentoResponse>> ConsultarEvento(string chaveAcesso)
        {
            // log inicial
            _logger.LogInformation($"NfseGovBrNfseEventosConsultarBus.ConsultarEvento() - inicio - chave de acesso = {chaveAcesso}");

            if (string.IsNullOrWhiteSpace(chaveAcesso))
                throw new Exception("Chave de acesso precisa ser informada para ser consultada");

            // objeto que faz a consulta na API da receita federal no módulo sefin nacional.
            var sefinExternal = new NfseGovBrSefinNacionalExternal();

            // consultar api gov.br
            var retornoExternal = await sefinExternal.NfseEventosConsultar(chaveAcesso);

            if (retornoExternal == null)
                throw new Exception("External do Sefin Nacional Gov.Br não retornou dados.");

            if (!retornoExternal.Sucesso ||
                retornoExternal.Item == null ||
                retornoExternal.Item.LoteDFe == null ||
                retornoExternal.Item.LoteDFe.Count == 0)
                throw new Exception(retornoExternal.ErroMensagensToString() + " | External do Sefin Nacional Gov.Br sem sucesso ou sem dados.");

            // log final
            _logger.LogInformation($"NfseGovBrNfseEventosConsultarBus.ConsultarEvento() - fim - chave de acesso = {chaveAcesso}");

            // valor retornado pelo método
            return retornoExternal.Item.LoteDFe;
        }



    }
}
