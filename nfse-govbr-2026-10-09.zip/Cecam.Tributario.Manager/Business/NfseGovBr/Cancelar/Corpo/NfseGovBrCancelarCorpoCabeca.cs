﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.IssNotaFiscal.Filter;
using Cecam.Tributario.Manager.Business.IssNotaFiscal;
using Cecam.Tributario.Manager.Business.NfseGovBr.Enviar;
using Cecam.Tributario.Manager.View.NfseGovBr.Evento;
using Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Cancelar.Corpo
{
    internal class NfseGovBrCancelarCorpoCabeca
    {
        #region Declarações

        /// <summary>
        /// Numero sequencial do evento
        /// </summary>
        private const string KnSeqEvento = "001";


        // logs
        private readonly ILogger<NfseGovBrCancelarBus> _logger;
        private readonly ILoggerHelper _loggerHelper;

        /// <summary>
        /// Todos os dados carregados da base para serem utilizados na geração do evento de cancelamento da nota fiscal
        /// </summary>
        private readonly NfseGovBrCancelarBusDados _dadosOrigem;


        public NfseGovBrCancelarCorpoCabeca(NfseGovBrCancelarBusDados dadosOrigem)
        {
            _dadosOrigem = dadosOrigem;

            // logs
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrCancelarBus>();
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;
            _loggerHelper.Logger = _logger;
            _loggerHelper.PrefixoNomeArquivo = dadosOrigem != null && dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + dadosOrigem.Cd_NotaFiscal.ToString() : "";
        }


        #endregion


        /// <summary>
        /// Preencher o objeto de evento de cancelamento da Nota Fiscal e seus filhos em memória com os dados carregados da base
        /// </summary>
        public async Task Processar()
        {
            // Carregar as várias entidades da base de dados para memória
            await CarregarDados();

            // preencher o objeto xml com os dados carregados da base
            PreencherObjetoComDadosCabeca();
            PreencherObjetoComDadosPedRegEvento();
            PreencherObjetoComDadosItemCancelamento();
        }


        /// <summary>
        /// Carregar as várias entidades da base de dados para memória
        /// </summary>
        private async Task CarregarDados()
        {
            // prefixo das mensagens de log
            string logMensagem = $"NfsCabeca.CarregarDados() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} ";

            // log início
            _loggerHelper.GravarTexto(logMensagem + "Início");

            // objeto de negocio
            var notaFiscalBus = new IssNotaFiscalBus();

            // carregar a nota fiscal completa com todos os seus dados
            _dadosOrigem.IssNotaFiscal = await notaFiscalBus.Carregar(new IssNotaFiscalBusFilter()
            {
                Cd_NotaFiscal = _dadosOrigem.Cd_NotaFiscal,
                IncluirItens = true,
                IncluirImpostos = true
            });

            if (_dadosOrigem.IssNotaFiscal == null)
                throw new Exception(logMensagem + "NFSe não foi encontrada.");

            // todas as notas fiscais da Cecam tem obrigatoriamente 1 (um) e somente 1 (um) item.
            if (_dadosOrigem.IssNotaFiscal.Itens == null || _dadosOrigem.IssNotaFiscal.Itens.Count != 1)
                throw new Exception(logMensagem + "Qtd de registros na IssNotaFiscalIntes esta errada (obrigatório um e somente um item)");

            if (string.IsNullOrWhiteSpace(_dadosOrigem.IssNotaFiscal.Govbr_ChaveAcesso))
                throw new Exception(logMensagem + "Não é possível enviar um cancelamento de NFSe que não tenha o campo 'Govbr_ChaveAcesso' preenchido.");

            // log fim
            _loggerHelper.GravarTexto(logMensagem + "Fim com sucesso");
        }



        /// <summary>
        /// Preencher o objeto xml com os dados carregados da base
        /// </summary>
        private void PreencherObjetoComDadosCabeca()
        {
            if (_dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.EventoParaEnvio == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosCabeca() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // criar cabeça do evento de cancelamento da nfse.
            var nfseEventoXml = new NfseEventoXml();
            _dadosOrigem.EventoParaEnvio = nfseEventoXml;

            // Versão da xml
            // valor fixo "1.00"
            nfseEventoXml.Versao = "1.00";

            // Grupo de informações do pedido de registro do evento
            var infNfseEventoXml = new InfNfseEventoXml();
            nfseEventoXml.InfNFSeEvento = infNfseEventoXml;

            // identificador da nfse
            infNfseEventoXml.Id = "EVT" + _dadosOrigem.IssNotaFiscal.Govbr_ChaveAcesso + "101101" + KnSeqEvento;

            // Versão da aplicação que gerou a NFS-e.
            infNfseEventoXml.verAplic = NfseGovBrDfeEnviarBusDados.VersaoGeradorNfse;

            // Ambiente gerador da NFS-e
            // 1 - Sistema Próprio do Município
            // 2 - Sefin Nacional NFS-e
            infNfseEventoXml.ambGer = "1";

            // Número sequencial do evento para o mesmo tipo de evento.
            // Para os eventos que ocorrem somente uma vez, como é o caso do cancelamento, o nSeqEvento = 001.
            // Para os eventos que possam existir mais de um evento do mesmo tipo o ambiente gerador deverá numerar de forma sequencial.
            infNfseEventoXml.nSeqEvento = KnSeqEvento;

            // Data/Hora do registro do evento.
            infNfseEventoXml.dhProc = DateTime.UtcNow.AddHours(-3).ToString("o");

            // Número sequencial do documento gerado por ambiente gerador de DFe do município.
            // Tabela ISSNotaFiscal ==> campo ==> cd_notafiscal 
            infNfseEventoXml.nDFe = _dadosOrigem.IssNotaFiscal.Cd_NotaFiscal.ToString();

            // log fim
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosCabeca() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }


        private void PreencherObjetoComDadosPedRegEvento()
        {
            if (_dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.EventoParaEnvio == null ||
                _dadosOrigem.EventoParaEnvio.InfNFSeEvento == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosPedRegEvento() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // pedido de registro de evento
            var pedRegEventoXml = new PedRegEventoXml();
            _dadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento = pedRegEventoXml;

            // Versão da xml
            // valor fixo "1.00"
            pedRegEventoXml.Versao = "1.00";

            // InfPedRegEventoXml
            var infPedRegEventoXml = new InfPedRegEventoXml();
            _dadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento.InfPedRegEvento = infPedRegEventoXml;

            // "O identificador do pedido de registro de evento é composto pela concatenação de campos que constam no leiaute.
            // A formação deste identificador considera o literal ""PRE"" associado a outras 56 posições numéricas, conforme descrito abaixo:
            // "PRE" + 
            // Chave de acesso da NFS-e(50) +
            // Código do evento(6)
            infPedRegEventoXml.Id = "PRE" + _dadosOrigem.IssNotaFiscal.Govbr_ChaveAcesso + "101101";

            /// Identificador da NFS-e a qual o evento será vinculada.
            infPedRegEventoXml.chNFSe = "" + _dadosOrigem.IssNotaFiscal.Govbr_ChaveAcesso;

            // helper com várias funções para cnpj e cpf.
            var cnpjCpfHelper = new CnpjCpfHelper();

            switch (cnpjCpfHelper.VerificarTipo(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF))
            {
                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CPF:
                    infPedRegEventoXml.CPFAutor = cnpjCpfHelper.RetornaSomenteNumerosLetras(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF);
                    break;

                case CnpjCpfHelper.CnpjCpfHelperTipoEnum.CNPJ:
                    infPedRegEventoXml.CNPJAutor = cnpjCpfHelper.RetornaSomenteNumerosLetras(_dadosOrigem.IssNotaFiscal.Nr_CGCCPF);
                    break;
            }

            // Data e hora do evento no formato AAAA-MM-DDThh:mm:ssTZD  
            infPedRegEventoXml.dhEvento = DateTime.UtcNow.AddHours(-3).ToString("o");

            // Tipo de ambiente:
            // 1 - Produção; 
            // 2 - Homologação;
            infPedRegEventoXml.tpAmb = ParametrosGlobal.NfseGovBr_HeAmbienteProducao ? "1" : "2";

            // Versão do aplicativo que gerou o pedido de registro de evento.
            infPedRegEventoXml.verAplic = NfseGovBrDfeEnviarBusDados.VersaoGeradorNfse;

            // log fim
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosPedRegEvento() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }


        private void PreencherObjetoComDadosItemCancelamento()
        {
            if (_dadosOrigem.IssNotaFiscal == null ||
                _dadosOrigem.EventoParaEnvio == null ||
                _dadosOrigem.EventoParaEnvio.InfNFSeEvento == null ||
                _dadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento == null ||
                _dadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento.InfPedRegEvento == null)
                return;

            // log início
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosItemCancelamento() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Início");

            // atalho
            var infPedRegEventoXml = _dadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento.InfPedRegEvento;
            if (infPedRegEventoXml == null)
                return;

            // item de cancelamento
            var eventoItemCancelamentoXml = new NfseEventoItemCancelamentoXml();
            infPedRegEventoXml.ItemCancelamento = eventoItemCancelamentoXml;

            // Descrição do evento: 
            // Cancelamento de NFS-e
            eventoItemCancelamentoXml.xDesc = "Cancelamento de NFS-e";

            // Código de justificativa de cancelamento:
            // 1 - Erro na Emissão;
            // 2 - Serviço não Prestado;
            // 9 - Outros;
            eventoItemCancelamentoXml.cMotivo = "1";

            // Descrição para explicitar o motivo indicado neste evento.
            if (string.IsNullOrWhiteSpace(_dadosOrigem.IssNotaFiscal.Ds_MotivoCancelamento))
            {
                // não temos motivo de cancelamento digitado pelo contribuinte,
                // então usar um texto padrão
                eventoItemCancelamentoXml.xMotivo = "Cancelamento de NFS-e";
            }
            else
            {
                // se temos motivo de cancelamento digitado pelo contribuinte.
                eventoItemCancelamentoXml.xMotivo = "" + _dadosOrigem.IssNotaFiscal.Ds_MotivoCancelamento;
            }

            // log fim
            _loggerHelper.GravarTexto($"NfsCabeca.PreencherObjetoComDadosItemCancelamento() Cd_NotaFiscal={_dadosOrigem.Cd_NotaFiscal} - Fim com sucesso");
        }

    }
}
