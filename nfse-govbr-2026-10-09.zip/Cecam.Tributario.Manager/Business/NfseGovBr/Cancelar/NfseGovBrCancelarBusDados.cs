﻿using Cecam.Tributario.Manager.View.NfseGovBr.Evento;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Cancelar
{
    internal class NfseGovBrCancelarBusDados : NfseGovBrBusDadosBase
    {
        #region Declarações


        /// <summary>
        /// Classe raiz da XMl em formato objeto com o evento de cancelamento da NFSe para ser enviada para gov.br
        /// </summary>
        public NfseEventoXml EventoParaEnvio = new NfseEventoXml();


        #endregion
    }
}
