﻿using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.NfseGovBr.Cancelar.Corpo;
using Cecam.Tributario.Manager.External.NfseGovBr;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr.Cancelar
{
    /// <summary>
    /// Enviar o próximo evento de cancelamento Nfse (nota fiscal de serviço eletrônica) para o servidor do gov.br
    /// </summary>
    public class NfseGovBrCancelarBus : NfseGovBrBusBase
    {
        #region Declarações


        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<NfseGovBrCancelarBus> _logger;


        /// <summary>
        /// converter objeto dados origem base para o dados origem cancelar
        /// </summary>
        private NfseGovBrCancelarBusDados DadosOrigem => (NfseGovBrCancelarBusDados)_dadosOrigem;


        public NfseGovBrCancelarBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<NfseGovBrCancelarBus>();
            _loggerHelper.Logger = _logger;

            // Contem todos os dados carregados da base para o evento de cancelamento da nota fiscal de serviço
            _dadosOrigem = new NfseGovBrCancelarBusDados();
        }


        #endregion


        /// <summary>
        /// Enviar o cancelamento da próxima Nfse (nota fiscal de serviço eletrônica) para o servidor do gov.br
        /// </summary>
        [Obsolete("NÃO PODE SER USADO, PQ NÃO FAZEMOS ENVIO DE NFSE PARA GOV.BR")]
        public async Task CancelarProximaNotaFiscal()
        {
            // log inicio
            LogAtalho("CancelarProximaNotaFiscal()", "Início");

            try
            {
                // limpar os objetos dessa classe para próximo evento de NFSe.
                LimparObjetosGlobais();

                // Carregar a partir da fila de entrada o próximo cancelamento de NFSe que precisa ser enviada para Gov.Br
                if (!(await CarregarProximaNotaFiscalParaEnvio(NfseGovBrEnum.enumFilaTipo.Cancelamento)))
                    return;

                // Carregar a nota fiscal eletrônica com todas as informações filhas
                await PreencherObjetoNotaFiscalComDados();

                // Converter o objeto de nota fiscal da prefeitura/cecam em texto no formato do objeto Gov.Br
                await ConverterObjetoNotaFiscalParaXML(DadosOrigem.EventoParaEnvio);

                // Assinar a XML com o certificado seguro
                await PreencherXmlComCertificado();

                // Validar a XML criada contra o XSD do gov.br
                await ValidarXmlContraXsd();

                // realizar o envio do evento de cancelamento nota fiscal para o servidor da receita federal
                await EnviarEventoNotaFiscal();

                // finalizar o envio da nota fiscal gravando na base na fila de entrada ou na fila de saída.
                await FinalizarComSucessoNoEnvio();
            }
            catch (Exception ex)
            {
                // logar erro
                LogAtalho("CancelarProximaNotaFiscal()", ex.ToString(), LogLevel.Error);

                // marcar Nota Fiscal na fila de entrada como erro e gravar o respectivo erro
                await FinalizarComErroNoEnvio(ex.ToString());

                // limpar os objetos dessa classe para próxima NFSe.
                LimparObjetosGlobais();
            }

            // log fim
            LogAtalho("CancelarProximaNotaFiscal()", "Fim");
        }


        /// <summary>
        /// Carregar a nota fiscal eletrônica com todas as informações filhas
        /// </summary>
        private async Task PreencherObjetoNotaFiscalComDados()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null)
                return;

            // log inicio
            LogAtalho("PreencherObjetoComDados()", "Início");

            // preencher a cabeça da nota fiscal
            var cabeca = new NfseGovBrCancelarCorpoCabeca(DadosOrigem);
            await cabeca.Processar();

            // log fim
            LogAtalho("PreencherObjetoComDados()", "Fim com suceso");
        }


        /// <summary>
        /// Assinar a XML com o certificado seguro
        /// </summary>
        private async Task PreencherXmlComCertificado()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.IssNotaFiscal == null ||
                DadosOrigem.EventoParaEnvio.InfNFSeEvento == null ||
                DadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento == null ||
                DadosOrigem.EventoParaEnvio.InfNFSeEvento.PedRegEvento.InfPedRegEvento == null ||
                DadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("PreencherXmlComCertificado()", "Início");

            // atalho
            var infNfseEvento = DadosOrigem.EventoParaEnvio.InfNFSeEvento;
            if (infNfseEvento == null ||
                infNfseEvento.PedRegEvento == null ||
                infNfseEvento.PedRegEvento.InfPedRegEvento == null)
                return;

            // a NFSe tem 2 assinaturas, uma para a NFSe outra para a DPS, cada uma com seu respectivo ID
            var dicNodes = new Dictionary<string, string>();
            dicNodes.Add("evento", "" + infNfseEvento.Id);
            dicNodes.Add("pedRegEvento", "" + infNfseEvento.PedRegEvento.InfPedRegEvento.Id);

            // assinar a xml com o certificado seguro nos nodes informados.
            PreencherXmlComCertificadoVariosNodes(dicNodes);

            // log fim
            LogAtalho("PreencherXmlComCertificado()", "Fim");

            await Task.CompletedTask;
        }


        /// <summary>
        /// Validar a XML criada contra o XSD do gov.br
        /// </summary>
        private async Task ValidarXmlContraXsd()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("ValidarXmlContraXsd()", "Início");

            // xsd para envio da NFSE
            var xsdPath = AppDomain.CurrentDomain.BaseDirectory + "Business\\NfseGovBr\\Xsds\\";

            await ValidarXmlContraXsdProcessar(new List<string>()
            {
                xsdPath + "evento_v1.00.xsd",
                xsdPath + "tiposEventos_v1.00.xsd",
                xsdPath + "pedRegEvento_v1.00.xsd",
                xsdPath + "tiposComplexos_v1.00.xsd",
                xsdPath + "tiposSimples_v1.00.xsd"
            });

            // log fim
            LogAtalho("ValidarXmlContraXsd()", "Fim");
        }


        /// <summary>
        /// Realizar o envio do evento de cancelamento da nota fiscal para o servidor da receita federal
        /// </summary>
        private async Task EnviarEventoNotaFiscal()
        {
            if (DadosOrigem.NotaFiscalFilaEntrada == null ||
                DadosOrigem.IssNotaFiscal == null ||
                DadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("EnviarEventoNotaFiscal()", "Início");

            // guardar o corpo da nfse antes de enviar para o servidor do gov.br
            DadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo = DadosOrigem.XmlParaEnvioAsString;

            // objeto que faz o envio para API da receita federal no módulo SEFIN.
            var sefinExternal = new NfseGovBrSefinNacionalExternal();

            // enviar
            var respostaExternal = await sefinExternal.NfseEventosEnviar(DadosOrigem.IssNotaFiscal.Govbr_ChaveAcesso + "", DadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo);

            // verificar se não temos resposta?
            if (respostaExternal == null)
                throw new Exception("EnviarEventoNotaFiscal() - método sefinExternal.NfseEventosEnviar() retornou uma resposta vazia **erro**");

            // guardar resposta na tabela de fila
            DadosOrigem.NotaFiscalFilaEntrada.EnvioMensagem = Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal);

            if (respostaExternal.Sucesso)
            {
                // completar os dados da tabela IssNotaFiscal com os dados retornados do servidor gov.br
                LogAtalho("EnviarEventoNotaFiscal()", "Atualizar tabela ISSNotaFiscal com retorno do servidor gov.br");

                if (respostaExternal.Item == null ||
                    respostaExternal.Item.EventoEnviado == null)
                {
                    // log resposta com erro
                    throw new Exception("EnviarEventoNotaFiscal - EventoEnviado com erro" + Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal));
                }

                // aqui tem um problema
                // na teoria, todo envio de qq coisa (nota,eventos, etc) deveria retornar um NSU unico
                // mas aqui nesse enviar evento não esta claro aonde esta o NSU retornado
                // completar a nota fiscal com os dados retornados do gov.br
                // DadosOrigem.IssNotaFiscal.GovBr_NsuCancelamento = respostaExternal.Item.EventoEnviado.EventoXmlGZipB64

                // logar resposta external
                LogAtalho("EnviarEventoNotaFiscal()", Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal));
            }
            else
            {
                // log resposta com erro
                throw new Exception("EnviarNotaFiscal().AdnExternal.EnviarDfe() - Resposta do gov.br com erro" + Newtonsoft.Json.JsonConvert.SerializeObject(respostaExternal));
            }

            // log fim
            LogAtalho("EnviarEventoNotaFiscal()", "Fim");
        }



        #region Auxiliares


        /// <summary>
        /// Limpar os objetos globais para processar uma nova NFSe
        /// </summary>
        private void LimparObjetosGlobais()
        {
            // objetos globais com o evento de cancelamento da NFse
            _dadosOrigem = new NfseGovBrCancelarBusDados();
        }


        #endregion
    }
}
