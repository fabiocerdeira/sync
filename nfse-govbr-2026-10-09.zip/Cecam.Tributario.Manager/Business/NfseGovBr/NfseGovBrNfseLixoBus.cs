﻿using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.NfseGovBr
{
    public class NfseGovBrNfseLixoBus : NfseGovBrNfseImportarNotaBusBase
    {
        /*
        protected readonly IIssNotaFiscalGovBrLixoRepository _lixoRepository;


        public NfseGovBrNfseLixoBus()
        {
            _lixoRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrLixoRepository>();
        }


        public async Task Processar()
        {
            Console.WriteLine("Processar inicio --------------------- \n\n\n");

            // culture quando o importador é executado
            Console.WriteLine("Culture Info: " + CultureInfo.CurrentCulture.Name + "\n\n\n");

            _dadosOrigem.NotaFiscalFilaImportarEntrada = await _filaEntradaRepository.GetIQueryable()
                .Where(x => x.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.NFSe && x.ChaveAcesso == ChaveAcessoProcessar)
                .OrderBy(x => x.Nsu)
                .FirstOrDefaultAsync();

            if (_dadosOrigem.NotaFiscalFilaImportarEntrada == null)
            {
                var notaXmlSaida = await _filaSaidaRepository.GetIQueryable()
                    .Where(x => x.FilaTipo == (int)NfseGovBrEnum.enumFilaTipo.NFSe && x.ChaveAcesso == ChaveAcessoProcessar)
                    .OrderBy(x => x.Nsu)
                    .FirstOrDefaultAsync();

                if (notaXmlSaida == null)
                    throw new Exception("Nota fila saida não encontrada");

                _dadosOrigem.NotaFiscalFilaImportarEntrada = new Database.Entity.IssNotaFiscalGovBr.IssNotaFiscalGovBrImportarEntradaEntity
                { 
                    Cd_Cecam = notaXmlSaida.Cd_Cecam,
                    Cd_Contribuinte = notaXmlSaida.Cd_Contribuinte,
                    ChaveAcesso = notaXmlSaida.ChaveAcesso,
                    Corpo = notaXmlSaida.Corpo,
                    DataHoraCriacao = notaXmlSaida.DataHoraCriacao,
                    DataHoraDocumento = notaXmlSaida.DataHoraDocumento,
                    DataHoraProcessamento = notaXmlSaida.DataHoraProcessamento,
                    DpsId = notaXmlSaida.DpsId,
                    FilaTipo =  notaXmlSaida.FilaTipo,
                    Id = notaXmlSaida.Id,
                    Mensagem = notaXmlSaida.Mensagem,
                    Motivo = "",
                    NfseId = notaXmlSaida.NfseId,
                    Nr_CGCCPF = notaXmlSaida.Nr_CGCCPF,
                    Nsu = notaXmlSaida.Nsu,
                    Status = notaXmlSaida.Status,
                    TipoDocumento = notaXmlSaida.TipoDocumento,
                    TipoEvento = notaXmlSaida.TipoEvento
                };
            }


            ConverterXmlStringParaClasse();

            // atalho para os valores guardados no resumo da nota
            var valorResumo = _dadosOrigem?.NotaFiscalImportada?.InfNFSe?.Valores;

            if (valorResumo == null)
                throw new Exception("ERRO ** valorResumo = null");

            decimal pcAliquota = 0;


            //valorResumo.pAliqAplic = "1987012.340";

            decimal.TryParse("" + ValorFormatoEuaParaBr(valorResumo.pAliqAplic), out pcAliquota);

            Console.WriteLine($"\n\n\nvalorResumo.pAliqAplic string retirada da XML = {valorResumo.pAliqAplic}");

            Console.WriteLine($"\n\n\npcAliquota convertido de string para decimal = {pcAliquota}\n\n\n");

            var lixoEnt = new Database.Entity.IssNotaFiscalGovBr.IssNotaFiscalGovBrLixoEntity
            {
                // Corpo = _dadosOrigem?.NotaFiscalFilaImportarEntrada?.Corpo,
                ValorDecimalA = pcAliquota,
                ValorNumericA = pcAliquota,
            };

            _lixoRepository.Add(lixoEnt);

            await _lixoRepository.SaveChangesAsync();

            Console.WriteLine("Processar FIM ------------------------");
        }


        */

        public async Task Processar()
        {
            await Task.CompletedTask;

            decimal valorDecimal = 0;
            string valor = "2.00";
            string valorFormatado = "2.00";

            Console.WriteLine($"\n\nvalor original string = {valor}");

            // Console.WriteLine("" + valorDecimal.ToString(CultureInfo.InvariantCulture));

            Decimal.TryParse(valor, out valorDecimal);

            Console.WriteLine($"\n\nvalor Decimal.TryParse valorDecimal = " + valorDecimal.ToString(CultureInfo.InvariantCulture));


            Decimal.TryParse(valor, NumberStyles.Number, new CultureInfo("pt-BR"), out valorDecimal);

            Console.WriteLine($"\n\nvalor Decimal.TryParse BRASIL valorDecimal = " + valorDecimal.ToString(CultureInfo.InvariantCulture));


            Decimal.TryParse(valor, NumberStyles.Number, new CultureInfo("en-US"), out valorDecimal);

            Console.WriteLine($"\n\nvalor Decimal.TryParse EUA valorDecimal = " + valorDecimal.ToString(CultureInfo.InvariantCulture));


            // ----------------------------------------------------------------

            valorFormatado = "" + ValorFormatoEuaParaBr(valorFormatado);

            Console.WriteLine($"\n\nvalor ValorFormatoEuaParaBr string = {valorFormatado}");

            Decimal.TryParse(valorFormatado, out valorDecimal);

            Console.WriteLine($"\n\nvalor Decimal.TryParse valorDecimal = " + valorDecimal.ToString(CultureInfo.InvariantCulture));

            Decimal.TryParse(valorFormatado, NumberStyles.Number, new CultureInfo("pt-BR"), out valorDecimal);

            Console.WriteLine($"\n\nvalor Decimal.TryParse BRASIL valorDecimal = " + valorDecimal.ToString(CultureInfo.InvariantCulture));

            Decimal.TryParse(valorFormatado, NumberStyles.Number, new CultureInfo("en-US"), out valorDecimal);

            Console.WriteLine($"\n\nvalor Decimal.TryParse EUA valorDecimal = " + valorDecimal.ToString(CultureInfo.InvariantCulture));
        }


        private string? ValorFormatoEuaParaBr(string? valor)
        {
            if (string.IsNullOrWhiteSpace(valor))
                return valor;

            return valor.Replace(",", "").Replace(".", ",");
        }
    }
}
