﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Enumerado.NfseGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Extend.Utf8StringWriter;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Xml;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.Business.NfseGovBr
{
    public abstract class NfseGovBrBusBase
    {
        #region Declarações


        // repositorios
        protected readonly IIssNotaFiscalGovBrFilaEntradaRepository _filaEntradaRepository;
        protected readonly IIssNotaFiscalGovBrFilaSaidaRepository _filaSaidaRepository;

        
        // logs
        protected readonly ILoggerHelper _loggerHelper;


        /// <summary>
        ///  Contem todos os dados carregados da base e convertidos em memoria para o envido das informações para o gov.br
        ///  É usado no envio de uma nova NFSe e no envio de um evento de cancelamento de NFSe
        /// </summary>
        protected NfseGovBrBusDadosBase _dadosOrigem = new NfseGovBrBusDadosBase();


        protected NfseGovBrBusBase()
        {
            // logs
            _loggerHelper = ServiceProviderGlobal.GetServico<ILoggerHelper>();
            _loggerHelper.ObjFullName = "" + GetType().FullName;

            // repositorios
            _filaEntradaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrFilaEntradaRepository>();
            _filaSaidaRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalGovBrFilaSaidaRepository>();
        }


        #endregion


        #region Finalizar


        /// <summary>
        /// O envio do evento de cancelamento da NFSe par gov.br aconteceu com sucesso.
        /// Mover uma nota fiscal da fila de entrada para fila de saída,
        /// Gravar as informações retornadas do gov.br
        /// </summary>
        protected async Task FinalizarComSucessoNoEnvio()
        {
            if (_dadosOrigem.NotaFiscalFilaEntrada == null || _dadosOrigem.IssNotaFiscal == null)
                return;

            // log inicio
            LogAtalho("FinalizarComSucessoNoEnvio()", "Início");

            var notaFiscalFilaSaida = new IssNotaFiscalGovBrFilaSaidaEntity()
            {
                Cd_Cecam = _dadosOrigem.NotaFiscalFilaEntrada.Cd_Cecam,
                Cd_NotaFiscal = _dadosOrigem.NotaFiscalFilaEntrada.Cd_NotaFiscal,
                EntradaDataHora = _dadosOrigem.NotaFiscalFilaEntrada.EntradaDataHora,
                EnvioDataHora = DateTime.UtcNow.AddHours(-3),
                EnvioCorpo = _dadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo,
                EnvioMensagem = _dadosOrigem.NotaFiscalFilaEntrada.EnvioMensagem,
                FilaTipo = _dadosOrigem.NotaFiscalFilaEntrada.FilaTipo
            };

            /*
             * FMC FMC FMC
             * 
             * AQUI TEM QUE ABRIR UMA TRANSAÇÃO
             */

            // salvar fila saída
            _filaSaidaRepository.DbSetEntity.Add(notaFiscalFilaSaida);
            await _filaSaidaRepository.SaveChangesAsync();

            // apagar da fila de entrada
            _filaEntradaRepository.DbSetEntity.Remove(_dadosOrigem.NotaFiscalFilaEntrada);
            await _filaEntradaRepository.SaveChangesAsync();

            // atualizar os campos da nota fiscal aqui com os campos recebidos do gov.br
            var _nfQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalQuery>();
            await _nfQuery.UpdateGovBrCriacaoNotaFiscal(_dadosOrigem.IssNotaFiscal);

            /*
             * FMC FMC FMC
             * 
             * AQUI TEM QUE FECHAR UMA TRANSAÇÃO
             */

            // log fim
            LogAtalho("FinalizarComSucessoNoEnvio()", "Fim");
        }


        /// <summary>
        /// Durante o envio do evento de cancelamento da nota fiscal para gov.br aconteceu um erro.
        /// Atualizar a fila de entrada com mensagem de erro
        /// Gravar as informações retornadas do gov.br
        /// </summary>
        protected async Task FinalizarComErroNoEnvio(string envioMensagem)
        {
            if (_dadosOrigem.NotaFiscalFilaEntrada == null)
                return;

            // log inicio
            LogAtalho("FinalizarComErroNoEnvio()", "Início");

            // atualizar a nota fiscal na fila de entrada
            _dadosOrigem.NotaFiscalFilaEntrada.EnvioDataHora = DateTime.UtcNow.AddHours(-3);
            _dadosOrigem.NotaFiscalFilaEntrada.Status = (int)NfseGovBrEnum.enumFilaStatus.ProcessadoComErro;
            _dadosOrigem.NotaFiscalFilaEntrada.EnvioMensagem = envioMensagem;

            // atualizar na base
            await _filaEntradaRepository.SaveChangesAsync();

            // log fim
            LogAtalho("FinalizarComErroNoEnvio()", "Fim");
        }


        #endregion


        /// <summary>
        /// Carregar a partir da fila de entrada a próxima nota fiscal que precisa ser enviada para Gov.Br
        /// IssNotaFiscalGovBrEnum.FilaTipo_EMISSAO_NF=1 | IssNotaFiscalGovBrEnum.FilaTipo_CANCELAMENTO_NF=2
        /// </summary>
        protected async Task<bool> CarregarProximaNotaFiscalParaEnvio(NfseGovBrEnum.enumFilaTipo filaTipo)
        {
            // log inicio
            LogAtalho("CarregarProximaNotaFiscalParaEnvio()", $"Início - filaTipo={filaTipo}");

            // carregar uma nota fiscal que foi emitida/cridada (filaTipo=1) na fila de entrada
            // carregar uma nota fiscal que foi cancelada (filaTipo=2) na fila de entrada
            // notas fiscais ainda não enviadas status=0
            // notas fiscais já tentou enviar anteriormente e deu erro status=1
            _dadosOrigem.NotaFiscalFilaEntrada = await _filaEntradaRepository.GetIQueryable()
                .Where(x => x.FilaTipo == (long)filaTipo &&
                (
                    x.Status == (int)NfseGovBrEnum.enumFilaStatus.BaixadoAguardandoProcessar ||
                    (
                        x.Status == (int)NfseGovBrEnum.enumFilaStatus.ProcessadoComErro && 
                        x.EnvioDataHora.HasValue && 
                        x.EnvioDataHora.Value <= DateTime.UtcNow.AddHours(-4)
                    )
                ))
                .OrderBy(x => x.Id)
                .FirstOrDefaultAsync();

            if (_dadosOrigem.NotaFiscalFilaEntrada == null)
            {
                // log fim
                LogAtalho("CarregarProximaNotaFiscalParaEnvio()", $"Fim - NÃO existem NFSe do tipo {filaTipo} na fila de entrada para enviar da Prefeitura para Gov.Br");
                return false;
            }

            // log fim
            LogAtalho("CarregarProximaNotaFiscalParaEnvio()", $"Fim - filaTipo={filaTipo}");

            // valor retornado pelo método qnd temos nota fiscal na fila 
            return true;
        }


        /// <summary>
        /// Converter o objeto de nota fiscal da prefeitura/cecam em texto no formato do objeto Gov.Br
        /// </summary>
        protected async Task ConverterObjetoNotaFiscalParaXML(object objParaConversao)
        {
            if (_dadosOrigem.NotaFiscalFilaEntrada == null ||
                _dadosOrigem.IssNotaFiscal == null ||
                objParaConversao == null)
                return;

            // log inicio
            LogAtalho("ConverterObjetoNotaFiscalParaXML()", "Início");

            // nameSpaces vazio nó raiz da xml.
            var ns = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            // ns.Add("", "");

            // objeto serializador
            var serializer = new XmlSerializer(objParaConversao.GetType());

            using (var writer = new Utf8StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(writer, new XmlWriterSettings()
                {
                    Indent = true, // remover tabulação para economizar espaços
                    NamespaceHandling = NamespaceHandling.Default
                }))

                serializer.Serialize(xmlWriter, objParaConversao, ns);
                _dadosOrigem.XmlParaEnvioAsString = writer.ToString();

                // desligado em 2025-10-14 pq vou resolver via xmlSerializer !!
                // bacalhau
                // para corrigir nameSpace pq o XmlSerializer não esta inserindo no objeto interno qnd tem a mesma Url do objeto Root
                // DadosOrigem.XmlParaEnvioAsString = DadosOrigem.XmlParaEnvioAsString.Replace("http://www.sped.fazenda.gov.br/nfse#", "http://www.sped.fazenda.gov.br/nfse");

                // somente par debugar
                // Console.WriteLine(DadosOrigem.XmlParaEnvioAsString);

                // log trace
                LogAtalho("ConverterObjetoNotaFiscalParaXML()", _dadosOrigem.XmlParaEnvioAsString);
            }

            // atualizar o corpo na fila de entrada
            _dadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo = _dadosOrigem.XmlParaEnvioAsString;

            // gravar somente a xml em arquivo separado
            // _logSimpleHelper.GravarLogArquivoDisco("nfse_" + DadosOrigem.Cd_NotaFiscal.ToString() + "_xml", DadosOrigem.XmlParaEnvioAsString);

            // log fim
            LogAtalho("ConverterObjetoNotaFiscalParaXML()", "Fim");

            await Task.FromResult(0);
        }


        #region Certificado digital seguro


        /// <summary>
        /// Assinar a XML com o certificado seguro
        /// </summary>
        protected void PreencherXmlComCertificadoVariosNodes(Dictionary<string, string> dicNodes)
        {
            if (_dadosOrigem.NotaFiscalFilaEntrada == null ||
                dicNodes == null)
                return;

            // log inicio
            LogAtalho("PreencherXmlComCertificadoVariosNodes()", "Início");

            // recuperar o certificado seguro
            var certificadoHelp = new X509CertificateHelper();
            var certificadoSeguro = certificadoHelp.GetCertificate();
            if (certificadoSeguro == null)
                throw new Exception("O certificado seguro da prefeitura não foi encontrado no servidor. Ele é obrigatório para o envio e consulta ao sistema do gov.br.");

            // criar objeto xml.
            var documentXml = new XmlDocument();
            documentXml.LoadXml(_dadosOrigem.XmlParaEnvioAsString);

            // todos os nodes informados.
            foreach (var itemNode in dicNodes)
            {
                PreencherXmlComCertificadoPorNode(certificadoSeguro, documentXml, itemNode.Key, itemNode.Value);
            }

            // atualizar a XML que será enviada com a XML assinada acima.
            _dadosOrigem.XmlParaEnvioAsString = documentXml.OuterXml;

            // atualizar o corpo na fila de entrada
            _dadosOrigem.NotaFiscalFilaEntrada.EnvioCorpo = _dadosOrigem.XmlParaEnvioAsString;

            // somente para debugar em desenvolvimento
            // var lg = new LogSimpleHelper();
            // lg.GravarExibir(DadosOrigem.XmlParaEnvioAsString);

            // log fim
            LogAtalho("PreencherXmlComCertificadoVariosNodes()", "Fim");
        }


        /// <summary>
        /// Assinar um determinado NODE com o certificado seguro
        /// </summary>
        private void PreencherXmlComCertificadoPorNode(X509Certificate2 certificado, XmlDocument documentXml, string tagName, string referenceId)
        {
            // recuperar lista de 'tagName'
            XmlNodeList? xmlNodeLista = documentXml.GetElementsByTagName(tagName);

            if (xmlNodeLista == null || xmlNodeLista.Count <= 0)
                throw new Exception($"Lista de node {tagName} não foi encontrado");

            // recuperar primeiro item 'tagName' da lista de 'tagName'
            XmlElement? xmlElemenTagName = xmlNodeLista[0] as XmlElement;

            if (xmlElemenTagName == null)
                throw new Exception($"Node {tagName} não foi encontrado");

            // criar assinatura referenciando o 'tagName'
            var signedXml = new SignedXml(xmlElemenTagName)
            {
                SigningKey = certificado.GetRSAPrivateKey(),
            };

            // nome do algoritimo de assinatura
            if (signedXml.SignedInfo != null)
                signedXml.SignedInfo.SignatureMethod = SignedXml.XmlDsigRSASHA1Url;


            // id do node raiz 'InfNFSe.Id'
            // var reference = new Reference(uri: "#" + DadosOrigem.NotaFiscalParaEnvio.InfNFSe.Id) { DigestMethod = SignedXml.XmlDsigSHA1Url };
            // id do node 'InfNFSe.Dps.InfDps.id'
            // var reference = new Reference(uri: "#" + DadosOrigem.NotaFiscalParaEnvio.InfNFSe.Dps.InfDps.id) { DigestMethod = SignedXml.XmlDsigSHA1Url };

            // assinando o 'tagName' com o seu respectivo atributo 'referenceId'
            var reference = new Reference(uri: "#" + referenceId) { DigestMethod = SignedXml.XmlDsigSHA1Url };
            reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
            reference.AddTransform(new XmlDsigC14NTransform());
            signedXml.AddReference(reference);

            // optional: embed the public key in the XML
            // this must not be trusted during validation (used for debugging only)
            var keyInfo = new KeyInfo();
            keyInfo.AddClause(new KeyInfoX509Data(certificado));
            signedXml.KeyInfo = keyInfo;

            // create signature
            signedXml.ComputeSignature();

            // get signature xml element and add it as a child of the root element
            xmlElemenTagName.AppendChild(signedXml.GetXml());
        }


        #endregion


        /// <summary>
        /// Validar a XML criada contra o XSD do gov.br
        /// </summary>
        protected async Task ValidarXmlContraXsdProcessar(List<string> xsds)
        {
            if (_dadosOrigem.NotaFiscalFilaEntrada == null ||
                _dadosOrigem.XmlParaEnvioAsString == null)
                return;

            // log inicio
            LogAtalho("ValidarXmlContraXsd()", "Início");

            // apenas para desenvolvimento, remover essas linhas comentadas.
            //DadosOrigem.XmlParaEnvioAsString = DadosOrigem.XmlParaEnvioAsString.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            //DadosOrigem.XmlParaEnvioAsString = DadosOrigem.XmlParaEnvioAsString.Replace("infNFSe id", "infNFSe Id");

            // criar objeto xml.
            var documentXml = new XmlDocument();
            documentXml.LoadXml(_dadosOrigem.XmlParaEnvioAsString);
            //documentXml.Load("C:\\Fontes2025-Gov\\trib-nfe-govbr\\Documentação\\NFSeGovBr\\dps baixado 2025-10-09.xml");

            // xsd para envio da NFSE
            var xsdPath = AppDomain.CurrentDomain.BaseDirectory + "Business\\NfseGovBr\\Xsds\\";

            // adicionar xsd
            foreach (var itemXsd in xsds )
            {
                documentXml.Schemas.Add(null, itemXsd);
            }

            // o xmldsig-core-schema.xsd não pode ser incluido da mesma forma que os outros acima.
            // pq ele tem um DTD dentro dele que gera erro.
            // então tem que ser incluid no formato abaixo, com o parametro 'DtdProcessing.Parse' para ignorar o DTD
            // depois ele é add() a lista de schemas com sucesso.
            var settingsXsd = new XmlReaderSettings();
            settingsXsd.DtdProcessing = DtdProcessing.Parse;
            XmlReader readerXsd = XmlReader.Create(xsdPath + "xmldsig-core-schema.xsd", settingsXsd);
            documentXml.Schemas.Add(null, readerXsd);

            // compilar os schemas XSD
            documentXml.Schemas.Compile();


            // validar
            try
            {
                documentXml.Validate(null);
            }
            /*
            catch (XmlSchemaValidationException exSchema)
            {
                throw new Exception("IssNotaFiscalGovBrEnvioBus.ValidarXmlContraXsd() **erro** Não foi possível validar a XML usando XSD", exSchema);
            }
            */
            catch (Exception ex)
            {
                throw new Exception("NfseGovBrBusBase.ValidarXmlContraXsd() **erro** Erro no processo de validar a XML usando XSD", ex);
            }

            // log fim
            LogAtalho("ValidarXmlContraXsd()", "Fim");

            await Task.CompletedTask;
        }


        #region Auxiliares


        /// <summary>
        /// Somente um atalho para gravar o log.
        /// </summary>
        protected void LogAtalho(string metodo, string texto, LogLevel logLevel = LogLevel.Information)
        {
            _loggerHelper.PrefixoNomeArquivo = _dadosOrigem != null && _dadosOrigem.Cd_NotaFiscal > 0 ? "nfse_enviar_cdNotaFiscal_" + _dadosOrigem.Cd_NotaFiscal.ToString() : "";
            _loggerHelper.GravarTexto(metodo + " " + texto, logLevel);
        }


        #endregion
    }
}
