﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Cecam.Tributario.Extend.Globals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.IssParametros
{
    public class IssParametrosCalcBus
    {
        #region Declarações

        /// <summary>
        /// Parametros de calculos para ISS do VB
        /// </summary>
        private readonly IIssParametrosCalcQuery _issParametrosCalcQuery;


        /// <summary>
        /// Parametros de calculos para ISS do VB
        /// </summary>
        public IssParametrosCalcEntity? IssParametrosCalc;


        public IssParametrosCalcBus()
        {
            // Parametros de calculos para ISS do VB
            _issParametrosCalcQuery = ServiceProviderGlobal.GetServico<IIssParametrosCalcQuery>();
        }

        #endregion


        /// <summary>
        /// Carregar IssParametroCalc
        /// </summary>
        public async Task Carregar()
        {
            // carregar do exercicio corrente
            IssParametrosCalc = await _issParametrosCalcQuery.Carregar();

            // validar
            if (IssParametrosCalc == null)
                throw new Exception("IssParametrosCalc não foi encontrado na base para esse exercicio");
        }


        /// <summary>
        /// Verificar se o servico informado tem beneficio fiscal
        /// </summary>
        public (bool TemBeneficio, decimal Aliquota, int? CdBeneficioFiscal)  VerificarServicoTemBeneficioFiscal(string? cdServico)
        {
            if (IssParametrosCalc == null) 
                throw new Exception("IssParametroCalc não foi carregado da base");

            if (string.IsNullOrWhiteSpace(cdServico))
                return (false, 0, null);

            // verificar se essa prefeitura NÃO utiliza beneficio fiscal?
            if (!string.Equals(IssParametrosCalc.Fl_UtilizaBeneficioFiscal, "S", StringComparison.InvariantCultureIgnoreCase))
                return (false, 0, null);

            // verificar se não temos o código do beneficio fiscal associado?
            if (IssParametrosCalc.Cd_BeneficioFiscal.GetValueOrDefault() <= 0) 
                return (false, 0, null);

            // verificar se não temos codigos de servico cadastrados ?
            if (string.IsNullOrWhiteSpace(IssParametrosCalc.Ds_ServicosBeneficioFiscal))
                return (false, 0, null);

            // lista 
            // 14-1, 14-12, 14.01 => para lista
            var lista = IssParametrosCalc.Ds_ServicosBeneficioFiscal.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            // limpar os caracteres especiais
            LimparCaracteresEspeciais(ref cdServico, ref lista);

            // verificar se o servico da NFSe esta na lista de servicos configurados como utilizam beneficio fiscal.
            if (lista.Contains(cdServico.Trim()))
                return (true, IssParametrosCalc.Pc_AliquotaBeneficioFiscal.GetValueOrDefault(), IssParametrosCalc.Cd_BeneficioFiscal);

            // default não tem beneficio
            return (false, 0, null);
        }


        /// <summary>
        /// Remover caracteres especiais, deixando somente letras e numeros
        /// Remove espaços, simbolos, acentos, etc.
        /// </summary>
        private void LimparCaracteresEspeciais(ref string texto, ref string[] lista)
        {
            if (!string.IsNullOrWhiteSpace(texto))
                texto = Regex.Replace(texto, @"[^a-zA-Z0-9\s]", string.Empty);

            if (lista != null && lista.Length > 0)
            {
                for (int i = 0; i < lista.Length; i++)
                {
                    lista[i] = Regex.Replace(lista[i], @"[^a-zA-Z0-9\s]", string.Empty);
                }
            }
        }
    }
}
