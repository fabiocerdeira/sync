﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Manager.Business.Iss;
using Cecam.Tributario.Manager.Business.IssNotaFiscal.Filter;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscal
{
    public class IssNotaFiscalBus
    {
        #region Declarações

        // log
        private readonly ILogger<IssNotaFiscalBus> _logger;

        // repositorios
        private readonly IIssNotaFiscalQuery _notaFiscalQuery;


        public IssNotaFiscalBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<IssNotaFiscalBus>();

            // repositorios
            _notaFiscalQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalQuery>();
        }

        #endregion


        /// <summary>
        /// Carregar uma única nota fiscal eletronica com os filhos indicados no filtro
        /// Realiza várias consultas ao banco para montar o objeto completo
        /// Realiza tratamentos de erro gerando exceções
        /// </summary>
        public async Task<IssNotaFiscalEntity?> Carregar(IssNotaFiscalBusFilter filtro)
        {
            var notaFiscalEntity = await _notaFiscalQuery.PrimeiroOuNull(ConverterFilter(filtro));

            if (notaFiscalEntity == null)
                return null;

            // todas as notas fiscais tem obrigatoriamente um e somente um item.
            // qualquer coisa diferente disso gerar erro.
            if (filtro.IncluirItens && (notaFiscalEntity.Itens == null || notaFiscalEntity.Itens.Count != 1))
                throw new Exception("IssNotaFiscalBus.CarregarUmaNotaFiscalCompleta() Erro ao carregar itens da nota fiscal");


            // carregar o servico do múnicipio
            // carregar os servicos do gov.br
            if ((filtro.IncluirServico || filtro.IncluirNbs || filtro.IncluirServicoNacional) && 
                notaFiscalEntity.Itens != null && notaFiscalEntity.Itens.Count > 0)
            {
                var itemNF = notaFiscalEntity.Itens.FirstOrDefault();

                if (itemNF != null)
                {
                    // recuperar o exercicio dessa nota fiscal
                    var cdExercicio = new EntityPropertyHelper().GetCdReferenciaAno(notaFiscalEntity.Cd_Referencia);

                    // carregar o servico do múnicipio
                    if (!string.IsNullOrWhiteSpace(itemNF.Cd_Servico))
                    {
                        var servicoQuery = ServiceProviderGlobal.GetServico<IIssServicoQuery>();
                        var servicoEntity = await servicoQuery.Listar(new IssServicoFilter()
                        {
                            Cd_Exercicio = cdExercicio,
                            Cd_Servico = itemNF.Cd_Servico
                        });

                        if (servicoEntity != null && servicoEntity.Count > 0)
                        {
                            itemNF.Servico = servicoEntity.FirstOrDefault();
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(itemNF.Cd_Nbs))
                    {
                        var nbsQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalNBSQuery>();
                        var nbsEntity = await nbsQuery.Listar(new IssNotaFiscalNBSFilter()
                        {
                            Cd_Exercicio = cdExercicio,
                            Cd_nbs = itemNF.Cd_Nbs
                        });

                        if (nbsEntity != null && nbsEntity.Count > 0)
                        {
                            itemNF.NBS = nbsEntity.FirstOrDefault();
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(itemNF.Cd_TributacaoNacional))
                    {
                        var servicoQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalServicoNacionalQuery>();
                        var servicoEntity = await servicoQuery.Listar(new IssNotaFiscalServicoNacionalFilter()
                        {
                            Cd_Exercicio = cdExercicio,
                            Cd_tributacaoNacional = itemNF.Cd_TributacaoNacional
                        });

                        if (servicoEntity != null && servicoEntity.Count > 0)
                        {
                            itemNF.ServicoNacional = servicoEntity.FirstOrDefault();
                        }
                    }

                    itemNF.ServicoNacional = new IssNotaFiscalServicoNacionalEntity();
                }
            }


            // carregar tomador
            if (filtro.IncluirTomador)
            {
                if (notaFiscalEntity.Cd_Tomador.GetValueOrDefault() > 0)
                {
                    // temos cd_tomador preenchido, então carregar da tabela IssTomador.
                    var tomadorQuery = ServiceProviderGlobal.GetServico<IIssTomadorQuery>();
                    notaFiscalEntity.Tomador = await tomadorQuery.PrimeiroOuNull(new IssTomadorFilter() { Cd_Tomador = notaFiscalEntity.Cd_Tomador.GetValueOrDefault() });
                }
                else
                {
                    // NÃO temos cd_tomador preenchido, então carregar da tabela IssContribuinte.
                    notaFiscalEntity.Tomador = await CarregarTomadorOrigemContribuinte(notaFiscalEntity.Nr_CGCCPFTomador);
                }
            }

            // carregar intermediario
            if (filtro.IncluirIntermediario)
            {
                if (notaFiscalEntity.Cd_TomadorIntermediario.GetValueOrDefault() > 0)
                {
                    // temos cd_tomadorIntermediario preenchido, então carregar da tabela IssTomador.
                    var tomadorQuery = ServiceProviderGlobal.GetServico<IIssTomadorQuery>();
                    notaFiscalEntity.Intermediario = await tomadorQuery.PrimeiroOuNull(new IssTomadorFilter() { Cd_Tomador = notaFiscalEntity.Cd_TomadorIntermediario.GetValueOrDefault() });
                }
            }

            // carregar prestador da nota
            if (filtro.IncluirPrestador)
            {
                if (notaFiscalEntity.Cd_Contribuinte.GetValueOrDefault() > 0)
                {
                    // primeira tentativa carregar usando o issContribuinte
                    var issContribuinteQuery = ServiceProviderGlobal.GetServico<IIssContribuinteQuery>();
                    notaFiscalEntity.Contribuinte = await issContribuinteQuery.PrimeiroOuNull(new IssContribuinteFilter { Cd_Contribuinte = notaFiscalEntity.Cd_Contribuinte.GetValueOrDefault() });

                    // verificar se não achou o IssContribuinte?
                    if (notaFiscalEntity.Contribuinte == null)
                    {
                        // não achou como contribuinte, então tentar carregar como eventual
                        var issEventualQuery = ServiceProviderGlobal.GetServico<IIssEventualQuery>();
                        notaFiscalEntity.Eventual = await issEventualQuery.PrimeiroOuNull(new IssEventualFilter { Cd_Eventual = notaFiscalEntity.Cd_Contribuinte.GetValueOrDefault() });
                    }
                }
            }

            /*
            no issweb antigo tem essa lógica:
            se notaFiscal.pnr_Aviso == "" e notaFiscal..pnr_Certificado != 0 então:
            SELECT nr_Aviso FROM ISSCertificado WHERE cd_cecam=xx AND nr_Certificado=xx;
            notaFiscal.pnr_Aviso = sql.nr_Aviso
            */

            // retornar nota fiscal
            return notaFiscalEntity;
        }




        




        #region Auxiliares

        /// <summary>
        /// Converter um objeto IssNotaFiscalBusFilter em IssNotaFiscalFilter para consultar a base sql
        /// </summary>
        public IssNotaFiscalFilter ConverterFilter(IssNotaFiscalBusFilter busFilter)
        {
            return new IssNotaFiscalFilter()
            {
                AsNoTracking = busFilter.AsNoTracking,

                Cd_NotaFiscal = busFilter.Cd_NotaFiscal,
                Cd_Referencia = busFilter.Cd_Referencia,
                Nr_CGCCPF = busFilter.Nr_CGCCPF,
                Nr_CGCCPFTomador = busFilter.Nr_CGCCPFTomador,
                Nr_CGCCPFTomadorIntermediario = busFilter.nr_CGCCPFTomadorIntermediario,
                Govbr_ChaveAcesso = busFilter.Govbr_ChaveAcesso,
                NrChaveValidacaoPreenchido = busFilter.NrChaveValidacaoPreenchido,

                IncluirItens = busFilter.IncluirItens,
                IncluirImpostos = busFilter.IncluirImpostos,
                IncluirPrestador = busFilter.IncluirPrestador,
                IncluirTomador = busFilter.IncluirTomador
            };
        }

        #endregion


        #region Privados


        /// <summary>
        /// Carregar o tomador usando o CgcCpfTomador a partir da tabela IssContribuinte
        /// </summary>
        private async Task<IssTomadorEntity?> CarregarTomadorOrigemContribuinte(string? nrCnpjCpf)
        {
            if (string.IsNullOrWhiteSpace(nrCnpjCpf))
                return null;

            // business de iss contribuinte
            var issContribuinteBus = new IssContribuinteBus();

            // contribuinte carregado
            var contribuinteEntity = await issContribuinteBus.CarregarContribuinteEmAtividade(new Iss.Filter.IssContribuinteBusFilter() { Nr_CnpjCpf = nrCnpjCpf });

            // verificar se não achou contribuinte?
            if (contribuinteEntity == null)
                return null;

            return new IssTomadorEntity()
            {
                Cd_Cecam = contribuinteEntity.Cd_Cecam,
                Nr_CGCCPF = contribuinteEntity.Nr_CGCCPF ?? string.Empty,
                Ds_RazaoSocial = contribuinteEntity.Ds_razaosocial,
                Fl_TipoPessoa = (byte)(contribuinteEntity.Fl_FisicaJuridica?.Trim().ToUpper() == "F" ? 1 : 0),

                // cd_MunicipioTomador
                // sg_UF
                // ds_Logradouro
                // cd_Numero
                // ds_Complemento
                // ds_Bairro
                // cd_CEP

                Dt_Atualizacao = contribuinteEntity.Dt_atualizacao.HasValue ? contribuinteEntity.Dt_atualizacao.Value : DateTime.MinValue,
                Cd_Usuario = string.Empty,
                Ds_Email = contribuinteEntity.Ds_email,
                Cd_RG_IE = contribuinteEntity.Cd_rg_ie,
                Ds_inscricao_municipal = contribuinteEntity.Ds_inscricao_municipal,
                Cd_Tomador = 0,

                // cd_TipoCalculo
                // sg_pais_ISO2
                // ds_enderecoExt
                // ds_cidadeExt
                // ds_estadoExt
            };
        }


        #endregion
    }
}
