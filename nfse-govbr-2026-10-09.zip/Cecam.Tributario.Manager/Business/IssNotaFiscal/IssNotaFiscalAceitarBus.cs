﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Extend;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.Iss;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Cecam.Tributario.Database.Enumerado.IssNotaFiscal.IssNotaFiscalEnum;
using static Cecam.Tributario.Database.Enumerado.IssNotaFiscal.IssNotaFiscalItemEnum;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscal
{
    /// <summary>
    /// Aceitar ou Rejeitar uma nota fiscal (NFS-e) pelo tomador, intermediario, tácito ou contribuinte
    /// </summary>
    public class IssNotaFiscalAceitarBus
    {
        #region Declarações

        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<IssNotaFiscalAceitarBus> _logger;


        public IssNotaFiscalAceitarBus()
        {
            _logger = ServiceProviderGlobal.CreateLogger<IssNotaFiscalAceitarBus>();
        }

        #endregion


        /// <summary>
        /// Recebe uma NFSe que tem imposto retido pelo tomador e criar uma nova NFSe para o tomador usando os mesmos valores da original.<br/>
        /// Ou recebe uma NFSe que tem imposto retido pelo intermediario e criar uma nova NFSe para o intermediario usando os mesmos valores da original.<br/>
        /// Vários campos são trocados nesse processo para indicar que a nova NFSe é do tomador ou do intermediario e que ele precisa recolher o imposto.<br/>
        /// Retorna o cdNotaFiscal da nova nota criada para o tomador ou para o intermediario.
        /// </summary>
        public async Task<decimal> AceitarNotaFiscal(IssNotaFiscalEntity notaOriginal, enumAceitadorNotaFiscal aceitador, string cnpjCpfAceitador)
        {
            if (string.IsNullOrWhiteSpace(notaOriginal.Govbr_ChaveAcesso))
                throw new Exception("Não é possível aceitar NFS-e a partir de uma nota que originalmente não foi criada no sistema gov.br");

            if (string.IsNullOrWhiteSpace(cnpjCpfAceitador))
                throw new Exception("Não é possível aceitar NFS-e por falta do CNPJ/CPF do reponsável pelo aceite");


            // clonar a nota original em uma nova nota.
            var novaNota = ClonarLimpandoPks(notaOriginal);

            // limpar alguns campos 
            novaNota.Cd_TipoCalculo = 0;
            novaNota.Dt_Criacao = DateTime.UtcNow.AddHours(-3);
            novaNota.Dt_Atualizacao = DateTime.UtcNow.AddHours(-3);

            // cnpj do aceitador da nota 
            // atenção: para esse cnpj/cpf é obrigatorio existir uma linha na tabela IssUsarioWeb
            // não importa se é uma emissão ou escrituração de nota
            novaNota.Nr_CGCCPFUsuarioAtualizacao = cnpjCpfAceitador.Trim();
            novaNota.Nr_CGCCPFUsuarioCriacao = cnpjCpfAceitador.Trim();

            // quem aceitou a nota?
            switch (aceitador)
            {
                case enumAceitadorNotaFiscal.Contribuinte:
                    novaNota.Fl_Tomador = (byte)enumFlTomador.NfseEmitidaPeloPrestador;
                    break;
                case enumAceitadorNotaFiscal.Tomador:
                case enumAceitadorNotaFiscal.Intermediario:
                    novaNota.Fl_Tomador = (byte)enumFlTomador.NfseEscrituradaPeloTomador;
                    novaNota.Nr_ChaveValidacao = string.Empty;
                    break;
                case enumAceitadorNotaFiscal.Tacito:
                    if (novaNota.Fl_Tomador == (byte)enumFlTomador.NfseEmitidaPeloPrestador)
                    {
                        novaNota.Fl_Tomador = (byte)enumFlTomador.NfseEscrituradaPeloTomador;
                        novaNota.Nr_ChaveValidacao = string.Empty;
                    }
                    else
                    {
                        novaNota.Fl_Tomador = (byte)enumFlTomador.NfseEmitidaPeloPrestador;
                    }
                    break;
            }

            // percorrer todos os itens da nota
            if (novaNota.Itens?.Any() == true)
            {
                foreach (var novaNotaItem in novaNota.Itens)
                {
                    if (novaNotaItem.Fl_Retido == (byte)enumFlRetido.RetidoPeloTomador)
                    {
                        // inverter o retido, agora é retido pelo prestador
                        novaNotaItem.Fl_Retido = (byte)enumFlRetido.RetidoPeloPrestador;
                        novaNotaItem.Vl_Devido = novaNotaItem.Vl_Tomado;
                        novaNotaItem.Vl_Tomado = 0;
                    }
                    else
                    {
                        // inverter o retido, agora é retido pelo tomador
                        novaNotaItem.Fl_Retido = (byte)enumFlRetido.RetidoPeloTomador;
                    }
                }
            }

            // Procurar pelo contribuinte ou eventual e retornar o seu respectivo código
            novaNota.Cd_Contribuinte = await RetornarCodigoContribuinteOuEventual(cnpjCpfAceitador);

            // eventual tambem não foi encontrado, tentar criar
            if (novaNota.Cd_Contribuinte == null)
                novaNota.Cd_Contribuinte = await CriarEventualApartirTomadorOuIntermediario(notaOriginal, aceitador);

            if (novaNota.Cd_Contribuinte == null)
                throw new Exception($"Erro * Não foi possivel aceitar NFS-e usando o CNPJ/CPF {cnpjCpfAceitador} informado");

            // salvar a nova nota fiscal
            var issNotaFiscalCriarBus = new IssNotaFiscalCriarBus();

            // verificar se a nota original é emissão, então o aceite tem que ser uma escrituração OU
            // se a nota original é escrituração, então o aceite tem que ser uma criação de nota.
            if (await VerificarEmitirOuEscriturar(notaOriginal))
            {
                // salvar uma nova nota emitida
                await issNotaFiscalCriarBus.Emitir(novaNota);
            }
            else
            {
                // salvar uma nova nota escriturada
                await issNotaFiscalCriarBus.Escriturar(novaNota);
            }

            // retornar a PK da nova nota gravada na base
            return novaNota.Cd_NotaFiscal;
        }

        /// <summary>
        /// verificar se a nota original é emissão, então o aceite tem que ser uma escrituração OU<br/>
        /// se a nota original é escrituração, então o aceite tem que ser uma criação de nota.<br/>
        /// true = emitir nota<br/>
        /// false = escriturar nota<br/>
        /// </summary>
        private async Task<bool> VerificarEmitirOuEscriturar(IssNotaFiscalEntity notaOriginal)
        {
            /*
            a) prestador é do municipio, emite nota (com nr_chave_validacao) SEM imposto retido pelo tomador que é do municipio ou fora do municipio 
                - não existe aceite pelo tomador nesse cenário
                - nota original do prestador é uma emissão com nr_chave_validacao
                - tomador não precisa gerar nenhum tipo de nota na base/prefeitura
                - retornar erro

            b) prestador é do municipio, emite nota (com nr_chave_validacao) com imposto retido pelo tomador que é do municipio 
                - existe aceite pelo tomador nesse cenário
                - nota original do prestador é uma emissão com nr_chave_validacao
                - nota tomador que é do mesmo municipio será uma emissão sem nr_chave_validação

            c) prestador é do municipio, emite nota (com nr_chave_validacao) com imposto retido pelo tomador que NÃO é do municipio
                liox- não existe aceite pelo tomador nesse cenário
                lixo- nota original é uma escriturada nesse municipio sem nr_chave_validacao
                lixo- não existe aceite nesse cenário, porque quem aceita é o tmador que é de outro municipio, então não entra no IssNotaFiscalAceitarBus
                - nota prestador com chvave de validação
                - nota tomador , cadastro eventual, ao aceita, sem chave de validação

            d) prestador NÃO é do municipio, emite nota com imposto retido pelo tomador que é do municipio sendo processado pelo importador
                - existe aceite pelo tomador
                - sempre que for aceite de outro municipio para um municipio da cecam, escriturar sem nr_chave_validação
                - mesmo que o tomador esteja na IssContribuinte ou na IssEventual
                - neste caso as 2 notas (original e aceita) ficam sem nr_chave_validacao e serão escrituração

            ** resumo FINAL usar essa regra aqui:
            ** 1) prestador da nota original (esta na issContribuinte) é desse municipio sendo procesado então emitir COM nr_chave_validação
            ** 2) prestador da nota original (não esta na issContribuinte) é de outro municipio sendo processado então nova nota é escriturar SEM nr_chave_validação
            ** 2.1) nesse caso as 2 notas sem nr_chave_validação (vazio sem preencher)
            */

            // business de iss contribuinte
            var issContribuinteBus = new IssContribuinteBus();

            // carregar contribuinte (mas precisa estar ativo)
            var contribuinteEntity = await issContribuinteBus.CarregarContribuinteEmAtividade(new Iss.Filter.IssContribuinteBusFilter() { Cd_Contribuinte = notaOriginal.Cd_Contribuinte });

            // verificar se achou contribuinte?
            if (contribuinteEntity != null)
            {
                // achou contribuinte, então retornar que é 'Emissão'
                return true;
            }

            // se não achou o contribuinte da nota, então ele é Eventual
            // logo a nota sendo aceita tem que ser uma escrituração
            return false;
        }


        /// <summary>
        /// Procurar pelo contribuinte ou eventual e retornar o seu respectivo código
        /// Se não encontrar retornar null
        /// </summary>
        private async Task<decimal?> RetornarCodigoContribuinteOuEventual(string cnpjCpfAceitador)
        {
            /*
            pesquisar o cnpj na tabela IssContribuinte, se encontrar então:
            novaNota.Cd_Contribuinte = IssContribuinte.Cd_Contribuinte

            se não achar em IssContribuinte, então pesquisar o cnpj na tabela IssEventual, se encontrar então:
            novaNota.Cd_Contribuinte = IssEventual.Cd_Eventual
            */

            // business de iss contribuinte
            var issContribuinteBus = new IssContribuinteBus();

            // carregar contribuinte (mas precisa estar ativo)
            var contribuinteEntity = await issContribuinteBus.CarregarContribuinteEmAtividade(new Iss.Filter.IssContribuinteBusFilter() { Nr_CnpjCpf = cnpjCpfAceitador });

            // verificar se achou contribuinte?
            if (contribuinteEntity != null)
            {
                // contribuinte encontrado

                // criar usuario web a partir do contribuinte
                await CriarUsuarioWebApartirContribuinte(contribuinteEntity);

                // informar na nota o cd_contribuinte do cnpj/cpf que aceitou a nota.
                return contribuinteEntity.Cd_Contribuinte;
            }
            else
            {
                // cnpj/cpf não foi encontrado como IssContribuinte, 
                // então vamos procurar como IssEventual.

                // query do eventual
                var issEventualQuery = ServiceProviderGlobal.GetServico<IIssEventualQuery>();

                // carregar eventual
                var eventualEntity = await issEventualQuery.PrimeiroOuNull(new IssEventualFilter { Nr_CGCCPF = cnpjCpfAceitador });

                if (eventualEntity != null)
                {
                    // eventual encontrado

                    // criar novo usuario web a partir do eventual
                    await CriarUsuarioWebApartirEventual(eventualEntity);

                    // informar na nota o cd_eventual do cnpj/cpf que aceitou a nota.
                    return eventualEntity.Cd_Eventual;
                }
            }

            // não encontrou
            return null;
        }


        /// <summary>
        /// Criar o IssEventual a partir do tomador ou do intermediário
        /// Retorna o código do eventual criado
        /// </summary>
        private async Task<decimal?> CriarEventualApartirTomadorOuIntermediario(IssNotaFiscalEntity notaOriginal, enumAceitadorNotaFiscal aceitador)
        {
            // atalho
            IssTomadorEntity? tomador = null;

            switch (aceitador)
            {
                case enumAceitadorNotaFiscal.Tomador:
                case enumAceitadorNotaFiscal.Tacito:
                    tomador = notaOriginal.Tomador;
                    break;
                case enumAceitadorNotaFiscal.Intermediario:
                    tomador = notaOriginal.Intermediario;
                    break;
            }

            // verificar se existe?
            if (tomador == null)
                throw new Exception("Não é possível criar um eventual a partir do tomador, porque o tomador não foi encontrado");

            // --------------------

            // criar novo eventual com os dados da nota fiscal original
            var eventualEntity = new IssEventualEntity
            {
                Nr_CGCCPF = tomador.Nr_CGCCPF,
                Ds_Razaosocial = tomador.Ds_RazaoSocial,
                Ds_Inscricao_Municipal = tomador.Ds_inscricao_municipal,
                // dados de contato
                Ds_Email = tomador.Ds_Email,
                Ds_EmailTributario = tomador.Ds_Email,
                Ds_EmailCorr = tomador.Ds_Email,
                Cd_TelefoneTributario = null,
                // endereço
                Ds_EnderTributario = tomador.Ds_Logradouro,
                Cd_NumeroTributario = tomador.Cd_Numero, 
                Ds_BairroTributario = tomador.Ds_Bairro,
                Sg_EstadoTributario = tomador.Sg_UF,
                Cd_CepTributario = tomador.Cd_CEP
            };

            // verificar se tomador original tem complemento no endereco?
            if (!string.IsNullOrWhiteSpace(tomador.Ds_Complemento))
                eventualEntity.Ds_EnderTributario = eventualEntity.Ds_EnderTributario + " comp:" + tomador.Ds_Complemento;

            // eventual business
            var eventualBus = new IssEventualBus();

            // criar ou editar o eventual
            var cdEventual = await eventualBus.CriarOuEditar(eventualEntity);

            // verificar se o novo eventual foi criado/editado com sucesso
            if (cdEventual <= 0)
                throw new Exception("Erro ao criar/editar eventual que é aceitador da NFSe");

            // --------------------------

            // criar novo usuario web a partir do eventual
            await CriarUsuarioWebApartirEventual(eventualEntity);

            // ----------------

            // retornar o código do novo eventual.
            return cdEventual;
        }


        /// <summary>
        /// Criar IssUsuarioWeb a partir do IssEventual
        /// </summary>
        private async Task CriarUsuarioWebApartirEventual(IssEventualEntity eventualEntity)
        {
            if (string.IsNullOrWhiteSpace(eventualEntity.Nr_CGCCPF))
                throw new Exception("CriarUsuarioWebApartirEventual() com CNPJ/CPF vazio não é permitido");

            // criar novo usuario web
            var usuarioWebEntity = new IssUsuarioWebEntity
            {
                Nr_CGCCPF = "" + eventualEntity.Nr_CGCCPF,
                Nm_Usuario = "" + eventualEntity.Ds_Razaosocial,
                Nm_Login = "" + eventualEntity.Nr_CGCCPF,
                Pw_Login = "",
                Ds_email = eventualEntity.Ds_Email,
                Fl_Tipo = 2,
                Nr_Acesso = 0,
                Cd_Contribuinte = eventualEntity.Cd_Eventual,
                Dt_Cadastro = DateTime.UtcNow.AddHours(-3),
                Ds_Usuario = eventualEntity.Nr_CGCCPF
            };

            // usuario web business
            var usuarioWebBus = new IssUsuarioWebBus();

            // tratar o tamanho dos campos string.
            usuarioWebBus.TratarTamanhoCampos(usuarioWebEntity);

            // criar o usuario web caso ele não exista na base
            await usuarioWebBus.CriarSeNaoExistir(usuarioWebEntity);
        }


        /// <summary>
        /// Criar IssUsuarioWeb a partir do IssContribuinte
        /// </summary>
        private async Task CriarUsuarioWebApartirContribuinte(IssContribuinteEntity contribunteEntity)
        {
            if (string.IsNullOrWhiteSpace(contribunteEntity.Nr_CGCCPF))
                throw new Exception("CriarUsuarioWebApartirContribuinte() com CNPJ/CPF vazio não é permitido");

            // criar novo usuario web
            var usuarioWebEntity = new IssUsuarioWebEntity
            {
                Nr_CGCCPF = "" + contribunteEntity.Nr_CGCCPF,
                Nm_Usuario = "" + contribunteEntity.Ds_razaosocial,
                Nm_Login = "" + contribunteEntity.Nr_CGCCPF,
                Pw_Login = "",
                Ds_email = contribunteEntity.Ds_email,
                Fl_Tipo = 2,
                Nr_Acesso = 0,
                Cd_Contribuinte = contribunteEntity.Cd_Contribuinte,
                Dt_Cadastro = DateTime.UtcNow.AddHours(-3),
                Ds_Usuario = contribunteEntity.Nr_CGCCPF
            };

            // usuario web business
            var usuarioWebBus = new IssUsuarioWebBus();

            // tratar o tamanho dos campos string.
            usuarioWebBus.TratarTamanhoCampos(usuarioWebEntity);

            // criar o usuario web caso ele não exista na base
            await usuarioWebBus.CriarSeNaoExistir(usuarioWebEntity);
        }


        /// <summary>
        /// Rejeitar nota fiscal que foi criada por outra entidade e associou esse 
        /// </summary>
        /// <returns></returns>
        public async Task RejeitarNotaFiscal(IssNotaFiscalEntity notaOriginal, DateTime dataRejeicao, string motivoRejeicao)
        {
            await Task.CompletedTask;

            var rejeicaoEntity = new IssNotaFiscalRejeicaoEntity()
            {
                Cd_Cecam = ParametrosGlobal.Cd_Cecam,
                Cd_NotaFiscal = notaOriginal.Cd_NotaFiscal,
                Ds_Rejeicao = motivoRejeicao,
                Dt_AceitoRejeitado = dataRejeicao,
                Fl_AceitoRejeitado = "R"
            };
            
            // salvar o motivo da rejeicao.
            // desliguei o salvar porque precisa escrever todo o corpo desse método
            var rejeicaoRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalRejeicaoRepository>();
            // rejeicaoRepository.Add(rejeicaoEntity);
            // await rejeicaoRepository.SaveChangesAsync();

            // erro para lembrar que esse código não esta pronto.
            throw new NotImplementedException("IssNotaFiscalAceitarBus.RejeitarNotaFiscal() Código fonte ainda não implementado.");
        }



        /// <summary>
        /// Clonar a IssNotaFiscal informada, gerando uma nova sem as PKs preenchidas
        /// </summary>
        public IssNotaFiscalEntity ClonarLimpandoPks(IssNotaFiscalEntity notaOriginal)
        {
            // clonar a nota original em uma nova nota.
            var novaNota = notaOriginal.Clone();

            // limpar os campos de PK da nota
            novaNota.Cd_NotaFiscal = 0;

            // limpar os campos de PK e Fk dos objetos filhos
            if (novaNota.Itens?.Any() == true)
            {
                foreach (var notaItem in novaNota.Itens)
                {
                    notaItem.Cd_NotaFiscal = 0;
                }
            }

            if (novaNota.Impostos?.Any() == true)
            {
                foreach (var impostoItem in novaNota.Impostos)
                {
                    impostoItem.Cd_NotaFiscal_Imposto = Guid.Empty;
                    impostoItem.Cd_NotaFiscal = 0;
                }
            }

            // retornar a nova nota.
            return novaNota;
        }
    }
}
