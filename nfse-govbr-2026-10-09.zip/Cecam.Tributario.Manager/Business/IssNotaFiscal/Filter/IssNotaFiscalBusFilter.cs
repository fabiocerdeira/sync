﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscal.Filter
{
    public class IssNotaFiscalBusFilter
    {
        #region Propriedades

        public decimal Cd_NotaFiscal { get; set; }

        public int? Cd_Referencia { get; set; }

        public string? Nr_CGCCPF { get; set; }

        public string? Nr_CGCCPFTomador { get; set; }

        public string? nr_CGCCPFTomadorIntermediario { get; set; }

        public string? Govbr_ChaveAcesso { get; set; }

        /// <summary>
        /// Filtra pelo campo NrChaveValidacao
        /// True = somente NrChaveValidacao preenchido
        /// False = somente NrChaveValidacao em branco ou null
        /// Null = não filtra pelo campo
        /// </summary>
        public bool? NrChaveValidacaoPreenchido { get; set; }

        #endregion


        /// <summary>
        /// AsNoTracking (default = true)
        /// </summary>
        public bool AsNoTracking { get; set; } = true;


        #region Incluir objetos filhos

        public bool IncluirItens { get; set; }

        /// <summary>
        /// Carregar o prestador da nota que pode ser um IssContribuinte ou IssEventual
        /// </summary>
        public bool IncluirPrestador { get; set; }


        public bool IncluirTomador { get; set; }

        public bool IncluirIntermediario { get; set; }

        public bool IncluirImpostos { get; set; }

        public bool IncluirServico { get; set; }

        #endregion


        #region impostos da NFSe gov.br

        public bool IncluirNbs { get; set; }

        public bool IncluirServicoNacional { get; set; }

        #endregion 

    }
}
