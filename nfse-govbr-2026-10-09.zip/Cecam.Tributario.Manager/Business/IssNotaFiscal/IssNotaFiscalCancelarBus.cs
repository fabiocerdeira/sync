﻿using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.Iss;
using Microsoft.Extensions.Logging;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscal
{
    public class IssNotaFiscalCancelarBus
    {
        #region Declarações

        // log
        private readonly ILogger<IssNotaFiscalCancelarBus> _logger;

        // repositorios
        private readonly IIssNotaFiscalQuery _notaFiscalQuery;


        public IssNotaFiscalCancelarBus()
        {
            // log
            _logger = ServiceProviderGlobal.CreateLogger<IssNotaFiscalCancelarBus>();

            // repositorios
            _notaFiscalQuery = ServiceProviderGlobal.GetServico<IIssNotaFiscalQuery>();
        }

        #endregion


        /// <summary>
        /// Realizar o cancelamento da NFSe informada
        /// </summary>
        public async Task CancelarNfse(string? motivo, decimal? cdNotaFiscal = null, string? govBrChaveAcesso = null, decimal? NrNotaFiscalSubstituta = 0)
        {
            if (cdNotaFiscal.GetValueOrDefault() <= 0 && string.IsNullOrWhiteSpace(govBrChaveAcesso))
                throw new Exception("Codigo da NFSe ou Chave de Acesso do GovBr precisam ser informados");

            var notaFiscalEntity = await _notaFiscalQuery.PrimeiroOuNull(new IssNotaFiscalFilter()
            {
                AsNoTracking = false,
                Cd_NotaFiscal = cdNotaFiscal,
                Govbr_ChaveAcesso = govBrChaveAcesso,
                IncluirPrestador = true // precisa do tomador para criar o comunicado de cancelamento
            });

            // valdiar se encontrou?
            if (notaFiscalEntity == null)
                throw new Exception("IssNotaFiscalCancelarBus.CancelarNfse() Erro pq não encontrou NFSe na base para ser cancelada");

            // mudar os campos para cancelar
            notaFiscalEntity.Cd_Situacao = 1;
            notaFiscalEntity.Dt_cancelamento = DateTime.UtcNow.AddHours(-3);
            notaFiscalEntity.Ds_MotivoCancelamento = motivo;
            notaFiscalEntity.Nr_Certificado = null;

            // numero da nota fiscal que esta substituindo essa nota fiscal que esta sendo cancelada
            notaFiscalEntity.Nr_NotaFiscalSubstituta = NrNotaFiscalSubstituta.GetValueOrDefault();

            // salvar na base
            _notaFiscalQuery.Repositorio.Update(notaFiscalEntity);
            await _notaFiscalQuery.Repositorio.SaveChangesAsync();

            // criar comunicado de cancelamento da nfse
            var comunicadoBus = new IssComunicadoBus();
            await comunicadoBus.CriarComunicadoCancelamento(notaFiscalEntity);
        }
    }
}
