﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Manager.Business.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Manager.Business.IssNotaFiscal
{
    /// <summary>
    /// Criar na base uma NFS-e (Nota Fiscal de Seriço Eletronica) com seus filhos (itens, impostos tomador, intermediários, etc)
    /// </summary>
    public class IssNotaFiscalCriarBus
    {
        #region Declarações

        private readonly ILogger<IssNotaFiscalCriarBus> _logger;
        private readonly IIssNotaFiscalRepository _notaFiscalRepository;
        private IssNotaFiscalEntity? _notaFiscalEntity = null;


        public IssNotaFiscalCriarBus()
        {
            _logger = ServiceProviderGlobal.CreateLogger<IssNotaFiscalCriarBus>();
            _notaFiscalRepository = ServiceProviderGlobal.GetServico<IIssNotaFiscalRepository>();
        }

        #endregion



        /// <summary>
        /// Emitir na base uma Nota Fiscal de Seriço Eletronica com seus filhos (item, tomador, etc)
        /// </summary>
        public async Task Emitir(IssNotaFiscalEntity notaFiscalEntity)
        {
            // log inicial
            _logger.LogInformation("IssNotaFiscalCriarBus.Criar() - inicio");

            // criar nota
            await CriarProcessar(notaFiscalEntity, false);

            // log final
            _logger.LogInformation("IssNotaFiscalCriarBus.Criar() - fim");
        }


        /// <summary>
        /// Escriturar na base uma Nota Fiscal de Seriço Eletronica com seus filhos (item, tomador, etc)
        /// </summary>
        public async Task Escriturar(IssNotaFiscalEntity notaFiscalEntity)
        {
            // log inicial
            _logger.LogInformation("IssNotaFiscalCriarBus.Escriturar() - inicio");

            // escriturar nota
            await CriarProcessar(notaFiscalEntity, true);

            // log final
            _logger.LogInformation("IssNotaFiscalCriarBus.Escriturar() - fim");
        }



        #region Auxiliares


        /// <summary>
        /// Emitir ou Escriturar uma nota fiscal
        /// </summary>
        private async Task CriarProcessar(IssNotaFiscalEntity notaFiscalEntity, bool heEscrituracao)
        {
            if (notaFiscalEntity.Itens == null || notaFiscalEntity.Itens.Count <= 0)
                throw new Exception("IssNotaFiscalCriarBus.Escriturar() Falta o ITEM da NFSe");

            // setar NFSe enetity na variavel global da classe
            _notaFiscalEntity = notaFiscalEntity;

            // Preencher a NFSe e todos os objetos filhos com o campo cd_cecam
            TratamentoCdCecam();

            // Tratamento para o campo 'Nr_ChaveValidacao'
            await TratamentoNrChaveValidacao(heEscrituracao);

            // Salvar o tomador e intermediario caso eles existam na NFSe
            await TratamentoTomadorIntermediario();

            // Tratamentos para o campo 'cd_notaFiscal' 
            await TratamentoCdNotaFiscal();

            // gravar na base
            // Salvar entity na base criando uma nova NFSe
            await Salvar(true);
        }


        /// <summary>
        /// Salvar entity na base criando uma nova NFSe
        /// </summary>
        private async Task Salvar(bool heNovo)
        {
            if (_notaFiscalEntity == null)
                return;

            // repo
            using (var uow = ServiceProviderGlobal.GetServico<IUnitOfWork>())
            using (var repo = ServiceProviderGlobal.GetServico<IIssNotaFiscalRepository>())
            {
                try
                {
                    // set uow para transações entre varios business.
                    repo.SetUnitOfWork(uow);

                    // iniciar transação
                    await uow.BeginTransactionAsync();

                    // verificar se é alteração ou novo ?
                    if (heNovo)
                        repo.Add(_notaFiscalEntity);
                    else
                        repo.Update(_notaFiscalEntity);

                    // salvar
                    await uow.SaveChangesAsync();
                    await uow.CommitTransactionAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogError("IssNotaFiscalCriarBus.Salvar()");
                    _logger.LogError(ex.ToString());
                    await uow.RollbackTransactionAsync();
                    throw;
                }
            }
        }


        /// <summary>
        /// Preencher a NFSe e todos os objetos filhos com o campo cd_cecam
        /// </summary>
        private void TratamentoCdCecam()
        {
            if (_notaFiscalEntity == null)
                return;

            // cd_cecam
            if (_notaFiscalEntity.Cd_Cecam <= 0)
                _notaFiscalEntity.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            // atribuir cd_cecam nos Itens 
            if (_notaFiscalEntity.Itens != null)
            {
                foreach (var item in _notaFiscalEntity.Itens)
                {
                    if (item.Cd_Cecam <= 0)
                        item.Cd_Cecam = ParametrosGlobal.Cd_Cecam;
                }
            }

            // atribuir cd_cecam nos Impostos
            if (_notaFiscalEntity.Impostos != null)
            {
                foreach (var impostoItem in _notaFiscalEntity.Impostos)
                {
                    if (impostoItem.Cd_Cecam <= 0)
                        impostoItem.Cd_Cecam = ParametrosGlobal.Cd_Cecam;
                }
            }
        }


        /// <summary>
        /// Salvar o tomador da NFSe caso ele exista
        /// Salvar o intermediario da NFSe caso ele exista
        /// </summary>
        private async Task TratamentoTomadorIntermediario()
        {
            if (_notaFiscalEntity == null)
                return;

            // tomadores:
            var issTomadorBus = new IssTomadorBus();

            if (_notaFiscalEntity.Tomador != null)
            {
                // salvar na base.
                // se já existir na base, então atualizar
                await issTomadorBus.CriarOuEditar(_notaFiscalEntity.Tomador);

                // recuperar a PK do tomador e associar na NFSE
                _notaFiscalEntity.Cd_Tomador = _notaFiscalEntity.Tomador.Cd_Tomador;
            }

            if (_notaFiscalEntity.Intermediario != null)
            {
                // salvar na base.
                // se já existir na base, então atualizar
                await issTomadorBus.CriarOuEditar(_notaFiscalEntity.Intermediario);

                // recuperar a PK do intermediario e associar na NFSE
                _notaFiscalEntity.Cd_TomadorIntermediario = _notaFiscalEntity.Intermediario.Cd_Tomador;
            }
        }


        /// <summary>
        /// Tratamentos para o campo 'cd_notaFiscal' 
        /// Se campo 'cd_notaFiscal' estiver preenchido, então verificar se já existe ou não na base?
        /// Se já existe na base para esse contribuinte para esse exercicio então retornar erro.
        /// Se não existe na base então será usado na gravação
        /// Se campo 'cd_notaFiscal' não  estiver preenchido, então gerar o próximo valor para esse contribuinte para esse exercicio.
        /// </summary>
        /// <returns></returns>
        private async Task TratamentoCdNotaFiscal()
        {
            if (_notaFiscalEntity == null || _notaFiscalEntity.Itens == null)
                return;

            // se não estiver preenchido então gerar o próximo?
            if (_notaFiscalEntity.Cd_NotaFiscal <= 0)
            {
                // recuperar o último 'cd_notaFiscal' desse contribuinte, nesse exercio
                decimal? cd_NotaFiscal = await _notaFiscalRepository.GetIQueryable()
                    .OrderByDescending(x => x.Cd_NotaFiscal)
                    .Select(x => x.Cd_NotaFiscal)
                    .FirstOrDefaultAsync();

                // primeira cd_notaFiscal da tabela
                if (!cd_NotaFiscal.HasValue)
                    cd_NotaFiscal = 0;

                // incrementar para próximo cd_notaFiscal e guardar na nota fiscal entity
                _notaFiscalEntity.Cd_NotaFiscal = cd_NotaFiscal.Value + 1;

                // atribuit cd_notaFiscal nos itens filhos da nota fiscal
                foreach (var nfseItem in _notaFiscalEntity.Itens)
                {
                    nfseItem.Cd_NotaFiscal = _notaFiscalEntity.Cd_NotaFiscal;
                }

                if (_notaFiscalEntity.Impostos != null)
                {
                    foreach (var impostoItem in _notaFiscalEntity.Impostos)
                    {
                        impostoItem.Cd_NotaFiscal = _notaFiscalEntity.Cd_NotaFiscal;
                    }
                }
            }
            else
            {
                // cd_notaFiscal esta preenchido,

                // verificar se existe ou não existe na base?
                if ((await _notaFiscalRepository.GetIQueryable()
                    .Where(x => x.Cd_Cecam == ParametrosGlobal.Cd_Cecam &&
                        x.Cd_Referencia.ToString().Substring(0, 4) == ParametrosGlobal.Cd_Exercicio.ToString() &&
                        x.Cd_NotaFiscal == _notaFiscalEntity.Cd_NotaFiscal).AnyAsync()) == true)
                {
                    // erro porque já existe esse cd_notaFiscal na base.
                    throw new Exception("Cd_NotaFiscal para esse contribuinte para esse exercicio já existe na IssNotaFiscal.");
                }
            }
        }


        /// <summary>
        /// Criar uma Chave de validação única para essa NFSe que esta sendo criada
        /// Somente é preenchido quando a NFSe é preenchida pelo prestador.
        /// Notas escrituradas pelo tomador esse campo fica vazio.
        /// </summary>
        private async Task TratamentoNrChaveValidacao(bool heEscrituracao)
        {
            // se não tiver nota ou chave validação já estiver preenchida, então sair.
            if (_notaFiscalEntity == null || !string.IsNullOrWhiteSpace(_notaFiscalEntity.Nr_ChaveValidacao))
                return;

            if (heEscrituracao)
            {
                // para escrituração esse campo fica vazio
                _notaFiscalEntity.Nr_ChaveValidacao = null;
                return;
            }

            // até 50 tentativas
            for (int i = 0; i < 50; i++)
            {
                // gerar nova chave
                _notaFiscalEntity.Nr_ChaveValidacao = Guid.NewGuid().ToString().Substring(19, 10).ToUpper();

                // verificar se chave ainda não existe na base, pq tem que ser única.
                if ((await _notaFiscalRepository.GetIQueryable().Where(x => 
                        x.Cd_Cecam == ParametrosGlobal.Cd_Cecam && 
                        x.Nr_ChaveValidacao == _notaFiscalEntity.Nr_ChaveValidacao).AnyAsync()) == false)
                    return;
            }

            // se chegou aqui então tentou várias combinações diferentes de 'chave' e todas foram repetidas.
            // que falta de sorte!
            throw new Exception("IssNotaFiscalCriarBus.TratamentoNrChaveValidacao() - não foi possível criar uma NrChaveValidacao única para NFSe");
        }


        #endregion
    }
}
