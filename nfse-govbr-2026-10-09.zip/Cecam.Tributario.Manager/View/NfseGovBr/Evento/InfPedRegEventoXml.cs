﻿using Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento
{
    /// <summary>
    /// Parte Geral do Pedido de Registro de Evento<br/>
    /// Grupo de informações do pedido de registro do evento
    /// </summary>
    public class InfPedRegEventoXml
    {
        /// <summary>
        /// "O identificador do pedido de registro de evento é composto pela concatenação de campos que constam no leiaute.<br/>
        /// A formação deste identificador considera o literal ""PRE"" associado a outras 56 posições numéricas, conforme descrito abaixo:<br/>
        /// "PRE" + <br/>
        /// Chave de acesso da NFS-e(50) +<br/>
        /// Código do evento(6)
        /// </summary>
        [XmlAttribute("Id")]
        public string Id { get; set; } = string.Empty;


        #region Elementos


        /// <summary>
        /// Identificador da NFS-e a qual o evento será vinculada.
        /// </summary>
        [XmlElement("chNFSe")]
        public string chNFSe { get; set; } = string.Empty;


        /// <summary>
        /// Número de inscrição federal (CNPJ) do autor do evento.<br/>
        /// CNPJ do autor do evento(parte interessada ou pessoa que figure na NFS-e.<br/>
        /// O autor do evento não é o procurador)
        /// </summary>
        [XmlElement("CNPJAutor")]
        public string CNPJAutor { get; set; } = string.Empty;


        /// <summary>
        /// "Número de inscrição federal (CPF) do autor do evento.<br/>
        /// CPF do autor do evento(parte interessada ou pessoa que figure na NFS-e como prestador, tomador, intermediário.O autor do evento poderá ser o procurador)."
        /// </summary>
        [XmlElement("CPFAutor")]
        public string CPFAutor { get; set; } = string.Empty;


        /// <summary>
        /// Data e hora do evento no formato AAAA-MM-DDThh:mm:ssTZD <br/>
        /// (UTC - Universal Coordinated Time, onde TZD pode ser -02:00 (Fernando de Noronha), -03:00 (Brasília) ou -04:00 (Manaus), no horário de verão serão -01:00, -02:00 e -03:00. <br/>
        /// Ex.: 2010-08-19T13:00:15-03:00.
        /// </summary>
        [XmlElement("dhEvento")]
        public string dhEvento { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de ambiente:<br/>
        /// 1 - Produção<br/>
        /// 2 - Homologação
        /// </summary>
        [XmlElement("tpAmb")]
        public string tpAmb { get; set; } = string.Empty;


        /// <summary>
        /// Versão do aplicativo que gerou o pedido de registro de evento.<br/>
        /// Versão do integrador
        /// </summary>
        [XmlElement("verAplic")]
        public string verAplic { get; set; } = string.Empty;


        #endregion


        #region Cancelamentos

        /// <summary>
        /// Parte Específica do Pedido de Registro de Evento<br/>
        /// Evento Cancelamento de NFS-e<br/>
        /// Cancelamento padrão de uma NFSe, usado em 90% dos casos (e101101)
        /// </summary>
        [XmlElement("e101101")]
        public NfseEventoItemCancelamentoXml? ItemCancelamento { get; set; }


        /// <summary>
        /// Parte Específica do Pedido de Registro de Evento<br/>
        /// Cancelamento de NFS-e por Substituição (e105102)
        /// </summary>
        [XmlElement("e105102")]
        public NfseEventoItemCancelamentoPorSubstituicaoXml? ItemCancelamentoPorSubstituicao { get; set; }


        /// <summary>
        /// Parte Específica do Pedido de Registro de Evento<br/>
        /// Solicitação de Análise Fiscal para Cancelamento de NFS-e (e101103)
        /// </summary>
        [XmlElement("e101103")]
        public NfseEventoItemSolicitacaoCancelamentoAnaliseFiscalXml? ItemSolicitacaoCancelamentoAnaliseFiscal { get; set; }


        /// <summary>
        /// Parte Específica do Pedido de Registro de Evento<br/>
        /// Cancelamento de NFSe deferido por analise fiscal (e105104)
        /// </summary>
        [XmlElement("e105104")]
        public NfseEventoItemCancelamentoDeferidoAnaliseFiscalXml? ItemCancelamentoDeferidoAnaliseFiscal { get; set; }


        /// <summary>
        /// Parte Específica do Pedido de Registro de Evento<br/>
        /// Cancelamento de NFSe Indeferido por analise fiscal (e105105)
        /// </summary>
        [XmlElement("e105105")]
        public NfseEventoItemCancelamentoIndeferidoAnaliseFiscalXml? ItemCancelamentoIndeferidoAnaliseFiscal { get; set; }


        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Cancelamento de NFS-e por Ofício (e305110)
        /// </summary>
        [XmlElement("e305110")]
        public NfseEventoItemCancelamentoPorOficioXml? ItemCancelamentoPorOficio { get; set; }


        #endregion


        #region Confirmação de aceite de nota


        #region Confirmação de aceite de nota por Prestador

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação do Prestador (e202201)
        /// </summary>
        [XmlElement("e202201")]
        public NfseEventoItemConfirmacaoPrestadorXml? ItemConfirmacaoPrestador202201 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação do Prestador (e202211)
        /// </summary>
        [XmlElement("e202211")]
        public NfseEventoItemConfirmacaoPrestadorXml? ItemConfirmacaoPrestador202211 { get; set; }

        #endregion


        #region Confirmação de aceite de nota por Tomador

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação do Tomador (e203202)
        /// </summary>
        [XmlElement("e203202")]
        public NfseEventoItemConfirmacaoTomadorXml? ItemConfirmacaoTomador203202 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação do Tomador (e203212)
        /// </summary>
        [XmlElement("e203212")]
        public NfseEventoItemConfirmacaoTomadorXml? ItemConfirmacaoTomador203212 { get; set; }

        #endregion


        #region Confirmação de aceite de nota por Intermediario

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação do Intermediario (e204203)
        /// </summary>
        [XmlElement("e204203")]
        public NfseEventoItemConfirmacaoIntermediarioXml? ItemConfirmacaoIntermediario204203 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação do Intermediario (e204213)
        /// </summary>
        [XmlElement("e204213")]
        public NfseEventoItemConfirmacaoIntermediarioXml? ItemConfirmacaoIntermediario204213 { get; set; }

        #endregion


        #region Confirmação de aceite de nota por Tacita

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação Tacita/municipio (e205204)
        /// </summary>
        [XmlElement("e205204")]
        public NfseEventoItemConfirmacaoTacitaXml? ItemConfirmacaoTacita205204 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Confirmação Tacita/municipio (e205214)
        /// </summary>
        [XmlElement("e205214")]
        public NfseEventoItemConfirmacaoTacitaXml? ItemConfirmacaoTacita205214 { get; set; }

        #endregion


        #endregion


        #region Rejeição

        #region Confirmação de aceite de nota por Prestador

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Rejeição do Prestador
        /// </summary>
        [XmlElement("e202205")]
        public NfseEventoItemRejeicaoPrestadorXml? ItemRejeicaoPrestador202205 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Rejeição do Prestador
        /// </summary>
        [XmlElement("e202215")]
        public NfseEventoItemRejeicaoPrestadorXml? ItemRejeicaoPrestador202215 { get; set; }

        #endregion


        #region Confirmação de aceite de nota por Tomador

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Rejeição do Tomador
        /// </summary>
        [XmlElement("e202206")]
        public NfseEventoItemRejeicaoTomadorXml? ItemRejeicaoTomador202206 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Rejeição do Tomador
        /// </summary>
        [XmlElement("e202216")]
        public NfseEventoItemRejeicaoTomadorXml? ItemRejeicaoTomador202216 { get; set; }

        #endregion


        #region Confirmação de aceite de nota por Intermediario

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Rejeição do Intermediario
        /// </summary>
        [XmlElement("e202207")]
        public NfseEventoItemRejeicaoIntermediarioXml? ItemRejeicaoIntermediario202207 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Rejeição do Intermediario
        /// </summary>
        [XmlElement("e202217")]
        public NfseEventoItemRejeicaoIntermediarioXml? ItemRejeicaoIntermediario202217 { get; set; }

        #endregion


        #region Anulação de Rejeição

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Anulação de Rejeição
        /// </summary>
        [XmlElement("e202208")]
        public NfseEventoItemRejeicaoAnulacaoXml? ItemRejeicaoAnulacao202208 { get; set; }

        /// <summary>
        /// Parte Específica do Evento<br/>
        /// Manifestação de NFS-e - Anulação de Rejeição
        /// </summary>
        [XmlElement("e202218")]
        public NfseEventoItemRejeicaoAnulacaoXml? ItemRejeicaoA202218 { get; set; }

        #endregion




        #endregion
    }
}
