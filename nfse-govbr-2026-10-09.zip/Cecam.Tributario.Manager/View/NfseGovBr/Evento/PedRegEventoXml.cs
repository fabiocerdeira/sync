﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento
{
    /// <summary>
    /// Leiaute do pedido de registro do evento gerado pelo autor do evento
    /// </summary>
    public class PedRegEventoXml
    {
        /// <summary>
        /// Versão do leiaute do pedido de registro do evento
        /// </summary>
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";


        /// <summary>
        /// Parte Geral do Pedido de Registro de Evento<br/>
        /// Grupo de informações do pedido de registro do evento
        /// </summary>
        [XmlElement("infPedReg")]
        public InfPedRegEventoXml? InfPedRegEvento { get; set; }
    }
}
