﻿using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using Microsoft.SqlServer.Server;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento
{
    /// <summary>
    /// Grupo de informações do pedido de registro do evento
    /// </summary>
    public class InfNfseEventoXml
    {
        /// <summary>
        /// O identificador do evento é composto pela concatenação de campos que constam no leiaute.<br/>
        /// A formação deste identificador considera o literal ""EVT"" associado a outras 59 posições numéricas, conforme descrito abaixo:<br/>
        /// "EVT" + <br/>
        /// id do Pedido de Registo de Evento(56) + <br/>
        /// Número sequencial do evento(nSeqEvento) (3)
        /// </summary>
        [XmlAttribute("Id")]
        public string Id { get; set; } = string.Empty;


        #region Elementos


        /// <summary>
        /// Versão da aplicação que gerou a NFS-e.<br/>
        /// Versão do integrador
        /// </summary>
        [XmlElement("verAplic")]
        public string verAplic { get; set; } = string.Empty;


        /// <summary>
        /// Ambiente gerador do evento da NFS-e:<br/>
        /// 1- Sistema Próprio do Município<br/>
        /// 2- Sefin Nacional NFS-e<br/>
        /// 3 - ADN NFS - e<br/>
        /// 4 - MAN<br/>
        /// Sistema Próprio do Municipio = 1 
        /// </summary>
        [XmlElement("ambGer")]
        public string ambGer { get; set; } = string.Empty;


        /// <summary>
        /// Número sequencial do evento para o mesmo tipo de evento.<br/>
        /// Para os eventos que ocorrem somente uma vez, como é o caso do cancelamento, o nSeqEvento = 001.<br/>
        /// Para os eventos que possam existir mais de um evento do mesmo tipo o ambiente gerador deverá numerar de forma sequencial.
        /// </summary>
        [XmlElement("nSeqEvento")]
        public string nSeqEvento { get; set; } = string.Empty;


        /// <summary>
        /// Data/Hora do registro do evento.<br/>
        /// Data e hora no formato UTC(Universal Coordinated Time):<br/>
        /// AAAA-MM-DDThh:mm:ssTZD
        /// </summary>
        [XmlElement("dhProc")]
        public string dhProc { get; set; } = string.Empty;


        /// <summary>
        /// Número sequencial do documento gerado por ambiente gerador de DFe do município.<br/>
        /// Tabela ISSNotaFiscal ==> campo ==> cd_notafiscal 
        /// </summary>
        [XmlElement("nDFe")]
        public string nDFe { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Leiaute do pedido de registro do evento gerado pelo autor do evento
        /// </summary>
        [XmlElement("pedRegEvento")]
        public PedRegEventoXml? PedRegEvento { get; set; }
    }
}
