﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento
{
    /// <summary>
    /// Classe raiz da XML de envio de evento da Nota Fiscal Serviço Eletronica 
    /// </summary>
    [XmlRoot("evento", Namespace = "http://www.sped.fazenda.gov.br/nfse", IsNullable = false)]
    public class NfseEventoXml
    {
        /// <summary>
        /// Versão do leiaute do evento
        /// </summary>
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";

        /// <summary>
        /// Grupo de informações do pedido de registro do evento
        /// </summary>
        [XmlElement("infEvento")]
        public InfNfseEventoXml? InfNFSeEvento { get; set; }
    }
}
