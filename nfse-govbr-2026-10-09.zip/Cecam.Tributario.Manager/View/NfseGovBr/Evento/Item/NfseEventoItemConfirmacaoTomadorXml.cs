﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Evento<br/>
    /// Manifestação de NFS-e - Confirmação do Tomador (e203212)
    /// </summary>
    public class NfseEventoItemConfirmacaoTomadorXml
    {
        /// <summary>
        /// Descrição do evento: <br/>
        /// Manifestação de NFS-e - Confirmação do Tomador
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;
    }
}
