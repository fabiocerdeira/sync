﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Evento<br/>
    /// Manifestação de NFS-e - Confirmação Tácita (quanto é feita pelo município) (e205214)
    /// </summary>
    public class NfseEventoItemConfirmacaoTacitaXml
    {
        /// <summary>
        /// Descrição do evento: <br/>
        /// Manifestação de NFS-e - Confirmação Tácita (quanto é feita pelo município)
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;


        /// <summary>
        /// CPF do agente da administração tributária municipal que efetuou a manifestação de confirmação tácita pelo município.
        /// </summary>
        [XmlElement("CPFAgTrib")]
        public string CPFAgTrib { get; set; } = string.Empty;
    }
}
