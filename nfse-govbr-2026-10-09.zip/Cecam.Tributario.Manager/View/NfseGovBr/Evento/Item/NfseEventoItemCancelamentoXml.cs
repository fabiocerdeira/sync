﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Pedido de Registro de Evento<br/>
    /// Evento Cancelamento de NFS-e<br/>
    /// Evento = e101101
    /// </summary>
    public class NfseEventoItemCancelamentoXml
    {
        /// <summary>
        /// Descrição do evento:<br/>
        /// Cancelamento de NFS-e
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;


        /// <summary>
        /// Código de justificativa de cancelamento:<br/>
        /// 1 - Erro na Emissão<br/>
        /// 2 - Serviço não Prestado<br/>
        /// 9 - Outros
        /// </summary>
        [XmlElement("cMotivo")]
        public string cMotivo { get; set; } = string.Empty;


        /// <summary>
        /// Retornar o motivo do cancelamento por extenso a partir do campo cMotivo
        /// </summary>
        public string CMotivoPorExtenso()
        {
            switch (("" + cMotivo).Trim())
            {
                case "1":
                    return "1 - Erro na Emissão";

                case "2":
                    return "2 - Serviço não Prestado";

                case "9":
                    return "9 - Outros";

                case "":
                    return "Código do motivo não informado";

                default:
                    return "Código do motivo informado não reconhecido pelo sistema";
            }
        }


        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.
        /// </summary>
        [XmlElement("xMotivo")]
        public string xMotivo { get; set; } = string.Empty;
    }
}



