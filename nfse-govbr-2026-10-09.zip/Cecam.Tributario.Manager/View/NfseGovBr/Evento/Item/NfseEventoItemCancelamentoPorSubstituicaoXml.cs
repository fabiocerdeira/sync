﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Pedido de Registro de Evento
    /// Cancelamento de NFS-e por Substituição
    /// Evento = e101102
    /// </summary>
    public class NfseEventoItemCancelamentoPorSubstituicaoXml
    {
        /// <summary>
        /// Descrição do evento:<br/>
        /// Cancelamento de NFS-e por Substituição
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;


        /// <summary>
        /// Código de justificativa de cancelamento substituição:<br/>
        /// 1 - Desenquadramento de NFS-e do Simples Nacional<br/>
        /// 2 - Enquadramento de NFS-e no Simples Nacional<br/>
        /// 3 - Inclusão Retroativa de Imunidade/Isenção para NFS-e<br/>
        /// 4 - Exclusão Retroativa de Imunidade/Isenção para NFS-e<br/>
        /// 5 - Rejeição de NFS-e pelo tomador ou pelo intermediário se responsável pelo recolhimento do tributo<br/>
        /// 9 - Outros<br/>
        /// Obtido do campo da DPS ""DPS/infDPS/subst/cMotivo
        /// </summary>
        [XmlElement("cMotivo")]
        public string cMotivo { get; set; } = string.Empty;


        /// <summary>
        /// Retornar o motivo do cancelamento por extenso a partir do campo cMotivo
        /// </summary>
        public string CMotivoPorExtenso()
        {
            switch (("" + cMotivo).Trim())
            {
                case "1":
                    return "1 - Desenquadramento de NFS-e do Simples Nacional";

                case "2":
                    return "2 - Enquadramento de NFS-e no Simples Nacional";

                case "3":
                    return "3 - Inclusão Retroativa de Imunidade/Isenção para NFS-e";

                case "4":
                    return "4 - Exclusão Retroativa de Imunidade/Isenção para NFS-e";

                case "5":
                    return "5 - Rejeição de NFS-e pelo tomador ou pelo intermediário se responsável pelo recolhimento do tributo";

                case "9":
                    return "9 - Outros";

                case "":
                    return "Código do motivo não informado";

                default:
                    return "Código do motivo informado não reconhecido pelo sistema";
            }
        }


        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.<br/>
        /// Obtido do campo da DPS "DPS/infDPS/subst/xMotivo"
        /// </summary>
        [XmlElement("xMotivo")]
        public string xMotivo { get; set; } = string.Empty;


        /// <summary>
        /// Chave de Acesso da NFS-e substituta.
        /// </summary>
        [XmlElement("chSubstituta")]
        public string chSubstituta { get; set; } = string.Empty;
    }
}
