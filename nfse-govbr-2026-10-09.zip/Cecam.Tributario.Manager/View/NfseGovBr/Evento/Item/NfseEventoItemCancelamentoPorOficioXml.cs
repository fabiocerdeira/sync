﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Evento<br/>
    /// Cancelamento de NFS-e por Ofício<br/>
    /// Evento = e305110
    /// </summary>
    public class NfseEventoItemCancelamentoPorOficioXml
    {
        /// <summary>
        /// Descrição do evento:<br/>
        /// Cancelamento de NFS-e por Ofício
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;


        /// <summary>
        /// CPF do agente tributário.
        /// </summary>
        [XmlElement("CPFAgTrib")]
        public string CpfAgTrib { get; set; } = string.Empty;


        /// <summary>
        /// Identificação do procedimento administrativo.
        /// </summary>
        [XmlElement("nProcAdm")]
        public string NProcAdm { get; set; } = string.Empty;


        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.
        /// </summary>
        [XmlElement("xProcAdm")]
        public string XProcAdm { get; set; } = string.Empty;
    }
}
