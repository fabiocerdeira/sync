﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Evento<br/>
    /// Manifestação de NFS-e - Rejeição do Tomador
    /// Evento e202206 e e202216
    /// </summary>
    public class NfseEventoItemRejeicaoTomadorXml
    {
        /// <summary>
        /// "Descrição do evento:
        /// Manifestação de NFS-e - Rejeição do Tomador
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;


        /// <summary>
        /// Motivo da Rejeição da NFS-e:<br/>
        /// 1 - NFS-e em duplicidade<br/>
        /// 2 - NFS-e já emitida pelo tomador<br/>
        /// 3 - Não ocorrência do fato gerador<br/>
        /// 4 - Erro quanto a responsabilidade tributária<br/>
        /// 5 - Erro quanto ao valor do serviço, valor das deduções ou serviço prestado ou data do fato gerador<br/>
        /// 9 - Outros
        /// </summary>
        [XmlElement("cMotivo")]
        public string cMotivo { get; set; } = string.Empty;


        /// <summary>
        /// Retornar o motivo da rejeição por extenso a partir do campo cMotivo
        /// </summary>
        public string CMotivoPorExtenso()
        {
            switch (("" + cMotivo).Trim())
            {
                case "1":
                    return "1 - NFS-e em duplicidade";

                case "2":
                    return "2 - NFS-e já emitida pelo tomador";

                case "3":
                    return "3 - Não ocorrência do fato gerador";

                case "4":
                    return "4 - Erro quanto a responsabilidade tributária";

                case "5":
                    return "5 - Erro quanto ao valor do serviço, valor das deduções ou serviço prestado ou data do fato gerador";

                case "9":
                    return "9 - Outros";

                case "":
                    return "Código do motivo não informado";

                default:
                    return "Código do motivo informado não reconhecido pelo sistema";
            }
        }


        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.
        /// </summary>
        [XmlElement("xMotivo")]
        public string xMotivo { get; set; } = string.Empty;
    }
}
