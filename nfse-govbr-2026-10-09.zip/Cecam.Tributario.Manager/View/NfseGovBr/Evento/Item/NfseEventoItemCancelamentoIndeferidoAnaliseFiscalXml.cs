﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    public class NfseEventoItemCancelamentoIndeferidoAnaliseFiscalXml
    {
        /// <summary>
        /// Descrição do evento: <br/>
        /// Cancelamento de NFS-e Indeferido por Analise Fiscal
        /// </summary>
        [XmlElement("xDesc")]
        public string xDesc { get; set; } = string.Empty;


        /// <summary>
        /// CPF do agente da administração tributária municipal que efetuou o indeferimento da  solicitação de análise fiscal para cancelamento de NFS-e.
        /// </summary>
        [XmlElement("CPFAgTrib")]
        public string CpfAgTrib { get; set; } = string.Empty;


        /// <summary>
        /// Número do processo administrativo municipal vinculado à  solicitação de análise fiscal para cancelamento de NFS-e.
        /// </summary>
        [XmlElement("nProcAdm")]
        public string NProcAdm { get; set; } = string.Empty;


        /// <summary>
        /// Resposta da solicitação de análise fiscal para cancelamento de NFS-e:<br/>
        /// 1 - Cancelamento de NFS-e Indeferido<br/>
        /// 2 - Cancelamento de NFS-e Indeferido Sem Análise de Mérito
        /// </summary>
        [XmlElement("cMotivo")]
        public string cMotivo { get; set; } = string.Empty;


        /// <summary>
        /// Retornar o motivo do cancelamento por extenso a partir do campo cMotivo
        /// </summary>
        public string CMotivoPorExtenso()
        {
            switch (("" + cMotivo).Trim())
            {
                case "1":
                    return "1 - Cancelamento de NFS-e Indeferido";

                case "2":
                    return "2 - Cancelamento de NFS-e Indeferido Sem Análise de Mérito";

                case "":
                    return "Código do motivo não informado";

                default:
                    return "Código do motivo informado não reconhecido pelo sistema";
            }
        }


        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.
        /// </summary>
        [XmlElement("xMotivo")]
        public string xMotivo { get; set; } = string.Empty;
    }
}
