﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Evento.Item
{
    /// <summary>
    /// Parte Específica do Evento<br/>
    /// Manifestação de NFS-e - Anulação da Rejeição<br/>
    /// Evento e202208 e e202218
    /// </summary>
    public class NfseEventoItemRejeicaoAnulacaoXml
    {
        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.
        /// </summary>
        [XmlElement("CPFAgTrib")]
        public string CPFAgTrib { get; set; } = string.Empty;


        /// <summary>
        /// Referência ao "id" do Evento de Manifestação de NFS-e - Rejeição, que originou o presente evento de anulação.
        /// </summary>
        [XmlElement("idEvManifRej")]
        public string IdEvManifRej { get; set; } = string.Empty;


        /// <summary>
        /// Descrição para explicitar o motivo indicado neste evento.
        /// </summary>
        [XmlElement("xMotivo")]
        public string xMotivo { get; set; } = string.Empty;
    }
}
