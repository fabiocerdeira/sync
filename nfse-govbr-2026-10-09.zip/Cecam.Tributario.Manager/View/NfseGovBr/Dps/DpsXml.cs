﻿using Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps
{
    public class DpsXml
    {
        /// <summary>
        /// Versão do leiaute da DPS.
        /// </summary>
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";


        [XmlElement("infDPS")]
        public InfDpsXml? InfDps { get; set; }
    }
}
