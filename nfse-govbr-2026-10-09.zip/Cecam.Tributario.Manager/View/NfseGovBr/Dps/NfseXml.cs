﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps
{
    /// <summary>
    /// Classe raiz da XML de envio da Nota Fiscal Serviço Eletronica 
    /// </summary>
    [XmlRoot("NFSe", Namespace = "http://www.sped.fazenda.gov.br/nfse", IsNullable = false)]
    public class NfseXml
    {
        /// <summary>
        /// Versão do leiaute da NFS-e.
        /// </summary>
        [XmlAttribute("versao")]
        public string Versao { get; set; } = "1.00";


        /// <summary>
        /// Grupo de informações da NFS-e
        /// </summary>
        [XmlElement("infNFSe")]
        public InfNfseXml? InfNFSe { get; set; }
    }
}
