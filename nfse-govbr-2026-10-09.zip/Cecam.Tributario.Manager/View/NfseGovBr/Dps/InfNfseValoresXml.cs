﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps
{
    /// <summary>
    /// Grupo de valores referentes ao serviço prestado
    /// </summary>
    public class InfNfseValoresXml
    {
        /// <summary>
        /// Valor monetário (R$) de dedução/redução da base de cálculo (BC) do ISSQN.
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao
        /// </summary>
        [XmlElement("vCalcDR")]
        public string vCalcDR { get; set; } = string.Empty;


        /// <summary>
        /// Tipo Benefício Municipal (BM):
        /// 1) "Isenção";
        /// 2) "Redução da BC em 'ppBM' %";
        /// 3) "Redução da BC em R$ 'vInfoBM' ";
        /// 4) "Alíquota Diferenciada de 'aliqDifBM' %";
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao > 0  = 3
        /// </summary>
        [XmlElement("tpBM")]
        public string tpBM { get; set; } = string.Empty;


        /// <summary>
        /// Valor monetário (R$) do percentual de redução da base de cálculo (BC) do ISSQN devido a um benefício municipal (BM).
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_Deducao
        /// </summary>
        [XmlElement("vCalcBM")]
        public string vCalcBM { get; set; } = string.Empty;


        /// <summary>
        /// Valor da Base de Cálculo do ISSQN (R$) = Valor do Serviço - Desconto Incondicionado - Deduções/Reduções - Benefício Municipal
        /// vBC = vServ - descIncond - (vDR ou vCalcDR + vCalcReeRepRes) - (vRedBCBM ou VCalcBM)
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> vl_item - vl_Deducao
        /// </summary>
        [XmlElement("vBC")]
        public string vBC { get; set; } = string.Empty;


        /// <summary>
        /// Alíquota aplicada sobre a base de cálculo para apuração do ISSQN.
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> pc_Aliquota
        /// </summary>
        [XmlElement("pAliqAplic")]
        public string pAliqAplic { get; set; } = string.Empty;


        /// <summary>
        /// Valor do ISSQN (R$) = Valor da Base de Cálculo x Alíquota
        /// vISSQN = vBC x pAliqAplic
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> Vl_Devido
        /// </summary>
        [XmlElement("vISSQN")]
        public string vISSQN { get; set; } = string.Empty;


        /// <summary>
        /// Valor total de retenções (R$) = S(CP + IRRF + CSLL + ISSQN* + (PIS + CONFINS)**)
        /// vTotalRet = (vRetCP + vRetIRRF + vRetCSLL) + vISSQN* + 
        /// (vPIS + vCOFINS)**
        /// Tabela ISSNotaFiscal ==> campo==> cd_notafiscal  ==> Tabela ISSNotaFiscaItem ==> fl_retido = 1 ==> vl_Tomado (Verificar tabela ISSNotaFiscalImposto)
        /// </summary>
        [XmlElement("vTotalRet")]
        public string vTotalRet { get; set; } = string.Empty;


        /// <summary>
        /// Valor líquido (R$) = Valor do serviço - Desconto condicionado - Desconto incondicionado - Valores retidos (CP, IRRF, CSLL)* - Valores, se retidos (ISSQN, PIS, COFINS)**
        /// VLiq = vServ – vDescIncond – vDescCond – (vRetCP + vRetIRRF + vRetCSLL)* – (vISSQN + vPIS + vCOFINS)**
        /// Verificar no código da aplicação como é a regra do cálculo do valor líquido da Nota Fiscal 
        /// </summary>
        [XmlElement("vLiq")]
        public string vLiq { get; set; } = string.Empty;


        /// <summary>
        /// Uso da Administração Tributária Municipal.
        /// Deixar em branco
        /// </summary>
        [XmlElement("xOutInf")]
        public string xOutInf { get; set; } = string.Empty;
    }
}
