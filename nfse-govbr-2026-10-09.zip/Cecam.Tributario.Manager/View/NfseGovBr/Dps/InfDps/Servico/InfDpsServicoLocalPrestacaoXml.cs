﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas ao local da prestação do serviço
    /// </summary>
    public class InfDpsServicoLocalPrestacaoXml
    {
        /// <summary>
        /// Código da localidade da prestação do serviço.<br/>
        /// <br/>
        /// Para atender o dispositivo do Art 3, par 2,<br/>
        /// (No caso dos serviços a que se refere o subitem 22.01 da lista anexa, considera-se ocorrido o fato gerador e devido o imposto em cada Município em cujo território haja extensão de rodovia explorada.)<br/>
        /// o Sistema Nacional NFS-e considera o trecho de concessão de exploração de rodovia como uma localidade de prestação de serviço, assim como qualquer município brasileiro.<br/>
        /// Para atender o dispositivo do Art 3, par 3,<br/>
        /// (Considera-se ocorrido o fato gerador do imposto no local do estabelecimento prestador nos serviços executados em águas marítimas, excetuados os serviços descritos no subitem 20.01)<br/>
        /// o Sistema Nacional NFS-e "Águas Marítimas" como uma localidade de prestação de serviço, assim como qualquer município brasileiro.<br/>
        /// cLocPrestacao poderá assumir: qualquer código que represente um município da tabela de códigos de municípios do IBGE, qualquer código quer represente um trecho de concessão de exploração de rodovias do cadastro próprio do Sistema Nacional NFS-e ou 0000000, que representa "Águas Marítimas".
        /// </summary>
        [XmlElement("cLocPrestacao")]
        public string cLocPrestacao { get; set; } = string.Empty;


        /// <summary>
        /// Código do país onde ocorreu a prestação do serviço.<br/>
        /// ver Tabela de Países ISO<br/>
        /// Somente vem preenchido quando o serviço é prestado fora do Brasil,<br/>
        /// porque quando é no Brasil, o campo 'cLocPrestacao' vem com o código do municipio do IBGE
        /// </summary>
        [XmlElement("cPaisPrestacao")]
        public string cPaisPrestacao { get; set; } = string.Empty;


        /// <summary>
        /// Código do país onde ocorreu o consumo do serviço prestado.<br/>
        /// ver Tabela de Países ISO
        /// </summary>
        [XmlElement("cPaisConsum")]
        public string cPaisConsum { get; set; } = string.Empty;
    }
}
