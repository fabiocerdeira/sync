﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Servico
{
    /// <summary>
    /// Grupo de informações relativas ao código do serviço prestado
    /// </summary>
    public class InfDpsServicoCodigoServicoXml
    {
        /// <summary>
        /// Código de tributação nacional do ISSQN.
        /// Tabela ListaServicoNacional campo 'cd_tributacaoNacional' exemplo '070202'
        /// </summary>
        [XmlElement("cTribNac")]
        public string cTribNac { get; set; } = string.Empty;


        /// <summary>
        /// Código de tributação municipal do ISSQN.
        /// Tabela IssServiçcos campo 'cd_servico', pode levar também o 'cd_exercicio' do ano corrente
        /// </summary>
        [XmlElement("cTribMun")]
        public string cTribMun { get; set; } = string.Empty;


        /// <summary>
        /// Descrição completa do serviço prestado
        /// Na documentação não deixa claro, se é descrição da Lista Nacional ou NBS,  vamos deixar o da Lista Nacional
        /// Tabela ISS_NFSE_ListaServicoNacional campo ‘ds_servicodescricao
        /// </summary>
        [XmlElement("xDescServ")]
        public string xDescServ { get; set; } = string.Empty;


        /// <summary>
        /// Código NBS correspondente ao serviço prestado
        /// Tabela ISS_NFSE_listaNBS campo 'cd_nbsFormatado' exemplo '1.0203.10.00'
        /// </summary>
        [XmlElement("cNBS")]
        public string cNBS { get; set; } = string.Empty;


        /// <summary>
        /// Código interno do contribuinte
        /// </summary>
        [XmlElement("cIntContrib")]
        public string cIntContrib { get; set; } = string.Empty;
    }
}
