﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps
{
    /// <summary>
    /// Grupo de informações relativas ao intermediário do serviço
    /// </summary>
    public class InfDpsIntermediarioXml
    {
        #region Elementos


        /// <summary>
        /// Número da inscrição federal (CNPJ) do intermediário de serviço
        /// </summary>
        [XmlElement("CNPJ")]
        public string CNPJ { get; set; } = string.Empty;


        /// <summary>
        /// Número da inscrição federal (CPF) do intermediário do serviço
        /// </summary>
        [XmlElement("CPF")]
        public string CPF { get; set; } = string.Empty;


        /// <summary>
        /// Número de identificação fiscal fornecido por órgão de administração tributária no exterior
        /// </summary>
        [XmlElement("NIF")]
        public string NIF { get; set; } = string.Empty;


        /// <summary>
        /// Motivo para não informação do NIF:
        /// 0 - Não informado na nota de origem;
        /// 1 - Dispensado do NIF;
        /// 2 - Não exigência do NIF;
        /// </summary>
        [XmlElement("cNaoNIF")]

        public string cNaoNIF { get; set; } = string.Empty;


        /// <summary>
        /// Número do Cadastro de Atividade Econômica da Pessoa Física (CAEPF) do intermediário do serviço.
        /// </summary>
        [XmlElement("CAEPF")]
        public string CAEPF { get; set; } = string.Empty;


        /// <summary>
        /// Número de inscrição municipal do intermediário do serviço
        /// </summary>
        [XmlElement("IM")]
        public string IM { get; set; } = string.Empty;


        /// <summary>
        /// Nome / Razão Social do intermediário
        /// </summary>
        [XmlElement("xNome")]
        public string xNome { get; set; } = string.Empty;


        /// <summary>
        /// Número do telefone do intermediário.
        /// (Preencher com o Código DDD + número do telefone. 
        /// Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)
        /// </summary>
        [XmlElement("fone")]
        public string fone { get; set; } = string.Empty;


        /// <summary>
        /// E-mail do intermediário.
        /// </summary>
        [XmlElement("email")]
        public string email { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço do intermediário do serviço.
        /// </summary>
        [XmlElement("end")]
        public InfDpsIntermediarioEnderecoXml? end { get; set; }
    }
}
