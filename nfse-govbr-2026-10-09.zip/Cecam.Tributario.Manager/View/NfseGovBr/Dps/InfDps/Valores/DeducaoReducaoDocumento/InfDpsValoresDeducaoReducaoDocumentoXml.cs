﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento
{
    /// <summary>
    /// Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
    /// </summary>
    public class InfDpsValoresDeducaoReducaoDocumentoXml
    {
        #region Elementos



        #endregion


        /// <summary>
        /// Grupo de informações de documento utilizado para dedução/redução do valor da base de cálculo (valor do serviço)
        /// NFSe/infNFSe/DPS/infDPS/valores/vDedRed/documentos/docDedRed/
        /// </summary>
        [XmlElement("docDedRed")]
        public InfDpsValoresDeducaoReducaoDocumentoDedRedXml? docDedRed { get; set; }
    }
}
