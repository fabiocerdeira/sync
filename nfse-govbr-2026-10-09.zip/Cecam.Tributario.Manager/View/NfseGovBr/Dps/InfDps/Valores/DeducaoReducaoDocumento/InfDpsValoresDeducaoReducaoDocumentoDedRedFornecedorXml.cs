﻿using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores.DeducaoReducaoDocumento
{
    /// <summary>
    /// Grupo de informações do fornecedor do serviço prestado
    /// </summary>
    public class InfDpsValoresDeducaoReducaoDocumentoDedRedFornecedorXml
    {
        #region Elementos


        /// <summary>
        /// Número da inscrição federal (CNPJ) do fornecedor de serviço.
        /// </summary>
        [XmlElement("CNPJ")]
        public string CNPJ { get; set; } = string.Empty;


        /// <summary>
        /// Número da inscrição federal (CPF) do fornecedor do serviço.
        /// </summary>
        [XmlElement("CPF")]
        public string CPF { get; set; } = string.Empty;


        /// <summary>
        /// Este elemento só deverá ser preenchido para fornecedores não residentes no Brasil.
        /// </summary>
        [XmlElement("NIF")]
        public string NIF { get; set; } = string.Empty;


        /// <summary>
        /// Motivo para não informação do NIF:
        ///
        ///0 - Não informado na nota de origem;
        ///1 - Dispensado do NIF;
        ///2 - Não exigência do NIF;
        /// </summary>
        [XmlElement("cNaoNIF")]
        public string cNaoNIF { get; set; } = string.Empty;


        /// <summary>
        /// Número do Cadastro de Atividade Econômica da Pessoa Física (CAEPF) do fornecedor do serviço.
        /// </summary>
        [XmlElement("CAEPF")]
        public string CAEPF { get; set; } = string.Empty;


        /// <summary>
        /// Número de inscrição municipal do fornecedor.
        /// </summary>
        [XmlElement("IM")]
        public string IM { get; set; } = string.Empty;


        /// <summary>
        /// Nome / Razão Social do fornecedor.
        /// </summary>
        [XmlElement("xNome")]
        public string xNome { get; set; } = string.Empty;


        /// <summary>
        /// Tipo e nome do logradouro do endereço do fornecedor.
        /// </summary>
        [XmlElement("xLgr")]
        public string xLgr { get; set; } = string.Empty;


        /// <summary>
        /// Número no logradouro do endereço do fornecedor.
        /// </summary>
        [XmlElement("nro")]
        public string nro { get; set; } = string.Empty;


        /// <summary>
        /// Complemento do endereço do fornecedor.
        /// </summary>
        [XmlElement("xCpl")]
        public string xCpl { get; set; } = string.Empty;


        /// <summary>
        /// Bairro do endereço do fornecedor.
        /// </summary>
        [XmlElement("xBairro")]
        public string xBairro { get; set; } = string.Empty;


        /// <summary>
        /// Número do telefone do fornecedor.
        ///(Preencher com o Código DDD + número do telefone. 
        ///Nas operações com exterior é permitido informar o código do país + código da localidade + número do telefone)
        /// </summary>
        [XmlElement("fone")]
        public string fone { get; set; } = string.Empty;


        /// <summary>
        /// E-mail do fornecedor.
        /// </summary>
        [XmlElement("email")]
        public string email { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço nacional.
        /// </summary>
        [XmlElement("endNac")]
        public EnderecoNacionalReduzidoXml? endNac { get; set; }


        /// <summary>
        /// Grupo de informações do endereço no exterior.
        /// </summary>
        [XmlElement("endExt")]
        public EnderecoExteriorXml? endExt { get; set; }
    }
}
