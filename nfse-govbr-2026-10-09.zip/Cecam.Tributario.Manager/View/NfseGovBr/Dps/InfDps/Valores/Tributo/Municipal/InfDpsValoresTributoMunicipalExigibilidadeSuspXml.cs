﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores.Tributo.Municipal
{
    /// <summary>
    /// Informações para a suspensão da Exigibilidade do ISSQN
    /// </summary>
    public class InfDpsValoresTributoMunicipalExigibilidadeSuspXml
    {
        #region Elementos


        /// <summary>
        /// Opção para Exigibilidade Suspensa:
        /// 1 - Exigibilidade do ISSQN Suspensa por Decisão Judicial;
        /// 2 - Exigibilidade do ISSQN Suspensa por Processo Administrativo;
        /// </summary>
        [XmlElement("tpSusp")]
        public string tpSusp { get; set; } = string.Empty;


        /// <summary>
        /// Número do processo judicial ou administrativo de suspensão da exigibilidade.
        /// </summary>
        [XmlElement("nProcesso")]
        public string nProcesso { get; set; } = string.Empty;


        #endregion
    }
}
