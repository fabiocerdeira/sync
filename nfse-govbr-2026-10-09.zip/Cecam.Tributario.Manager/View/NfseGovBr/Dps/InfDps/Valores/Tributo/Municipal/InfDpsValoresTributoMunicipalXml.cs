﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps.Valores.Tributo.Municipal
{
    /// <summary>
    /// Grupo de informações relacionados ao Imposto Sobre Serviços de Qualquer Natureza - ISSQN
    /// </summary>
    public class InfDpsValoresTributoMunicipalXml
    {
        #region Elementos


        /// <summary>
        /// Tributação do ISSQN sobre o serviço prestado:<br/>
        /// 1 = Operação tributável<br/>
        /// 2 = Imunidade<br/>
        /// 3 = Exportação de serviço<br/>
        /// 4 = Não Incidência
        /// </summary>
        [XmlElement("tribISSQN")]
        public string tribISSQN { get; set; } = string.Empty;


        /// <summary>
        /// Código do país onde se verficou o resultado da prestação do serviço para o caso de Exportação de Serviço.<br/>
        /// Ver tabela de países ISO
        /// </summary>
        [XmlElement("cPaisResult")]
        public string cPaisResult { get; set; } = string.Empty;


        /// <summary>
        /// Identificação da Imunidade do ISSQN – somente para o caso de Imunidade.<br/>
        /// Tipos de Imunidades:<br/>
        /// 0 - Imunidade (tipo não informado na nota de origem)<br/>
        /// 1 - Patrimônio, renda ou serviços, uns dos outros (CF88, Art 150, VI, a)<br/>
        /// 2 - Templos de qualquer culto (CF88, Art 150, VI, b)<br/>
        /// 3 - Patrimônio, renda ou serviços dos partidos políticos, inclusive suas fundações, das entidades sindicais dos trabalhadores, das instituições de educação e de assistência social, sem fins lucrativos, atendidos os requisitos da lei (CF88, Art 150, VI, c)<br/>
        /// 4 - Livros, jornais, periódicos e o papel destinado a sua impressão (CF88, Art 150, VI, d)<br/>
        /// 5 - Fonogramas e videofonogramas musicais produzidos no Brasil contendo obras musicais ou literomusicais de autores brasileiros e/ou obras em geral interpretadas por artistas brasileiros bem como os suportes materiais ou arquivos digitais que os contenham, salvo na etapa de replicação industrial de mídias ópticas de leitura a laser.   (CF88, Art 150, VI, e)
        /// </summary>
        [XmlElement("tpImunidade")]
        public string tpImunidade { get; set; } = string.Empty;


        /// <summary>
        /// Valor da alíquota (%) do serviço prestado relativo ao município sujeito ativo (município de incidência) do ISSQN.
        /// </summary>
        [XmlElement("pAliq")]
        public string pAliq { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de retencao do ISSQN:<br/>
        /// 1 - Não Retido<br/>
        /// 2 - Retido pelo Tomador<br/>
        /// 3 - Retido pelo Intermediario<br/>
        /// </summary>
        [XmlElement("tpRetISSQN")]
        public string tpRetISSQN { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações sobre o tipo do Benefício Municipal
        /// </summary>
        [XmlElement("BM")]
        public InfDpsValoresTributoMunicipalBeneficioMunicipalXml? BM { get; set; }


        /// <summary>
        /// Informações para a suspensão da Exigibilidade do ISSQN
        /// </summary>
        [XmlElement("exigSusp")]
        public InfDpsValoresTributoMunicipalExigibilidadeSuspXml? exigSusp { get; set; }
    }
}
