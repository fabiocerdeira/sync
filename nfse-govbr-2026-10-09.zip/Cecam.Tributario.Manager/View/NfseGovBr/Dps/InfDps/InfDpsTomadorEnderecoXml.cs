﻿using Cecam.Tributario.Manager.View.NfseGovBr.Dps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cecam.Tributario.Manager.View.NfseGovBr.Dps.InfDps
{
    /// <summary>
    /// Grupo de informações do endereço do tomador do serviço.
    /// </summary>
    public class InfDpsTomadorEnderecoXml
    {
        #region Elementos


        /// <summary>
        /// Tipo e nome do logradouro do endereço do tomador do serviço.
        /// </summary>
        [XmlElement("xLgr")]
        public string xLgr { get; set; } = string.Empty;


        /// <summary>
        /// Número no logradouro do endereço do tomador do serviço.
        /// </summary>
        [XmlElement("nro")]
        public string nro { get; set; } = string.Empty;


        /// <summary>
        /// Complemento do endereço do tomador do serviço.
        /// </summary>
        [XmlElement("xCpl")]
        public string xCpl { get; set; } = string.Empty;


        /// <summary>
        /// Bairro do endereço do tomador do serviço.
        /// </summary>
        [XmlElement("xBairro")]
        public string xBairro { get; set; } = string.Empty;


        #endregion


        /// <summary>
        /// Grupo de informações do endereço nacional.
        /// </summary>
        [XmlElement("endNac")]
        public EnderecoNacionalReduzidoXml? endNac { get; set; }


        /// <summary>
        /// Grupo de informações do endereço no exterior.
        /// </summary>
        [XmlElement("endExt")]
        public EnderecoExteriorXml? endExt { get; set; }
    }
}
