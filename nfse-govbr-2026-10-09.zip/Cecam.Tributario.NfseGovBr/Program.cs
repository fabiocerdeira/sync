﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Helpers;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.NfseGovBr;
using Cecam.Tributario.Manager.Business.NfseGovBr.Download;
using Cecam.Tributario.Manager.Business.SysObject;
using Cecam.Tributario.Manager.Configuration;
using Cecam.Tributario.NfseGovBr.Nota;

namespace Cecam.Tributario.NfseGovBr
{
    internal class Program
    {
        private static LoggerHelper _loggerHelper = new LoggerHelper();

        static async Task Main(string[] args)
        {
            // usados para processar uma NFSE especifica da fila de entrada
            long? nsuProcessar = null;
            string? chaveAcessoProcessar = null;
            bool ignorarDataHoraProcessamento = false;
            bool somenteDownloadSemImportar = false;

            // inicializar a biblioteca CORE
            IniciarManager.Iniciar();

            // log acompanhamento
            _loggerHelper.GravarTexto("Importador Notas Fiscais de Serviço Eletrônicas de Gov.Br (Emissor Nacional) para Prefeitura/Cecam");
            _loggerHelper.GravarTexto("Data hora local " + DateTime.UtcNow.AddHours(-3).ToString());
            _loggerHelper.GravarTexto("Versão " + ParametrosGlobal.Versao);

#if DEBUG
            Console.ForegroundColor = ConsoleColor.Red;
            _loggerHelper.GravarTexto("Compilado como DEBUG\nCompilado como DEBUG\nCompilado como DEBUG\nCompilado como DEBUG");
            Console.ResetColor();
#endif
#if !DEBUG
            Console.ForegroundColor = ConsoleColor.Green;
            _loggerHelper.GravarTexto("Compilado como PRODUÇÃO\nCompilado como PRODUÇÃO\nCompilado como PRODUÇÃO\nCompilado como PRODUÇÃO");
            Console.ResetColor();
#endif


            // ------------------------------------------------------------

            /*
            // criar as classes templates no disco "C:\"
            var sis = new SysObjectBus();
            sis.Fazer();
            return;
            */


            /*
             * validar se todos os campos estão criados corretamente na base da prefeitura?
             */
            /*
            var mig = new MigrationVerificacaoManager();
            if (!(await mig.VerificarSeEstruturaBancoEstaOk()))
                return;
            */



            #region Parametros de entrada

#if DEBUG
            // var argumento = new List<string>() { "din" }; 
            // var argumento = new List<string>() { "cd" }; // testar certificado digital
            // var argumento = new List<string>() { "dw", "35027542217837384000102000000000000626014196813246" }; // download eventos araçariguama
            // var argumento = new List<string>() { "dw", "43149022225092298000138000000000038725126219021418" }; // download eventos pariquera
            // var argumento = new List<string>() { "ca", "42054072241761127000100000000000080426011239223670" }; // processar a chave de acesso informada
            // var argumento = new List<string>() { "cl", "lm" };
            // var argumento = new List<string>() { "din", "35027542218651697000126000000000005026021558225740" }; // entrada
            // argumento = new List<string>() { "din", "35027542212017814000118000000000000326018898889972" }; // saida
            //var argumento = new List<string>() { "exp", "35092542242989102000121000000000004526010934188346" }; // exportar fila sql

            var argumento = new List<string>() { "soDown" }; 
            args = argumento.ToArray();
#endif

            if (args.Length > 0)
            {
                if (args.Contains("?"))
                {
                    ExibirParametros();
                    return;
                }

                if (args.Contains("cd", StringComparer.OrdinalIgnoreCase))
                {
                    // somente para testar o certificado digital da prefeitura
                    // não grava nada no banco de dados
                    var certHelper = new X509CertificateHelper();
                    certHelper.Dump();
                    return;
                }

                if (args.Contains("cl", StringComparer.OrdinalIgnoreCase))
                {
                    // listar todos os certificados instalados na maquina
                    // não grava nada no banco de dados
                    var certHelper = new X509CertificateHelper();
                    certHelper.DumpListarTodos(args[1]);
                    return;
                }

                if (args.Contains("dw", StringComparer.OrdinalIgnoreCase))
                {
                    // download da NFSE usando a chave informada como parametro
                    var dwEventos = new NfseGovBrNfseDownloadEventoBus();
                    await dwEventos.DownloadEventos(new List<string> { args[1] });
                }

                if (args.Contains("igh", StringComparer.OrdinalIgnoreCase))
                {
                    // ignorar data hora do processamento da fila de entrada que estão com status de erro.
                    ignorarDataHoraProcessamento = true;
                }

                if (args.Contains("sodown", StringComparer.OrdinalIgnoreCase))
                {
                    // somente realizar download das notas e eventos sem importar da fila de entrada.
                    somenteDownloadSemImportar = true;
                }

                if (args[0].ToLower() == "din")
                {
                    // problemas de ponto e virgula no dinheiro
                    var govLixo = new NfseGovBrNfseLixoBus();
                    // govLixo.ChaveAcessoProcessar = args[1];
                    await govLixo.Processar();
                    return;
                }

                if (args.Length == 2)
                {
                    if (args[0].ToLower() == "nsu")
                    {
                        if (long.TryParse(args[1], out long nsuPro))
                            nsuProcessar = nsuPro;
                    }

                    if (args[0].ToLower() == "ca") chaveAcessoProcessar = args[1];

                    if (args[0].ToLower() == "exp")
                    {
                        // exportar fila entrada e saida
                        var govExportarFilas = new NfseGovBrExportarSqlBus();
                        await govExportarFilas.Exportar(args[1]);
                        return;
                    }
                }
            }

            #endregion


            // ------------------------------------------------------------


            var qtdLoop = 1;

            if (args.Length > 0)
            {
                if (args.Contains("10")) qtdLoop = 10;
                if (args.Contains("50")) qtdLoop = 50;
                if (args.Contains("100")) qtdLoop = 100;
                if (args.Contains("500")) qtdLoop = 500;
            }

            for (int i = 0; i < qtdLoop; i++)
            {
                // importar nfse do gov.br
                var importar = new ImportarNotaManager();

                // informar nsu/chave-acesso para importar ignorando a ordem da fila de entrada
                importar.NsuProcessar = nsuProcessar;
                importar.ChaveAcessoProcessar = chaveAcessoProcessar;
                importar.IgnorarDataHoraProcessamento = ignorarDataHoraProcessamento;
                importar.SomenteDownloadSemImportar = somenteDownloadSemImportar;

                // importar nfse do gov.br
                await importar.Importar();
            }

            // ------------------------------------------------------------

            // limpar pastas de log mais antigas
            _loggerHelper.LimparPastasAntigas(true);

            // ------------------------------------------------------------

            // log acompanhamento
            Console.ForegroundColor = ConsoleColor.Green;
            _loggerHelper.GravarTexto("Fim do sicronizador Prefeitura/Cecam e Gov.Br " + DateTime.UtcNow.AddHours(-3).ToString());
            Console.ResetColor();
        }


        /// <summary>
        /// Exibir na tela do console os parametros de inicialização do programa de importação das notas.
        /// </summary>
        private static void ExibirParametros()
        {
            Console.WriteLine("Importador Notas Fiscais de Serviço Eletrônicas de Gov.Br (Emissor Nacional) para Prefeitura/Cecam\n");

            Console.WriteLine("Sincronizador de Notas Fiscais de Serviço  entre Prefeitura/Cecam e Gov.Br");
            Console.WriteLine("Data hora local " + DateTime.UtcNow.AddHours(-3).ToString());
            Console.WriteLine("Versão " + ParametrosGlobal.Versao);

            Console.WriteLine("\nCecam.Tributario.NfseGovBr.exe [parametros]\n");

            Console.WriteLine("Parametros:\n");

            Console.WriteLine("cd : verificar se certificado digital esta instalado e com permissão");
            Console.WriteLine("cl : listar todos os certificados instalados no servidor");

            Console.WriteLine("\ndw [chave de acesso] : download da nota fiscal e dos eventos da chave informada");
            Console.WriteLine("nsu [nsu]: importar da fila de entrada a nota ou evento com o nsu informado");
            Console.WriteLine("ca [chave de cesso] : importar da fila de entrada a nota ou evento com a chave de acesso informada");
            Console.WriteLine("sodown : somente realizar download das notas e eventos sem importar da fila de entrada.");

            Console.WriteLine("\nexp [chave de acesso] : exportar fila entrada e saida usando a chave de acesso informada");
            Console.WriteLine("exp [nsu]: exportar fila entrada e saida usando a nsu informada");

            Console.WriteLine("\n500 : excutar o importador 500 vezes em seguida");
            Console.WriteLine("igh : ignorar data hora do processamento da fila de entrada que estão com status de erro e reprocessa imediatamente");

            Console.WriteLine("\nExemplo de chave de acesso: 35092542242989102000121000000000004526010934188346");
            Console.WriteLine("Exemplo de nsu: 5001\n\n\n");
        }
    }
}
