﻿using Cecam.Tributario.Extend.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfseGovBr.Configuration
{
    public class CertificadoVerificacaoManager
    {
        public bool VerificarCertificadoSeguro()
        {
            // incluir o certificado seguro no header
            var certificadoHelp = new X509CertificateHelper();

            // versão mais completa de carregamento do certificado
            // carrega do registro do windows, usando thumbPrint
            var certificadoSeguro = certificadoHelp.GetCertificate();

            // versão que funciona com sucesso, mas somente carrega do arquivo .PFX do disco.
            //var certificadoSeguro = certificadoHelp.GetCertificatOldLoad(); 

            // validar carregamento do certificado
            if (certificadoSeguro == null)
            {
                Mensagem("Certificado digital da prefeitura não foi encontrado no servidor da prefeitura, então nenhuma NFSe pode ser baixada. Por favor corrigir.");
                return false;
            }

            // verificar a data de vigencia (inicio e fim) do certificado
            if (!certificadoHelp.VerificarVigencia(certificadoSeguro))
            {
                Mensagem("Certificado digital da prefeitura esta fora da data de vigência, então nenhuma NFSe pode ser baixada. Por favor corrigir.");
                
                // mesmo fora da data de vigencia ele continua funcionando no gov.br
                // então não retornar erro.
                // return false;
            }

            return true;
        }


        private void Mensagem(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(msg);
            }
            Console.ResetColor();
        }


    }
}
