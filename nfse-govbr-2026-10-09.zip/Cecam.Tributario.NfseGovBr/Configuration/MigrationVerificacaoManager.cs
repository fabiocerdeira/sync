﻿using Cecam.Tributario.Database.Migration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfseGovBr.Configuration
{
    internal class MigrationVerificacaoManager
    {
        /// <summary>
        /// Verificar se todos os campos estão criados corretamente na base da prefeitura?
        /// </summary>
        public async Task<bool> VerificarSeEstruturaBancoEstaOk()
        {
            var migra = new MigrationCheckExists();
            var listaErros = await migra.CheckExists();

            if (listaErros != null && listaErros.Count > 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;

                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("ERRO NA ESTRUTURA DA BASE SQL SERVER");
                }

                foreach (var item in listaErros)
                {
                    Console.WriteLine(item);
                }

                Console.ResetColor();
                return false;
            }

            return true;
        }
    }
}
