﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.NfseGovBr.Consultar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfseGovBr.Nota
{
    internal class ConsultarNotaManager
    {
        private LoggerHelper _loggerHelper = new LoggerHelper();

        public async Task Consultar()
        {
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.ConsultarNotaManager.Consultar() | inicio");
            _loggerHelper.GravarTexto("He ambiente de produção: " + ParametrosGlobal.NfseGovBr_HeAmbienteProducao);
            _loggerHelper.GravarTexto($"CdCecam: {ParametrosGlobal.Cd_Cecam}");
            _loggerHelper.GravarTexto($"Exercicio: {ParametrosGlobal.Cd_Exercicio}");
            _loggerHelper.GravarTexto("AdnUrl: " + ParametrosGlobal.NfseGovBr_Adn_Url);
            _loggerHelper.GravarTexto("SefinUrl: " + ParametrosGlobal.NfseGovBr_Sefin_Url);
            _loggerHelper.GravarTexto("Certificado digital thumbPrint CurrentUser: " + ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);
            _loggerHelper.GravarTexto("Certificado digital thumbprint LocalMachine: " + ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);
            _loggerHelper.GravarTexto("Certificado digital arquivo .pfx: " + ParametrosGlobal.CertificadoDigitalCaminho);

            // ----------------------------------------------------------------------------


            // nota fiscal eletronica para gov.br
            var notaGovBus = new NfseGovBrNfseConsultarBus();

            string chaveAcessoComErro = "000ABC";
            string chaveAcessoComSucesso = "12345678901234567890123456789012345678901234567890";


            // ---------------------------------

            var notaGovAdnBus = new NfseGovBrAdnDfeConsultarBus();
            var ret1 = notaGovAdnBus.TemporarioParaDesenvovler();



            // ---------------------------------

            // consultar a nfse com SUCESSO em formato texto
            var xmlTexto = await notaGovBus.ConsultarNfse(chaveAcessoComSucesso);

            // logar no arquivo e na tela só para debugar desenvolvivmento.
            _loggerHelper.GravarArquivoDisco(xmlTexto, $"{chaveAcessoComSucesso}_nfse_baixada.xml");


            // ---------------------------------

            try
            {
                // consultar a nfse com ERRO
                await notaGovBus.ConsultarNfse(chaveAcessoComErro);
            }
            catch (Exception ex)
            {
                _loggerHelper.GravarTexto("**ERRO** " + ex.ToString());
            }

            // ---------------------------------


            // consultar a nfse com SUCESSO em formato objeto
            var xmlView = await notaGovBus.ConsultarNfseAsView(chaveAcessoComSucesso);

            // logar no arquivo e na tela só para debugar desenvolvivmento.
            _loggerHelper.GravarArquivoDisco(Newtonsoft.Json.JsonConvert.SerializeObject(xmlView), $"{chaveAcessoComSucesso}_nfse_baixada.json");

            // ---------------------------------

            // consultar a NFSe como pdf
            var pdfAsBase64 = await notaGovBus.DanfseConsultar(chaveAcessoComSucesso);

            // logar no arquivo e na tela só para debugar desenvolvivmento.
            _loggerHelper.GravarArquivoDisco(pdfAsBase64, $"{chaveAcessoComSucesso}_nfse_baixada.pdf");


            // ----------------------------------------------------------------------------

            // LOG FIM
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.ConsultarNotaManager.Consultar() | fim com sucesso");

            await Task.CompletedTask;
        }
    }
}
