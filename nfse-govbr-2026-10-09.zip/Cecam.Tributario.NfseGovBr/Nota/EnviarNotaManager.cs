﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.NfseGovBr.Enviar;

namespace Cecam.Tributario.NfseGovBr.Nota
{
    [Obsolete("NÃO PODE SER USADO, PQ NÃO FAZEMOS ENVIO DE NFSE PARA GOV.BR")]
    internal class EnviarNotaManager
    {
        private LoggerHelper _loggerHelper = new LoggerHelper();

        [Obsolete("NÃO PODE SER USADO, PQ NÃO FAZEMOS ENVIO DE NFSE PARA GOV.BR")]
        public async Task Enviar()
        {
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.EnviarNotaManager.Enviar() | inicio");
            _loggerHelper.GravarTexto("He ambiente de produção: " + ParametrosGlobal.NfseGovBr_HeAmbienteProducao);
            _loggerHelper.GravarTexto($"CdCecam: {ParametrosGlobal.Cd_Cecam}");
            _loggerHelper.GravarTexto($"Exercicio: {ParametrosGlobal.Cd_Exercicio}");
            _loggerHelper.GravarTexto("AdnUrl: " + ParametrosGlobal.NfseGovBr_Adn_Url);
            _loggerHelper.GravarTexto("SefinUrl: " + ParametrosGlobal.NfseGovBr_Sefin_Url);
            _loggerHelper.GravarTexto("Certificado digital thumbPrint CurrentUser: " + ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);
            _loggerHelper.GravarTexto("Certificado digital thumbprint LocalMachine: " + ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);
            _loggerHelper.GravarTexto("Certificado digital arquivo .pfx: " + ParametrosGlobal.CertificadoDigitalCaminho);

            // nota fiscal eletronica para gov.br
            var notaGovBus = new NfseGovBrDfeEnviarBus();

            // enviar a próxima nota fiscal de serviço eletrônica
            await notaGovBus.EnviarProximaNotaFiscal();

            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.EnviarNotaManager.Enviar() | fim com sucesso");
        }
    }
}
