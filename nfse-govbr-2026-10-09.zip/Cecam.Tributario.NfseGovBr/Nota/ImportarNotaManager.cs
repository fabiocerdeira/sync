﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.NfseGovBr.Download;
using Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Evento;
using Cecam.Tributario.Manager.Business.NfseGovBr.Importar.Nota;
using Cecam.Tributario.NfseGovBr.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfseGovBr.Nota
{
    internal class ImportarNotaManager
    {
        #region Declarações


        private LoggerHelper _loggerHelper = new LoggerHelper();


        /// <summary>
        /// NSU para carregar da base para ser processado fora da ordem da fila de entrada
        /// </summary>
        public long? NsuProcessar { get; set; }


        /// <summary>
        /// Chave de Acesso para carregar da base para ser processado fora da ordem da fila de entrada
        /// </summary>
        public string? ChaveAcessoProcessar { get; set; }


        /// <summary>
        /// Ignorar a data hora do ultimo processamento
        /// </summary>
        public bool IgnorarDataHoraProcessamento { get; set; } = false;


        /// <summary>
        /// Somente baixar (fazer download) das notas fiscal e eventos sem importar da fila de entrada.
        /// </summary>
        public bool SomenteDownloadSemImportar { get; set; } = false;


        #endregion


        public async Task Importar()
        {
            Console.ResetColor();
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.ImportarNotaManager.Importar() - Início");
            _loggerHelper.GravarTexto("He ambiente de produção: " + ParametrosGlobal.NfseGovBr_HeAmbienteProducao);
            _loggerHelper.GravarTexto($"CdCecam: {ParametrosGlobal.Cd_Cecam}");
            _loggerHelper.GravarTexto($"Exercicio: {ParametrosGlobal.Cd_Exercicio}");
            _loggerHelper.GravarTexto("AdnUrl: " + ParametrosGlobal.NfseGovBr_Adn_Url);
            _loggerHelper.GravarTexto("SefinUrl: " + ParametrosGlobal.NfseGovBr_Sefin_Url);
            _loggerHelper.GravarTexto("Certificado digital thumbPrint CurrentUser: " + ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);
            _loggerHelper.GravarTexto("Certificado digital thumbprint LocalMachine: " + ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);
            _loggerHelper.GravarTexto("Certificado digital arquivo .pfx: " + ParametrosGlobal.CertificadoDigitalCaminho);
            // culture quando o importador é executado
            _loggerHelper.GravarTexto("Culture Info: " + CultureInfo.CurrentCulture.Name);

            // ----------------------------------------------------------------------------

            // Baixar as notas do gov.br para a base da prefeitura/cecam
            await BaixarNotas();

            // Importar NFSe baixadas do Gov.Br para base Prefeitura/Cecam
            await ImportarNotas();

            // Importar Eventos de NFSe baixadas do Gov.Br para base Prefeitura/Cecam
            await ImportarEventos();

            // ----------------------------------------------------------------------------

            /*
            var listaTask = new List<Task>();

            // Baixar as notas do gov.br para a base da prefeitura/cecam
            var t1 = Task.Run(() => BaixarNotas());
            listaTask.Add(t1);

            // Importar NFSe baixadas do Gov.Br para base Prefeitura/Cecam
            // Importar Eventos de NFSe baixadas do Gov.Br para base Prefeitura/Cecam
            var t2 = Task.Run(() => ImportarAmbos());
            listaTask.Add(t2);

            // aguardar as 2 tasks terminar.
            Task.WaitAll(listaTask);
            */

            // ----------------------------------------------------------------------------

            // LOG FIM
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.ImportarNotaManager.Importar() - Fim com sucesso");
        }


        /// <summary>
        /// Baixar as notas do gov.br para a base da prefeitura/cecam
        /// </summary>
        private async Task BaixarNotas()
        {
            // log
            _loggerHelper.GravarTexto("--- Baixar NFSe do Gov.Br para base Prefeitura/Cecam");

            // Validar certificado seguro da prefeitura instalado no servidor
            var certifica = new CertificadoVerificacaoManager();
            if (!certifica.VerificarCertificadoSeguro())
                return;

            for (int i = 0; i < 100; i++)
            {
                // business de baixar a NFSe do gov.br
                var downloadNotaBus = new NfseGovBrNfseDownloadNotaBus();

                // baixar NFSe em lote
                var baixouNotas = await downloadNotaBus.DownloadLote();

                // se não teve notas baixadas então sair do loop
                if (!baixouNotas)
                    break;
            }
        }


        private async Task ImportarAmbos()
        {
            Thread.Sleep(5000);
            await ImportarNotas();

            Thread.Sleep(5000);
            await ImportarEventos();
        }

        /// <summary>
        /// Importar NFSe baixadas do Gov.Br para base Prefeitura/Cecam
        /// </summary>
        private async Task ImportarNotas()
        {
            // verificar se somente estamos fazendo download sem importar notas e eventos?
            if (SomenteDownloadSemImportar)
                return;

            // log
            _loggerHelper.GravarTexto("--- Importar NFSe baixadas do Gov.Br para base Prefeitura/Cecam");

            for (int i = 0; i < 5000; i++)
            {
                // bussines de importação de NFSe
                var importarNotaBus = new NfseGovBrNfseImportarNotaBus();

                // nfse para processar ignorando a ordem da fila de entrada
                importarNotaBus.NsuProcessar = NsuProcessar;
                importarNotaBus.ChaveAcessoProcessar = ChaveAcessoProcessar;
                importarNotaBus.IgnorarDataHoraProcessamento = IgnorarDataHoraProcessamento;

                // importar da fila de entrada para base prefeitura/cecam
                var encontrouAlgumaNfse = await importarNotaBus.Importar();

                // se não encontrou nfse para ser importada então sair do loop
                if (!encontrouAlgumaNfse)
                    break;

                // se tem parametro com a NFSe que precisa ser processada fora da ordem da fila, então sair do loop
                if (NsuProcessar != null || !string.IsNullOrWhiteSpace(ChaveAcessoProcessar))
                    break;
            }
        }


        /// <summary>
        /// Importar Eventos de NFSe baixadas do Gov.Br para base Prefeitura/Cecam
        /// </summary>
        private async Task ImportarEventos()
        {
            // verificar se somente estamos fazendo download sem importar notas e eventos?
            if (SomenteDownloadSemImportar)
                return;

            // log
            _loggerHelper.GravarTexto("--- Importar Eventos de NFSe baixadas do Gov.Br para base Prefeitura/Cecam");

            for (int i = 0; i < 5000; i++)
            {
                // business de importação dos Eventos da NFSe
                var importarEventosBus = new NfseGovBrNfseImportarEventoBus();

                // nfse para processar ignorando a ordem da fila de entrada
                importarEventosBus.NsuProcessar = NsuProcessar;
                importarEventosBus.ChaveAcessoProcessar = ChaveAcessoProcessar;
                importarEventosBus.IgnorarDataHoraProcessamento = IgnorarDataHoraProcessamento;

                // importar da fila de entrada para base prefeitura/cecam
                var encontrouAlgumEvento = await importarEventosBus.Importar();

                // se não encontrou evento de nfse para ser importada então sair do loop
                if (!encontrouAlgumEvento)
                    break;

                // se tem parametro com a NFSe que precisa ser processada fora da ordem da fila, então sair do loop
                if (NsuProcessar != null || !string.IsNullOrWhiteSpace(ChaveAcessoProcessar))
                    break;
            }
        }

    }
}
