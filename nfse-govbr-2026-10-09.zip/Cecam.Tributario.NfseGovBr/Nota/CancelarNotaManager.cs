﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Business.NfseGovBr.Cancelar;
using Cecam.Tributario.Manager.Business.NfseGovBr.Consultar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.NfseGovBr.Nota
{
    [Obsolete("NÃO PODE SER USADO, PQ NÃO FAZEMOS ENVIO DE NFSE PARA GOV.BR")]
    internal class CancelarNotaManager
    {
        private LoggerHelper _loggerHelper = new LoggerHelper();

        [Obsolete("NÃO PODE SER USADO, PQ NÃO FAZEMOS ENVIO DE NFSE PARA GOV.BR")]
        public async Task Cancelar()
        {
            // log
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.CancelarNotaManager.Cancelar() | inicio");
            _loggerHelper.GravarTexto("He ambiente de produção: " + ParametrosGlobal.NfseGovBr_HeAmbienteProducao);
            _loggerHelper.GravarTexto($"CdCecam: {ParametrosGlobal.Cd_Cecam}");
            _loggerHelper.GravarTexto($"Exercicio: {ParametrosGlobal.Cd_Exercicio}");
            _loggerHelper.GravarTexto("AdnUrl: " + ParametrosGlobal.NfseGovBr_Adn_Url);
            _loggerHelper.GravarTexto("SefinUrl: " + ParametrosGlobal.NfseGovBr_Sefin_Url);
            _loggerHelper.GravarTexto("Certificado digital thumbPrint CurrentUser: " + ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);
            _loggerHelper.GravarTexto("Certificado digital thumbprint LocalMachine: " + ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);
            _loggerHelper.GravarTexto("Certificado digital arquivo .pfx: " + ParametrosGlobal.CertificadoDigitalCaminho);

            try
            {
                // cancelar uma nota fiscal de serviço eletronica para gov.br
                var notaGovBus = new NfseGovBrCancelarBus();

                // cancelar a próxima nota fiscal de serviço eletrônica
                await notaGovBus.CancelarProximaNotaFiscal();
            }
            catch (Exception ex)
            {
                // log de erro
                _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.CancelarNotaManager.Cancelar() | fim com erro" + ex.ToString());
            }

            // ------------------------------------------------

            try
            {
                // consultar evento de cancelamento
                var eventoGovBr = new NfseGovBrNfseEventosConsultarBus();

                var retornoEventoConsultar = await eventoGovBr.ConsultarEvento("chave-acesso-qualquer");
            }
            catch (Exception ex)
            {
                // log de erro
                _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.CancelarNotaManager.Cancelar() | fim com erro" + ex.ToString());
            }

            // log
            _loggerHelper.GravarTexto("Cecam.Tributario.NfseGovBr.Nota.CancelarNotaManager.Cancelar() | fim com sucesso");
        }
    }
}
