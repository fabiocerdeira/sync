﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
//using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Extend
{
    public static class CloneExtension
    {
        /*
        public static T CloneV2<T>(this T source)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(T));
            using (MemoryStream ms = new MemoryStream())
            {
                serializer.WriteObject(ms, source);
                ms.Seek(0, SeekOrigin.Begin);
                return (T)serializer.ReadObject(ms);
            }
        }
        */

        /// <summary>
        /// Clone esse objeto e todos os seus objetos filhos carregados.
        /// Atenção especial ao chamar esse método quando existirem propriedades que ainda não foram carregadas na base,
        /// porque o processo de percorrer os objetos filhos vai acabar por chamar a consulta ao banco,
        /// como regra isso NÃO pode acontecer ou vai sobre carregar a base e o sistema.
        /// </summary>
        public static T Clone<T>(this T obj)
        {
            if (ReferenceEquals(obj, null))
                throw new Exception("CloneExtension.Clone - erro - objeto de origem não pode ser null");

            // para evitar 'self referencing loop'
            var jSettings = new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore };

            string json = Newtonsoft.Json.JsonConvert.SerializeObject(obj, jSettings);

            if (string.IsNullOrWhiteSpace(json))
                throw new Exception("CloneExtension.Clone - erro - não foi possível serializar objeto de origem");

            var retorno = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(json);

            if (retorno == null)
                throw new Exception("CloneExtension.Clone - erro - não foi possível deSerializar objeto de destino");

            return retorno;
        }
    }
}
