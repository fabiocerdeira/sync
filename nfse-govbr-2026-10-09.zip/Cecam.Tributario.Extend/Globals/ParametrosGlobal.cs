﻿using Microsoft.Extensions.Configuration;

namespace Cecam.Tributario.Extend.Globals
{
    public static class ParametrosGlobal
    {
        /// <summary>
        /// Versão do sistema
        /// </summary>
        public static string Versao { get; } = "2026.08.11";


        /// <summary>
        /// Código da prefeitura dentro da Cecam
        /// </summary>
        public static int Cd_Cecam { get; set; }

        
        /// <summary>
        /// Exercicio corrente
        /// </summary>
        public static int Cd_Exercicio { get; set; }


        /// <summary>
        /// ApiKey utilizada na segurança do projeto WEB.API dessa solução
        /// </summary>
        public static string WebApiKey { get; } = "Tributos@Cecam";



        #region Certificado digital da prefeitura


        /// <summary>
        /// Caminho no disco do certificado digital da prefeitura no formato arquivo .pfx protegido por senha
        /// </summary>
        public static string CertificadoDigitalCaminho { get; set; } = string.Empty;


        /// <summary>
        /// Senha para acesso ao certificado digital da prefeitura
        /// </summary>
        public static string CertificadoDigitalSenha { get; set; } = string.Empty;


        /// <summary>
        /// Thumbprint para encontrar o certificado digital instalado na maquina/servidor no repositório 'Local Machine'
        /// </summary>
        public static string CertificadoDigitalThumbPrintLocalMachine { get; set; } = string.Empty;


        /// <summary>
        /// Thumbprint para encontrar o certificado digital instalado na maquina/servidor no repositório 'Current User'
        /// </summary>
        public static string CertificadoDigitalThumbPrintCurrentUser { get; set; } = string.Empty;


        /// <summary>
        /// Carregar o certificado digital via arquivo .pfx usando LoadCertificate modelo antigo/obsoleto.
        /// </summary>
        public static bool CertificadoDigitalModeloAntigo { get; set; }


        #endregion



        #region Nota Fiscal de Serviço Eletronica


        /// <summary>
        /// Indica se o ambiente da NFSe do Gov.Br que os dados estão sendo enviados é de produção (true) ou de homologação (false)
        /// </summary>
        public static bool NfseGovBr_HeAmbienteProducao { get; set; }


        /// <summary>
        /// Url do Gov.Br para envio e consulta de nota fiscal de servico eletronico
        /// </summary>
        public static string NfseGovBr_Adn_Url { get; set; } = string.Empty;


        /// <summary>
        /// Url do Gov.Br para envio e consulta de nota fiscal de servico eletronico
        /// </summary>
        public static string NfseGovBr_Sefin_Url { get; set; } = string.Empty;


        #endregion



        #region Monitor

        /// <summary>
        /// Pasta raiz do monitor do sistema
        /// </summary>
        public static string MonitorPasta { get; set; } = string.Empty;

        #endregion




        /// <summary>
        /// Carregar os parametros do arquivo para as propriedades
        /// </summary>
        public static void Carregar(IConfiguration _configuration)
        {
            // Código da prefeitura dentro da Cecam
            int cdCecam = 0;
            int.TryParse("" + _configuration["Cd_Cecam"], out cdCecam);
            Cd_Cecam = cdCecam;

            // exercicio corrente
            if (int.TryParse("" + _configuration["Exercicio"], out var anoExercicio))
                Cd_Exercicio = anoExercicio;
            else
                Cd_Exercicio = DateTime.Now.Year;

            // ambiente do gov.br para nota fiscal de serviço eletronica
            NfseGovBr_HeAmbienteProducao = _configuration.GetValue<bool>("NfseGovBr:AmbienteProducao");

            // url do gov.br para nota fiscal de serviço eletronica
            NfseGovBr_Adn_Url = "" + _configuration["NfseGovBr:Adn:Url"];
            NfseGovBr_Sefin_Url = "" + _configuration["NfseGovBr:Sefin:Url"];

            if (!string.IsNullOrWhiteSpace(NfseGovBr_Adn_Url) && !NfseGovBr_Adn_Url.EndsWith('/'))
                NfseGovBr_Adn_Url += '/';

            if (!string.IsNullOrWhiteSpace(NfseGovBr_Sefin_Url) && !NfseGovBr_Sefin_Url.EndsWith('/'))
                NfseGovBr_Sefin_Url += '/';

            // thumb print do certificado digital da prefeitura instalado no registro do windows da maquina/servidor
            CertificadoDigitalThumbPrintLocalMachine = ("" + _configuration["CertificadoDigital:InstaladoServidor:ThumbPrintLocalMachine"]).Replace(" ","").Trim();
            CertificadoDigitalThumbPrintCurrentUser = ("" + _configuration["CertificadoDigital:InstaladoServidor:ThumbPrintCurrentUser"]).Replace(" ","").Trim();

            // caminho pasta local do servidor com o certificado digital da prefeitura
            CertificadoDigitalSenha = "" + _configuration["CertificadoDigital:ArquivoEmDisco:Senha"];
            CertificadoDigitalModeloAntigo = _configuration.GetValue<bool>("CertificadoDigital:ArquivoEmDisco:ModeloAntigo");
            CertificadoDigitalCaminho = "" + _configuration["CertificadoDigital:ArquivoEmDisco:Caminho"];

            // monitor
            MonitorPasta = string.Empty + _configuration["Monitor:Pasta"];
            if (!string.IsNullOrWhiteSpace(MonitorPasta) && !MonitorPasta.EndsWith('\\'))
                MonitorPasta += '\\';
        }
    }
}
