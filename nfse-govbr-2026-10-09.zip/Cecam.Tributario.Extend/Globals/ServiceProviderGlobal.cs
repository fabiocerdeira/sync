﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Cecam.Tributario.Extend.Globals
{
    public static class ServiceProviderGlobal
    {
        /// <summary>
        /// Referencia ao servico global
        /// </summary>
        public static IServiceProvider ServiceProviderReference { get; set; } = new ServiceCollection().BuildServiceProvider();
        

        /// <summary>
        /// Retornar um servico global
        /// </summary>
        public static TEntity GetServico<TEntity>() where TEntity : notnull
        {
            return ServiceProviderReference.GetRequiredService<TEntity>();
        }


        /// <summary>
        /// Criar e retornar objeto para LOG
        /// </summary>
        public static ILogger<TEntity> CreateLogger<TEntity>() where TEntity : notnull
        {
            return GetServico<ILoggerFactory>().CreateLogger<TEntity>();
        }
    }
}
