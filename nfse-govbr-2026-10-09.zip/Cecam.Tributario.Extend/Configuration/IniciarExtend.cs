﻿using Cecam.Tributario.Extend.Globals;
using Cecam.Tributario.Extend.Logg;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Configuration
{
    public static class IniciarExtend
    {
        public static IServiceCollection ServiceList { get; private set; } = new ServiceCollection();


        public static IConfiguration Configuration { get; private set; } = new ConfigurationBuilder().Build();


        public static void Create()
        {
            // carregar arquivo de configurações
            // IConfiguration configuration = new ConfigurationBuilder()
            Configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("AppSettings.json")
#if DEBUG
                .AddJsonFile($"AppSettings.dev.json", true, true)
#endif
                .Build();

            // parametros do settings.json para memória.
            ParametrosGlobal.Carregar(Configuration);


            // logger
            ILoggerFactory loggerFactory = LoggerFactory.Create(b =>
            {
                b.AddConfiguration(Configuration.GetSection("Logging"));
                b.AddConsole();
                b.AddDebug();
                b.AddProvider(new FileLoggerProvider());
            });


            // preparar EF Core para executar service colletion
            // que é o controlador de "DI"
            // var services = new ServiceCollection();
            // services.Clear();
            ServiceList.Clear();
            // services.AddHttpClient();

            // incluir o iConfiguration na coleção de serviços par DI.
            ServiceList.AddSingleton<IConfiguration>(provider => Configuration);
            ServiceList.AddTransient<ILoggerFactory>(provider => loggerFactory);

        }


        public static void Build() 
        {
            // build das configurações acima.
            ServiceProviderGlobal.ServiceProviderReference = ServiceList.BuildServiceProvider();
        }
    }
}
