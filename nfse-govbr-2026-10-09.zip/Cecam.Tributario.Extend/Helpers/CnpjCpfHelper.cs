﻿using System.Text.RegularExpressions;

namespace Cecam.Tributario.Extend.Helpers
{
    public class CnpjCpfHelper
    {
        /// <summary>
        /// Enum com o tipo de inscrição federal
        /// </summary>
        public enum CnpjCpfHelperTipoEnum
        {
            Erro = 0,
            CPF = 1,
            CNPJ = 2
        }


        /// <summary>
        /// Retornar o texto informado mantendo somente os numeros de 0 até 9 e letras removendo simbolos e espaços
        /// </summary>
        public string RetornaSomenteNumerosLetras(string texto)
        {
            return Regex.Replace("" + texto, @"[^a-zA-Z0-9\s]", string.Empty);
        }


        /// <summary>
        /// Indica se o texto informado é um tipo 1=cnpj ou 2=cpf ou 0=erro ?
        /// </summary>
        public CnpjCpfHelperTipoEnum VerificarTipo(string texto)
        {
            switch (RetornaSomenteNumerosLetras(texto).Length)
            {
                case 11:
                    return CnpjCpfHelperTipoEnum.CPF;
                case 14:
                    return CnpjCpfHelperTipoEnum.CNPJ;
                default:
                    return CnpjCpfHelperTipoEnum.Erro;
            }
        }

    }
}
