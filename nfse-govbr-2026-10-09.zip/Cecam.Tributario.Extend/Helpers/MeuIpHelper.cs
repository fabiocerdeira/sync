﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Helpers
{
    public class MeuIpHelper
    {
        public string RetornarMeuIp()
        {
            // versão curta, porem não trata endereços locais como "::1"
            // var meuIp = Dns.GetHostEntry(Dns.GetHostName()).AddressList[0].ToString();

            // valor retornado pelo método
            string meuIp = string.Empty;

            var listaIps = Dns.GetHostEntry(Dns.GetHostName()).AddressList;

            if (listaIps != null)
            {
                foreach (var item in listaIps)
                {
                    // 127.0.0.1
                    if (item.ToString().Length >= 9)
                    {
                        meuIp = item.ToString();
                    }
                }
            }

            // não pode retornar vazio
            if (string.IsNullOrWhiteSpace(meuIp)) 
                meuIp = "127.0.0.1";

            // valor retornado pelo método
            return meuIp;
        }
    }
}
