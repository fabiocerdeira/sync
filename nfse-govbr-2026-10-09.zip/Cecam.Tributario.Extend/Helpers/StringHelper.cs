﻿using System.Text.RegularExpressions;

namespace Cecam.Tributario.Extend.Helpers
{
    public class StringHelper
    {
        /// <summary>
        /// Remover espaços duplos dentro do texto entre as palavras/letras
        /// </summary>
        public string? RemoverEspacosDuplos(string? texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return texto;

            // alterar espaços duplos por 1 espaço simples.
            return Regex.Replace(texto, @"\s+", " ").Trim();
        }


        /// <summary>
        /// Reduzir a qtd de caracteres da string informada
        /// </summary>
        public string? ReduzirTamanho(int tamanho, string? texto, string reticencias, bool removerEspacosDuplos = true)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return texto;

            // remover espaços duplos
            if (removerEspacosDuplos)
                texto = Regex.Replace(texto, @"\s+", " ").Trim();

            if (texto.Length <= tamanho)
                return texto;

            return texto.Substring(0, tamanho - reticencias.Length) + reticencias;
        }
    }
}
