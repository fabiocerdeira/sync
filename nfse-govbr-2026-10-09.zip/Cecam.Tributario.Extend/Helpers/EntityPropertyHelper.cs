﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Helpers
{
    /// <summary>
    /// Ajudas com campos de propriedade das classes do tipo entity
    /// </summary>
    public class EntityPropertyHelper
    {
        /// <summary>
        /// Recebe o campo 'Cd_Referencia' e retorna o ANO
        /// </summary>
        public int GetCdReferenciaAno(int cdReferencia)
        {
            if (cdReferencia <= 0 || cdReferencia.ToString().Length != 6)
                return 0;

            var anoString = cdReferencia.ToString().Substring(0, 4);

            if (int.TryParse(anoString, out var anoInt))
                return anoInt;

            return 0;
        }


        /// <summary>
        /// Recebe o campo 'Cd_Referencia' e retorna o MES
        /// </summary>
        public int GetCdReferenciaMes(int cdReferencia)
        {
            if (cdReferencia <= 0 || cdReferencia.ToString().Length != 6)
                return 0;

            var mesString = cdReferencia.ToString().Substring(4, 2);

            if (int.TryParse(mesString, out var mesInt))
                return mesInt;

            return 0;
        }
    }
}
