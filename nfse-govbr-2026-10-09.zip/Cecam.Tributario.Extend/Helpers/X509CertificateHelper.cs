﻿using Cecam.Tributario.Extend.Globals;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Cecam.Tributario.Extend.Helpers
{
    /// <summary>
    /// Carregar o certificado seguro a partir das configurações do app.settings.
    /// </summary>
    public class X509CertificateHelper
    {

        /// <summary>
        /// Retornar o certificado seguro, instalado no servidor ou arquivo em disco.
        /// Para funcionar é necessário confgiurar o app.settings.
        /// </summary>
        public X509Certificate2? GetCertificate()
        {
            // carregar o certificado que esta instalado nos servidor.
            X509Certificate2? cert = GetCertificateInstalado();

            // verificar se não encontrou o certificado instalado no servidor,
            // então carregar o certificado a partir do arquivo em disco.
            if (cert == null)
            {
                if (ParametrosGlobal.CertificadoDigitalModeloAntigo)
                {
                    // usar modelo antigo de carregar do arquivo em disco.
                    cert = GetCertificateModeloAntigoPorArquivo();
                }
                else
                {
                    cert = GetCertificatePorArquivo();
                }
            }

            return cert;
        }


        /// <summary>
        /// Verificar a data de vigência do certificado. <br/>
        /// Se a data atual é maior que a data de inicio e se a data atual é menor que a data de fim ?
        /// </summary>
        public bool VerificarVigencia(X509Certificate2 cert)
        {
            // retornar se o certificado esta com data vigente correta?
            return DateTime.Now >= cert.NotBefore && DateTime.Now <= cert.NotAfter;
        }


        #region Dump

        /// <summary>
        /// Carregar o certificado original e gravar logs e pfx com a versão carregada
        /// </summary>
        public void Dump()
        {
            var cert = GetCertificateInstaladoPorStoreLocation(StoreLocation.LocalMachine, ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);
            Testar(cert, "Local Machine | Computador", ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);
            DumpCriarArquivos(cert, "LocalMachine", "LM");

            cert = GetCertificateInstaladoPorStoreLocation(StoreLocation.CurrentUser, ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);
            Testar(cert, "Current User | Usuario Local", ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);
            DumpCriarArquivos(cert, "CurrentUser", "CU");

            cert = GetCertificateModeloAntigoCarregar();
            Testar(cert, "Arquivo Modelo Antigo", ParametrosGlobal.CertificadoDigitalCaminho);
            DumpCriarArquivos(cert, "ArquivoModeloAntigo", "AA");

            cert = GetCertificatePorArquivoCarregar();
            Testar(cert, "Arquivo Modelo Novo", ParametrosGlobal.CertificadoDigitalCaminho);
            DumpCriarArquivos(cert, "ArquivoModeloNovo", "AN");
        }


        private void Testar(X509Certificate2? certificado, string local, string chaveArquivo)
        {
            // pular linhas
            Console.WriteLine("\n\n");

            // local do certificado
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("------------------------------  " + local);

            if (certificado == null)
            {
                // certificado não encontrado
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Certificado " + local + " NÃO encontrado. Chave/Arquivo = " + chaveArquivo);
                Console.ResetColor();
                return;
            }

            // cabeça
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Certificado " + local + " SIM encontrado. Chave/Arquivo = " + chaveArquivo);
            Console.WriteLine("Certificado nome amigavel : " + certificado.FriendlyName);

            // datas de vigencia
            Console.ForegroundColor = VerificarVigencia(certificado) ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine("Certificado data inicio : " + certificado.NotBefore);
            Console.WriteLine("Certificado data fim : " + certificado.NotAfter);

            // private key
            Console.ForegroundColor = certificado.HasPrivateKey ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine("Certificado tem chave privada : " + certificado.HasPrivateKey);

            if (certificado.HasPrivateKey)
            {
                try
                {
                    var pk = certificado.GetRSAPrivateKey();
                
                    if (pk != null)
                    {
                        string keyName = "" + ((System.Security.Cryptography.RSACng)pk).Key.KeyName;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Certificado chave privada KeyName = " + keyName);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Certificado chave privada EXISTE mas NÃO tem permissão");
                    }
                }
                catch (Exception)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("ERRO ** Não foi possivel recuperar GetRSAPrivateKey()");
                }
            }

            // reset color
            Console.ResetColor();
        }


        /// <summary>
        /// Criar um arquivo em disco com o certificado informado no parametro
        /// </summary>
        private void DumpCriarArquivos(X509Certificate2? certificado, string nomeArquivo, string nomeDetalhe)
        {
            if (certificado == null)
                return;

            var pastaSaida = AppDomain.CurrentDomain.BaseDirectory + $"certificados";

            // apagar lixo antigo
            if (Directory.Exists(pastaSaida))
                Directory.Delete(pastaSaida, true);

            /*
            Directory.CreateDirectory(pastaSaida);

            // ----------------------------

            var jsonCert = Newtonsoft.Json.JsonConvert.SerializeObject(certificado, Newtonsoft.Json.Formatting.Indented);

            File.WriteAllText(pastaSaida + $"\\{nomeArquivo}_certificadoSeguro.json", jsonCert, Encoding.UTF8);

            // ----------------------------

            // apenas para debugar e saber qual é o tipo correto
            var tipo = X509Certificate2.GetCertContentType(certificado.GetRawCertData());

            // gravar no disco usando varios formatos
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_Authenticode.pfx", X509ContentType.Authenticode);
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_Cert.cer", X509ContentType.Cert); // .cer
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_Pfx.pfx", X509ContentType.Pfx);
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_Pkcs12.pfx", X509ContentType.Pkcs12); // .pfx
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_Pkcs7.p7b", X509ContentType.Pkcs7); // .p7b
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_SerializedCert.sst", X509ContentType.SerializedCert); // .sst
            DumpEscreverArquivo(certificado, pastaSaida + $"\\{nomeArquivo}_SerializedStore.sst", X509ContentType.SerializedStore);
            */

            pastaSaida = AppDomain.CurrentDomain.BaseDirectory + "Log_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + DateTime.UtcNow.AddHours(-3).ToString(@"yyyy\\MM\\dd");
            Directory.CreateDirectory(pastaSaida);

            DumpEscreverArquivo(certificado, pastaSaida + $"\\detalhe{nomeDetalhe}1.txt", X509ContentType.Cert); // .cer
            DumpEscreverArquivo(certificado, pastaSaida + $"\\detalhe{nomeDetalhe}2.txt", X509ContentType.Pfx); // .pfx
            DumpEscreverArquivo(certificado, pastaSaida + $"\\detalhe{nomeDetalhe}3.txt", X509ContentType.Pkcs12); // .pfx
            DumpEscreverArquivo(certificado, pastaSaida + $"\\detalhe{nomeDetalhe}4.txt", X509ContentType.SerializedCert); // .sst
            DumpEscreverArquivo(certificado, pastaSaida + $"\\detalhe{nomeDetalhe}5.txt", X509ContentType.SerializedStore);
        }


        private void DumpEscreverArquivo(X509Certificate2 certificado, string nomeArquivo, X509ContentType tp)
        {
            try
            {
                File.WriteAllBytes(nomeArquivo, certificado.Export(tp, ParametrosGlobal.CertificadoDigitalSenha));
            }
            catch (Exception ex)
            {
                var msg = ex.ToString();
            }
        }


        /// <summary>
        /// Listar na tela todos os ceritifcados instalados no servidor
        /// </summary>
        public void DumpListarTodos(string local)
        {
            if (local.ToLower()=="lm")
                DumpListarTodosProcessar(StoreLocation.LocalMachine, "LM");

            if (local.ToLower() == "cu")
                DumpListarTodosProcessar(StoreLocation.CurrentUser, "CU");
        }


        private void DumpListarTodosProcessar(StoreLocation storeLocation, string local)
        {
            var listaCertificados = new X509Store(storeLocation);

            listaCertificados.Open(OpenFlags.MaxAllowed);

            foreach (var item in listaCertificados.Certificates)
            {
                Console.WriteLine("------------------------------------------------------------------------------------");
                Console.WriteLine(local + " | " + item.FriendlyName + " | " + item.Subject + " | " + item.Thumbprint);
                Console.WriteLine(item.ToString());
                Console.WriteLine("------------------------------------------------------------------------------------\n\n\n\n");
            }
        }

        #endregion


        #region Certificado instalado no servidor como localMachine ou currentUser

        /// <summary>
        /// Retornar o certificado instalado no servidor.
        /// Esse método busca em todos os storeLocations (LocalMachine ou CurrentUser)
        /// </summary>
        public X509Certificate2? GetCertificateInstalado()
        {
            // tentar carregar certificado se estiver instalado em LocalMachine
            X509Certificate2? cert = GetCertificateInstaladoPorStoreLocation(StoreLocation.LocalMachine, ParametrosGlobal.CertificadoDigitalThumbPrintLocalMachine);

            // tentar carregar certificado se estiver instalado em CurrentUser
            if (cert == null)
                cert = GetCertificateInstaladoPorStoreLocation(StoreLocation.CurrentUser, ParametrosGlobal.CertificadoDigitalThumbPrintCurrentUser);

            // valor retornado pelo método
            return cert;
        }


        /// <summary>
        /// Retornar o certificado instalado no servidor informando o StoreLocation (LocalMachine ou CurrentUser)
        /// </summary>
        public X509Certificate2? GetCertificateInstaladoPorStoreLocation(StoreLocation storeLocation, string thumbPrint)
        {
            // verificar se temos o thumbprint configurado para carregar o certificado instalado no servidor.
            if (string.IsNullOrWhiteSpace(thumbPrint))
                return null;

            var listaCertificados = new X509Store(storeLocation);

            // listaCertificados.Open(OpenFlags.ReadOnly);
            listaCertificados.Open(OpenFlags.MaxAllowed);

            // valor retornado pelo método
            X509Certificate2? certInstalado = null;

            if (listaCertificados.Certificates.Count > 0)
            {
                // procurar certificado pelo thumbPrint
                certInstalado = listaCertificados.Certificates.FirstOrDefault(x => x.Thumbprint.Replace(" ", "").Trim().ToUpper() == thumbPrint.ToUpper());
            }

            // fechar lista
            listaCertificados.Close();

            // valor retornado pelo método
            return certInstalado;
        }

        #endregion


        #region Certificado por arquivo modelo antigo


        /// <summary>
        /// Carregar o certificado digital a partir de uma pasta no disco.
        /// Obrigatorio o arquivo '.pfx' exisitr no disco e estar protegido por senha.
        /// </summary>
        public X509Certificate2? GetCertificateModeloAntigoPorArquivo()
        {
            // validar parametros configurado no app.settings
            GetCertificateModeloAntigoValidar();

            // tive que usar essa versão obsoleta pq é a única que realemente funciona.
            // o X509CertificateLoader.LoadPkcs12FromFile carrega mas no momento do envio, o gov.br rejeita o certificado
            // acho que tem relação com o campo 'FriendlyName' que precisa obrigatoriamente conter o nome+cnpj da prefeitura,
            // e quando é carregado pelos outros métodos esse nome vem com o thumbprint do certificado nesse campo ao inves do nome+cnpj
            return GetCertificateModeloAntigoCarregar();
        }

        /// <summary>
        /// Carregar o certificado digital a partir de uma pasta no disco.
        /// Obrigatorio o arquivo '.pfx' exisitr no disco e estar protegido por senha.
        /// </summary>
        public void GetCertificateModeloAntigoValidar()
        {
            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalCaminho))
                throw new Exception("Certificado digital da prefeitura não foi configurado no app.settings. **erro**");

            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalSenha))
                throw new Exception("Senha para certificado digital da prefeitura não foi configurado no app.settings. **erro**");

            // validar parametros configurado no app.settings
            if (!File.Exists(ParametrosGlobal.CertificadoDigitalCaminho))
                throw new Exception("Certificado digital da prefeitura não foi encontrado no servidor. **erro**");
        }

        /// <summary>
        /// Carregar o certificado digital a partir de uma pasta no disco.
        /// Obrigatorio o arquivo '.pfx' exisitr no disco e estar protegido por senha.
        /// </summary>
        public X509Certificate2? GetCertificateModeloAntigoCarregar()
        {
            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalCaminho))
                return null;

            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalSenha))
                return null;

            // validar parametros configurado no app.settings
            if (!File.Exists(ParametrosGlobal.CertificadoDigitalCaminho))
                return null;

            // tive que usar essa versão obsoleta pq é a única que realemente funciona.
            // o X509CertificateLoader.LoadPkcs12FromFile carrega mas no momento do envio, o gov.br rejeita o certificado
            // acho que tem relação com o campo 'FriendlyName' que precisa obrigatoriamente conter o nome+cnpj da prefeitura,
            // e quando é carregado pelos outros métodos esse nome vem com o thumbprint do certificado nesse campo ao inves do nome+cnpj
            // return new X509Certificate2(ParametrosGlobal.CertificadoDigitalCaminho, ParametrosGlobal.CertificadoDigitalSenha);

#pragma warning disable SYSLIB0057
            return new X509Certificate2(ParametrosGlobal.CertificadoDigitalCaminho, ParametrosGlobal.CertificadoDigitalSenha, 
                X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
#pragma warning restore
        }

        #endregion


        #region Certificado por arquivo modelo novo

        /// <summary>
        /// Retornar o certificado seguro do servidor a partir de um arquivo .cer ou .pfx copiado em alguma pasta do servidor
        /// </summary>
        public X509Certificate2? GetCertificatePorArquivo()
        {
            // validar parametros configurado no app.settings
            GetCertificatePorArquivoValidar();

            // carregar o certificado do disco
            return GetCertificatePorArquivoCarregar();
        }

        /// <summary>
        /// Retornar o certificado seguro do servidor a partir de um arquivo .cer ou .pfx copiado em alguma pasta do servidor
        /// </summary>
        public void GetCertificatePorArquivoValidar()
        {
            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalCaminho))
                throw new Exception("Certificado digital da prefeitura não foi configurado no app.settings. **erro**");

            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalSenha))
                throw new Exception("Senha para certificado digital da prefeitura não foi configurado no app.settings. **erro**");

            // validar parametros configurado no app.settings
            if (!File.Exists(ParametrosGlobal.CertificadoDigitalCaminho))
                throw new Exception("Certificado digital da prefeitura não foi encontrado no servidor. **erro**");
        }

        /// <summary>
        /// Retornar o certificado seguro do servidor a partir de um arquivo .cer ou .pfx copiado em alguma pasta do servidor
        /// </summary>
        public X509Certificate2? GetCertificatePorArquivoCarregar()
        {
            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalCaminho))
                return null;

            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalSenha))
                return null;

            // validar parametros configurado no app.settings
            if (!File.Exists(ParametrosGlobal.CertificadoDigitalCaminho))
                return null;

            // carregar o certificado do disco
            //return X509CertificateLoader.LoadPkcs12FromFile(ParametrosGlobal.CertificadoDigitalCaminho, ParametrosGlobal.CertificadoDigitalSenha,
            //    X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);

            /*
            var xxx = X509CertificateLoader.LoadCertificateFromFile(ParametrosGlobal.CertificadoDigitalCaminho);
            var stream = new MemoryStream();
            var c = X509CertificateLoader.LoadPkcs12(stream.ToArray(), ParametrosGlobal.CertificadoDigitalSenha,
                X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
            return c;
            */

            return  X509CertificateLoader.LoadPkcs12FromFile(ParametrosGlobal.CertificadoDigitalCaminho, ParametrosGlobal.CertificadoDigitalSenha,
                X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
        }

        #endregion
    }
}
