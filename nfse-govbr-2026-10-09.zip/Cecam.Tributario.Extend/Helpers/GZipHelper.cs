﻿using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Helpers
{
    public class GZipHelper
    {
        /// <summary>
        /// Compactar/zipar o texto informado no parametro e retornar um base64 (usando UTF8)
        /// </summary>
        /// <param name="value">texto aberto/descompactado que será zipado/compactado</param>
        /// <returns>string em formato base64 contendo texto compactado</returns>
        public string CompactarStringTobase64(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            // compactar corpo
            // var gziped = new MemoryStream();

            using (var gziped = new MemoryStream())
            {
                using (var gzip = new GZipStream(gziped, CompressionMode.Compress))
                {
                    gzip.Write(Encoding.UTF8.GetBytes(value));

                    // converter string compactada em string base64
                    return Convert.ToBase64String(gziped.ToArray());
                }
            }
        }


        /// <summary>
        /// Descompactar/unzipar uma string base64 que contem uma string compactada e retornar uma texto aberto (usando UTF8)
        /// </summary>
        /// <param name="base64value">string em formato base64 contendo texto compactado</param>
        /// <returns>texto aberto/descompactado</returns>
        public string DescompactarBase64ToString(string base64value)
        {
            if (string.IsNullOrWhiteSpace(base64value))
                return string.Empty;

            // em 2025-11-21 isso não é mais usado...
            // converte de base64 para string (ainda compactada)
            // var value = Encoding.UTF8.GetString(Convert.FromBase64String(base64value));

            using (var gziped = new MemoryStream(Convert.FromBase64String(base64value)))
            {
                using (var gzip = new GZipStream(gziped, CompressionMode.Decompress))
                {
                    using (var streamReader = new StreamReader(gzip, Encoding.UTF8))
                    {
                        // retornar o texto aberto/descompactado
                        return streamReader.ReadToEnd();
                    }
                }
            }
        }
    }
}
