﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Helpers
{
    public class Base64Helper
    {
        /// <summary>
        /// Encode da string/texto informado no parametro e retorna um base64 usando UTF8
        /// </summary>
        public string EncodeStringToBase64(string stringValue)
        {
            if (string.IsNullOrWhiteSpace(stringValue))
                return string.Empty;

            return Convert.ToBase64String(Encoding.UTF8.GetBytes(stringValue));
        }


        /// <summary>
        /// Encode do byte array informado no parametro e retorna um base64.
        /// </summary>
        /// <param name="bArray"></param>
        /// <returns></returns>
        public string EncodeArrayToBase64(byte[] bArray)
        {
            return Convert.ToBase64String(bArray);
        }


        /// <summary>
        /// Decode da base64 informado no parametro e retorna uma string/texto usando UTF8
        /// </summary>
        public string DecodeBase64ToString(string base64value)
        {
            if (string.IsNullOrWhiteSpace(base64value))
                return string.Empty;

            return Encoding.UTF8.GetString(Convert.FromBase64String(base64value));
        }
    }
}
