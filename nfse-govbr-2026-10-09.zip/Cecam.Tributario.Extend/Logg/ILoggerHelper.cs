﻿using Microsoft.Extensions.Logging;

namespace Cecam.Tributario.Extend.Logg
{
    public interface ILoggerHelper
    {
        ILogger? Logger { get; set; }

        void Inicializar<TEntity>() where TEntity : notnull;

        bool ExibirNaTela { get; set; }

        string PrefixoNomeArquivo { get; set; }

        string ObjFullName { get; set; }

        void GravarObjeto(object obj, LogLevel logLevel = LogLevel.Information);

        void GravarTexto(string mensagem, LogLevel logLevel = LogLevel.Information);

        void Gravar(string mensagem, LogLevel logLevel = LogLevel.Information, string nomeArquivo = "");

        void GravarArquivoDisco(string mensagem, string nomeArquivo, string pasta = "");
    }
}
