﻿using Cecam.Tributario.Extend.Globals;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Extend.Logg
{
    public class FileLogger : ILogger
    {
        private readonly string _categoryName;
        private readonly StreamWriter _writer;

        
        /*
        Profundidade dos logs:
        Trace, Debug, Information, Warning, Error, Critical, None
        */


        public FileLogger(string categoryName)
        {
            if (string.IsNullOrWhiteSpace(categoryName))
                categoryName = "Geral";

            _categoryName = categoryName;

            var logPath = AppDomain.CurrentDomain.BaseDirectory + "Log_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + DateTime.UtcNow.AddHours(-3).Year + "\\" + DateTime.UtcNow.AddHours(-3).ToString("MM") + "\\" + DateTime.UtcNow.AddHours(-3).ToString("dd");

            Directory.CreateDirectory(logPath);

            // primeiro numero do minuto
            // feito para separar o log em arquivos a cada 10 minutos
            var minuto = DateTime.UtcNow.AddHours(-3).ToString("mm")[0];

            _writer = new StreamWriter(logPath + "\\" + categoryName + "_" + DateTime.UtcNow.AddHours(-3).ToString("yyyyMMdd_HH") + minuto + "0.txt", true, Encoding.UTF8);
        }


        ~FileLogger() 
        {
            if (_writer != null)
            {
                _writer.Flush();
                _writer.Close();
                _writer.Dispose();
            }
        }


        public IDisposable? BeginScope<TState>(TState state) where TState : notnull
        {
            return null;
        }


        public bool IsEnabled(LogLevel logLevel)
        {
            // return logLevel < LogLevel.None;
            return true;
        }


        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            //if (!IsEnabled(logLevel))
            //    return;

            _writer.WriteLine($"[{logLevel}] [{DateTime.UtcNow.AddHours(-3).ToString("HH:mm:ss:fff")}] " + formatter(state, exception));
            _writer.Flush();
        }
    }
}
