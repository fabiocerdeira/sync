﻿using Cecam.Tributario.Extend.Globals;
using Microsoft.Extensions.Logging;
using System.Text;

namespace Cecam.Tributario.Extend.Logg
{
    public class LoggerHelper : ILoggerHelper
    {
        public ILogger? Logger { get; set; }


        public bool ExibirNaTela { get; set; } = true;
        

        public string PrefixoNomeArquivo { get; set; } = string.Empty;
        

        public string ObjFullName { get; set; } = string.Empty;


        public LoggerHelper()
        {
        }


        public LoggerHelper(string objFullName, ILogger logger)
        {
            ObjFullName = objFullName;
            Logger = logger;
        }


        public void Inicializar<TEntity>() where TEntity : notnull
        {
            ObjFullName = "" + typeof(TEntity).FullName;
            Logger = ServiceProviderGlobal.CreateLogger<TEntity>();
        }


        /// <summary>
        /// Gravar objeto no arquivo de log em disco e exibir na tela.
        /// </summary>
        public void GravarObjeto(object obj, LogLevel logLevel = LogLevel.Information)
        {
            // gravar log no arquivo em disco
            Gravar(Newtonsoft.Json.JsonConvert.SerializeObject(obj), logLevel);
        }


        /// <summary>
        /// Gravar mensagem de texto no arquivo em disco e exibir na tela.
        /// </summary>
        public void GravarTexto(string mensagem, LogLevel logLevel = LogLevel.Information)
        {
            // gravar log no arquivo em disco
            Gravar(mensagem, logLevel);

        }


        /// <summary>
        /// Gravar log
        /// </summary>
        public void Gravar(string mensagem, LogLevel logLevel = LogLevel.Information, string nomeArquivo = "")
        {
            try
            {
                // exibir na tela.
                if (ExibirNaTela)
                    Console.WriteLine(mensagem + " " + ObjFullName +  Environment.NewLine);

                if (Logger != null)
                    Logger.Log(logLevel, mensagem);

                // corpo da mensagem
                mensagem = "**" + DateTime.UtcNow.AddHours(-3).ToString("dd/MM/yyyy HH:mm:ss.fff") + "** " + ObjFullName + Environment.NewLine + Environment.NewLine + mensagem + Environment.NewLine + Environment.NewLine;

                if (string.IsNullOrWhiteSpace(nomeArquivo))
                    nomeArquivo = "Completo";

                // primeiro numero do minuto
                // feito para separar o log em arquivos a cada 10 minutos
                var minuto = DateTime.UtcNow.AddHours(-3).ToString("mm")[0];

                // juntar os nomes do arquivo
                nomeArquivo = this.PrefixoNomeArquivo + nomeArquivo + "_" + DateTime.UtcNow.AddHours(-3).ToString("yyyyMMdd_HH") + minuto + "0.txt";

                // gravar no arquivo
                GravarArquivoDisco(mensagem, nomeArquivo);
            }
            catch (Exception)
            {
            }
        }


        /// <summary>
        /// Método mais base, que grava a mensagem, no arquivo informado
        /// </summary>
        public void GravarArquivoDisco(string mensagem, string nomeArquivo, string pasta = "")
        {
            try
            {
                if (string.IsNullOrWhiteSpace(pasta))
                    pasta = AppDomain.CurrentDomain.BaseDirectory + "Log_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + DateTime.UtcNow.AddHours(-3).ToString(@"yyyy\\MM\\dd");

                // criar a pasta caso não exista.
                Directory.CreateDirectory(pasta);

                // append
                File.AppendAllText(pasta + "\\" + nomeArquivo, mensagem, Encoding.UTF8);
            }
            catch (Exception)
            {
            }
        }


        /// <summary>
        /// Apagar pastas de logs mais antigas
        /// </summary>
        public void LimparPastasAntigas(bool somenteMadrugada)
        {
            // verificar se deve fazer limpeza somente de madrugada ?
            if (somenteMadrugada && DateTime.UtcNow.AddHours(-3).Hour >= 5)
                return;

            // -----------------

            // pastas que serão apagadas
            // baixados_[cd_cecam]
            // log_0 (zero)
            // log_[cd_cecam]

            var dataAntiga = DateTime.UtcNow.AddHours(-3);
            var pasta = string.Empty;

            for (double i = 7; i <= 14; i++)
            {
                dataAntiga = DateTime.UtcNow.AddHours(-3).AddDays(-i);

                try
                {
                    pasta = AppDomain.CurrentDomain.BaseDirectory + "Log_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + dataAntiga.ToString(@"yyyy\\MM\\dd");

                    if (Directory.Exists(pasta))
                        Directory.Delete(pasta, true); // true=recursivo
                }
                catch (Exception)
                {
                }

                try
                {
                    pasta = AppDomain.CurrentDomain.BaseDirectory + "Log_0\\" + dataAntiga.ToString(@"yyyy\\MM\\dd");

                    if (Directory.Exists(pasta))
                        Directory.Delete(pasta, true); // true=recursivo
                }
                catch (Exception)
                {
                }

                try
                {
                    pasta = AppDomain.CurrentDomain.BaseDirectory + "baixados_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + dataAntiga.ToString(@"yyyy\\MM\\dd");

                    if (Directory.Exists(pasta))
                        Directory.Delete(pasta, true); // true=recursivo
                }
                catch (Exception)
                {
                }

                try
                {
                    pasta = AppDomain.CurrentDomain.BaseDirectory + "SQL_" + ParametrosGlobal.Cd_Cecam.ToString() + "\\" + dataAntiga.ToString(@"yyyy\\MM\\dd");

                    if (Directory.Exists(pasta))
                        Directory.Delete(pasta, true); // true=recursivo
                }
                catch (Exception)
                {
                }
            }
        }
    }
}
