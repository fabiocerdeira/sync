using Cecam.Tributario.Api.Middleware;
using Cecam.Tributario.Api.SwaggerExt;
using Cecam.Tributario.Manager.Configuration;

namespace Cecam.Tributario.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            // ligar o recebimento opcional do certificado seguro via header
            // HttpContext.Connection.ClientCertificate passa a conter o certificado
            builder.WebHost.ConfigureKestrel(o =>
            {
                o.ConfigureHttpsDefaults(x => 
                {
                    x.ClientCertificateMode = Microsoft.AspNetCore.Server.Kestrel.Https.ClientCertificateMode.AllowCertificate;
                    x.SslProtocols = System.Security.Authentication.SslProtocols.Tls12 | System.Security.Authentication.SslProtocols.Tls13;
                    x.AllowAnyClientCertificate();
                    x.ClientCertificateValidation = (cert, chain, policyErros) =>
                    {
                        return true;
                    };
                });
            });


            // Add services to the container.
            builder.Services.AddControllers();

            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();

            // swagger
            // builder.Services.AddSwaggerGen(); // add original do .net
            builder.Services.AddCustomSwaggerGen(); // meu add extendido.

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.UseDeveloperExceptionPage();
            }

            // swagger
            app.UseSwagger();
            app.UseSwaggerUI();

            // fmc desligado temporario
            app.UseHttpsRedirection();

            // UseAuthentication => JwtBearer
            app.UseAuthentication();

            app.UseAuthorization();

#if !DEBUG
            app.UseApiKeyMiddleware(); // api key de seguran�a
#endif

            app.MapControllers();

            // iniciar a biblioteca com todas as regras de negocio do sistema.
            IniciarManager.Iniciar();

            app.Run();
        }
    }
}
