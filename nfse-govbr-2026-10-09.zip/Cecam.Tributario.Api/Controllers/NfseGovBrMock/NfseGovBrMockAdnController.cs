﻿using Cecam.Tributario.Extend.Logg;
using Cecam.Tributario.Manager.Api.Request.NfseGovBr.Adn;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Adn.Dfe;
using Cecam.Tributario.Manager.Api.Response.NfseGovBr.Dfe;
using Microsoft.AspNetCore.Mvc;

namespace Cecam.Tributario.Api.Controllers.NfseGovBrMock
{
    [Route("[controller]")]
    [ApiController]
    public class NfseGovBrMockAdnController : Controller
    {
        /// <summary>
        /// Recepciona um lote de Documentos
        /// </summary>
        /// <param name="xSsl">Ceritifcado Base64</param>
        /// <param name="xForward">IP transmisao</param>
        /// <param name="dfeRequest">Lote com várias Dfe</param>
        [HttpPost("dfe")]
        public async Task<ActionResult<NfseGovBrAdnDfeResponse>> Dfe(
            [FromHeader(Name = "X-SSL-Client-Cert")] string xSsl,
            [FromHeader(Name = "X-Forwarded-For")] string xForward,
            DfeEnviarRequest dfeRequest)
        {
            var lg = new LoggerHelper();
            lg.GravarObjeto(dfeRequest);

            if (HttpContext.Connection.ClientCertificate == null)
                return CriarProblemDetails("Falta o certificado seguro no header", "O header da requisição não contem o certificado seguro");

            if (string.IsNullOrWhiteSpace(xSsl) || xSsl.Length <= 2)
                return CriarProblemDetails("Falta o certificado no campo X-SSL-Client-Cert", "Campo X-SSL-Client-Cert não informado corretamente");

            if (string.IsNullOrWhiteSpace(xForward) || xForward.Length < 7)
                return CriarProblemDetails("Falta o IP de origem no campo X-Forwarded-For", "Campo X-Forwarded-For não informado corretamente");
                          
            await Task.CompletedTask;

            // sucesso no recebimento
            return new NfseGovBrAdnDfeResponse()
            {
                DataHoraProcessamento = DateTime.Now.ToString("o"),
                TipoAmbiente = "PRODUCAORESTRITA",
                VersaoAplicativo = "v1.00.00",

                Lote = new List<NfseGovBrAdnDfeDocumentoResponse>()
                {
                    new NfseGovBrAdnDfeDocumentoResponse()
                    {
                        ChaveAcesso = ("ChaveAcesso--" + Guid.NewGuid().ToString() + Guid.NewGuid().ToString()).Replace("-","").Substring(0, 50),
                        Nsu = "NSU--" + Guid.NewGuid().ToString(),
                        StatusProcessamento = "xssl = " + xSsl + " xForward = " + xForward
                    }
                }
            };
        }



        /// <summary>
        /// Retorna um lote contendo até 50 Documentos Fiscais de Serviço a partir do NSU informado, sem incluí-lo
        /// </summary>
        /// <param name="nsu"></param>
        /// <returns></returns>
        [HttpGet("municipios/dfe/{nsu}")]
        public async Task<ActionResult<NfseGovBrDfeResponse>> MunicipiosDfe(long nsu,
            [FromQuery(Name = "tipoNSU")] string tipoNSU,
            [FromQuery(Name = "lote")] bool lote = true)
        {
            await Task.CompletedTask;

            // exemplo de retorno sem nenhum documento localizado
            if (nsu.ToString().StartsWith('9'))
                return StatusCode(404, CriarDfeResponseNenhumDocumento());

            if (nsu > 0)
                return CriarDfeResponseDocumentosLocalizados();

            return new NfseGovBrDfeResponse()
            {
                DataHoraProcessamento = DateTime.UtcNow.AddHours(-3).ToString("o"),
                TipoAmbiente = "HOMOLOGACAO",
            };
        }


        /// <summary>
        /// Retorna um lote contendo até 50 Documentos Fiscais de Serviço do tipo evento vinculados à chave de acesso informado
        /// </summary>
        [HttpGet("municipios/NFSe/{chaveAcesso}/Eventos")]
        public async Task<ActionResult<NfseGovBrDfeResponse>> MunicipiosNfseEventos(string chaveAcesso)
        {
            await Task.CompletedTask;

            // exemplo de retorno sem nenhum documento localizado
            if (chaveAcesso.StartsWith('0'))
                return CriarDfeResponseNenhumDocumento();

            return new NfseGovBrDfeResponse()
            {
                DataHoraProcessamento = DateTime.UtcNow.AddHours(-3).ToString("o"),
                TipoAmbiente = "HOMOLOGACAO",
            };
        }




        #region Auxiliares


        private ObjectResult CriarProblemDetails(string titulo, string detalhe)
        {
            var prob = new ProblemDetails()
            {
                Type = "/docs/errors/badrequest",
                Status = StatusCodes.Status400BadRequest,
                Instance = HttpContext.Request.Path,
                Title = titulo,
                Detail = detalhe
            };

            return StatusCode(400, prob);
        }


        /// <summary>
        /// Criar uma Dfe sem NENHUM DOCUMENTO LOCALIZADO pelo gov.br
        /// </summary>
        private NfseGovBrDfeResponse CriarDfeResponseNenhumDocumento()
        {
            return new NfseGovBrDfeResponse
            {
                StatusProcessamento = "NENHUM_DOCUMENTO_LOCALIZADO",
                LoteDFe = new List<NfseGovBrDfeDocumentoResponse>(),
                Alertas = new List<NfseGovBrMensagemProcessamentoResponse>(),
                Erros = new List<NfseGovBrMensagemProcessamentoResponse>
                {
                    new NfseGovBrMensagemProcessamentoResponse
                    {
                        Mensagem = null,
                        Codigo = "E2020",
                        Descricao = "Nenhum documento localizado - não existem documentos fiscais para o Município a partir do NSU informado."
                    }
                },
                TipoAmbiente = "HOMOLOGACAO",
                VersaoAplicativo = "1.0.0.0",
                DataHoraProcessamento = DateTime.UtcNow.AddHours(-3).ToString("o")
            };
        }


        /// <summary>
        /// Criar uma Dfe sem NENHUM DOCUMENTO LOCALIZADO pelo gov.br
        /// </summary>
        private NfseGovBrDfeResponse CriarDfeResponseDocumentosLocalizados()
        {
            // ler exemplo do arquivo em disco.
            string conteudoXml = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Controllers\\NfseGovBrMock\\Exemplos\\nfse_2025_11_05_incompleto.xml", System.Text.Encoding.UTF8);
            // string conteudoXml = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Controllers\\NfseGovBrMock\\Exemplos\\35261002259399940000148000000000000125111225158490.xml", System.Text.Encoding.UTF8);

            return new NfseGovBrDfeResponse
            {
                StatusProcessamento = "DOCUMENTOS_LOCALIZADOS",
                LoteDFe = new List<NfseGovBrDfeDocumentoResponse>
                {
                    new NfseGovBrDfeDocumentoResponse
                    {
                        DataHoraGeracao = DateTime.UtcNow.AddHours(-3).ToString("o"),
                        DataHoraRecebimento = DateTime.UtcNow.AddHours(-3).ToString("o"),
                        ChaveAcesso = "chave-acesso-fake",
                        Nsu = 9990,
                        TipoDocumento = "NFSE",
                        TipoEvento = null,
                        ArquivoXml = conteudoXml.Replace(Environment.NewLine, string.Empty).Replace("\t", string.Empty)
                    }
                },
                Alertas = new List<NfseGovBrMensagemProcessamentoResponse>(),
                Erros = new List<NfseGovBrMensagemProcessamentoResponse>(),
                TipoAmbiente = "HOMOLOGACAO",
                VersaoAplicativo = "1.0.0.0",
                DataHoraProcessamento = DateTime.UtcNow.AddHours(-3).ToString("o")
            };
        }


        #endregion
    }
}
