﻿using Cecam.Tributario.Manager.Api.WebApi;
using Cecam.Tributario.Manager.Business.NfseGovBr.Consultar;
using Microsoft.AspNetCore.Mvc;

namespace Cecam.Tributario.Api.Controllers.NfseGovBr
{
    [Route("[controller]")]
    [ApiController]
    public class NfseGovBrController : Controller
    {
        /// <summary>
        /// Retorna uma Danfe, em formato de Base64 de um PDF, a partir de sua chave de acesso.
        /// Uma Danfe é a representação gráfica de uma NFSe.
        /// </summary>
        [HttpGet("danfse/base64/{chaveAcesso}")]
        public async Task<ActionResult<WebApiBaseResponse<string>>> DanfseAsBase64Pdf(string chaveAcesso)
        {
            if (string.IsNullOrWhiteSpace(chaveAcesso))
                return StatusCode(400, new { msg = "A chave de acesso precisa ser informada." });

            // consultar danfe usando a bussines
            var consulta = new NfseGovBrNfseConsultarBus();

            // resposta encapsulada.
            return new WebApiBaseResponse<string>()
            {
                // retornar em formato base64
                Item = await consulta.DanfseConsultar(chaveAcesso),
                StatusCode = StatusCodes.Status200OK,
                Sucesso = true
            };
        }


        /// <summary>
        /// Retorna uma Danfe, em formato de PDF, a partir de sua chave de acesso.
        /// Uma Danfe é a representação gráfica de uma NFSe.
        /// </summary>
        [HttpGet("danfse/pdf/{chaveAcesso}")]
        public async Task<ActionResult> DanfseAsPdf(string chaveAcesso)
        {
            if (string.IsNullOrWhiteSpace(chaveAcesso))
                return StatusCode(400, new { msg = "A chave de acesso precisa ser informada." });

            // consultar danfe usando a bussines
            var consulta = new NfseGovBrNfseConsultarBus();
            var base64string = await consulta.DanfseConsultar(chaveAcesso);

            // string -> byte array
            var byteArrayFinal = Convert.FromBase64String(base64string);

            // exibir o pdf na tela do navegador
            return File(byteArrayFinal, "application/pdf");
        }
    }
}
