﻿using Microsoft.OpenApi.Models;
using System.Diagnostics.CodeAnalysis;

namespace Cecam.Tributario.Api.SwaggerExt
{
    [ExcludeFromCodeCoverage]
    public static class SwaggerExtension
    {
        public static IServiceCollection AddCustomSwaggerGen(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1",
                    new OpenApiInfo
                    {
                        Title = "Cecam Tributos 2026.01.05",
                        Version = "v1",
                        Description = "API para Tributos",
                        Contact = new OpenApiContact
                        {
                            Name = "Cecam"
                        }
                    });

                c.AddSecurityDefinition("ApiKey", new OpenApiSecurityScheme
                {
                    Name = "X-API-KEY",
                    Type = SecuritySchemeType.ApiKey,
                    In = ParameterLocation.Header,
                    Description = "Enter Api Key"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "ApiKey"
                            }
                        },
                        new string[] { }
                    }
                });

            });
            return services;
        }
    }
}
