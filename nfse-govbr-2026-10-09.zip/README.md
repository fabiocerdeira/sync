# Cecam.Tributario.CORE

## Utilizar a branch "MASTER"

Projeto com todos os objetos que representam a base de 'tributos'.

As explicações mais detalhadas nos arquivos de README na pasta 'Readmes'.

[Cecam.Tributario.CORE | Documentação/Readmes/README.md](Documentação/Readmes/README.md)



Esteiras TFS

\\azuredevops\drops\trib-nfe-govbr\




