﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;

namespace Cecam.Tributario.Database.QueryInterface.Endereco
{
    public interface ICecamPaisIbgeQuery
    {
        Task<List<CecamPaisIbgeEntity>> Listar(CecamPaisIbgeFilter filtro);

        Task<List<CecamPaisIbgeEntity>> ListarSQL(CecamPaisIbgeFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
