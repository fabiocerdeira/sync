﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;

namespace Cecam.Tributario.Database.QueryInterface.Endereco
{
    public interface ICecamLogradouroQuery
    {
        Task<List<CecamLogradouroEntity>> Listar(CecamLogradouroFilter filtro);

        Task<List<CecamLogradouroEntity>> ListarSQL(CecamLogradouroFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
