﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;

namespace Cecam.Tributario.Database.QueryInterface.Endereco
{
    public interface ICecamMunicipioQuery
    {
        Task<CecamMunicipioEntity?> PrimeiroOuNull(CecamMunicipioFilter filtro);

        Task<List<CecamMunicipioEntity>> Listar(CecamMunicipioFilter filtro);

        Task<List<CecamMunicipioEntity>> ListarSQL(CecamMunicipioFilter filtro);

        Task<CecamMunicipioEntity> CarregarOutroPais();

        // Task<int> UpdateExemploSQL();
    }
}
