﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;

namespace Cecam.Tributario.Database.QueryInterface.Endereco
{
    public interface ICecamBairroQuery
    {
        Task<List<CecamBairroEntity>> Listar(CecamBairroFilter filtro);

        Task<List<CecamBairroEntity>> ListarSQL(CecamBairroFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
