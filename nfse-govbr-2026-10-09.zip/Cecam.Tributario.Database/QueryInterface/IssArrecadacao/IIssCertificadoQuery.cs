﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.Filter.IssArrecadacao;

namespace Cecam.Tributario.Database.QueryInterface.IssArrecadacao
{
    public interface IIssCertificadoQuery
    {
        Task<IssCertificadoEntity?> PrimeiroOuNull(IssCertificadoFilter filtro);

        Task<List<IssCertificadoEntity>> Listar(IssCertificadoFilter filtro);

        Task<List<IssCertificadoEntity>> ListarSQL(IssCertificadoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
