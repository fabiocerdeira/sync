﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.Filter.IssArrecadacao;

namespace Cecam.Tributario.Database.QueryInterface.IssArrecadacao
{
    public interface IIssParcelaQuery
    {
        Task<IssParcelaEntity?> PrimeiroOuNull(IssParcelaFilter filtro);

        Task<List<IssParcelaEntity>> Listar(IssParcelaFilter filtro);

        Task<List<IssParcelaEntity>> ListarSQL(IssParcelaFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
