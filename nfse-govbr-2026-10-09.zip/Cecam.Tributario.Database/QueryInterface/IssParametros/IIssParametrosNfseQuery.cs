﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.Filter.IssParametros;

namespace Cecam.Tributario.Database.QueryInterface.IssParametros
{
    public interface IIssParametrosNfseQuery
    {
        Task<IssParametrosNfseEntity?> Carregar();

        Task<List<IssParametrosNfseEntity>> Listar(IssParametrosNfseFilter filtro);

        Task<List<IssParametrosNfseEntity>> ListarSQL(IssParametrosNfseFilter filtro);

        #region Atualizar

        Task AtualizarNsuBaixadoUltimo(long ultimoNsu);

        Task AtualizarNsuBaixadoHorario(DateTime dataHora);

        #endregion
    }
}
