﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.Filter.IssParametros;

namespace Cecam.Tributario.Database.QueryInterface.IssParametros
{
    public interface IIssParametrosCalcQuery
    {
        Task<IssParametrosCalcEntity?> Carregar();

        Task<List<IssParametrosCalcEntity>> Listar(IssParametrosCalcFilter filtro);

        Task<List<IssParametrosCalcEntity>> ListarSQL(IssParametrosCalcFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
