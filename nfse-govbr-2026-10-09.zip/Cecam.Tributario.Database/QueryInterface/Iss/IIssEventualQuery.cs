﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssEventualQuery
    {
        Task<IssEventualEntity?> PrimeiroOuNull(IssEventualFilter filtro);

        Task<List<IssEventualEntity>> Listar(IssEventualFilter filtro);

        Task<List<IssEventualEntity>> ListarSQL(IssEventualFilter filtro);
    }
}
