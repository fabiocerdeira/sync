﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssUsuarioWebQuery
    {
        Task<IssUsuarioWebEntity?> PrimeiroOuNull(IssUsuarioWebFilter filtro);

        Task<List<IssUsuarioWebEntity>> Listar(IssUsuarioWebFilter filtro);

        Task<List<IssUsuarioWebEntity>> ListarSQL(IssUsuarioWebFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
