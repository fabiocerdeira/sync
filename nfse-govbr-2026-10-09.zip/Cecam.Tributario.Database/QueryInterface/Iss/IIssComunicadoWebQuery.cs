﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssComunicadoWebQuery
    {
        Task<List<IssComunicadoWebEntity>> Listar(IssComunicadoWebFilter filtro);

        Task<List<IssComunicadoWebEntity>> ListarSQL(IssComunicadoWebFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
