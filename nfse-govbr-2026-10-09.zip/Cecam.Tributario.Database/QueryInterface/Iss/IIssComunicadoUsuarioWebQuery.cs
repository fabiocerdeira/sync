﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssComunicadoUsuarioWebQuery
    {
        Task<List<IssComunicadoUsuarioWebEntity>> Listar(IssComunicadoUsuarioWebFilter filtro);

        Task<List<IssComunicadoUsuarioWebEntity>> ListarSQL(IssComunicadoUsuarioWebFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
