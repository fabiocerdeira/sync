﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssItensAtividadesQuery
    {
        Task<IssItensAtividadesEntity?> PrimeiroOuNull(IssItensAtividadesFilter filtro);

        Task<List<IssItensAtividadesEntity>> Listar(IssItensAtividadesFilter filtro);

        Task<List<IssItensAtividadesEntity>> ListarSQL(IssItensAtividadesFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
