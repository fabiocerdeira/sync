﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface IIssTomadorQuery
    {
        Task<IssTomadorEntity?> PrimeiroOuNull(IssTomadorFilter filtro);

        Task<List<IssTomadorEntity>> Listar(IssTomadorFilter filtro);

        Task<List<IssTomadorEntity>> ListarSQL(IssTomadorFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
