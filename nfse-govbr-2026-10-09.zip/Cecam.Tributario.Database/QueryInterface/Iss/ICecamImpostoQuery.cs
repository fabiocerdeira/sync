﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    public interface ICecamImpostoQuery
    {
        Task<List<CecamImpostoEntity>> Listar(CecamImpostoFilter filtro);

        Task<List<CecamImpostoEntity>> ListarSQL(CecamImpostoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
