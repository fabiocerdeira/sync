﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;

namespace Cecam.Tributario.Database.QueryInterface.Iss
{
    /// <summary>
    /// Serviço executado/prestado na NFSe pelo emitente/prestador
    /// </summary>
    public interface IIssServicoQuery
    {
        Task<IssServicoEntity?> PrimeiroOuNull(IssServicoFilter filtro);

        Task<List<IssServicoEntity>> Listar(IssServicoFilter filtro);

        Task<List<IssServicoEntity>> ListarSQL(IssServicoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
