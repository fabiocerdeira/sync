﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalImpostoQuery
    {
        Task<IssNotaFiscalImpostoEntity?> PrimeiroOuNull(IssNotaFiscalImpostoFilter filtro);

        Task<List<IssNotaFiscalImpostoEntity>> Listar(IssNotaFiscalImpostoFilter filtro);

        Task<List<IssNotaFiscalImpostoEntity>> ListarSQL(IssNotaFiscalImpostoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
