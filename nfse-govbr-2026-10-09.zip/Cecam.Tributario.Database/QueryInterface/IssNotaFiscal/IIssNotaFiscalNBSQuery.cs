﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalNBSQuery
    {
        Task<IssNotaFiscalNBSEntity?> PrimeiroOuNull(IssNotaFiscalNBSFilter filtro);

        Task<List<IssNotaFiscalNBSEntity>> Listar(IssNotaFiscalNBSFilter filtro);

        Task<List<IssNotaFiscalNBSEntity>> ListarSQL(IssNotaFiscalNBSFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
