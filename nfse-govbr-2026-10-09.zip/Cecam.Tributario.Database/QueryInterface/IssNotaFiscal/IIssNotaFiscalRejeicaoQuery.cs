﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalRejeicaoQuery
    {
        Task<List<IssNotaFiscalRejeicaoEntity>> Listar(IssNotaFiscalRejeicaoFilter filtro);

        Task<List<IssNotaFiscalRejeicaoEntity>> ListarSQL(IssNotaFiscalRejeicaoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
