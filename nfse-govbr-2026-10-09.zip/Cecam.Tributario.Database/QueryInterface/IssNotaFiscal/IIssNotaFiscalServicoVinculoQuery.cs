﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalServicoVinculoQuery
    {
        Task<IssNotaFiscalServicoVinculoEntity?> PrimeiroOuNull(IssNotaFiscalServicoVinculoFilter filtro);

        Task<List<IssNotaFiscalServicoVinculoEntity>> Listar(IssNotaFiscalServicoVinculoFilter filtro);

        Task<List<IssNotaFiscalServicoVinculoEntity>> ListarSQL(IssNotaFiscalServicoVinculoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
