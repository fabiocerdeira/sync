﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalServicoNacionalQuery
    {
        Task<IssNotaFiscalServicoNacionalEntity?> PrimeiroOuNull(IssNotaFiscalServicoNacionalFilter filtro);

        Task<List<IssNotaFiscalServicoNacionalEntity>> Listar(IssNotaFiscalServicoNacionalFilter filtro);

        Task<List<IssNotaFiscalServicoNacionalEntity>> ListarSQL(IssNotaFiscalServicoNacionalFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
