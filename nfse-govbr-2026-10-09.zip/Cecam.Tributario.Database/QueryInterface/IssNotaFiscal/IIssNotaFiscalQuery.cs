﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalQuery
    {
        IIssNotaFiscalRepository Repositorio { get; }

        Task<IssNotaFiscalEntity?> PrimeiroOuNull(IssNotaFiscalFilter filtro);

        Task<List<IssNotaFiscalEntity>> Listar(IssNotaFiscalFilter filtro);

        Task<List<IssNotaFiscalEntity>> ListarSQL(IssNotaFiscalFilter filtro);


        #region Gov.Br

        Task<int> UpdateGovBrCriacaoNotaFiscal(IssNotaFiscalEntity entity);

        Task<int> UpdateGovBrEventoUltimaConsulta(string govbrChaveAcesso);

        Task<Dictionary<int, int>> ListarNfseEmitidasErradamentePeloIssWeb();

        #endregion
    }
}
