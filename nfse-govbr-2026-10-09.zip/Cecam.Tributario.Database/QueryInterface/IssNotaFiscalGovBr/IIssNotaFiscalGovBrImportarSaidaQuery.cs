﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr
{
    public interface IIssNotaFiscalGovBrImportarSaidaQuery
    {
        Task<List<IssNotaFiscalGovBrImportarSaidaEntity>> Listar(IssNotaFiscalGovBrImportarSaidaFilter filtro);

        Task<List<IssNotaFiscalGovBrImportarSaidaEntity>> ListarSQL(IssNotaFiscalGovBrImportarSaidaFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
