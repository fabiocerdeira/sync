﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr
{
    public interface IIssNotaFiscalGovBrImportarEntradaQuery
    {
        Task<List<IssNotaFiscalGovBrImportarEntradaEntity>> Listar(IssNotaFiscalGovBrImportarEntradaFilter filtro);

        Task<List<IssNotaFiscalGovBrImportarEntradaEntity>> ListarSQL(IssNotaFiscalGovBrImportarEntradaFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
