﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr
{
    public interface IIssNotaFiscalGovBrLixoQuery
    {
        Task<IssNotaFiscalGovBrLixoEntity?> PrimeiroOuNull(IssNotaFiscalGovBrLixoFilter filtro);

        Task<List<IssNotaFiscalGovBrLixoEntity>> Listar(IssNotaFiscalGovBrLixoFilter filtro);

        Task<List<IssNotaFiscalGovBrLixoEntity>> ListarSQL(IssNotaFiscalGovBrLixoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
