﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr
{
    public interface IISSNotaFiscalGovBrDocArrecadacaoQuery
    {
        Task<ISSNotaFiscalGovBrDocArrecadacaoEntity?> PrimeiroOuNull(ISSNotaFiscalGovBrDocArrecadacaoFilter filtro);

        Task<List<ISSNotaFiscalGovBrDocArrecadacaoEntity>> Listar(ISSNotaFiscalGovBrDocArrecadacaoFilter filtro);

        Task<List<ISSNotaFiscalGovBrDocArrecadacaoEntity>> ListarSQL(ISSNotaFiscalGovBrDocArrecadacaoFilter filtro);

        // Task<int> UpdateExemploSQL();
    }
}
