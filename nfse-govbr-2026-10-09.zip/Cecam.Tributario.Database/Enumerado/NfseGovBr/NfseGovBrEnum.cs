﻿namespace Cecam.Tributario.Database.Enumerado.NfseGovBr
{
    public static class NfseGovBrEnum
    {
        public enum enumFilaTipo
        {
            OutroNaoIdentificado = 0,
            NFSe = 1,
            Cancelamento = 2,
            AceiteNotaFiscal = 3,
            Ignorado = 4
        }

        public enum enumFilaStatus
        {
            BaixadoAguardandoProcessar = 0,
            ProcessadoComErro = 1,
            ProcessadoComSucesso = 2,
            DuplicadoNaoPodeProcessar = 3,
            PrestadorOutroMunicipio = 4,
            ExercicioAntes2026 = 5,
            Ignorado = 6
        }
    }
}
