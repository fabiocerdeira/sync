﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Enumerado.Iss
{
    public static class IssTomadorEnum
    {
        public enum enumFlTipoPessoa
        {
            PessoaJuridica = 0,
            PessoaFisica = 1,
            OutroPaisEstrangeiro = 2
        }
    }
}
