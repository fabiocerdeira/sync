﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Enumerado.Endereco
{
    public static class CecamEnderecoEnum
    {
        /// <summary>
        /// Constante para o estado OP = OUTRO PAIS
        /// </summary>
        public const string kEstadoOutroPais = "OP";
    }
}
