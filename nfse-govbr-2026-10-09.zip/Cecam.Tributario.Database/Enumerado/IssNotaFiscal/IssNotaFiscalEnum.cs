﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Enumerado.IssNotaFiscal
{
    public static class IssNotaFiscalEnum
    {
        /// <summary>
        /// Situação da NFSe
        /// </summary>
        public enum enumCdSituacao
        {
            Ativa = 0,
            Cancelada = 1,
            Excluida = 2
        }


        /// <summary>
        /// Local de prestação do servico
        /// </summary>
        public enum enumLocalPrestacao
        {
            NaoIdentificado = 0,
            NaSedeDoPrestador = 1,
            NaSedeDoPrestadorImovel = 2,
            NaSedeDoPrestadorEmViaPublica = 3,
            ForaDoMunicipioDoPrestador = 4
        }


        /// <summary>
        /// Flag se foi o tomador quem escriturou a NFSe ou foi emitida pelo prestador<br/>
        /// Tabela IssNotaFiscal campo Fl_tomador
        /// </summary>
        public enum enumFlTomador
        {
            NfseEmitidaPeloPrestador = 0,
            NfseEscrituradaPeloTomador = 1
        }


        /// <summary>
        /// Indica quem aceitou a nota fiscal no gov.br<br/>
        /// Usado no método de aceite da nota fiscal
        /// </summary>
        public enum enumAceitadorNotaFiscal
        { 
            Contribuinte = 1,
            Tomador = 2,
            Intermediario = 3,
            Tacito = 4
        }



        /// <summary>
        /// Identifica o tipo de contribuinte associado na nota fiscal no campo cd_contribuinte
        /// </summary>
        public enum enumTipoContribuinte
        {
            NaoInformado = 0,
            IssContribuinte = 1,
            IssEventual = 2
        }
    }
}
