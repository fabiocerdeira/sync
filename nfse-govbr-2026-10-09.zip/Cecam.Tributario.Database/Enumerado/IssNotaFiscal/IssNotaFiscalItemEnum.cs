﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Enumerado.IssNotaFiscal
{
    public static class IssNotaFiscalItemEnum
    {
        /// <summary>
        /// Quem reteve o imposto?
        /// </summary>
        public enum enumFlRetido
        {
            RetidoPeloTomador = 0,
            RetidoPeloPrestador = 1
        }
    }
}
