﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscal
{
    public class IssNotaFiscalServicoVinculoEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalServicoVinculoEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalServicoVinculoEntity> builder)
        {
            builder.ToTable("ISSServicos_Vinculos");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Exercicio,
				 x.Cd_Servico,
				 x.Cd_tributacaoNacional,
				 x.Cd_nbs
			});


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
            builder.Property(x => x.Cd_Servico).HasColumnName("cd_Servico");
			builder.Property(x => x.Cd_tributacaoNacional).HasColumnName("cd_tributacaoNacional").HasConversion(c => c.Trim(), c => c.Trim());
            builder.Property(x => x.Cd_nbs).HasColumnName("cd_nbs").HasConversion(c => c.Trim(), c => c.Trim());

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
