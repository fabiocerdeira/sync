﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscal
{
    public class IssNotaFiscalNBSEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalNBSEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalNBSEntity> builder)
        {
            builder.ToTable("ISS_NFSE_ListaNBS");

            // primary key
			builder.HasNoKey();


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Cd_nbs).HasColumnName("cd_nbs");
			builder.Property(x => x.Ds_nbsDescricao).HasColumnName("ds_nbsDescricao");
			builder.Property(x => x.Cd_nbsFormatado).HasColumnName("cd_nbsFormatado");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
