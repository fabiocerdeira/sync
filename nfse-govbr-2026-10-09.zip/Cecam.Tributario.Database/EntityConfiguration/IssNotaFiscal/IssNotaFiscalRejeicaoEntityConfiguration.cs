﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscal
{
    public class IssNotaFiscalRejeicaoEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalRejeicaoEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalRejeicaoEntity> builder)
        {
            builder.ToTable("ISSNotaFiscalRejeicao");

            // primary key
			builder.HasNoKey();


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("Cd_Cecam");
			builder.Property(x => x.Cd_NotaFiscal).HasColumnName("Cd_NotaFiscal").HasColumnType("numeric(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Ds_Rejeicao).HasColumnName("ds_Rejeicao");
			builder.Property(x => x.Dt_AceitoRejeitado).HasColumnName("dt_AceitoRejeitado");
			builder.Property(x => x.Fl_AceitoRejeitado).HasColumnName("fl_AceitoRejeitado");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
