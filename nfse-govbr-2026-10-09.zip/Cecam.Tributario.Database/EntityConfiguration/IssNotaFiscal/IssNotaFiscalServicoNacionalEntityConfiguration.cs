﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscal
{
    public class IssNotaFiscalServicoNacionalEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalServicoNacionalEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalServicoNacionalEntity> builder)
        {
            builder.ToTable("ISS_NFSE_ListaServicoNacional");

            // primary key
			builder.HasNoKey();


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Cd_tributacaoNacional).HasColumnName("cd_tributacaoNacional").IsRequired(false);
			builder.Property(x => x.Cd_Item).HasColumnName("cd_Item");
			builder.Property(x => x.Cd_subItem).HasColumnName("cd_subItem");
			builder.Property(x => x.Cd_Desdobro).HasColumnName("cd_Desdobro");
			builder.Property(x => x.Ds_servicoDescricao).HasColumnName("ds_servicoDescricao");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
