﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscal
{
    public class IssNotaFiscalImpostoEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalImpostoEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalImpostoEntity> builder)
        {
            builder.ToTable("ISSNotaFiscalImpostos");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_NotaFiscal_Imposto
			});


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_NotaFiscal_Imposto).HasColumnName("cd_NotaFiscal_Imposto");
			builder.Property(x => x.Cd_NotaFiscal).HasColumnName("cd_NotaFiscal").HasColumnType("numeric(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Cd_Imposto).HasColumnName("cd_Imposto");
			builder.Property(x => x.Vl_Imposto).HasColumnName("vl_imposto").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);

            #endregion


            #region Relacionamentos

            builder.HasOne(x => x.NotaFiscal).WithMany(x => x.Impostos).HasForeignKey(x => new { x.Cd_Cecam, x.Cd_NotaFiscal });

            #endregion
        }
    }
}
