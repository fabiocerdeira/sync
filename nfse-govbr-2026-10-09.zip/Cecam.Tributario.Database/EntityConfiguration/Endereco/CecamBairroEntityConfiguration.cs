﻿using Cecam.Tributario.Database.Entity.Endereco;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Endereco
{
    public class CecamBairroEntityConfiguration : IEntityTypeConfiguration<CecamBairroEntity>
    {
        public void Configure(EntityTypeBuilder<CecamBairroEntity> builder)
        {
            builder.ToTable("CECAMBairros");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Bairro
			});




            #region Propriedades
			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Bairro).HasColumnName("Cd_Bairro");
			builder.Property(x => x.Ds_Bairro).HasColumnName("Ds_Bairro").IsRequired(false);
			builder.Property(x => x.Cd_classificacaobairro).HasColumnName("cd_classificacaobairro").IsRequired(false);
			builder.Property(x => x.Fl_inativo).HasColumnName("fl_inativo").IsRequired(false);
			builder.Property(x => x.Fl_sistema).HasColumnName("fl_sistema").IsRequired(false);
			builder.Property(x => x.Dt_atualizacao).HasColumnName("dt_atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_usuario).HasColumnName("nm_usuario").IsRequired(false);
			builder.Property(x => x.Fl_Web).HasColumnName("fl_Web").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
