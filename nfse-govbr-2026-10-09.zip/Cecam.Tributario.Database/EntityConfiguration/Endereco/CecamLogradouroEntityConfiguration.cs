﻿using Cecam.Tributario.Database.Entity.Endereco;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Endereco
{
    public class CecamLogradouroEntityConfiguration : IEntityTypeConfiguration<CecamLogradouroEntity>
    {
        public void Configure(EntityTypeBuilder<CecamLogradouroEntity> builder)
        {
            builder.ToTable("CECAMLogradouros");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Logradouro
			});




            #region Propriedades
			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Logradouro).HasColumnName("Cd_Logradouro");
			builder.Property(x => x.Ds_TipoLogradouro).HasColumnName("ds_TipoLogradouro").IsRequired(false);
			builder.Property(x => x.Ds_Logradouro).HasColumnName("Ds_Logradouro").IsRequired(false);
			builder.Property(x => x.Ds_Antigo).HasColumnName("Ds_Antigo").IsRequired(false);
			builder.Property(x => x.Ds_LeiDecreto).HasColumnName("Ds_LeiDecreto").IsRequired(false);
			builder.Property(x => x.Fl_inativo).HasColumnName("fl_inativo").IsRequired(false);
			builder.Property(x => x.Fl_sistema).HasColumnName("fl_sistema").IsRequired(false);
			builder.Property(x => x.Dt_atualizacao).HasColumnName("dt_atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_usuario).HasColumnName("nm_usuario").IsRequired(false);
			builder.Property(x => x.Fl_Web).HasColumnName("fl_Web").IsRequired(false);
			builder.Property(x => x.Cd_Loteamento).HasColumnName("cd_Loteamento").IsRequired(false);
			builder.Property(x => x.Ds_Loteamento).HasColumnName("ds_Loteamento").IsRequired(false);
			builder.Property(x => x.Cd_bairro).HasColumnName("cd_bairro").IsRequired(false);
			builder.Property(x => x.Ds_bairro).HasColumnName("ds_bairro").IsRequired(false);
			builder.Property(x => x.Cd_CEP).HasColumnName("cd_CEP").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
