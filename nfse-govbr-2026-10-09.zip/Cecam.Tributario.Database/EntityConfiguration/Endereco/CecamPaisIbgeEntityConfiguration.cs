﻿using Cecam.Tributario.Database.Entity.Endereco;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Endereco
{
    public class CecamPaisIbgeEntityConfiguration : IEntityTypeConfiguration<CecamPaisIbgeEntity>
    {
        public void Configure(EntityTypeBuilder<CecamPaisIbgeEntity> builder)
        {
            builder.ToTable("ISS_NFSE_Paises_ISO2_IBGE");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Sg_pais_ISO2
			});


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Sg_pais_ISO2).HasColumnName("sg_pais_ISO2");
			builder.Property(x => x.Ds_paisDescricao).HasColumnName("ds_paisDescricao");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
