﻿using Cecam.Tributario.Database.Entity.Endereco;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Endereco
{
    public class CecamMunicipioEntityConfiguration : IEntityTypeConfiguration<CecamMunicipioEntity>
    {
        public void Configure(EntityTypeBuilder<CecamMunicipioEntity> builder)
        {
            builder.ToTable("CECAMMunicipio");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_MunicipioIBGE
			});




            #region Propriedades
			builder.Property(x => x.Cd_MunicipioIBGE).HasColumnName("cd_MunicipioIBGE").HasColumnType("decimal(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Cd_Municipio).HasColumnName("cd_Municipio").HasColumnType("decimal(15,0)").HasPrecision(15,0);
			builder.Property(x => x.Nr_Ano).HasColumnName("nr_Ano");
			builder.Property(x => x.Sg_UF).HasColumnName("sg_UF");
			builder.Property(x => x.Ds_NomeMunicipio).HasColumnName("ds_NomeMunicipio");
			builder.Property(x => x.Cd_CEPInicial).HasColumnName("cd_CEPInicial").HasColumnType("decimal(8,0)").HasPrecision(8,0);
			builder.Property(x => x.Cd_CEPFinal).HasColumnName("cd_CEPFinal").HasColumnType("decimal(8,0)").HasPrecision(8,0);
			builder.Property(x => x.Cd_Jucesp).HasColumnName("cd_Jucesp").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
