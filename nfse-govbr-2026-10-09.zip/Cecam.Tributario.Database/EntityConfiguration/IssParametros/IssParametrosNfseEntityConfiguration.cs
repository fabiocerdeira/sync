﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssParametros
{
    public class IssParametrosNfseEntityConfiguration : IEntityTypeConfiguration<IssParametrosNfseEntity>
    {
        public void Configure(EntityTypeBuilder<IssParametrosNfseEntity> builder)
        {
            builder.ToTable("IssParametrosNfSE");


            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam
			});


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("Cd_Cecam");
			builder.Property(x => x.Cd_IBGE).HasColumnName("cd_IBGE").HasColumnType("decimal(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Nr_CNPJMunicipio).HasColumnName("nr_CNPJMunicipio");
			builder.Property(x => x.Nr_LegislacaoBenefício).HasColumnName("nr_legislacaoBenefício").IsRequired(false);
            builder.Property(x => x.Dt_InicioIntegracao).HasColumnName("dt_inicioIntegracao").IsRequired(false);
			builder.Property(x => x.Tp_IntegracaoTipo).HasColumnName("tp_integracaoTipo").IsRequired(false);
			builder.Property(x => x.Govbr_nsuBaixadoUltimo).HasColumnName("govbr_nsuBaixadoUltimo").IsRequired(false);
			builder.Property(x => x.Govbr_nsuBaixadoHorario).HasColumnName("govbr_nsuBaixadoHorario").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
