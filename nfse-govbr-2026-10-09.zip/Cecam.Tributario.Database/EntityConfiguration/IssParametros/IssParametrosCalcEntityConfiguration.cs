﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssParametros
{
    public class IssParametrosCalcEntityConfiguration : IEntityTypeConfiguration<IssParametrosCalcEntity>
    {
        public void Configure(EntityTypeBuilder<IssParametrosCalcEntity> builder)
        {
            builder.ToTable("ISSParametrosCalc");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Exercicio
			});


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("Cd_Cecam");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Fl_emitecarneisentos).HasColumnName("fl_emitecarneisentos").IsRequired(false);
			builder.Property(x => x.Cd_SubGrupoImposto).HasColumnName("cd_SubGrupoImposto").IsRequired(false);
			builder.Property(x => x.Cd_SubGrupoTaxa).HasColumnName("cd_SubGrupoTaxa").IsRequired(false);
			builder.Property(x => x.Cd_GrupoISS).HasColumnName("cd_GrupoISS").IsRequired(false);
			builder.Property(x => x.Cd_GrupoISSvar).HasColumnName("cd_GrupoISSvar").IsRequired(false);
			builder.Property(x => x.Cd_SubGrupoISSvar).HasColumnName("cd_SubGrupoISSvar").IsRequired(false);
			builder.Property(x => x.Sg_MoedaPadrao).HasColumnName("sg_MoedaPadrao").IsRequired(false);
			builder.Property(x => x.Fl_UtilizaFaixaValores).HasColumnName("fl_UtilizaFaixaValores");
			builder.Property(x => x.Fl_UtilizaValorMinimo).HasColumnName("fl_UtilizaValorMinimo").IsRequired(false);
			builder.Property(x => x.Fl_UtilizaValorMinimoTaxa).HasColumnName("fl_UtilizaValorMinimoTaxa").IsRequired(false);
			builder.Property(x => x.Fl_UtilizaConversaoCertidoes).HasColumnName("fl_UtilizaConversaoCertidoes");
			builder.Property(x => x.Fl_Desconto).HasColumnName("fl_Desconto").IsRequired(false);
			builder.Property(x => x.Vlr_Minimo).HasColumnName("vlr_Minimo").HasColumnType("numeric(12,4)").HasPrecision(12,4).IsRequired(false);
			builder.Property(x => x.Vlr_MinimoTaxa).HasColumnName("vlr_MinimoTaxa").HasColumnType("numeric(12,4)").HasPrecision(12,4).IsRequired(false);
			builder.Property(x => x.Ds_DescontoEspecial).HasColumnName("ds_DescontoEspecial").IsRequired(false);
			builder.Property(x => x.Fl_TipoValorIntervaloBaixa).HasColumnName("fl_TipoValorIntervaloBaixa").IsRequired(false);
			builder.Property(x => x.Vlr_IntervaloMaximoBaixa).HasColumnName("vlr_IntervaloMaximoBaixa").HasColumnType("numeric(10,4)").HasPrecision(10,4).IsRequired(false);
			builder.Property(x => x.Vlr_IntervaloMinimoBaixa).HasColumnName("vlr_IntervaloMinimoBaixa").HasColumnType("numeric(10,4)").HasPrecision(10,4).IsRequired(false);
			builder.Property(x => x.Ds_Juros).HasColumnName("ds_Juros").IsRequired(false);
			builder.Property(x => x.Ds_Multa).HasColumnName("ds_Multa").IsRequired(false);
			builder.Property(x => x.Ds_Imposto).HasColumnName("ds_Imposto").IsRequired(false);
			builder.Property(x => x.Fl_UtilizacaoValoresJurosMulta).HasColumnName("fl_UtilizacaoValoresJurosMulta").IsRequired(false);
			builder.Property(x => x.Sg_MoedaCorrente).HasColumnName("sg_MoedaCorrente").IsRequired(false);
			builder.Property(x => x.Cd_TributoJurosImposto).HasColumnName("cd_TributoJurosImposto").IsRequired(false);
			builder.Property(x => x.Cd_TributoMultasImposto).HasColumnName("cd_TributoMultasImposto").IsRequired(false);
			builder.Property(x => x.Cd_TributoCorrecaoImposto).HasColumnName("cd_TributoCorrecaoImposto").IsRequired(false);
			builder.Property(x => x.Cd_TributoTarifaBancaria).HasColumnName("cd_TributoTarifaBancaria").IsRequired(false);
			builder.Property(x => x.Nm_DiretorioDocumentos).HasColumnName("nm_DiretorioDocumentos").IsRequired(false);
			builder.Property(x => x.Fl_TipoAtualizacaoValor).HasColumnName("fl_TipoAtualizacaoValor").IsRequired(false);
			builder.Property(x => x.Fl_TipoNrAviso).HasColumnName("fl_TipoNrAviso").IsRequired(false);
			builder.Property(x => x.Msg_ParcelaUnica).HasColumnName("msg_ParcelaUnica").IsRequired(false);
			builder.Property(x => x.Msg_DemaisParcelas).HasColumnName("msg_DemaisParcelas").IsRequired(false);
			builder.Property(x => x.Nm_TipoAplicacaoJuros).HasColumnName("nm_TipoAplicacaoJuros").IsRequired(false);
			builder.Property(x => x.Nm_TipoAplicacaoMulta).HasColumnName("nm_TipoAplicacaoMulta").IsRequired(false);
			builder.Property(x => x.Cd_FicharecImposto).HasColumnName("cd_FicharecImposto").IsRequired(false);
			builder.Property(x => x.Cd_FicharecTaxa).HasColumnName("cd_FicharecTaxa").IsRequired(false);
			builder.Property(x => x.Fl_Ajuste).HasColumnName("fl_Ajuste").IsRequired(false);
			builder.Property(x => x.Cd_GrupoGuiaExpediente).HasColumnName("cd_GrupoGuiaExpediente").IsRequired(false);
			builder.Property(x => x.Cd_TributoJurosTaxa).HasColumnName("cd_TributoJurosTaxa").IsRequired(false);
			builder.Property(x => x.Cd_TributoMultasTaxa).HasColumnName("cd_TributoMultasTaxa").IsRequired(false);
			builder.Property(x => x.Cd_TributoCorrecaoTaxa).HasColumnName("cd_TributoCorrecaoTaxa").IsRequired(false);
			builder.Property(x => x.Cd_FichaRecImpostoTaxas).HasColumnName("cd_FichaRecImpostoTaxas").IsRequired(false);
			builder.Property(x => x.Msg_ParcelasVariaveis).HasColumnName("msg_ParcelasVariaveis").IsRequired(false);
			builder.Property(x => x.Msg_ParcelaUnicaTaxa).HasColumnName("msg_ParcelaUnicaTaxa").IsRequired(false);
			builder.Property(x => x.Msg_DemaisParcelasTaxa).HasColumnName("msg_DemaisParcelasTaxa").IsRequired(false);
			builder.Property(x => x.Msg_ParcelasGuias).HasColumnName("msg_ParcelasGuias").IsRequired(false);
			builder.Property(x => x.Msg_ParcelasEventuais).HasColumnName("msg_ParcelasEventuais").IsRequired(false);
			builder.Property(x => x.Msg_ParcelasExpediente).HasColumnName("msg_ParcelasExpediente").IsRequired(false);
			builder.Property(x => x.Vlr_ResCalculo).HasColumnName("vlr_ResCalculo").HasColumnType("decimal(14,2)").HasPrecision(14,2).IsRequired(false);
			builder.Property(x => x.Cd_ReceitaAClassificar).HasColumnName("cd_ReceitaAClassificar").HasColumnType("decimal(12,0)").HasPrecision(12,0).IsRequired(false);
			builder.Property(x => x.Cd_ClienteGOL).HasColumnName("cd_ClienteGOL").HasColumnType("decimal(6,0)").HasPrecision(6,0).IsRequired(false);
			builder.Property(x => x.Fl_TipoNrOcorrencia).HasColumnName("fl_TipoNrOcorrencia").IsRequired(false);
			builder.Property(x => x.Dt_atualizacao).HasColumnName("dt_atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_usuario).HasColumnName("nm_usuario").IsRequired(false);
			builder.Property(x => x.Nr_ISSEAnoMesImplantacao).HasColumnName("nr_ISSEAnoMesImplantacao").IsRequired(false);
			builder.Property(x => x.Nr_ISSEMesesParaEscrituracao).HasColumnName("nr_ISSEMesesParaEscrituracao").IsRequired(false);
			builder.Property(x => x.Nr_ISSEMesesParaRetificacao).HasColumnName("nr_ISSEMesesParaRetificacao").IsRequired(false);
			builder.Property(x => x.Nr_ISSEDiaVencimento).HasColumnName("nr_ISSEDiaVencimento").IsRequired(false);
			builder.Property(x => x.Nr_ISSENumeroDiasVencimento).HasColumnName("nr_ISSENumeroDiasVencimento").IsRequired(false);
			builder.Property(x => x.Nr_ISSEPermitirOutraAtividade).HasColumnName("nr_ISSEPermitirOutraAtividade").IsRequired(false);
			builder.Property(x => x.Nr_ISSEDiasStandBy).HasColumnName("nr_ISSEDiasStandBy").IsRequired(false);
			builder.Property(x => x.Nr_ISSEConfirmacaoCadastro).HasColumnName("nr_ISSEConfirmacaoCadastro").IsRequired(false);
			builder.Property(x => x.Msg_ObsAdicionaisCapaCarne).HasColumnName("msg_ObsAdicionaisCapaCarne").IsRequired(false);
			builder.Property(x => x.Fl_emiteAlvaraWEB).HasColumnName("fl_emiteAlvaraWEB").IsRequired(false);
			builder.Property(x => x.Fl_TipoValorIntervaloBaixaDVAT).HasColumnName("fl_TipoValorIntervaloBaixaDVAT").IsRequired(false);
			builder.Property(x => x.Vlr_IntervaloMaximoBaixaDVAT).HasColumnName("vlr_IntervaloMaximoBaixaDVAT").HasColumnType("decimal(10,4)").HasPrecision(10,4).IsRequired(false);
			builder.Property(x => x.Vlr_IntervaloMinimoBaixaDVAT).HasColumnName("vlr_IntervaloMinimoBaixaDVAT").HasColumnType("decimal(10,4)").HasPrecision(10,4).IsRequired(false);
			builder.Property(x => x.Ds_ISSESenhaAdmin).HasColumnName("ds_ISSESenhaAdmin").IsRequired(false);
			builder.Property(x => x.Nr_NFEQtdeDiasPreCadastro).HasColumnName("nr_NFEQtdeDiasPreCadastro").IsRequired(false);
			builder.Property(x => x.Nr_NFEQtdeNFBloco).HasColumnName("nr_NFEQtdeNFBloco").IsRequired(false);
			builder.Property(x => x.Nr_NFEQtdeDiasRPS).HasColumnName("nr_NFEQtdeDiasRPS").IsRequired(false);
			builder.Property(x => x.Cd_NFETipoDocto).HasColumnName("cd_NFETipoDocto").IsRequired(false);
			builder.Property(x => x.Cd_NFETipoDoctoRPS).HasColumnName("cd_NFETipoDoctoRPS").IsRequired(false);
			builder.Property(x => x.Fl_NFEDiscriminaImposto).HasColumnName("fl_NFEDiscriminaImposto").IsRequired(false);
			builder.Property(x => x.Ds_NFECapaBloco).HasColumnName("ds_NFECapaBloco").IsRequired(false);
			builder.Property(x => x.Fl_permiteAlteracaoSenhaWEB).HasColumnName("fl_permiteAlteracaoSenhaWEB").IsRequired(false);
			builder.Property(x => x.Msg_ParcelaUnica_Ambulantes).HasColumnName("msg_ParcelaUnica_Ambulantes").IsRequired(false);
			builder.Property(x => x.Msg_DemaisParcelas_Ambulantes).HasColumnName("msg_DemaisParcelas_Ambulantes").IsRequired(false);
			builder.Property(x => x.Msg_ParcelaUnicaTaxa_Ambulantes).HasColumnName("msg_ParcelaUnicaTaxa_Ambulantes").IsRequired(false);
			builder.Property(x => x.Msg_DemaisParcelasTaxa_Ambulantes).HasColumnName("msg_DemaisParcelasTaxa_Ambulantes").IsRequired(false);
			builder.Property(x => x.Msg_ParcelasGuias_Ambulantes).HasColumnName("msg_ParcelasGuias_Ambulantes").IsRequired(false);
			builder.Property(x => x.Cd_ControleAmbulanteInicial).HasColumnName("cd_ControleAmbulanteInicial").HasColumnType("decimal(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Cd_ControleAmbulanteFinal).HasColumnName("cd_ControleAmbulanteFinal").HasColumnType("decimal(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Msg_ParcelasExpediente_Ambulantes).HasColumnName("msg_ParcelasExpediente_Ambulantes").IsRequired(false);
			builder.Property(x => x.Fl_PermitirAcessoGuiaAvulsa).HasColumnName("fl_PermitirAcessoGuiaAvulsa");
			builder.Property(x => x.Msg_NotificacaoCarne).HasColumnName("msg_NotificacaoCarne").IsRequired(false);
			builder.Property(x => x.Fl_VerificaAlvaraBombeiros).HasColumnName("fl_VerificaAlvaraBombeiros").IsRequired(false);
			builder.Property(x => x.Nr_QtdDiasVencimentoAlvaraWeb).HasColumnName("nr_QtdDiasVencimentoAlvaraWeb").IsRequired(false);
			builder.Property(x => x.Ds_UrlCadastroWeb).HasColumnName("ds_UrlCadastroWeb").IsRequired(false);
			builder.Property(x => x.Cd_ISSEVencimento).HasColumnName("cd_ISSEVencimento");
			builder.Property(x => x.Pc_desconto_Principal).HasColumnName("pc_desconto_Principal").HasColumnType("decimal(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Pc_desconto_Multa).HasColumnName("pc_desconto_Multa").HasColumnType("decimal(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Pc_desconto_Juros).HasColumnName("pc_desconto_Juros").HasColumnType("decimal(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Pc_desconto_Correcao).HasColumnName("pc_desconto_Correcao").HasColumnType("decimal(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Fl_AceitedoTomador).HasColumnName("fl_AceitedoTomador").IsRequired(false);
			builder.Property(x => x.Nm_TipoAplicacaoCorrecao).HasColumnName("nm_TipoAplicacaoCorrecao").IsRequired(false);
			builder.Property(x => x.Ds_ISSEMsgPersonalRPS).HasColumnName("ds_ISSEMsgPersonalRPS");
			builder.Property(x => x.Ds_URLISSEletronico).HasColumnName("ds_URLISSEletronico").IsRequired(false);
			builder.Property(x => x.Fl_InibirInfo).HasColumnName("fl_InibirInfo").IsRequired(false);
			builder.Property(x => x.Fl_NaoConsultarDivida).HasColumnName("fl_NaoConsultarDivida").IsRequired(false);
			builder.Property(x => x.Fl_UtilizaDescAtivBoleto).HasColumnName("fl_UtilizaDescAtivBoleto");
			builder.Property(x => x.Dt_VencMaxImpressaoParcelaWeb).HasColumnName("dt_VencMaxImpressaoParcelaWeb").IsRequired(false);
			builder.Property(x => x.Vlr_ValorMinimoISSEletronico).HasColumnName("vlr_ValorMinimoISSEletronico").HasColumnType("decimal(12,2)").HasPrecision(12,2).IsRequired(false);
			builder.Property(x => x.Fl_PermiteEncerrar).HasColumnName("fl_PermiteEncerrar").IsRequired(false);
			builder.Property(x => x.Ds_FinalidadeParcelasWeb).HasColumnName("ds_FinalidadeParcelasWeb").IsRequired(false);
			builder.Property(x => x.Fl_AtualizaEmissaoGuiaWEB).HasColumnName("fl_AtualizaEmissaoGuiaWEB").IsRequired(false);
			builder.Property(x => x.Fl_AlteraDECA).HasColumnName("fl_AlteraDECA").IsRequired(false);
			builder.Property(x => x.Fl_VerDebExercDVAT).HasColumnName("fl_VerDebExercDVAT").IsRequired(false);
			builder.Property(x => x.Fl_ConsistirPagtoCancNF).HasColumnName("fl_ConsistirPagtoCancNF").IsRequired(false);
			builder.Property(x => x.Cd_subGrupoTxCompensacao).HasColumnName("cd_subGrupoTxCompensacao").IsRequired(false);
			builder.Property(x => x.Cd_tributoTxCompensacao).HasColumnName("cd_tributoTxCompensacao").IsRequired(false);
			builder.Property(x => x.Vl_TxCompensacao).HasColumnName("vl_TxCompensacao").HasColumnType("decimal(12,2)").HasPrecision(12,2).IsRequired(false);
			builder.Property(x => x.Fl_NaoPermitirRetencaoTomador).HasColumnName("fl_NaoPermitirRetencaoTomador").IsRequired(false);
			builder.Property(x => x.Fl_NaoPermitirCancNotasGuiaPaga).HasColumnName("fl_NaoPermitirCancNotasGuiaPaga").IsRequired(false);
			builder.Property(x => x.Fl_NaoPermitirRetencaoTomadorSuperSimples).HasColumnName("fl_NaoPermitirRetencaoTomadorSuperSimples").IsRequired(false);
			builder.Property(x => x.Cd_taxaGuiaeventual).HasColumnName("cd_taxaGuiaeventual").IsRequired(false);
			builder.Property(x => x.Fl_NaoPermitirCancNotaGuiaGerada).HasColumnName("fl_NaoPermitirCancNotaGuiaGerada").IsRequired(false);
			builder.Property(x => x.Fl_NaoPermitirCancNotaGuiaVencida).HasColumnName("fl_NaoPermitirCancNotaGuiaVencida").IsRequired(false);
			builder.Property(x => x.Fl_UtilizaBeneficioFiscal).HasColumnName("fl_UtilizaBeneficioFiscal").IsRequired(false);
			builder.Property(x => x.Cd_BeneficioFiscal).HasColumnName("cd_BeneficioFiscal").IsRequired(false);
			builder.Property(x => x.Pc_AliquotaBeneficioFiscal).HasColumnName("pc_AliquotaBeneficioFiscal").HasColumnType("decimal(5,2)").HasPrecision(5,2).IsRequired(false);
			builder.Property(x => x.Ds_ServicosBeneficioFiscal).HasColumnName("ds_ServicosBeneficioFiscal").IsRequired(false);
			builder.Property(x => x.Ds_UrlAPIIntegracaoNFE).HasColumnName("ds_UrlAPIIntegracaoNFE").IsRequired(false);
			builder.Property(x => x.Ds_UrlAPIIntegracaoNFEDados).HasColumnName("ds_UrlAPIIntegracaoNFEDados").IsRequired(false);
			builder.Property(x => x.Fl_AliquotaDiferenteLocalPrestacao).HasColumnName("fl_AliquotaDiferenteLocalPrestacao").IsRequired(false);
			builder.Property(x => x.Nr_ISSEqtdeDiasCancelAposEmissao).HasColumnName("nr_ISSEqtdeDiasCancelAposEmissao").IsRequired(false);
			builder.Property(x => x.Ds_ISSEleiPermissaoCancelAposEmissao).HasColumnName("ds_ISSEleiPermissaoCancelAposEmissao").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
