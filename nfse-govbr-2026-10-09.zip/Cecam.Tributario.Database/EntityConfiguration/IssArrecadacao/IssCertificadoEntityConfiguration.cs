﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssArrecadacao
{
    public class IssCertificadoEntityConfiguration : IEntityTypeConfiguration<IssCertificadoEntity>
    {
        public void Configure(EntityTypeBuilder<IssCertificadoEntity> builder)
        {
            builder.ToTable("IssCertificado");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Nr_Certificado
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Nr_Certificado).HasColumnName("nr_Certificado").HasColumnType("numeric(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Cd_Situacao).HasColumnName("cd_Situacao");
			builder.Property(x => x.Nr_Retificacao).HasColumnName("nr_Retificacao").HasColumnType("numeric(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Fl_Pago).HasColumnName("fl_Pago");
			builder.Property(x => x.Nr_CGCCPFUsuarioCriacao).HasColumnName("nr_CGCCPFUsuarioCriacao");
			builder.Property(x => x.Dt_Criacao).HasColumnName("dt_Criacao");
			builder.Property(x => x.Nr_CGCCPFUsuarioAtualizacao).HasColumnName("nr_CGCCPFUsuarioAtualizacao").IsRequired(false);
			builder.Property(x => x.Dt_Atualizacao).HasColumnName("dt_Atualizacao").IsRequired(false);
			builder.Property(x => x.Nr_Aviso).HasColumnName("nr_Aviso").IsRequired(false);
			builder.Property(x => x.Dt_VencimentoGuia).HasColumnName("dt_VencimentoGuia").IsRequired(false);
			builder.Property(x => x.Nr_Chave).HasColumnName("nr_Chave");
			builder.Property(x => x.Cd_Referencia).HasColumnName("cd_Referencia").IsRequired(false);
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF").IsRequired(false);
			builder.Property(x => x.Ds_MotivoCancelamento).HasColumnName("ds_MotivoCancelamento").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
