﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssArrecadacao
{
    public class IssParcelaEntityConfiguration : IEntityTypeConfiguration<IssParcelaEntity>
    {
        public void Configure(EntityTypeBuilder<IssParcelaEntity> builder)
        {
            builder.ToTable("IssParcelas");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Exercicio,
				 x.Cd_Contribuinte,
				 x.Nr_Aviso,
				 x.Cd_GrupoTributo
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Cd_Contribuinte).HasColumnName("Cd_Contribuinte").HasColumnType("numeric(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Nr_Aviso).HasColumnName("Nr_Aviso");
			builder.Property(x => x.Cd_GrupoTributo).HasColumnName("cd_GrupoTributo");
			builder.Property(x => x.Nr_parcela).HasColumnName("nr_parcela").IsRequired(false);
			builder.Property(x => x.Cd_Lote).HasColumnName("cd_Lote").HasColumnType("numeric(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Sg_IndiceFinanceiro).HasColumnName("sg_IndiceFinanceiro").IsRequired(false);
			builder.Property(x => x.Dt_atualizacao).HasColumnName("dt_atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_usuario).HasColumnName("nm_usuario").IsRequired(false);
			builder.Property(x => x.Dt_vencimento).HasColumnName("dt_vencimento").IsRequired(false);
			builder.Property(x => x.Vl_ReceitaBruta).HasColumnName("vl_ReceitaBruta").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_aliquota).HasColumnName("vl_aliquota").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_tributo).HasColumnName("vl_tributo").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Pc_desconto).HasColumnName("pc_desconto").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_parcela).HasColumnName("vl_parcela").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_multa).HasColumnName("vl_multa").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_juros).HasColumnName("vl_juros").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_correcao).HasColumnName("vl_correcao").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_Tarifa).HasColumnName("vl_Tarifa").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Dt_pagamento).HasColumnName("dt_pagamento").IsRequired(false);
			builder.Property(x => x.Vl_pago).HasColumnName("vl_pago").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Fl_DividaAtiva).HasColumnName("fl_DividaAtiva").IsRequired(false);
			builder.Property(x => x.Vl_Diferenca).HasColumnName("vl_Diferenca").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Nr_Guia).HasColumnName("nr_Guia").HasColumnType("numeric(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Ds_Obs).HasColumnName("ds_Obs").IsRequired(false);
			builder.Property(x => x.Dt_Estorno).HasColumnName("dt_Estorno").IsRequired(false);
			builder.Property(x => x.Ds_MotivoEstorno).HasColumnName("ds_MotivoEstorno").IsRequired(false);
			builder.Property(x => x.Nm_usuarioestorno).HasColumnName("nm_usuarioestorno").IsRequired(false);
			builder.Property(x => x.Dt_criacao).HasColumnName("dt_criacao").IsRequired(false);
			builder.Property(x => x.Nm_usuariocriacao).HasColumnName("nm_usuariocriacao").IsRequired(false);
			builder.Property(x => x.Fl_web).HasColumnName("fl_web").IsRequired(false);
			builder.Property(x => x.Ds_mesref).HasColumnName("ds_mesref").IsRequired(false);
			builder.Property(x => x.Dt_Auditoria).HasColumnName("dt_Auditoria").IsRequired(false);
			builder.Property(x => x.Nr_AvisoOrigemGA).HasColumnName("nr_AvisoOrigemGA").IsRequired(false);
			builder.Property(x => x.Nr_Certificado).HasColumnName("nr_Certificado").HasColumnType("numeric(20,0)").HasPrecision(20,0).IsRequired(false);
			builder.Property(x => x.Dt_AcaoFiscal).HasColumnName("dt_AcaoFiscal").IsRequired(false);
			builder.Property(x => x.Cd_AnoBase).HasColumnName("cd_AnoBase").IsRequired(false);
			builder.Property(x => x.Nr_GuiaUnificada).HasColumnName("nr_GuiaUnificada").HasColumnType("numeric(20,0)").HasPrecision(20,0).IsRequired(false);
			builder.Property(x => x.Cd_TipoEstorno).HasColumnName("cd_TipoEstorno").HasColumnType("numeric(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Fl_CobrancaRegistro).HasColumnName("fl_CobrancaRegistro").IsRequired(false);
			builder.Property(x => x.Cd_ExercicioGuiaUnificada).HasColumnName("cd_ExercicioGuiaUnificada").IsRequired(false);
			builder.Property(x => x.Nr_Processo).HasColumnName("nr_Processo").HasColumnType("numeric(20,0)").HasPrecision(20,0).IsRequired(false);
			builder.Property(x => x.Aa_Processo).HasColumnName("aa_Processo").IsRequired(false);
			builder.Property(x => x.Dt_Processo).HasColumnName("dt_Processo").IsRequired(false);
			builder.Property(x => x.Nr_GuiaUnificadaISS).HasColumnName("nr_GuiaUnificadaISS").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
