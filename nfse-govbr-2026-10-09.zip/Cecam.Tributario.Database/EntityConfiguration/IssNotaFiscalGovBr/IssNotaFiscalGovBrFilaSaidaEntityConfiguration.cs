﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.ISSNotaFiscalGovBr
{
    public class ISSNotaFiscalGovBrFilaSaidaEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalGovBrFilaSaidaEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalGovBrFilaSaidaEntity> builder)
        {
            builder.ToTable("ISSNotaFiscal_GovBr_FilaSaida");

			builder.HasKey(x => new {
				 x.Id
			});

            #region Propriedades

            builder.Property(x => x.Id).HasColumnName("Id");
			builder.Property(x => x.Cd_Cecam).HasColumnName("Cd_Cecam");
			builder.Property(x => x.Cd_NotaFiscal).HasColumnName("Cd_NotaFiscal").HasColumnType("decimal(18,0)").HasPrecision(18,0);
			builder.Property(x => x.FilaTipo).HasColumnName("FilaTipo");
			builder.Property(x => x.EntradaDataHora).HasColumnName("EntradaDataHora");
			builder.Property(x => x.EnvioDataHora).HasColumnName("EnvioDataHora").IsRequired(false);
			builder.Property(x => x.EnvioCorpo).HasColumnName("EnvioCorpo").IsRequired(false);
			builder.Property(x => x.EnvioMensagem).HasColumnName("EnvioMensagem").IsRequired(false);

            #endregion

            #region Relacionamentos
            #endregion
        }
    }
}
