﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscalGovBr
{
    public class ISSNotaFiscalGovBrDocArrecadacaoEntityConfiguration : IEntityTypeConfiguration<ISSNotaFiscalGovBrDocArrecadacaoEntity>
    {
        public void Configure(EntityTypeBuilder<ISSNotaFiscalGovBrDocArrecadacaoEntity> builder)
        {
            builder.ToTable("ISSNotaFiscal_GovBr_DocArrecadacao");

            // primary key
			builder.HasKey(x => new {
				 x.Id
			});




            #region Propriedades

			builder.Property(x => x.Id).HasColumnName("id");
			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_NotaFiscal).HasColumnName("cd_NotaFiscal").HasColumnType("numeric(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Dt_criacao).HasColumnName("dt_criacao");
			builder.Property(x => x.Dt_vencimento).HasColumnName("dt_vencimento");
			builder.Property(x => x.Dt_cancelamento).HasColumnName("dt_cancelamento").IsRequired(false);
			builder.Property(x => x.Dt_pagamento).HasColumnName("dt_pagamento").IsRequired(false);
			builder.Property(x => x.Vl_tributo).HasColumnName("vl_tributo").HasColumnType("numeric(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Nr_Certificado).HasColumnName("nr_Certificado").HasColumnType("numeric(20,0)").HasPrecision(20,0).IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
