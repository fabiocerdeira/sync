﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrLixoEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalGovBrLixoEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalGovBrLixoEntity> builder)
        {
            builder.ToTable("ISSNotaFiscal_GovBr_Lixo");

            // primary key
			builder.HasKey(x => new {
				 x.Id
			});


            #region Propriedades

			builder.Property(x => x.Id).HasColumnName("id");
			builder.Property(x => x.ValorDecimalA).HasColumnName("valorDecimalA").HasColumnType("decimal(18,4)").HasPrecision(18,4).IsRequired(false);
			builder.Property(x => x.ValorNumericA).HasColumnName("valorNumericA").HasColumnType("numeric(18,4)").HasPrecision(18,4).IsRequired(false);
			builder.Property(x => x.Corpo).HasColumnName("corpo").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
