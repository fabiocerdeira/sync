﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrImportarEntradaEntityConfiguration : IEntityTypeConfiguration<IssNotaFiscalGovBrImportarEntradaEntity>
    {
        public void Configure(EntityTypeBuilder<IssNotaFiscalGovBrImportarEntradaEntity> builder)
        {
            builder.ToTable("ISSNotaFiscal_GovBr_ImportarEntrada");

            // primary key
			builder.HasKey(x => new {
				 x.Id
			});


            #region Propriedades

			builder.Property(x => x.Id).HasColumnName("Id");
			builder.Property(x => x.Cd_Cecam).HasColumnName("Cd_Cecam");
			builder.Property(x => x.FilaTipo).HasColumnName("FilaTipo");
			builder.Property(x => x.Status).HasColumnName("Status");
			builder.Property(x => x.ChaveAcesso).HasColumnName("ChaveAcesso").IsRequired(false);
			builder.Property(x => x.Nsu).HasColumnName("Nsu").IsRequired(false);
			builder.Property(x => x.NfseId).HasColumnName("NfseId").IsRequired(false);
			builder.Property(x => x.DpsId).HasColumnName("DpsId").IsRequired(false);
			builder.Property(x => x.DataHoraDocumento).HasColumnName("DataHoraDocumento").IsRequired(false);
			builder.Property(x => x.TipoDocumento).HasColumnName("TipoDocumento").IsRequired(false);
			builder.Property(x => x.TipoEvento).HasColumnName("TipoEvento").IsRequired(false);
			builder.Property(x => x.DataHoraCriacao).HasColumnName("DataHoraCriacao");
			builder.Property(x => x.DataHoraProcessamento).HasColumnName("DataHoraProcessamento").IsRequired(false);
			builder.Property(x => x.Corpo).HasColumnName("Corpo").IsRequired(false);
			builder.Property(x => x.Mensagem).HasColumnName("Mensagem").IsRequired(false);
            builder.Property(x => x.Cd_Contribuinte).HasColumnName("cd_Contribuinte").HasColumnType("decimal(18,0)").HasPrecision(18, 0).IsRequired(false);
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("Nr_CGCCPF").IsRequired(false);
            builder.Property(x => x.Motivo).HasColumnName("Motivo").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
