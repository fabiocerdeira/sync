﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssComunicadoUsuarioWebEntityConfiguration : IEntityTypeConfiguration<IssComunicadoUsuarioWebEntity>
    {
        public void Configure(EntityTypeBuilder<IssComunicadoUsuarioWebEntity> builder)
        {
            builder.ToTable("ISSComunicadoUsuarioWeb");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Comunicado,
				 x.Nr_CGCCPF
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Comunicado).HasColumnName("cd_Comunicado").HasColumnType("decimal(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF").HasColumnType("decimal(15,0)").HasPrecision(15,0);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
