﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssContribuinteEntityConfiguration : IEntityTypeConfiguration<IssContribuinteEntity>
    {
        public void Configure(EntityTypeBuilder<IssContribuinteEntity> builder)
        {
            builder.ToTable("ISSContribuintes");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Contribuinte
			});




            #region Propriedades
			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Contribuinte).HasColumnName("cd_Contribuinte").HasColumnType("decimal(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Cd_TipoImposto).HasColumnName("cd_TipoImposto").IsRequired(false);
			builder.Property(x => x.Cd_tipocalculo).HasColumnName("cd_tipocalculo").IsRequired(false);
			builder.Property(x => x.Cd_Estimado).HasColumnName("cd_Estimado").IsRequired(false);
			builder.Property(x => x.Cd_periodo).HasColumnName("cd_periodo").IsRequired(false);
			builder.Property(x => x.Ds_inscricao_municipal).HasColumnName("ds_inscricao_municipal");
			builder.Property(x => x.Cd_conselho_regional).HasColumnName("cd_conselho_regional").IsRequired(false);
			builder.Property(x => x.Cd_Imovel).HasColumnName("cd_Imovel").HasColumnType("decimal(10,0)").HasPrecision(10,0).IsRequired(false);
			builder.Property(x => x.Cd_Logradouro).HasColumnName("Cd_Logradouro").IsRequired(false);
			builder.Property(x => x.Cd_Bairro).HasColumnName("Cd_Bairro").IsRequired(false);
			builder.Property(x => x.Cd_Trecho).HasColumnName("Cd_Trecho").IsRequired(false);
			builder.Property(x => x.Cd_Contador).HasColumnName("cd_Contador").IsRequired(false);
			builder.Property(x => x.Ds_razaosocial).HasColumnName("ds_razaosocial").IsRequired(false);
			builder.Property(x => x.Ds_fantasia).HasColumnName("ds_fantasia").IsRequired(false);
			builder.Property(x => x.Cd_numero).HasColumnName("cd_numero").IsRequired(false);
			builder.Property(x => x.Ds_complemento).HasColumnName("ds_complemento").IsRequired(false);
			builder.Property(x => x.Ds_andar).HasColumnName("ds_andar").IsRequired(false);
			builder.Property(x => x.Ds_apto).HasColumnName("ds_apto").IsRequired(false);
			builder.Property(x => x.Cd_LogradouroCorr).HasColumnName("cd_LogradouroCorr").IsRequired(false);
			builder.Property(x => x.Ds_TipoLogradouroCorr).HasColumnName("ds_TipoLogradouroCorr").IsRequired(false);
			builder.Property(x => x.Ds_EnderCorr).HasColumnName("ds_EnderCorr").IsRequired(false);
			builder.Property(x => x.Cd_numcorr).HasColumnName("cd_numcorr").IsRequired(false);
			builder.Property(x => x.Cd_TrechoCorr).HasColumnName("cd_TrechoCorr").IsRequired(false);
			builder.Property(x => x.Ds_Trechocorr).HasColumnName("ds_Trechocorr").IsRequired(false);
			builder.Property(x => x.Cd_BairroCorr).HasColumnName("cd_BairroCorr").IsRequired(false);
			builder.Property(x => x.Ds_bairrocorr).HasColumnName("ds_bairrocorr").IsRequired(false);
			builder.Property(x => x.Ds_complcorr).HasColumnName("ds_complcorr").IsRequired(false);
			builder.Property(x => x.Ds_andarcorr).HasColumnName("ds_andarcorr").IsRequired(false);
			builder.Property(x => x.Ds_aptocorr).HasColumnName("ds_aptocorr").IsRequired(false);
			builder.Property(x => x.Ds_cidadecorr).HasColumnName("ds_cidadecorr").IsRequired(false);
			builder.Property(x => x.Cd_cepcorr).HasColumnName("cd_cepcorr").IsRequired(false);
			builder.Property(x => x.Sg_estadocorr).HasColumnName("sg_estadocorr").IsRequired(false);
			builder.Property(x => x.Ds_paiscorr).HasColumnName("ds_paiscorr").IsRequired(false);
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF").IsRequired(false);
			builder.Property(x => x.Cd_rg_ie).HasColumnName("cd_rg_ie").IsRequired(false);
			builder.Property(x => x.Ds_OrgEmissor).HasColumnName("ds_OrgEmissor").IsRequired(false);
			builder.Property(x => x.Dt_inicio_ativ).HasColumnName("dt_inicio_ativ").IsRequired(false);
			builder.Property(x => x.Dt_atualizacao).HasColumnName("dt_atualizacao").IsRequired(false);
			builder.Property(x => x.Dt_encerramento).HasColumnName("dt_encerramento").IsRequired(false);
			builder.Property(x => x.Dt_reabertura).HasColumnName("dt_reabertura").IsRequired(false);
			builder.Property(x => x.Cd_telefone).HasColumnName("cd_telefone").IsRequired(false);
			builder.Property(x => x.Ds_complTelefone).HasColumnName("ds_complTelefone").IsRequired(false);
			builder.Property(x => x.Cd_fax).HasColumnName("cd_fax").IsRequired(false);
			builder.Property(x => x.Ds_complFax).HasColumnName("ds_complFax").IsRequired(false);
			builder.Property(x => x.Ds_email).HasColumnName("ds_email").IsRequired(false);
			builder.Property(x => x.Vl_area_ocupada).HasColumnName("vl_area_ocupada").HasColumnType("decimal(12,2)").HasPrecision(12,2).IsRequired(false);
			builder.Property(x => x.Vl_area_direta).HasColumnName("vl_area_direta").HasColumnType("decimal(12,2)").HasPrecision(12,2).IsRequired(false);
			builder.Property(x => x.Vl_area_indireta).HasColumnName("vl_area_indireta").HasColumnType("decimal(12,2)").HasPrecision(12,2).IsRequired(false);
			builder.Property(x => x.Vl_capital_social).HasColumnName("vl_capital_social").HasColumnType("decimal(12,2)").HasPrecision(12,2).IsRequired(false);
			builder.Property(x => x.Ds_ativ).HasColumnName("ds_ativ").IsRequired(false);
			builder.Property(x => x.Ds_registro_conselho).HasColumnName("ds_registro_conselho").IsRequired(false);
			builder.Property(x => x.Fl_EndEntrega).HasColumnName("fl_EndEntrega");
			builder.Property(x => x.Ds_Obs).HasColumnName("ds_Obs").IsRequired(false);
			builder.Property(x => x.Qd_Funcionarios).HasColumnName("qd_Funcionarios").IsRequired(false);
			builder.Property(x => x.Cd_TipoEstabelec).HasColumnName("cd_TipoEstabelec").IsRequired(false);
			builder.Property(x => x.Cd_TipoEmpresa).HasColumnName("cd_TipoEmpresa").IsRequired(false);
			builder.Property(x => x.Fl_MicroEmpresa).HasColumnName("fl_MicroEmpresa").IsRequired(false);
			builder.Property(x => x.Fl_FisicaJuridica).HasColumnName("fl_FisicaJuridica").IsRequired(false);
			builder.Property(x => x.Nm_usuario).HasColumnName("nm_usuario").IsRequired(false);
			builder.Property(x => x.Ds_inscricao_anterior).HasColumnName("ds_inscricao_anterior").IsRequired(false);
			builder.Property(x => x.Cd_dbaubanco).HasColumnName("cd_dbaubanco").IsRequired(false);
			builder.Property(x => x.Cd_dbauagencia).HasColumnName("cd_dbauagencia").IsRequired(false);
			builder.Property(x => x.Cd_dbauconta).HasColumnName("cd_dbauconta").IsRequired(false);
			builder.Property(x => x.Dt_cadastrobanco).HasColumnName("dt_cadastrobanco").IsRequired(false);
			builder.Property(x => x.Cd_categoria).HasColumnName("cd_categoria").IsRequired(false);
			builder.Property(x => x.Fl_web).HasColumnName("fl_web").IsRequired(false);
			builder.Property(x => x.Fl_IgnorarISSWEB).HasColumnName("fl_IgnorarISSWEB").IsRequired(false);
			builder.Property(x => x.Nr_CGCCPFMatriz).HasColumnName("nr_CGCCPFMatriz").IsRequired(false);
			builder.Property(x => x.Ds_Obs_Carne).HasColumnName("ds_Obs_Carne").IsRequired(false);
			builder.Property(x => x.Fl_IncentivoFiscal).HasColumnName("fl_IncentivoFiscal").IsRequired(false);
			builder.Property(x => x.Nr_ISSEAnoMesCertificado).HasColumnName("nr_ISSEAnoMesCertificado").IsRequired(false);
			builder.Property(x => x.Cd_RegimeTributacao).HasColumnName("cd_RegimeTributacao").IsRequired(false);
			builder.Property(x => x.Dt_inicioRegimeTributacao).HasColumnName("dt_inicioRegimeTributacao").IsRequired(false);
			builder.Property(x => x.Dt_fimRegimeTributacao).HasColumnName("dt_fimRegimeTributacao").IsRequired(false);
			builder.Property(x => x.Dt_AberturaEmpresa).HasColumnName("dt_AberturaEmpresa").IsRequired(false);
			builder.Property(x => x.Fl_estabelecido).HasColumnName("fl_estabelecido");
			builder.Property(x => x.Nr_ProtocoloJUCESP).HasColumnName("nr_ProtocoloJUCESP").IsRequired(false);
			builder.Property(x => x.Nr_CPFResponsavel).HasColumnName("nr_CPFResponsavel").IsRequired(false);
			builder.Property(x => x.Nm_Responsavel).HasColumnName("nm_Responsavel").IsRequired(false);
			builder.Property(x => x.Ds_EmailResponsavel).HasColumnName("ds_EmailResponsavel").IsRequired(false);
			builder.Property(x => x.Ds_QualificacaoResponsavel).HasColumnName("ds_QualificacaoResponsavel").IsRequired(false);
			builder.Property(x => x.Cd_TelefoneResponsavel1).HasColumnName("cd_TelefoneResponsavel1").IsRequired(false);
			builder.Property(x => x.Cd_TelefoneResponsavel2).HasColumnName("cd_TelefoneResponsavel2").IsRequired(false);
			builder.Property(x => x.Cd_FaxResponsavel).HasColumnName("cd_FaxResponsavel").IsRequired(false);
			builder.Property(x => x.Ds_Enquadramento).HasColumnName("ds_Enquadramento").IsRequired(false);
			builder.Property(x => x.Ds_FormaAtuacao).HasColumnName("ds_FormaAtuacao").IsRequired(false);
			builder.Property(x => x.Ds_TipoUnidade).HasColumnName("ds_TipoUnidade").IsRequired(false);
			builder.Property(x => x.Fl_ISSDigital).HasColumnName("fl_ISSDigital").IsRequired(false);
			builder.Property(x => x.Sg_Estado).HasColumnName("sg_Estado").IsRequired(false);
			builder.Property(x => x.Ds_Cidade).HasColumnName("ds_Cidade").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
