﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssTomadorEntityConfiguration : IEntityTypeConfiguration<IssTomadorEntity>
    {
        public void Configure(EntityTypeBuilder<IssTomadorEntity> builder)
        {
            builder.ToTable("IssTomador");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Nr_CGCCPF,
				 x.Cd_Usuario
			});


			// cd_tomador não é PK, mas é unique.
			builder.HasAlternateKey(x => x.Cd_Tomador);

            #region Propriedades


			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF");
			builder.Property(x => x.Ds_RazaoSocial).HasColumnName("ds_RazaoSocial").IsRequired(false);
			builder.Property(x => x.Cd_MunicipioTomador).HasColumnName("cd_MunicipioTomador").HasColumnType("decimal(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Sg_UF).HasColumnName("sg_UF");
			builder.Property(x => x.Fl_TipoPessoa).HasColumnName("fl_TipoPessoa");
			builder.Property(x => x.Ds_Logradouro).HasColumnName("ds_Logradouro");
			builder.Property(x => x.Cd_Numero).HasColumnName("cd_Numero");
			builder.Property(x => x.Ds_Complemento).HasColumnName("ds_Complemento");
			builder.Property(x => x.Ds_Bairro).HasColumnName("ds_Bairro");
			builder.Property(x => x.Dt_Atualizacao).HasColumnName("dt_Atualizacao");
			builder.Property(x => x.Cd_Usuario).HasColumnName("cd_Usuario");
			builder.Property(x => x.Ds_Email).HasColumnName("ds_Email").IsRequired(false);
			builder.Property(x => x.Cd_CEP).HasColumnName("cd_CEP").IsRequired(false);
			builder.Property(x => x.Cd_RG_IE).HasColumnName("cd_RG_IE").IsRequired(false);
			builder.Property(x => x.Ds_inscricao_municipal).HasColumnName("ds_inscricao_municipal").IsRequired(false);
			builder.Property(x => x.Cd_Tomador).HasColumnName("cd_Tomador").HasColumnType("decimal(18,0)").HasPrecision(18,0).ValueGeneratedOnAdd();
			builder.Property(x => x.Cd_TipoCalculo).HasColumnName("cd_TipoCalculo").IsRequired(false);
            builder.Property(x => x.Sg_Pais_ISO2).HasColumnName("sg_pais_ISO2").IsRequired(false);
            builder.Property(x => x.Ds_EnderecoExt).HasColumnName("ds_enderecoExt").IsRequired(false);
            builder.Property(x => x.Ds_CidadeExt).HasColumnName("ds_cidadeExt").IsRequired(false);
            builder.Property(x => x.Ds_EstadoExt).HasColumnName("ds_estadoExt").IsRequired(false);


            #endregion


            #region Relacionamentos

            // builder.HasMany(x => x.NotasFiscais).WithMany(x => x.Tomador).HasPrincipalKey(x => new { x.Cd_Tomador });

            #endregion
        }
    }
}
