﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class CecamImpostoEntityConfiguration : IEntityTypeConfiguration<CecamImpostoEntity>
    {
        public void Configure(EntityTypeBuilder<CecamImpostoEntity> builder)
        {
            builder.ToTable("CecamImpostos");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Imposto
			});


            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Imposto).HasColumnName("cd_Imposto");
			builder.Property(x => x.Sg_Imposto).HasColumnName("sg_Imposto");
			builder.Property(x => x.Ds_Imposto).HasColumnName("ds_Imposto");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
