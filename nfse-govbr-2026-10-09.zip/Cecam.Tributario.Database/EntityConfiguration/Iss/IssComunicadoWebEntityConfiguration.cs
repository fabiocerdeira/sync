﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssComunicadoWebEntityConfiguration : IEntityTypeConfiguration<IssComunicadoWebEntity>
    {
        public void Configure(EntityTypeBuilder<IssComunicadoWebEntity> builder)
        {
            builder.ToTable("ISSComunicadoWeb");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Comunicado
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Comunicado).HasColumnName("cd_Comunicado").HasColumnType("decimal(18,0)").HasPrecision(18,0);
			builder.Property(x => x.Dt_Criacao).HasColumnName("dt_Criacao");
			builder.Property(x => x.Dt_Validade).HasColumnName("dt_Validade");
			builder.Property(x => x.Ds_Titulo).HasColumnName("ds_Titulo");
			builder.Property(x => x.Ds_Assunto).HasColumnName("ds_Assunto");
			builder.Property(x => x.Ds_Anexo).HasColumnName("ds_Anexo");
			builder.Property(x => x.Fl_Especifico).HasColumnName("fl_Especifico");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
