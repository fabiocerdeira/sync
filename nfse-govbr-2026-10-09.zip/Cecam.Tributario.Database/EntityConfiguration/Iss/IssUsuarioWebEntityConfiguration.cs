﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssUsuarioWebEntityConfiguration : IEntityTypeConfiguration<IssUsuarioWebEntity>
    {
        public void Configure(EntityTypeBuilder<IssUsuarioWebEntity> builder)
        {
            builder.ToTable("ISSUsuarioWeb");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Nr_CGCCPF
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF");
			builder.Property(x => x.Nm_Usuario).HasColumnName("nm_Usuario");
			builder.Property(x => x.Nm_Login).HasColumnName("nm_Login");
			builder.Property(x => x.Pw_Login).HasColumnName("pw_Login");
			builder.Property(x => x.Ds_email).HasColumnName("ds_email").IsRequired(false);
			builder.Property(x => x.Fl_Tipo).HasColumnName("fl_Tipo");
			builder.Property(x => x.Nr_Acesso).HasColumnName("Nr_Acesso").IsRequired(false);
			builder.Property(x => x.Cd_Contribuinte).HasColumnName("Cd_Contribuinte").HasColumnType("decimal(18,0)").HasPrecision(18,0).IsRequired(false);
			builder.Property(x => x.Dt_Cadastro).HasColumnName("dt_Cadastro").IsRequired(false);
			builder.Property(x => x.Ds_Usuario).HasColumnName("ds_Usuario").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
