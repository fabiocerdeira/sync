﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssServicoEntityConfiguration : IEntityTypeConfiguration<IssServicoEntity>
    {
        public void Configure(EntityTypeBuilder<IssServicoEntity> builder)
        {
            builder.ToTable("IssServicos");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Servico,
				 x.Cd_Exercicio
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Servico).HasColumnName("cd_Servico");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Cd_incidencia).HasColumnName("cd_incidencia").IsRequired(false);
			builder.Property(x => x.Sg_IndiceFinanceiro).HasColumnName("sg_IndiceFinanceiro").IsRequired(false);
			builder.Property(x => x.Ds_Servico).HasColumnName("ds_Servico").IsRequired(false);
			builder.Property(x => x.Vl_Fixo).HasColumnName("vl_Fixo").HasColumnType("decimal(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Vl_Aliquota).HasColumnName("vl_Aliquota").HasColumnType("decimal(7,4)").HasPrecision(7,4).IsRequired(false);
			builder.Property(x => x.Dt_Atualizacao).HasColumnName("dt_Atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_Usuario).HasColumnName("nm_Usuario").IsRequired(false);
			builder.Property(x => x.Fl_Local).HasColumnName("fl_Local").IsRequired(false);
			builder.Property(x => x.Fl_AceitaDeducao).HasColumnName("fl_AceitaDeducao").IsRequired(false);
			builder.Property(x => x.Fl_AceitaRetido).HasColumnName("fl_AceitaRetido").IsRequired(false);
			builder.Property(x => x.Fl_Web).HasColumnName("fl_Web").IsRequired(false);
			builder.Property(x => x.Vl_PercDeducao).HasColumnName("vl_PercDeducao").HasColumnType("decimal(7,4)").HasPrecision(7,4).IsRequired(false);
			builder.Property(x => x.Fl_tipoLancamentoISSWeb).HasColumnName("fl_tipoLancamentoISSWeb").IsRequired(false);
			builder.Property(x => x.FL_OBRIGARETENCAO).HasColumnName("FL_OBRIGARETENCAO").IsRequired(false);
			builder.Property(x => x.Fl_ImpDevidoDomTomador).HasColumnName("fl_ImpDevidoDomTomador").IsRequired(false);
			builder.Property(x => x.Fl_ExcetoMEI).HasColumnName("fl_ExcetoMEI").IsRequired(false);
			builder.Property(x => x.Vl_AliquotaRetroativa).HasColumnName("vl_AliquotaRetroativa").HasColumnType("decimal(10,4)").HasPrecision(10,4).IsRequired(false);
			builder.Property(x => x.Dt_LimiteIncidencia).HasColumnName("dt_LimiteIncidencia").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
