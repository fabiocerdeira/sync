﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssEventualEntityConfiguration : IEntityTypeConfiguration<IssEventualEntity>
    {
        public void Configure(EntityTypeBuilder<IssEventualEntity> builder)
        {
            builder.ToTable("IssEventual");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_Eventual
			});


			// triggers
			builder.ToTable(tb => tb.HasTrigger("insISSEventual_LOG"));
			builder.ToTable(tb => tb.HasTrigger("updISSEventual_LOG"));

            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_Eventual).HasColumnName("cd_Eventual").HasColumnType("decimal(10,0)").HasPrecision(10,0);
			builder.Property(x => x.Ds_Razaosocial).HasColumnName("ds_razaosocial").IsRequired(false);
			builder.Property(x => x.Nr_CGCCPF).HasColumnName("nr_CGCCPF").IsRequired(false);
			builder.Property(x => x.Ds_EnderTributario).HasColumnName("ds_EnderTributario").IsRequired(false);
			builder.Property(x => x.Ds_BairroTributario).HasColumnName("ds_bairroTributario").IsRequired(false);
			builder.Property(x => x.Ds_CidadeTributario).HasColumnName("ds_cidadeTributario").IsRequired(false);
			builder.Property(x => x.Cd_CepTributario).HasColumnName("cd_cepTributario").IsRequired(false);
			builder.Property(x => x.Ds_EnderCorr).HasColumnName("ds_EnderCorr").IsRequired(false);
			builder.Property(x => x.Ds_ComplCorr).HasColumnName("ds_complcorr").IsRequired(false);
			builder.Property(x => x.Ds_BairroCorr).HasColumnName("ds_bairrocorr").IsRequired(false);
			builder.Property(x => x.Ds_CidadeCorr).HasColumnName("ds_cidadecorr").IsRequired(false);
			builder.Property(x => x.Cd_CepCorr).HasColumnName("cd_cepcorr").IsRequired(false);
			builder.Property(x => x.Sg_EstadoCorr).HasColumnName("sg_estadocorr").IsRequired(false);
			builder.Property(x => x.Ds_Item_Atividade).HasColumnName("ds_item_atividade").IsRequired(false);
			builder.Property(x => x.Fl_web).HasColumnName("fl_web").IsRequired(false);
			builder.Property(x => x.Cd_RG_IE).HasColumnName("cd_RG_IE").IsRequired(false);
			builder.Property(x => x.Sg_EstadoTributario).HasColumnName("sg_EstadoTributario").IsRequired(false);
			builder.Property(x => x.Cd_TelefoneTributario).HasColumnName("cd_TelefoneTributario").IsRequired(false);
			builder.Property(x => x.Cd_FAXTributario).HasColumnName("cd_FAXTributario").IsRequired(false);
			builder.Property(x => x.Ds_Email).HasColumnName("ds_Email").IsRequired(false);
			builder.Property(x => x.Nm_Contato).HasColumnName("nm_Contato").IsRequired(false);
			builder.Property(x => x.Nm_ResponsavelCadastroWeb).HasColumnName("nm_ResponsavelCadastroWeb").IsRequired(false);
			builder.Property(x => x.Nr_ResponsavelCadastroWebCPF).HasColumnName("nr_ResponsavelCadastroWebCPF").IsRequired(false);
			builder.Property(x => x.Nr_ResponsavelCadastroWebRG).HasColumnName("nr_ResponsavelCadastroWebRG").IsRequired(false);
			builder.Property(x => x.Ds_ResponsavelCadastroWebEmail).HasColumnName("ds_ResponsavelCadastroWebEmail").IsRequired(false);
			builder.Property(x => x.Cd_Grupo_Atividade).HasColumnName("cd_grupo_atividade").IsRequired(false);
			builder.Property(x => x.Cd_Sub_Grupo_Atividade).HasColumnName("cd_sub_grupo_atividade").IsRequired(false);
			builder.Property(x => x.Cd_Item_Atividade).HasColumnName("cd_item_atividade").IsRequired(false);
			builder.Property(x => x.Dt_Criacao).HasColumnName("dt_Criacao").IsRequired(false);
			builder.Property(x => x.Nm_UsuarioCriacao).HasColumnName("nm_UsuarioCriacao").IsRequired(false);
			builder.Property(x => x.Fl_CadastroOBRAS).HasColumnName("fl_CadastroOBRAS").IsRequired(false);
			builder.Property(x => x.Ds_Inscricao_Municipal).HasColumnName("ds_inscricao_municipal").IsRequired(false);
			builder.Property(x => x.Ds_Inscricao_Estadual).HasColumnName("ds_inscricao_estadual").IsRequired(false);
			builder.Property(x => x.Ds_ComplTributario).HasColumnName("ds_complTributario").IsRequired(false);
			builder.Property(x => x.Fl_IgnorarISSWEB).HasColumnName("fl_IgnorarISSWEB").IsRequired(false);
			builder.Property(x => x.Dt_Atualizacao).HasColumnName("dt_Atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_UsuarioAtualizacao).HasColumnName("nm_UsuarioAtualizacao").IsRequired(false);
			builder.Property(x => x.Fl_IncentivoFiscal).HasColumnName("fl_IncentivoFiscal").IsRequired(false);
			builder.Property(x => x.Nr_Registro).HasColumnName("nr_Registro").IsRequired(false);
			builder.Property(x => x.Cd_Conselho_Regional).HasColumnName("cd_Conselho_Regional").IsRequired(false);
			builder.Property(x => x.Ds_Registro_Conselho).HasColumnName("ds_Registro_Conselho").IsRequired(false);
			builder.Property(x => x.Cd_TipoCalculo).HasColumnName("cd_TipoCalculo").IsRequired(false);
			builder.Property(x => x.Cd_NumeroTributario).HasColumnName("cd_NumeroTributario").IsRequired(false);
			builder.Property(x => x.Cd_NumeroCorr).HasColumnName("cd_NumeroCorr").IsRequired(false);
			builder.Property(x => x.Ds_EmailTributario).HasColumnName("ds_EmailTributario").IsRequired(false);
			builder.Property(x => x.Ds_EmailCorr).HasColumnName("ds_EmailCorr").IsRequired(false);
			builder.Property(x => x.Cd_TelefoneCorr).HasColumnName("cd_TelefoneCorr").IsRequired(false);

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
