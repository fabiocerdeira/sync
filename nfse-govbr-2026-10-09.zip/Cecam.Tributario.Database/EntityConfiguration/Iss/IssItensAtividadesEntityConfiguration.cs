﻿using Cecam.Tributario.Database.Entity.Iss;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Cecam.Tributario.Database.EntityConfiguration.Iss
{
    public class IssItensAtividadesEntityConfiguration : IEntityTypeConfiguration<IssItensAtividadesEntity>
    {
        public void Configure(EntityTypeBuilder<IssItensAtividadesEntity> builder)
        {
            builder.ToTable("ISSItensAtividades");

            // primary key
			builder.HasKey(x => new {
				 x.Cd_Cecam,
				 x.Cd_grupo_atividade,
				 x.Cd_sub_grupo_atividade,
				 x.Cd_item_atividade,
				 x.Cd_Exercicio
			});




            #region Propriedades

			builder.Property(x => x.Cd_Cecam).HasColumnName("cd_Cecam");
			builder.Property(x => x.Cd_grupo_atividade).HasColumnName("cd_grupo_atividade");
			builder.Property(x => x.Cd_sub_grupo_atividade).HasColumnName("cd_sub_grupo_atividade");
			builder.Property(x => x.Cd_item_atividade).HasColumnName("cd_item_atividade");
			builder.Property(x => x.Cd_Exercicio).HasColumnName("cd_Exercicio");
			builder.Property(x => x.Ds_item_atividade).HasColumnName("ds_item_atividade").IsRequired(false);
			builder.Property(x => x.Cd_Servico).HasColumnName("cd_Servico").IsRequired(false);
			builder.Property(x => x.Vl_Taxa).HasColumnName("vl_Taxa").HasColumnType("decimal(14,4)").HasPrecision(14,4).IsRequired(false);
			builder.Property(x => x.Sg_IndiceFinanceiro).HasColumnName("sg_IndiceFinanceiro").IsRequired(false);
			builder.Property(x => x.Dt_Atualizacao).HasColumnName("dt_Atualizacao").IsRequired(false);
			builder.Property(x => x.Nm_Usuario).HasColumnName("nm_Usuario").IsRequired(false);
			builder.Property(x => x.Fl_Eventual).HasColumnName("fl_Eventual");
			builder.Property(x => x.Fl_Web).HasColumnName("fl_Web").IsRequired(false);
			builder.Property(x => x.Cd_AtividadeCNAE).HasColumnName("cd_AtividadeCNAE").HasColumnType("decimal(18,0)").HasPrecision(18,0).IsRequired(false);
			builder.Property(x => x.Fl_ResponsavelTecnicoObras).HasColumnName("fl_ResponsavelTecnicoObras").IsRequired(false);
			builder.Property(x => x.Fl_Item_Atividade_NFE).HasColumnName("fl_Item_Atividade_NFE");

            #endregion


            #region Relacionamentos
            #endregion
        }
    }
}
