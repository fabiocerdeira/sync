﻿using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;

namespace Cecam.Tributario.Database.Infra
{
    public class Repository<TEntity> : IDisposable, IRepository<TEntity> where TEntity : class 
    {
        #region Variaveis

        protected ITributosContext _dbContext;
        protected DbSet<TEntity> _dbSet;

        #endregion


        #region Construtores

        public Repository()
        {
            _dbContext = ServiceProviderGlobal.GetServico<ITributosContext>();
            _dbSet = _dbContext.Set<TEntity>();
        }

        /*
        public Repository(ITributosContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<TEntity>();
        }

        public Repository(IUnitOfWork unit)
        {
            _dbContext = unit.DbContext;
            _dbSet = _dbContext.Set<TEntity>();
        }
        */

        #endregion


        #region Contexto


        public ITributosContext DbContext => _dbContext;


        public DbSet<TEntity> DbSetEntity => _dbSet;


        public void SetUnitOfWork(IUnitOfWork unit)
        {
            _dbContext = unit.DbContext;
            _dbSet = _dbContext.Set<TEntity>();
        }


        #endregion


        public IQueryable<TEntity> GetIQueryable()
        {
            return _dbSet.AsQueryable();
        }




        public void Add(TEntity entity)
        {
            _dbSet.Add(entity);
        }


        public void AddList(List<TEntity> entities)
        {
            _dbSet.AddRange(entities);
        }


        public void Update(TEntity entity)
        {
            _dbSet.Update(entity);
            // _dbContext.Entry(entity).State = EntityState.Modified;
        }


        public void UpdateList(List<TEntity> entities)
        {
            // foreach (var entity in entities) { Update(entity); }
            _dbSet.UpdateRange(entities);
        }



        public async Task<int> SaveChangesAsync()
        {
            return await _dbContext.SaveChangesAsync(new CancellationToken());
        }


        public void Dispose()
        {
            _dbContext?.Dispose();
        }



        #region Transação

        public async Task BeginTransactionAsync()
        {
            await _dbContext.Database.BeginTransactionAsync(new CancellationToken());
        }

        public async Task CommitTransactionAsync()
        {
            await _dbContext.Database.CommitTransactionAsync(new CancellationToken());
        }

        public async Task RollbackTransactionAsync()
        {
            await _dbContext.Database.RollbackTransactionAsync(new CancellationToken());
        }

        #endregion




        /*

        [Obsolete("Utilize AddAsync")]
        public void Add(TEntity entity)
        {
            _dbSet.Add(entity);
        }


        public async Task AddAsync(TEntity entity)
        {
            await _dbSet.AddAsync(entity);
        }


        [Obsolete("Utilizar AddRangeAsync")]
        public void AddRange(IEnumerable<TEntity> entity)
        {
            _dbSet.AddRange(entity);
        }
        
        public async Task AddRangeAsync(IEnumerable<TEntity> entity)
        {
            await _dbSet.AddRangeAsync(entity);
        }


        public void UpdateRange(IEnumerable<TEntity> entities)
        {
            _dbSet.UpdateRange(entities);
        }


        public void Delete(TEntity entity)
        {
            _dbSet.Remove(entity);
        }

        public void Delete(TEntity entity)
        {
            _dbSet.asyn(entity);
        }


        public void DeleteRange(IEnumerable<TEntity> entity)
        {
            _dbSet.RemoveRange(entity);
        }



        [Obsolete("Utilize SaveChangesAsync")]
        public int SaveChanges()
        {
            return _dbContext.SaveChanges();
        }


        */

    }
}
