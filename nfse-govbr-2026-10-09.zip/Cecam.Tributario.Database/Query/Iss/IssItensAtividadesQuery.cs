﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssItensAtividadesQuery : QueryBase, IIssItensAtividadesQuery
    {
        protected readonly IIssItensAtividadesRepository _issItensAtividadesRepositorio;


        public IssItensAtividadesQuery(IIssItensAtividadesRepository issItensAtividadesRepositorio)
        {
            _issItensAtividadesRepositorio = issItensAtividadesRepositorio;
        }


        public async Task<IssItensAtividadesEntity?> PrimeiroOuNull(IssItensAtividadesFilter filtro)
        {
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssItensAtividadesEntity>> Listar(IssItensAtividadesFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issItensAtividadesRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_grupo_atividade.HasValue && filtro.Cd_grupo_atividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_grupo_atividade == filtro.Cd_grupo_atividade.Value);

			if (filtro.Cd_sub_grupo_atividade.HasValue && filtro.Cd_sub_grupo_atividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_sub_grupo_atividade == filtro.Cd_sub_grupo_atividade.Value);

			if (filtro.Cd_item_atividade.HasValue && filtro.Cd_item_atividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_item_atividade == filtro.Cd_item_atividade.Value);

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_item_atividade))
				consulta = consulta.Where(x => x.Ds_item_atividade == filtro.Ds_item_atividade);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
                consulta = consulta.Where(x => x.Cd_Servico != null && x.Cd_Servico.Replace("-", string.Empty).Replace(".", string.Empty).Trim() == filtro.Cd_Servico.Replace("-", string.Empty).Replace(".", string.Empty).Trim());

			if (filtro.Vl_Taxa.HasValue && filtro.Vl_Taxa.Value > 0)
				consulta = consulta.Where(x => x.Vl_Taxa == filtro.Vl_Taxa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_IndiceFinanceiro))
				consulta = consulta.Where(x => x.Sg_IndiceFinanceiro == filtro.Sg_IndiceFinanceiro);

			if (filtro.Dt_Atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Atualizacao == filtro.Dt_Atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Usuario))
				consulta = consulta.Where(x => x.Nm_Usuario == filtro.Nm_Usuario);

			if (filtro.Fl_Eventual.HasValue && filtro.Fl_Eventual.Value > 0)
				consulta = consulta.Where(x => x.Fl_Eventual == filtro.Fl_Eventual.Value);

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
				consulta = consulta.Where(x => x.Fl_Web == filtro.Fl_Web.Value);

			if (filtro.Cd_AtividadeCNAE.HasValue && filtro.Cd_AtividadeCNAE.Value > 0)
				consulta = consulta.Where(x => x.Cd_AtividadeCNAE == filtro.Cd_AtividadeCNAE.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_ResponsavelTecnicoObras))
				consulta = consulta.Where(x => x.Fl_ResponsavelTecnicoObras == filtro.Fl_ResponsavelTecnicoObras);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_Item_Atividade_NFE))
				consulta = consulta.Where(x => x.Fl_Item_Atividade_NFE == filtro.Fl_Item_Atividade_NFE);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssItensAtividadesEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssItensAtividadesEntity>> ListarSQL(IssItensAtividadesFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSItensAtividades WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_grupo_atividade.HasValue && filtro.Cd_grupo_atividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_grupo_atividade = {filtro.Cd_grupo_atividade}");
			}

			if (filtro.Cd_sub_grupo_atividade.HasValue && filtro.Cd_sub_grupo_atividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_sub_grupo_atividade = {filtro.Cd_sub_grupo_atividade}");
			}

			if (filtro.Cd_item_atividade.HasValue && filtro.Cd_item_atividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_item_atividade = {filtro.Cd_item_atividade}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_item_atividade))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_item_atividade {MontarCampoString(filtro.Ds_item_atividade)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Trim(Replace(Replace(ISNULL(cd_Servico,''),'.',''),'-','')) {MontarCampoString(filtro.Cd_Servico.Replace(".", string.Empty).Replace("-", string.Empty))}");
            }

            if (filtro.Vl_Taxa.HasValue && filtro.Vl_Taxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Taxa = {filtro.Vl_Taxa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_IndiceFinanceiro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_IndiceFinanceiro {MontarCampoString(filtro.Sg_IndiceFinanceiro)}");
			}

			if (filtro.Dt_Atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Atualizacao = {filtro.Dt_Atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Usuario {MontarCampoString(filtro.Nm_Usuario)}");
			}

			if (filtro.Fl_Eventual.HasValue && filtro.Fl_Eventual.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Eventual = {filtro.Fl_Eventual}");
			}

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Web = {filtro.Fl_Web}");
			}

			if (filtro.Cd_AtividadeCNAE.HasValue && filtro.Cd_AtividadeCNAE.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_AtividadeCNAE = {filtro.Cd_AtividadeCNAE}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_ResponsavelTecnicoObras))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_ResponsavelTecnicoObras {MontarCampoString(filtro.Fl_ResponsavelTecnicoObras)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_Item_Atividade_NFE))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Item_Atividade_NFE {MontarCampoString(filtro.Fl_Item_Atividade_NFE)}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issItensAtividadesRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSItensAtividades SET campo = 'valor' WHERE pk = 666";

            return await _issItensAtividadesRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
