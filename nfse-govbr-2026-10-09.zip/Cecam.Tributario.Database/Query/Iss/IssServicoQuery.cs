﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    /// <summary>
    /// Serviço executado/prestado na NFSe pelo emitente/prestador
    /// </summary>
    public class IssServicoQuery : QueryBase, IIssServicoQuery
    {
        protected readonly IIssServicoRepository _issServicoRepositorio;


        public IssServicoQuery(IIssServicoRepository issServicoRepositorio)
        {
            _issServicoRepositorio = issServicoRepositorio;
        }


        public async Task<IssServicoEntity?> PrimeiroOuNull(IssServicoFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssServicoEntity>> Listar(IssServicoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issServicoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
				consulta = consulta.Where(x => x.Cd_Servico.Replace("-", string.Empty).Replace(".", string.Empty).Trim() == filtro.Cd_Servico.Replace("-",string.Empty).Replace(".", string.Empty).Trim());

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

			if (filtro.Cd_incidencia.HasValue && filtro.Cd_incidencia.Value > 0)
				consulta = consulta.Where(x => x.Cd_incidencia == filtro.Cd_incidencia.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_IndiceFinanceiro))
				consulta = consulta.Where(x => x.Sg_IndiceFinanceiro == filtro.Sg_IndiceFinanceiro);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Servico))
				consulta = consulta.Where(x => x.Ds_Servico == filtro.Ds_Servico);

			if (filtro.Vl_Fixo.HasValue && filtro.Vl_Fixo.Value > 0)
				consulta = consulta.Where(x => x.Vl_Fixo == filtro.Vl_Fixo.Value);

			if (filtro.Vl_Aliquota.HasValue && filtro.Vl_Aliquota.Value > 0)
				consulta = consulta.Where(x => x.Vl_Aliquota == filtro.Vl_Aliquota.Value);

			if (filtro.Dt_Atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Atualizacao == filtro.Dt_Atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Usuario))
				consulta = consulta.Where(x => x.Nm_Usuario == filtro.Nm_Usuario);

			if (filtro.Fl_Local.HasValue && filtro.Fl_Local.Value > 0)
				consulta = consulta.Where(x => x.Fl_Local == filtro.Fl_Local.Value);

			if (filtro.Fl_AceitaDeducao.HasValue && filtro.Fl_AceitaDeducao.Value > 0)
				consulta = consulta.Where(x => x.Fl_AceitaDeducao == filtro.Fl_AceitaDeducao.Value);

			if (filtro.Fl_AceitaRetido.HasValue && filtro.Fl_AceitaRetido.Value > 0)
				consulta = consulta.Where(x => x.Fl_AceitaRetido == filtro.Fl_AceitaRetido.Value);

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
				consulta = consulta.Where(x => x.Fl_Web == filtro.Fl_Web.Value);

			if (filtro.Vl_PercDeducao.HasValue && filtro.Vl_PercDeducao.Value > 0)
				consulta = consulta.Where(x => x.Vl_PercDeducao == filtro.Vl_PercDeducao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_tipoLancamentoISSWeb))
				consulta = consulta.Where(x => x.Fl_tipoLancamentoISSWeb == filtro.Fl_tipoLancamentoISSWeb);

			if (filtro.FL_OBRIGARETENCAO.HasValue && filtro.FL_OBRIGARETENCAO.Value > 0)
				consulta = consulta.Where(x => x.FL_OBRIGARETENCAO == filtro.FL_OBRIGARETENCAO.Value);

			if (filtro.Fl_ImpDevidoDomTomador.HasValue && filtro.Fl_ImpDevidoDomTomador.Value > 0)
				consulta = consulta.Where(x => x.Fl_ImpDevidoDomTomador == filtro.Fl_ImpDevidoDomTomador.Value);

			if (filtro.Fl_ExcetoMEI.HasValue && filtro.Fl_ExcetoMEI.Value > 0)
				consulta = consulta.Where(x => x.Fl_ExcetoMEI == filtro.Fl_ExcetoMEI.Value);

			if (filtro.Vl_AliquotaRetroativa.HasValue && filtro.Vl_AliquotaRetroativa.Value > 0)
				consulta = consulta.Where(x => x.Vl_AliquotaRetroativa == filtro.Vl_AliquotaRetroativa.Value);

			if (filtro.Dt_LimiteIncidencia.HasValue)
				consulta = consulta.Where(x => x.Dt_LimiteIncidencia == filtro.Dt_LimiteIncidencia.Value);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssServicoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssServicoEntity>> ListarSQL(IssServicoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssServicos WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Trim(Replace(Replace(cd_Servico,'.',''),'-','')) {MontarCampoString(filtro.Cd_Servico.Replace(".", string.Empty).Replace("-", string.Empty))}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			if (filtro.Cd_incidencia.HasValue && filtro.Cd_incidencia.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_incidencia = {filtro.Cd_incidencia}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_IndiceFinanceiro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_IndiceFinanceiro {MontarCampoString(filtro.Sg_IndiceFinanceiro)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Servico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Servico {MontarCampoString(filtro.Ds_Servico)}");
			}

			if (filtro.Vl_Fixo.HasValue && filtro.Vl_Fixo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Fixo = {filtro.Vl_Fixo}");
			}

			if (filtro.Vl_Aliquota.HasValue && filtro.Vl_Aliquota.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Aliquota = {filtro.Vl_Aliquota}");
			}

			if (filtro.Dt_Atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Atualizacao = {filtro.Dt_Atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Usuario {MontarCampoString(filtro.Nm_Usuario)}");
			}

			if (filtro.Fl_Local.HasValue && filtro.Fl_Local.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Local = {filtro.Fl_Local}");
			}

			if (filtro.Fl_AceitaDeducao.HasValue && filtro.Fl_AceitaDeducao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AceitaDeducao = {filtro.Fl_AceitaDeducao}");
			}

			if (filtro.Fl_AceitaRetido.HasValue && filtro.Fl_AceitaRetido.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AceitaRetido = {filtro.Fl_AceitaRetido}");
			}

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Web = {filtro.Fl_Web}");
			}

			if (filtro.Vl_PercDeducao.HasValue && filtro.Vl_PercDeducao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_PercDeducao = {filtro.Vl_PercDeducao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_tipoLancamentoISSWeb))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_tipoLancamentoISSWeb {MontarCampoString(filtro.Fl_tipoLancamentoISSWeb)}");
			}

			if (filtro.FL_OBRIGARETENCAO.HasValue && filtro.FL_OBRIGARETENCAO.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" FL_OBRIGARETENCAO = {filtro.FL_OBRIGARETENCAO}");
			}

			if (filtro.Fl_ImpDevidoDomTomador.HasValue && filtro.Fl_ImpDevidoDomTomador.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_ImpDevidoDomTomador = {filtro.Fl_ImpDevidoDomTomador}");
			}

			if (filtro.Fl_ExcetoMEI.HasValue && filtro.Fl_ExcetoMEI.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_ExcetoMEI = {filtro.Fl_ExcetoMEI}");
			}

			if (filtro.Vl_AliquotaRetroativa.HasValue && filtro.Vl_AliquotaRetroativa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_AliquotaRetroativa = {filtro.Vl_AliquotaRetroativa}");
			}

			if (filtro.Dt_LimiteIncidencia.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_LimiteIncidencia = {filtro.Dt_LimiteIncidencia}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issServicoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE IssServicos SET campo = 'valor' WHERE pk = 666";

            return await _issServicoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
