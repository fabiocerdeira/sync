﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssContribuinteQuery : QueryBase, IIssContribuinteQuery
    {
        protected readonly IIssContribuinteRepository _issContribuinteRepositorio;


        public IssContribuinteQuery(IIssContribuinteRepository issContribuinteRepositorio)
        {
            _issContribuinteRepositorio = issContribuinteRepositorio;
        }


        public async Task<IssContribuinteEntity?> PrimeiroOuNull(IssContribuinteFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssContribuinteEntity>> Listar(IssContribuinteFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issContribuinteRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

            if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
                consulta = consulta.Where(x => x.Cd_Contribuinte == filtro.Cd_Contribuinte.Value);

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CgcCpf))
                consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CgcCpf);

            if (!string.IsNullOrWhiteSpace(filtro.Ds_Inscricao_Municipal))
                consulta = consulta.Where(x => x.Ds_inscricao_municipal == filtro.Ds_Inscricao_Municipal);


            /*
			if (filtro.Cd_TipoImposto.HasValue && filtro.Cd_TipoImposto.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoImposto == filtro.Cd_TipoImposto.Value);

			if (filtro.Cd_tipocalculo.HasValue && filtro.Cd_tipocalculo.Value > 0)
				consulta = consulta.Where(x => x.Cd_tipocalculo == filtro.Cd_tipocalculo.Value);

			if (filtro.Cd_Estimado.HasValue && filtro.Cd_Estimado.Value > 0)
				consulta = consulta.Where(x => x.Cd_Estimado == filtro.Cd_Estimado.Value);

			if (filtro.Cd_periodo.HasValue && filtro.Cd_periodo.Value > 0)
				consulta = consulta.Where(x => x.Cd_periodo == filtro.Cd_periodo.Value);

			if (filtro.Cd_conselho_regional.HasValue && filtro.Cd_conselho_regional.Value > 0)
				consulta = consulta.Where(x => x.Cd_conselho_regional == filtro.Cd_conselho_regional.Value);

			if (filtro.Cd_Imovel.HasValue && filtro.Cd_Imovel.Value > 0)
				consulta = consulta.Where(x => x.Cd_Imovel == filtro.Cd_Imovel.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Logradouro))
				consulta = consulta.Where(x => x.Cd_Logradouro == filtro.Cd_Logradouro);

			if (filtro.Cd_Bairro.HasValue && filtro.Cd_Bairro.Value > 0)
				consulta = consulta.Where(x => x.Cd_Bairro == filtro.Cd_Bairro.Value);

			if (filtro.Cd_Trecho.HasValue && filtro.Cd_Trecho.Value > 0)
				consulta = consulta.Where(x => x.Cd_Trecho == filtro.Cd_Trecho.Value);

			if (filtro.Cd_Contador.HasValue && filtro.Cd_Contador.Value > 0)
				consulta = consulta.Where(x => x.Cd_Contador == filtro.Cd_Contador.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_razaosocial))
				consulta = consulta.Where(x => x.Ds_razaosocial == filtro.Ds_razaosocial);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_fantasia))
				consulta = consulta.Where(x => x.Ds_fantasia == filtro.Ds_fantasia);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_numero))
				consulta = consulta.Where(x => x.Cd_numero == filtro.Cd_numero);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complemento))
				consulta = consulta.Where(x => x.Ds_complemento == filtro.Ds_complemento);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_andar))
				consulta = consulta.Where(x => x.Ds_andar == filtro.Ds_andar);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_apto))
				consulta = consulta.Where(x => x.Ds_apto == filtro.Ds_apto);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_LogradouroCorr))
				consulta = consulta.Where(x => x.Cd_LogradouroCorr == filtro.Cd_LogradouroCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_TipoLogradouroCorr))
				consulta = consulta.Where(x => x.Ds_TipoLogradouroCorr == filtro.Ds_TipoLogradouroCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EnderCorr))
				consulta = consulta.Where(x => x.Ds_EnderCorr == filtro.Ds_EnderCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_numcorr))
				consulta = consulta.Where(x => x.Cd_numcorr == filtro.Cd_numcorr);

			if (filtro.Cd_TrechoCorr.HasValue && filtro.Cd_TrechoCorr.Value > 0)
				consulta = consulta.Where(x => x.Cd_TrechoCorr == filtro.Cd_TrechoCorr.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Trechocorr))
				consulta = consulta.Where(x => x.Ds_Trechocorr == filtro.Ds_Trechocorr);

			if (filtro.Cd_BairroCorr.HasValue && filtro.Cd_BairroCorr.Value > 0)
				consulta = consulta.Where(x => x.Cd_BairroCorr == filtro.Cd_BairroCorr.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_bairrocorr))
				consulta = consulta.Where(x => x.Ds_bairrocorr == filtro.Ds_bairrocorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complcorr))
				consulta = consulta.Where(x => x.Ds_complcorr == filtro.Ds_complcorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_andarcorr))
				consulta = consulta.Where(x => x.Ds_andarcorr == filtro.Ds_andarcorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_aptocorr))
				consulta = consulta.Where(x => x.Ds_aptocorr == filtro.Ds_aptocorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_cidadecorr))
				consulta = consulta.Where(x => x.Ds_cidadecorr == filtro.Ds_cidadecorr);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_cepcorr))
				consulta = consulta.Where(x => x.Cd_cepcorr == filtro.Cd_cepcorr);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_estadocorr))
				consulta = consulta.Where(x => x.Sg_estadocorr == filtro.Sg_estadocorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_paiscorr))
				consulta = consulta.Where(x => x.Ds_paiscorr == filtro.Ds_paiscorr);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_rg_ie))
				consulta = consulta.Where(x => x.Cd_rg_ie == filtro.Cd_rg_ie);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_OrgEmissor))
				consulta = consulta.Where(x => x.Ds_OrgEmissor == filtro.Ds_OrgEmissor);

			if (filtro.Dt_inicio_ativ.HasValue)
				consulta = consulta.Where(x => x.Dt_inicio_ativ == filtro.Dt_inicio_ativ.Value);

			if (filtro.Dt_atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_atualizacao == filtro.Dt_atualizacao.Value);

			if (filtro.Dt_encerramento.HasValue)
				consulta = consulta.Where(x => x.Dt_encerramento == filtro.Dt_encerramento.Value);

			if (filtro.Dt_reabertura.HasValue)
				consulta = consulta.Where(x => x.Dt_reabertura == filtro.Dt_reabertura.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_telefone))
				consulta = consulta.Where(x => x.Cd_telefone == filtro.Cd_telefone);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complTelefone))
				consulta = consulta.Where(x => x.Ds_complTelefone == filtro.Ds_complTelefone);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_fax))
				consulta = consulta.Where(x => x.Cd_fax == filtro.Cd_fax);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complFax))
				consulta = consulta.Where(x => x.Ds_complFax == filtro.Ds_complFax);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_email))
				consulta = consulta.Where(x => x.Ds_email == filtro.Ds_email);

			if (filtro.Vl_area_ocupada.HasValue && filtro.Vl_area_ocupada.Value > 0)
				consulta = consulta.Where(x => x.Vl_area_ocupada == filtro.Vl_area_ocupada.Value);

			if (filtro.Vl_area_direta.HasValue && filtro.Vl_area_direta.Value > 0)
				consulta = consulta.Where(x => x.Vl_area_direta == filtro.Vl_area_direta.Value);

			if (filtro.Vl_area_indireta.HasValue && filtro.Vl_area_indireta.Value > 0)
				consulta = consulta.Where(x => x.Vl_area_indireta == filtro.Vl_area_indireta.Value);

			if (filtro.Vl_capital_social.HasValue && filtro.Vl_capital_social.Value > 0)
				consulta = consulta.Where(x => x.Vl_capital_social == filtro.Vl_capital_social.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ativ))
				consulta = consulta.Where(x => x.Ds_ativ == filtro.Ds_ativ);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_registro_conselho))
				consulta = consulta.Where(x => x.Ds_registro_conselho == filtro.Ds_registro_conselho);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_EndEntrega))
				consulta = consulta.Where(x => x.Fl_EndEntrega == filtro.Fl_EndEntrega);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Obs))
				consulta = consulta.Where(x => x.Ds_Obs == filtro.Ds_Obs);

			if (filtro.Qd_Funcionarios.HasValue && filtro.Qd_Funcionarios.Value > 0)
				consulta = consulta.Where(x => x.Qd_Funcionarios == filtro.Qd_Funcionarios.Value);

			if (filtro.Cd_TipoEstabelec.HasValue && filtro.Cd_TipoEstabelec.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoEstabelec == filtro.Cd_TipoEstabelec.Value);

			if (filtro.Cd_TipoEmpresa.HasValue && filtro.Cd_TipoEmpresa.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoEmpresa == filtro.Cd_TipoEmpresa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_MicroEmpresa))
				consulta = consulta.Where(x => x.Fl_MicroEmpresa == filtro.Fl_MicroEmpresa);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_FisicaJuridica))
				consulta = consulta.Where(x => x.Fl_FisicaJuridica == filtro.Fl_FisicaJuridica);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
				consulta = consulta.Where(x => x.Nm_usuario == filtro.Nm_usuario);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_inscricao_anterior))
				consulta = consulta.Where(x => x.Ds_inscricao_anterior == filtro.Ds_inscricao_anterior);

			if (filtro.Cd_dbaubanco.HasValue && filtro.Cd_dbaubanco.Value > 0)
				consulta = consulta.Where(x => x.Cd_dbaubanco == filtro.Cd_dbaubanco.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_dbauagencia))
				consulta = consulta.Where(x => x.Cd_dbauagencia == filtro.Cd_dbauagencia);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_dbauconta))
				consulta = consulta.Where(x => x.Cd_dbauconta == filtro.Cd_dbauconta);

			if (filtro.Dt_cadastrobanco.HasValue)
				consulta = consulta.Where(x => x.Dt_cadastrobanco == filtro.Dt_cadastrobanco.Value);

			if (filtro.Cd_categoria.HasValue && filtro.Cd_categoria.Value > 0)
				consulta = consulta.Where(x => x.Cd_categoria == filtro.Cd_categoria.Value);

			if (filtro.Fl_web.HasValue && filtro.Fl_web.Value > 0)
				consulta = consulta.Where(x => x.Fl_web == filtro.Fl_web.Value);

			if (filtro.Fl_IgnorarISSWEB.HasValue && filtro.Fl_IgnorarISSWEB.Value > 0)
				consulta = consulta.Where(x => x.Fl_IgnorarISSWEB == filtro.Fl_IgnorarISSWEB.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFMatriz))
				consulta = consulta.Where(x => x.Nr_CGCCPFMatriz == filtro.Nr_CGCCPFMatriz);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Obs_Carne))
				consulta = consulta.Where(x => x.Ds_Obs_Carne == filtro.Ds_Obs_Carne);

			if (filtro.Fl_IncentivoFiscal.HasValue && filtro.Fl_IncentivoFiscal.Value > 0)
				consulta = consulta.Where(x => x.Fl_IncentivoFiscal == filtro.Fl_IncentivoFiscal.Value);

			if (filtro.Nr_ISSEAnoMesCertificado.HasValue && filtro.Nr_ISSEAnoMesCertificado.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEAnoMesCertificado == filtro.Nr_ISSEAnoMesCertificado.Value);

			if (filtro.Cd_RegimeTributacao.HasValue && filtro.Cd_RegimeTributacao.Value > 0)
				consulta = consulta.Where(x => x.Cd_RegimeTributacao == filtro.Cd_RegimeTributacao.Value);

			if (filtro.Dt_inicioRegimeTributacao.HasValue)
				consulta = consulta.Where(x => x.Dt_inicioRegimeTributacao == filtro.Dt_inicioRegimeTributacao.Value);

			if (filtro.Dt_fimRegimeTributacao.HasValue)
				consulta = consulta.Where(x => x.Dt_fimRegimeTributacao == filtro.Dt_fimRegimeTributacao.Value);

			if (filtro.Dt_AberturaEmpresa.HasValue)
				consulta = consulta.Where(x => x.Dt_AberturaEmpresa == filtro.Dt_AberturaEmpresa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_estabelecido))
				consulta = consulta.Where(x => x.Fl_estabelecido == filtro.Fl_estabelecido);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ProtocoloJUCESP))
				consulta = consulta.Where(x => x.Nr_ProtocoloJUCESP == filtro.Nr_ProtocoloJUCESP);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CPFResponsavel))
				consulta = consulta.Where(x => x.Nr_CPFResponsavel == filtro.Nr_CPFResponsavel);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Responsavel))
				consulta = consulta.Where(x => x.Nm_Responsavel == filtro.Nm_Responsavel);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EmailResponsavel))
				consulta = consulta.Where(x => x.Ds_EmailResponsavel == filtro.Ds_EmailResponsavel);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_QualificacaoResponsavel))
				consulta = consulta.Where(x => x.Ds_QualificacaoResponsavel == filtro.Ds_QualificacaoResponsavel);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneResponsavel1))
				consulta = consulta.Where(x => x.Cd_TelefoneResponsavel1 == filtro.Cd_TelefoneResponsavel1);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneResponsavel2))
				consulta = consulta.Where(x => x.Cd_TelefoneResponsavel2 == filtro.Cd_TelefoneResponsavel2);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_FaxResponsavel))
				consulta = consulta.Where(x => x.Cd_FaxResponsavel == filtro.Cd_FaxResponsavel);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Enquadramento))
				consulta = consulta.Where(x => x.Ds_Enquadramento == filtro.Ds_Enquadramento);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_FormaAtuacao))
				consulta = consulta.Where(x => x.Ds_FormaAtuacao == filtro.Ds_FormaAtuacao);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_TipoUnidade))
				consulta = consulta.Where(x => x.Ds_TipoUnidade == filtro.Ds_TipoUnidade);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_ISSDigital))
				consulta = consulta.Where(x => x.Fl_ISSDigital == filtro.Fl_ISSDigital);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_Estado))
				consulta = consulta.Where(x => x.Sg_Estado == filtro.Sg_Estado);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Cidade))
				consulta = consulta.Where(x => x.Ds_Cidade == filtro.Ds_Cidade);
			*/


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssContribuinteEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssContribuinteEntity>> ListarSQL(IssContribuinteFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSContribuintes WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Contribuinte = {filtro.Cd_Contribuinte}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			/*
			if (filtro.Cd_TipoImposto.HasValue && filtro.Cd_TipoImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoImposto = {filtro.Cd_TipoImposto}");
			}

			if (filtro.Cd_tipocalculo.HasValue && filtro.Cd_tipocalculo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_tipocalculo = {filtro.Cd_tipocalculo}");
			}

			if (filtro.Cd_Estimado.HasValue && filtro.Cd_Estimado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Estimado = {filtro.Cd_Estimado}");
			}

			if (filtro.Cd_periodo.HasValue && filtro.Cd_periodo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_periodo = {filtro.Cd_periodo}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_inscricao_municipal))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_inscricao_municipal = '{filtro.Ds_inscricao_municipal.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_conselho_regional.HasValue && filtro.Cd_conselho_regional.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_conselho_regional = {filtro.Cd_conselho_regional}");
			}

			if (filtro.Cd_Imovel.HasValue && filtro.Cd_Imovel.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Imovel = {filtro.Cd_Imovel}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Logradouro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Logradouro = '{filtro.Cd_Logradouro.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_Bairro.HasValue && filtro.Cd_Bairro.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Bairro = {filtro.Cd_Bairro}");
			}

			if (filtro.Cd_Trecho.HasValue && filtro.Cd_Trecho.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Trecho = {filtro.Cd_Trecho}");
			}

			if (filtro.Cd_Contador.HasValue && filtro.Cd_Contador.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Contador = {filtro.Cd_Contador}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_razaosocial))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_razaosocial = '{filtro.Ds_razaosocial.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_fantasia))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_fantasia = '{filtro.Ds_fantasia.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_numero))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_numero = '{filtro.Cd_numero.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complemento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_complemento = '{filtro.Ds_complemento.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_andar))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_andar = '{filtro.Ds_andar.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_apto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_apto = '{filtro.Ds_apto.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_LogradouroCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_LogradouroCorr = '{filtro.Cd_LogradouroCorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_TipoLogradouroCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_TipoLogradouroCorr = '{filtro.Ds_TipoLogradouroCorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EnderCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_EnderCorr = '{filtro.Ds_EnderCorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_numcorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_numcorr = '{filtro.Cd_numcorr.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_TrechoCorr.HasValue && filtro.Cd_TrechoCorr.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TrechoCorr = {filtro.Cd_TrechoCorr}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Trechocorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Trechocorr = '{filtro.Ds_Trechocorr.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_BairroCorr.HasValue && filtro.Cd_BairroCorr.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_BairroCorr = {filtro.Cd_BairroCorr}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_bairrocorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_bairrocorr = '{filtro.Ds_bairrocorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complcorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_complcorr = '{filtro.Ds_complcorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_andarcorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_andarcorr = '{filtro.Ds_andarcorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_aptocorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_aptocorr = '{filtro.Ds_aptocorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_cidadecorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_cidadecorr = '{filtro.Ds_cidadecorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_cepcorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_cepcorr = '{filtro.Cd_cepcorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_estadocorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_estadocorr = '{filtro.Sg_estadocorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_paiscorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_paiscorr = '{filtro.Ds_paiscorr.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF = '{filtro.Nr_CGCCPF.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_rg_ie))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_rg_ie = '{filtro.Cd_rg_ie.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_OrgEmissor))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_OrgEmissor = '{filtro.Ds_OrgEmissor.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_inicio_ativ.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_inicio_ativ = {filtro.Dt_inicio_ativ}");
			}

			if (filtro.Dt_atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_atualizacao = {filtro.Dt_atualizacao}");
			}

			if (filtro.Dt_encerramento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_encerramento = {filtro.Dt_encerramento}");
			}

			if (filtro.Dt_reabertura.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_reabertura = {filtro.Dt_reabertura}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_telefone))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_telefone = '{filtro.Cd_telefone.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complTelefone))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_complTelefone = '{filtro.Ds_complTelefone.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_fax))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_fax = '{filtro.Cd_fax.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_complFax))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_complFax = '{filtro.Ds_complFax.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_email))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_email = '{filtro.Ds_email.Trim().Replace("\'","")}'");
			}

			if (filtro.Vl_area_ocupada.HasValue && filtro.Vl_area_ocupada.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_area_ocupada = {filtro.Vl_area_ocupada}");
			}

			if (filtro.Vl_area_direta.HasValue && filtro.Vl_area_direta.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_area_direta = {filtro.Vl_area_direta}");
			}

			if (filtro.Vl_area_indireta.HasValue && filtro.Vl_area_indireta.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_area_indireta = {filtro.Vl_area_indireta}");
			}

			if (filtro.Vl_capital_social.HasValue && filtro.Vl_capital_social.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_capital_social = {filtro.Vl_capital_social}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ativ))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ativ = '{filtro.Ds_ativ.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_registro_conselho))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_registro_conselho = '{filtro.Ds_registro_conselho.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_EndEntrega))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_EndEntrega = '{filtro.Fl_EndEntrega.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Obs))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Obs = '{filtro.Ds_Obs.Trim().Replace("\'","")}'");
			}

			if (filtro.Qd_Funcionarios.HasValue && filtro.Qd_Funcionarios.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Qd_Funcionarios = {filtro.Qd_Funcionarios}");
			}

			if (filtro.Cd_TipoEstabelec.HasValue && filtro.Cd_TipoEstabelec.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoEstabelec = {filtro.Cd_TipoEstabelec}");
			}

			if (filtro.Cd_TipoEmpresa.HasValue && filtro.Cd_TipoEmpresa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoEmpresa = {filtro.Cd_TipoEmpresa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_MicroEmpresa))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_MicroEmpresa = '{filtro.Fl_MicroEmpresa.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_FisicaJuridica))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_FisicaJuridica = '{filtro.Fl_FisicaJuridica.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuario = '{filtro.Nm_usuario.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_inscricao_anterior))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_inscricao_anterior = '{filtro.Ds_inscricao_anterior.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_dbaubanco.HasValue && filtro.Cd_dbaubanco.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_dbaubanco = {filtro.Cd_dbaubanco}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_dbauagencia))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_dbauagencia = '{filtro.Cd_dbauagencia.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_dbauconta))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_dbauconta = '{filtro.Cd_dbauconta.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_cadastrobanco.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_cadastrobanco = {filtro.Dt_cadastrobanco}");
			}

			if (filtro.Cd_categoria.HasValue && filtro.Cd_categoria.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_categoria = {filtro.Cd_categoria}");
			}

			if (filtro.Fl_web.HasValue && filtro.Fl_web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_web = {filtro.Fl_web}");
			}

			if (filtro.Fl_IgnorarISSWEB.HasValue && filtro.Fl_IgnorarISSWEB.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_IgnorarISSWEB = {filtro.Fl_IgnorarISSWEB}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFMatriz))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPFMatriz = '{filtro.Nr_CGCCPFMatriz.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Obs_Carne))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Obs_Carne = '{filtro.Ds_Obs_Carne.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_IncentivoFiscal.HasValue && filtro.Fl_IncentivoFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_IncentivoFiscal = {filtro.Fl_IncentivoFiscal}");
			}

			if (filtro.Nr_ISSEAnoMesCertificado.HasValue && filtro.Nr_ISSEAnoMesCertificado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEAnoMesCertificado = {filtro.Nr_ISSEAnoMesCertificado}");
			}

			if (filtro.Cd_RegimeTributacao.HasValue && filtro.Cd_RegimeTributacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_RegimeTributacao = {filtro.Cd_RegimeTributacao}");
			}

			if (filtro.Dt_inicioRegimeTributacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_inicioRegimeTributacao = {filtro.Dt_inicioRegimeTributacao}");
			}

			if (filtro.Dt_fimRegimeTributacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_fimRegimeTributacao = {filtro.Dt_fimRegimeTributacao}");
			}

			if (filtro.Dt_AberturaEmpresa.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_AberturaEmpresa = {filtro.Dt_AberturaEmpresa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_estabelecido))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_estabelecido = '{filtro.Fl_estabelecido.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ProtocoloJUCESP))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ProtocoloJUCESP = '{filtro.Nr_ProtocoloJUCESP.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CPFResponsavel))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CPFResponsavel = '{filtro.Nr_CPFResponsavel.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Responsavel))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Responsavel = '{filtro.Nm_Responsavel.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EmailResponsavel))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_EmailResponsavel = '{filtro.Ds_EmailResponsavel.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_QualificacaoResponsavel))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_QualificacaoResponsavel = '{filtro.Ds_QualificacaoResponsavel.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneResponsavel1))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TelefoneResponsavel1 = '{filtro.Cd_TelefoneResponsavel1.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneResponsavel2))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TelefoneResponsavel2 = '{filtro.Cd_TelefoneResponsavel2.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_FaxResponsavel))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_FaxResponsavel = '{filtro.Cd_FaxResponsavel.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Enquadramento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Enquadramento = '{filtro.Ds_Enquadramento.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_FormaAtuacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_FormaAtuacao = '{filtro.Ds_FormaAtuacao.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_TipoUnidade))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_TipoUnidade = '{filtro.Ds_TipoUnidade.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_ISSDigital))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_ISSDigital = '{filtro.Fl_ISSDigital.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_Estado))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_Estado = '{filtro.Sg_Estado.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Cidade))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Cidade = '{filtro.Ds_Cidade.Trim().Replace("\'","")}'");
			}
			*/


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issContribuinteRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSContribuintes SET campo = 'valor' WHERE pk = 666";

            return await _issContribuinteRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
