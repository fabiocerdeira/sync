﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssUsuarioWebQuery : QueryBase, IIssUsuarioWebQuery
    {
        protected readonly IIssUsuarioWebRepository _issUsuarioWebRepositorio;


        public IssUsuarioWebQuery(IIssUsuarioWebRepository issUsuarioWebRepositorio)
        {
            _issUsuarioWebRepositorio = issUsuarioWebRepositorio;
        }


        public async Task<IssUsuarioWebEntity?> PrimeiroOuNull(IssUsuarioWebFilter filtro)
        {
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssUsuarioWebEntity>> Listar(IssUsuarioWebFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issUsuarioWebRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
				consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Usuario))
				consulta = consulta.Where(x => x.Nm_Usuario == filtro.Nm_Usuario);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Login))
				consulta = consulta.Where(x => x.Nm_Login == filtro.Nm_Login);

			if (!string.IsNullOrWhiteSpace(filtro.Pw_Login))
				consulta = consulta.Where(x => x.Pw_Login == filtro.Pw_Login);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_email))
				consulta = consulta.Where(x => x.Ds_email == filtro.Ds_email);

			if (filtro.Fl_Tipo.HasValue && filtro.Fl_Tipo.Value > 0)
				consulta = consulta.Where(x => x.Fl_Tipo == filtro.Fl_Tipo.Value);

			if (filtro.Nr_Acesso.HasValue && filtro.Nr_Acesso.Value > 0)
				consulta = consulta.Where(x => x.Nr_Acesso == filtro.Nr_Acesso.Value);

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
				consulta = consulta.Where(x => x.Cd_Contribuinte == filtro.Cd_Contribuinte.Value);

			if (filtro.Dt_Cadastro.HasValue)
				consulta = consulta.Where(x => x.Dt_Cadastro == filtro.Dt_Cadastro.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Usuario))
				consulta = consulta.Where(x => x.Ds_Usuario == filtro.Ds_Usuario);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssUsuarioWebEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssUsuarioWebEntity>> ListarSQL(IssUsuarioWebFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSUsuarioWeb WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF {MontarCampoString(filtro.Nr_CGCCPF)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Usuario {MontarCampoString(filtro.Nm_Usuario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Login))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Login {MontarCampoString(filtro.Nm_Login)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Pw_Login))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pw_Login {MontarCampoString(filtro.Pw_Login)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_email))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_email {MontarCampoString(filtro.Ds_email)}");
			}

			if (filtro.Fl_Tipo.HasValue && filtro.Fl_Tipo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Tipo = {filtro.Fl_Tipo}");
			}

			if (filtro.Nr_Acesso.HasValue && filtro.Nr_Acesso.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Acesso = {filtro.Nr_Acesso}");
			}

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Contribuinte = {filtro.Cd_Contribuinte}");
			}

			if (filtro.Dt_Cadastro.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Cadastro = {filtro.Dt_Cadastro}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Usuario {MontarCampoString(filtro.Ds_Usuario)}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issUsuarioWebRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSUsuarioWeb SET campo = 'valor' WHERE pk = 666";

            return await _issUsuarioWebRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
