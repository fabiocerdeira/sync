﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class CecamImpostoQuery : QueryBase, ICecamImpostoQuery
    {
        protected readonly ICecamImpostoRepository _cecamImpostoRepositorio;


        public CecamImpostoQuery(ICecamImpostoRepository cecamImpostoRepositorio)
        {
            _cecamImpostoRepositorio = cecamImpostoRepositorio;
        }


        public async Task<List<CecamImpostoEntity>> Listar(CecamImpostoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _cecamImpostoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Imposto.HasValue)
				consulta = consulta.Where(x => x.Cd_Imposto == filtro.Cd_Imposto.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_Imposto))
				consulta = consulta.Where(x => x.Sg_Imposto == filtro.Sg_Imposto);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Imposto))
				consulta = consulta.Where(x => x.Ds_Imposto == filtro.Ds_Imposto);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<CecamImpostoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<CecamImpostoEntity>> ListarSQL(CecamImpostoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM CecamImpostos WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Imposto.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Imposto {MontarCampoString(filtro.Cd_Imposto.GetValueOrDefault().ToString())}");
            }

			if (!string.IsNullOrWhiteSpace(filtro.Sg_Imposto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_Imposto {MontarCampoString(filtro.Sg_Imposto)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Imposto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Imposto {MontarCampoString(filtro.Ds_Imposto)}");
			}

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _cecamImpostoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE CecamImpostos SET campo = 'valor' WHERE pk = 666";

            return await _cecamImpostoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
