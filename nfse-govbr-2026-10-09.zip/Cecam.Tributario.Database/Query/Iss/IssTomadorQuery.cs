﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssTomadorQuery : QueryBase, IIssTomadorQuery
    {
        protected readonly IIssTomadorRepository _issTomadorRepositorio;


        public IssTomadorQuery(IIssTomadorRepository issTomadorRepositorio)
        {
            _issTomadorRepositorio = issTomadorRepositorio;
        }


        public async Task<IssTomadorEntity?> PrimeiroOuNull(IssTomadorFilter filtro)
		{
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }



        public async Task<List<IssTomadorEntity>> Listar(IssTomadorFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issTomadorRepositorio.GetIQueryable();

            #region PK

            if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
				consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF);

            if (!string.IsNullOrWhiteSpace(filtro.Cd_Usuario))
                consulta = consulta.Where(x => x.Cd_Usuario == filtro.Cd_Usuario);

            #endregion

            #region Propriedades

            if (!string.IsNullOrWhiteSpace(filtro.Ds_inscricao_municipal))
                consulta = consulta.Where(x => x.Ds_inscricao_municipal == filtro.Ds_inscricao_municipal);

            if (filtro.Cd_Tomador.HasValue && filtro.Cd_Tomador.Value > 0)
                consulta = consulta.Where(x => x.Cd_Tomador == filtro.Cd_Tomador.Value);

            if (filtro.Cd_MunicipioTomador.HasValue && filtro.Cd_MunicipioTomador.Value > 0)
                consulta = consulta.Where(x => x.Cd_MunicipioTomador == filtro.Cd_MunicipioTomador.Value);

            if (!string.IsNullOrWhiteSpace(filtro.Sg_UF))
                consulta = consulta.Where(x => x.Sg_UF == filtro.Sg_UF);


            /*
			if (!string.IsNullOrWhiteSpace(filtro.Ds_RazaoSocial))
				consulta = consulta.Where(x => x.Ds_RazaoSocial == filtro.Ds_RazaoSocial);

			if (filtro.Fl_TipoPessoa.HasValue && filtro.Fl_TipoPessoa.Value > 0)
				consulta = consulta.Where(x => x.Fl_TipoPessoa == filtro.Fl_TipoPessoa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Logradouro))
				consulta = consulta.Where(x => x.Ds_Logradouro == filtro.Ds_Logradouro);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Numero))
				consulta = consulta.Where(x => x.Cd_Numero == filtro.Cd_Numero);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Complemento))
				consulta = consulta.Where(x => x.Ds_Complemento == filtro.Ds_Complemento);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Bairro))
				consulta = consulta.Where(x => x.Ds_Bairro == filtro.Ds_Bairro);

			if (filtro.Dt_Atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Atualizacao == filtro.Dt_Atualizacao.Value);


			if (!string.IsNullOrWhiteSpace(filtro.Ds_Email))
				consulta = consulta.Where(x => x.Ds_Email == filtro.Ds_Email);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CEP))
				consulta = consulta.Where(x => x.Cd_CEP == filtro.Cd_CEP);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_RG_IE))
				consulta = consulta.Where(x => x.Cd_RG_IE == filtro.Cd_RG_IE);

			if (filtro.Cd_TipoCalculo.HasValue && filtro.Cd_TipoCalculo.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoCalculo == filtro.Cd_TipoCalculo.Value);
			*/


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssTomadorEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssTomadorEntity>> ListarSQL(IssTomadorFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssTomador WITH(NOLOCK) ");

            #region PK

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF {MontarCampoString(filtro.Nr_CGCCPF)}");
			}

            if (!string.IsNullOrWhiteSpace(filtro.Cd_Usuario))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Cd_Usuario {MontarCampoString(filtro.Cd_Usuario)}");
            }

            #endregion

            #region Propriedades

            if (!string.IsNullOrWhiteSpace(filtro.Ds_inscricao_municipal))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Ds_inscricao_municipal {MontarCampoString(filtro.Ds_inscricao_municipal)}");
            }

            if (filtro.Cd_Tomador.HasValue && filtro.Cd_Tomador.Value > 0)
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Cd_Tomador = {filtro.Cd_Tomador}");
            }

            if (filtro.Cd_MunicipioTomador.HasValue && filtro.Cd_MunicipioTomador.Value > 0)
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Cd_MunicipioTomador = {filtro.Cd_MunicipioTomador}");
            }

            if (!string.IsNullOrWhiteSpace(filtro.Sg_UF))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Sg_UF {MontarCampoString(filtro.Sg_UF)}");
            }


            /*
			if (!string.IsNullOrWhiteSpace(filtro.Ds_RazaoSocial))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_RazaoSocial = '{filtro.Ds_RazaoSocial.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_TipoPessoa.HasValue && filtro.Fl_TipoPessoa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_TipoPessoa = {filtro.Fl_TipoPessoa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Logradouro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Logradouro = '{filtro.Ds_Logradouro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Numero))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Numero = '{filtro.Cd_Numero.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Complemento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Complemento = '{filtro.Ds_Complemento.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Bairro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Bairro = '{filtro.Ds_Bairro.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_Atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Atualizacao = {filtro.Dt_Atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Email))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Email = '{filtro.Ds_Email.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CEP))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_CEP = '{filtro.Cd_CEP.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_RG_IE))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_RG_IE = '{filtro.Cd_RG_IE.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_TipoCalculo.HasValue && filtro.Cd_TipoCalculo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoCalculo = {filtro.Cd_TipoCalculo}");
			}
			*/


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issTomadorRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE IssTomador SET campo = 'valor' WHERE pk = 666";

            return await _issTomadorRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
