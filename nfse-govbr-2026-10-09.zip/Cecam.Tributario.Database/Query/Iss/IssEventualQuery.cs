﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssEventualQuery : QueryBase, IIssEventualQuery
    {
        protected readonly IIssEventualRepository _issEventualRepositorio;


        public IssEventualQuery(IIssEventualRepository issEventualRepositorio)
        {
            _issEventualRepositorio = issEventualRepositorio;
        }


        public async Task<IssEventualEntity?> PrimeiroOuNull(IssEventualFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssEventualEntity>> Listar(IssEventualFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issEventualRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Eventual.HasValue && filtro.Cd_Eventual.Value > 0)
				consulta = consulta.Where(x => x.Cd_Eventual == filtro.Cd_Eventual.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_RazaoSocial))
				consulta = consulta.Where(x => x.Ds_Razaosocial == filtro.Ds_RazaoSocial);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
				consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EnderTributario))
				consulta = consulta.Where(x => x.Ds_EnderTributario == filtro.Ds_EnderTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_BairroTributario))
				consulta = consulta.Where(x => x.Ds_BairroTributario == filtro.Ds_BairroTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_CidadeTributario))
				consulta = consulta.Where(x => x.Ds_CidadeTributario == filtro.Ds_CidadeTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CepTributario))
				consulta = consulta.Where(x => x.Cd_CepTributario == filtro.Cd_CepTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EnderCorr))
				consulta = consulta.Where(x => x.Ds_EnderCorr == filtro.Ds_EnderCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ComplCorr))
				consulta = consulta.Where(x => x.Ds_ComplCorr == filtro.Ds_ComplCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_BairroCorr))
				consulta = consulta.Where(x => x.Ds_BairroCorr == filtro.Ds_BairroCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_CidadeCorr))
				consulta = consulta.Where(x => x.Ds_CidadeCorr == filtro.Ds_CidadeCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CepCorr))
				consulta = consulta.Where(x => x.Cd_CepCorr == filtro.Cd_CepCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_EstadoCorr))
				consulta = consulta.Where(x => x.Sg_EstadoCorr == filtro.Sg_EstadoCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Item_Atividade))
				consulta = consulta.Where(x => x.Ds_Item_Atividade == filtro.Ds_Item_Atividade);

			if (filtro.Fl_web.HasValue && filtro.Fl_web.Value > 0)
				consulta = consulta.Where(x => x.Fl_web == filtro.Fl_web.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_RG_IE))
				consulta = consulta.Where(x => x.Cd_RG_IE == filtro.Cd_RG_IE);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_EstadoTributario))
				consulta = consulta.Where(x => x.Sg_EstadoTributario == filtro.Sg_EstadoTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneTributario))
				consulta = consulta.Where(x => x.Cd_TelefoneTributario == filtro.Cd_TelefoneTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_FAXTributario))
				consulta = consulta.Where(x => x.Cd_FAXTributario == filtro.Cd_FAXTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Email))
				consulta = consulta.Where(x => x.Ds_Email == filtro.Ds_Email);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Contato))
				consulta = consulta.Where(x => x.Nm_Contato == filtro.Nm_Contato);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_ResponsavelCadastroWeb))
				consulta = consulta.Where(x => x.Nm_ResponsavelCadastroWeb == filtro.Nm_ResponsavelCadastroWeb);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ResponsavelCadastroWebCPF))
				consulta = consulta.Where(x => x.Nr_ResponsavelCadastroWebCPF == filtro.Nr_ResponsavelCadastroWebCPF);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ResponsavelCadastroWebRG))
				consulta = consulta.Where(x => x.Nr_ResponsavelCadastroWebRG == filtro.Nr_ResponsavelCadastroWebRG);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ResponsavelCadastroWebEmail))
				consulta = consulta.Where(x => x.Ds_ResponsavelCadastroWebEmail == filtro.Ds_ResponsavelCadastroWebEmail);

			if (filtro.Cd_Grupo_Atividade.HasValue && filtro.Cd_Grupo_Atividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_Grupo_Atividade == filtro.Cd_Grupo_Atividade.Value);

			if (filtro.Cd_Sub_Grupo_Atividade.HasValue && filtro.Cd_Sub_Grupo_Atividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_Sub_Grupo_Atividade == filtro.Cd_Sub_Grupo_Atividade.Value);

			if (filtro.Cd_Item_Atividade.HasValue && filtro.Cd_Item_Atividade.Value > 0)
				consulta = consulta.Where(x => x.Cd_Item_Atividade == filtro.Cd_Item_Atividade.Value);

			if (filtro.Dt_Criacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Criacao == filtro.Dt_Criacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_UsuarioCriacao))
				consulta = consulta.Where(x => x.Nm_UsuarioCriacao == filtro.Nm_UsuarioCriacao);

			if (filtro.Fl_CadastroOBRAS.HasValue && filtro.Fl_CadastroOBRAS.Value > 0)
				consulta = consulta.Where(x => x.Fl_CadastroOBRAS == filtro.Fl_CadastroOBRAS.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Inscricao_Municipal))
				consulta = consulta.Where(x => x.Ds_Inscricao_Municipal == filtro.Ds_Inscricao_Municipal);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Inscricao_Estadual))
				consulta = consulta.Where(x => x.Ds_Inscricao_Estadual == filtro.Ds_Inscricao_Estadual);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ComplTributario))
				consulta = consulta.Where(x => x.Ds_ComplTributario == filtro.Ds_ComplTributario);

			if (filtro.Fl_IgnorarISSWEB.HasValue && filtro.Fl_IgnorarISSWEB.Value > 0)
				consulta = consulta.Where(x => x.Fl_IgnorarISSWEB == filtro.Fl_IgnorarISSWEB.Value);

			if (filtro.Dt_Atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Atualizacao == filtro.Dt_Atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_UsuarioAtualizacao))
				consulta = consulta.Where(x => x.Nm_UsuarioAtualizacao == filtro.Nm_UsuarioAtualizacao);

			if (filtro.Fl_IncentivoFiscal.HasValue && filtro.Fl_IncentivoFiscal.Value > 0)
				consulta = consulta.Where(x => x.Fl_IncentivoFiscal == filtro.Fl_IncentivoFiscal.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Registro))
				consulta = consulta.Where(x => x.Nr_Registro == filtro.Nr_Registro);

			if (filtro.Cd_Conselho_Regional.HasValue && filtro.Cd_Conselho_Regional.Value > 0)
				consulta = consulta.Where(x => x.Cd_Conselho_Regional == filtro.Cd_Conselho_Regional.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Registro_Conselho))
				consulta = consulta.Where(x => x.Ds_Registro_Conselho == filtro.Ds_Registro_Conselho);

			if (filtro.Cd_TipoCalculo.HasValue && filtro.Cd_TipoCalculo.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoCalculo == filtro.Cd_TipoCalculo.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_NumeroTributario))
				consulta = consulta.Where(x => x.Cd_NumeroTributario == filtro.Cd_NumeroTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_NumeroCorr))
				consulta = consulta.Where(x => x.Cd_NumeroCorr == filtro.Cd_NumeroCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EmailTributario))
				consulta = consulta.Where(x => x.Ds_EmailTributario == filtro.Ds_EmailTributario);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EmailCorr))
				consulta = consulta.Where(x => x.Ds_EmailCorr == filtro.Ds_EmailCorr);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneCorr))
				consulta = consulta.Where(x => x.Cd_TelefoneCorr == filtro.Cd_TelefoneCorr);


            #endregion


            #region Relacionamentos
            #endregion


            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssEventualEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssEventualEntity>> ListarSQL(IssEventualFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssEventual WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Eventual.HasValue && filtro.Cd_Eventual.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Eventual = {filtro.Cd_Eventual}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_RazaoSocial))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_razaosocial {MontarCampoString(filtro.Ds_RazaoSocial)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF {MontarCampoString(filtro.Nr_CGCCPF)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EnderTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_EnderTributario {MontarCampoString(filtro.Ds_EnderTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_BairroTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_bairroTributario {MontarCampoString(filtro.Ds_BairroTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_CidadeTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_cidadeTributario {MontarCampoString(filtro.Ds_CidadeTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CepTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_cepTributario {MontarCampoString(filtro.Cd_CepTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EnderCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_EnderCorr {MontarCampoString(filtro.Ds_EnderCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ComplCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_complcorr {MontarCampoString(filtro.Ds_ComplCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_BairroCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_bairrocorr {MontarCampoString(filtro.Ds_BairroCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_CidadeCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_cidadecorr {MontarCampoString(filtro.Ds_CidadeCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CepCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_cepcorr {MontarCampoString(filtro.Cd_CepCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_EstadoCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_estadocorr {MontarCampoString(filtro.Sg_EstadoCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Item_Atividade))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_item_atividade {MontarCampoString(filtro.Ds_Item_Atividade)}");
			}

			if (filtro.Fl_web.HasValue && filtro.Fl_web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_web = {filtro.Fl_web}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_RG_IE))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_RG_IE {MontarCampoString(filtro.Cd_RG_IE)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_EstadoTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_EstadoTributario {MontarCampoString(filtro.Sg_EstadoTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TelefoneTributario {MontarCampoString(filtro.Cd_TelefoneTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_FAXTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_FAXTributario {MontarCampoString(filtro.Cd_FAXTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Email))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Email {MontarCampoString(filtro.Ds_Email)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Contato))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Contato {MontarCampoString(filtro.Nm_Contato)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_ResponsavelCadastroWeb))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_ResponsavelCadastroWeb {MontarCampoString(filtro.Nm_ResponsavelCadastroWeb)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ResponsavelCadastroWebCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ResponsavelCadastroWebCPF {MontarCampoString(filtro.Nr_ResponsavelCadastroWebCPF)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ResponsavelCadastroWebRG))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ResponsavelCadastroWebRG {MontarCampoString(filtro.Nr_ResponsavelCadastroWebRG)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ResponsavelCadastroWebEmail))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ResponsavelCadastroWebEmail {MontarCampoString(filtro.Ds_ResponsavelCadastroWebEmail)}");
			}

			if (filtro.Cd_Grupo_Atividade.HasValue && filtro.Cd_Grupo_Atividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_grupo_atividade = {filtro.Cd_Grupo_Atividade}");
			}

			if (filtro.Cd_Sub_Grupo_Atividade.HasValue && filtro.Cd_Sub_Grupo_Atividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_sub_grupo_atividade = {filtro.Cd_Sub_Grupo_Atividade}");
			}

			if (filtro.Cd_Item_Atividade.HasValue && filtro.Cd_Item_Atividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_item_atividade = {filtro.Cd_Item_Atividade}");
			}

			if (filtro.Dt_Criacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Criacao = {filtro.Dt_Criacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_UsuarioCriacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_UsuarioCriacao {MontarCampoString(filtro.Nm_UsuarioCriacao)}");
			}

			if (filtro.Fl_CadastroOBRAS.HasValue && filtro.Fl_CadastroOBRAS.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_CadastroOBRAS = {filtro.Fl_CadastroOBRAS}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Inscricao_Municipal))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_inscricao_municipal {MontarCampoString(filtro.Ds_Inscricao_Municipal)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Inscricao_Estadual))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_inscricao_estadual {MontarCampoString(filtro.Ds_Inscricao_Estadual)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ComplTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_complTributario {MontarCampoString(filtro.Ds_ComplTributario)}");
			}

			if (filtro.Fl_IgnorarISSWEB.HasValue && filtro.Fl_IgnorarISSWEB.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_IgnorarISSWEB = {filtro.Fl_IgnorarISSWEB}");
			}

			if (filtro.Dt_Atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Atualizacao = {filtro.Dt_Atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_UsuarioAtualizacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_UsuarioAtualizacao {MontarCampoString(filtro.Nm_UsuarioAtualizacao)}");
			}

			if (filtro.Fl_IncentivoFiscal.HasValue && filtro.Fl_IncentivoFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_IncentivoFiscal = {filtro.Fl_IncentivoFiscal}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Registro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Registro {MontarCampoString(filtro.Nr_Registro)}");
			}

			if (filtro.Cd_Conselho_Regional.HasValue && filtro.Cd_Conselho_Regional.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Conselho_Regional = {filtro.Cd_Conselho_Regional}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Registro_Conselho))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Registro_Conselho {MontarCampoString(filtro.Ds_Registro_Conselho)}");
			}

			if (filtro.Cd_TipoCalculo.HasValue && filtro.Cd_TipoCalculo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoCalculo = {filtro.Cd_TipoCalculo}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_NumeroTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NumeroTributario {MontarCampoString(filtro.Cd_NumeroTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_NumeroCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NumeroCorr {MontarCampoString(filtro.Cd_NumeroCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EmailTributario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_EmailTributario {MontarCampoString(filtro.Ds_EmailTributario)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_EmailCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_EmailCorr {MontarCampoString(filtro.Ds_EmailCorr)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_TelefoneCorr))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TelefoneCorr {MontarCampoString(filtro.Cd_TelefoneCorr)}");
			}


            #endregion


            #region Relacionamentos
            #endregion


            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issEventualRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE IssEventual SET campo = 'valor' WHERE pk = 666";

            return await _issEventualRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
