﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssComunicadoWebQuery : QueryBase, IIssComunicadoWebQuery
    {
        protected readonly IIssComunicadoWebRepository _issComunicadoWebRepositorio;


        public IssComunicadoWebQuery(IIssComunicadoWebRepository issComunicadoWebRepositorio)
        {
            _issComunicadoWebRepositorio = issComunicadoWebRepositorio;
        }


        public async Task<List<IssComunicadoWebEntity>> Listar(IssComunicadoWebFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issComunicadoWebRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Comunicado.HasValue && filtro.Cd_Comunicado.Value > 0)
				consulta = consulta.Where(x => x.Cd_Comunicado == filtro.Cd_Comunicado.Value);

			if (filtro.Dt_Criacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Criacao == filtro.Dt_Criacao.Value);

			if (filtro.Dt_Validade.HasValue)
				consulta = consulta.Where(x => x.Dt_Validade == filtro.Dt_Validade.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Titulo))
				consulta = consulta.Where(x => x.Ds_Titulo == filtro.Ds_Titulo);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Assunto))
				consulta = consulta.Where(x => x.Ds_Assunto == filtro.Ds_Assunto);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Anexo))
				consulta = consulta.Where(x => x.Ds_Anexo == filtro.Ds_Anexo);

			if (filtro.Fl_Especifico.HasValue && filtro.Fl_Especifico.Value > 0)
				consulta = consulta.Where(x => x.Fl_Especifico == filtro.Fl_Especifico.Value);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssComunicadoWebEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssComunicadoWebEntity>> ListarSQL(IssComunicadoWebFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSComunicadoWeb WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Comunicado.HasValue && filtro.Cd_Comunicado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Comunicado = {filtro.Cd_Comunicado}");
			}

			if (filtro.Dt_Criacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Criacao = {filtro.Dt_Criacao}");
			}

			if (filtro.Dt_Validade.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Validade = {filtro.Dt_Validade}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Titulo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Titulo {MontarCampoString(filtro.Ds_Titulo)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Assunto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Assunto {MontarCampoString(filtro.Ds_Assunto)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Anexo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Anexo {MontarCampoString(filtro.Ds_Anexo)}");
			}

			if (filtro.Fl_Especifico.HasValue && filtro.Fl_Especifico.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Especifico = {filtro.Fl_Especifico}");
			}

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issComunicadoWebRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSComunicadoWeb SET campo = 'valor' WHERE pk = 666";

            return await _issComunicadoWebRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
