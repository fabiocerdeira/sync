﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Filter.Iss;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Iss
{
    public class IssComunicadoUsuarioWebQuery : QueryBase, IIssComunicadoUsuarioWebQuery
    {
        protected readonly IIssComunicadoUsuarioWebRepository _issComunicadoUsuarioWebRepositorio;


        public IssComunicadoUsuarioWebQuery(IIssComunicadoUsuarioWebRepository issComunicadoUsuarioWebRepositorio)
        {
            _issComunicadoUsuarioWebRepositorio = issComunicadoUsuarioWebRepositorio;
        }


        public async Task<List<IssComunicadoUsuarioWebEntity>> Listar(IssComunicadoUsuarioWebFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issComunicadoUsuarioWebRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Comunicado.HasValue && filtro.Cd_Comunicado.Value > 0)
				consulta = consulta.Where(x => x.Cd_Comunicado == filtro.Cd_Comunicado.Value);

			if (filtro.Nr_CGCCPF.HasValue && filtro.Nr_CGCCPF.Value > 0)
				consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF.Value);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssComunicadoUsuarioWebEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssComunicadoUsuarioWebEntity>> ListarSQL(IssComunicadoUsuarioWebFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSComunicadoUsuarioWeb WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Comunicado.HasValue && filtro.Cd_Comunicado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Comunicado = {filtro.Cd_Comunicado}");
			}

			if (filtro.Nr_CGCCPF.HasValue && filtro.Nr_CGCCPF.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF = {filtro.Nr_CGCCPF}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issComunicadoUsuarioWebRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSComunicadoUsuarioWeb SET campo = 'valor' WHERE pk = 666";

            return await _issComunicadoUsuarioWebRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
