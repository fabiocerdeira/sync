﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscal
{
    public class IssNotaFiscalRejeicaoQuery : QueryBase, IIssNotaFiscalRejeicaoQuery
    {
        protected readonly IIssNotaFiscalRejeicaoRepository _issNotaFiscalRejeicaoRepositorio;


        public IssNotaFiscalRejeicaoQuery(IIssNotaFiscalRejeicaoRepository issNotaFiscalRejeicaoRepositorio)
        {
            _issNotaFiscalRejeicaoRepositorio = issNotaFiscalRejeicaoRepositorio;
        }


        public async Task<List<IssNotaFiscalRejeicaoEntity>> Listar(IssNotaFiscalRejeicaoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issNotaFiscalRejeicaoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Rejeicao))
				consulta = consulta.Where(x => x.Ds_Rejeicao == filtro.Ds_Rejeicao);

			if (filtro.Dt_AceitoRejeitado.HasValue)
				consulta = consulta.Where(x => x.Dt_AceitoRejeitado == filtro.Dt_AceitoRejeitado.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AceitoRejeitado))
				consulta = consulta.Where(x => x.Fl_AceitoRejeitado == filtro.Fl_AceitoRejeitado);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalRejeicaoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalRejeicaoEntity>> ListarSQL(IssNotaFiscalRejeicaoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscalRejeicao WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Rejeicao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Rejeicao {MontarCampoString(filtro.Ds_Rejeicao)}");
			}

			if (filtro.Dt_AceitoRejeitado.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_AceitoRejeitado = {filtro.Dt_AceitoRejeitado}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AceitoRejeitado))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AceitoRejeitado {MontarCampoString(filtro.Fl_AceitoRejeitado)}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalRejeicaoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSNotaFiscalRejeicao SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalRejeicaoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
