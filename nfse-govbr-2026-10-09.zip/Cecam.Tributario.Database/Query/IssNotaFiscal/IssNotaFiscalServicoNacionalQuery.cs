﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscal
{
    public class IssNotaFiscalServicoNacionalQuery : QueryBase, IIssNotaFiscalServicoNacionalQuery
    {
        protected readonly IIssNotaFiscalServicoNacionalRepository _issNotaFiscalServicoNacionalRepositorio;


        public IssNotaFiscalServicoNacionalQuery(IIssNotaFiscalServicoNacionalRepository issNotaFiscalServicoNacionalRepositorio)
        {
            _issNotaFiscalServicoNacionalRepositorio = issNotaFiscalServicoNacionalRepositorio;
        }


        public async Task<IssNotaFiscalServicoNacionalEntity?> PrimeiroOuNull(IssNotaFiscalServicoNacionalFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssNotaFiscalServicoNacionalEntity>> Listar(IssNotaFiscalServicoNacionalFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issNotaFiscalServicoNacionalRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_tributacaoNacional))
				consulta = consulta.Where(x => x.Cd_tributacaoNacional == filtro.Cd_tributacaoNacional);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Item))
				consulta = consulta.Where(x => x.Cd_Item == filtro.Cd_Item);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_subItem))
				consulta = consulta.Where(x => x.Cd_subItem == filtro.Cd_subItem);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Desdobro))
				consulta = consulta.Where(x => x.Cd_Desdobro == filtro.Cd_Desdobro);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_servicoDescricao))
				consulta = consulta.Where(x => x.Ds_servicoDescricao == filtro.Ds_servicoDescricao);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalServicoNacionalEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalServicoNacionalEntity>> ListarSQL(IssNotaFiscalServicoNacionalFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISS_NFSE_ListaServicoNacional WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_tributacaoNacional))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_tributacaoNacional = '{filtro.Cd_tributacaoNacional.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Item))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Item = '{filtro.Cd_Item.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_subItem))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_subItem = '{filtro.Cd_subItem.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Desdobro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Desdobro = '{filtro.Cd_Desdobro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_servicoDescricao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_servicoDescricao = '{filtro.Ds_servicoDescricao.Trim().Replace("\'","")}'");
			}

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalServicoNacionalRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISS_NFSE_ListaServicoNacional SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalServicoNacionalRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
