﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscal
{
    public class IssNotaFiscalServicoVinculoQuery : QueryBase, IIssNotaFiscalServicoVinculoQuery
    {
        protected readonly IIssNotaFiscalServicoVinculoRepository _issNotaFiscalServicoVinculoRepositorio;


        public IssNotaFiscalServicoVinculoQuery(IIssNotaFiscalServicoVinculoRepository issNotaFiscalServicoVinculoRepositorio)
        {
            _issNotaFiscalServicoVinculoRepositorio = issNotaFiscalServicoVinculoRepositorio;
        }


        public async Task<IssNotaFiscalServicoVinculoEntity?> PrimeiroOuNull(IssNotaFiscalServicoVinculoFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssNotaFiscalServicoVinculoEntity>> Listar(IssNotaFiscalServicoVinculoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issNotaFiscalServicoVinculoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
				consulta = consulta.Where(x => x.Cd_Servico == filtro.Cd_Servico);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_tributacaoNacional))
				consulta = consulta.Where(x => x.Cd_tributacaoNacional == filtro.Cd_tributacaoNacional);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_nbs))
				consulta = consulta.Where(x => x.Cd_nbs == filtro.Cd_nbs);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalServicoVinculoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalServicoVinculoEntity>> ListarSQL(IssNotaFiscalServicoVinculoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSServicos_Vinculos WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Servico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Servico {MontarCampoString(filtro.Cd_Servico)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_tributacaoNacional))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_tributacaoNacional {MontarCampoString(filtro.Cd_tributacaoNacional)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_nbs))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_nbs {MontarCampoString(filtro.Cd_nbs)}");
			}

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalServicoVinculoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSServicos_Vinculos SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalServicoVinculoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
