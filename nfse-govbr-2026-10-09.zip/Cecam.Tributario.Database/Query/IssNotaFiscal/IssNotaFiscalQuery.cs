﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Enumerado.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscal
{
    public class IssNotaFiscalQuery : QueryBase, IIssNotaFiscalQuery
    {
        #region Declarações


        protected readonly IIssNotaFiscalRepository _issNotaFiscalRepositorio;

		
		/// <summary>
		/// Repositorio 
		/// </summary>
		public IIssNotaFiscalRepository Repositorio => _issNotaFiscalRepositorio;



        public IssNotaFiscalQuery(IIssNotaFiscalRepository issNotaFiscalRepositorio)
        {
            _issNotaFiscalRepositorio = issNotaFiscalRepositorio;
        }


        #endregion


        /// <summary>
        /// Carregar somente uma nota fiscal e seus filhos
        /// </summary>
        public async Task<IssNotaFiscalEntity?> PrimeiroOuNull(IssNotaFiscalFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


		/// <summary>
		/// Carregar uma lista de notas fiscais
		/// </summary>
        public async Task<List<IssNotaFiscalEntity>> Listar(IssNotaFiscalFilter filtro)
        {
            var consulta = _issNotaFiscalRepositorio.GetIQueryable();

            #region Propriedades

            if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

			if (filtro.Cd_Referencia.HasValue && filtro.Cd_Referencia.Value > 0)
				consulta = consulta.Where(x => x.Cd_Referencia == filtro.Cd_Referencia.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
				consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF);

			if (!string.IsNullOrWhiteSpace(filtro.Govbr_ChaveAcesso))
				consulta = consulta.Where(x => x.Govbr_ChaveAcesso == filtro.Govbr_ChaveAcesso);

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFTomador))
                consulta = consulta.Where(x => x.Nr_CGCCPFTomador == filtro.Nr_CGCCPFTomador);

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFTomadorIntermediario))
                consulta = consulta.Where(x => x.Nr_CGCCPFTomadorIntermediario == filtro.Nr_CGCCPFTomadorIntermediario);

			if (filtro.NrChaveValidacaoPreenchido.HasValue)
			{
				if (filtro.NrChaveValidacaoPreenchido.Value == true)
                    consulta = consulta.Where(x => !string.IsNullOrWhiteSpace(x.Nr_ChaveValidacao));
				else
                    consulta = consulta.Where(x => string.IsNullOrWhiteSpace(x.Nr_ChaveValidacao));
            }


            #region Campos ainda não usados

            /*
			if (filtro.Cd_TipoDocumento.HasValue && filtro.Cd_TipoDocumento.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoDocumento == filtro.Cd_TipoDocumento.Value);

			if (filtro.Nr_NotaFiscal.HasValue && filtro.Nr_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Nr_NotaFiscal == filtro.Nr_NotaFiscal.Value);

			if (filtro.Cd_Situacao.HasValue && filtro.Cd_Situacao.Value > 0)
				consulta = consulta.Where(x => x.Cd_Situacao == filtro.Cd_Situacao.Value);

			if (filtro.Dt_Emissao.HasValue)
				consulta = consulta.Where(x => x.Dt_Emissao == filtro.Dt_Emissao.Value);


			if (!string.IsNullOrWhiteSpace(filtro.Ds_Observacao))
				consulta = consulta.Where(x => x.Ds_Observacao == filtro.Ds_Observacao);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioCriacao))
				consulta = consulta.Where(x => x.Nr_CGCCPFUsuarioCriacao == filtro.Nr_CGCCPFUsuarioCriacao);

			if (filtro.Dt_Criacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Criacao == filtro.Dt_Criacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioAtualizacao))
				consulta = consulta.Where(x => x.Nr_CGCCPFUsuarioAtualizacao == filtro.Nr_CGCCPFUsuarioAtualizacao);

			if (filtro.Dt_Atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Atualizacao == filtro.Dt_Atualizacao.Value);

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
				consulta = consulta.Where(x => x.Nr_Certificado == filtro.Nr_Certificado.Value);

			if (filtro.Nr_NotaFiscalSubstituta.HasValue && filtro.Nr_NotaFiscalSubstituta.Value > 0)
				consulta = consulta.Where(x => x.Nr_NotaFiscalSubstituta == filtro.Nr_NotaFiscalSubstituta.Value);

			if (filtro.Fl_LocalPrestacao.HasValue && filtro.Fl_LocalPrestacao.Value > 0)
				consulta = consulta.Where(x => x.Fl_LocalPrestacao == filtro.Fl_LocalPrestacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_LocalPrestacao))
				consulta = consulta.Where(x => x.Ds_LocalPrestacao == filtro.Ds_LocalPrestacao);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_LocalPrestacaoCompl))
				consulta = consulta.Where(x => x.Ds_LocalPrestacaoCompl == filtro.Ds_LocalPrestacaoCompl);

			if (filtro.Cd_Imovel.HasValue && filtro.Cd_Imovel.Value > 0)
				consulta = consulta.Where(x => x.Cd_Imovel == filtro.Cd_Imovel.Value);

			if (filtro.Cd_CidadePrestacao.HasValue && filtro.Cd_CidadePrestacao.Value > 0)
				consulta = consulta.Where(x => x.Cd_CidadePrestacao == filtro.Cd_CidadePrestacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Logradouro))
				consulta = consulta.Where(x => x.Nm_Logradouro == filtro.Nm_Logradouro);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Numero))
				consulta = consulta.Where(x => x.Nr_Numero == filtro.Nr_Numero);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Complemento))
				consulta = consulta.Where(x => x.Ds_Complemento == filtro.Ds_Complemento);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Bairro))
				consulta = consulta.Where(x => x.Nm_Bairro == filtro.Nm_Bairro);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CEP))
				consulta = consulta.Where(x => x.Cd_CEP == filtro.Cd_CEP);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Aviso))
				consulta = consulta.Where(x => x.Nr_Aviso == filtro.Nr_Aviso);

			if (filtro.Fl_PrestadorNaoInscrito.HasValue && filtro.Fl_PrestadorNaoInscrito.Value > 0)
				consulta = consulta.Where(x => x.Fl_PrestadorNaoInscrito == filtro.Fl_PrestadorNaoInscrito.Value);

			if (filtro.Fl_Tomador.HasValue && filtro.Fl_Tomador.Value > 0)
				consulta = consulta.Where(x => x.Fl_Tomador == filtro.Fl_Tomador.Value);

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
				consulta = consulta.Where(x => x.Fl_Web == filtro.Fl_Web.Value);

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
				consulta = consulta.Where(x => x.Cd_Contribuinte == filtro.Cd_Contribuinte.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ChaveValidacao))
				consulta = consulta.Where(x => x.Nr_ChaveValidacao == filtro.Nr_ChaveValidacao);

			if (filtro.Cd_RPS.HasValue)
				consulta = consulta.Where(x => x.Cd_RPS == filtro.Cd_RPS.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_MotivoCancelamento))
				consulta = consulta.Where(x => x.Ds_MotivoCancelamento == filtro.Ds_MotivoCancelamento);

			if (filtro.Nr_Lote.HasValue && filtro.Nr_Lote.Value > 0)
				consulta = consulta.Where(x => x.Nr_Lote == filtro.Nr_Lote.Value);

			if (filtro.Cd_PreNota.HasValue && filtro.Cd_PreNota.Value > 0)
				consulta = consulta.Where(x => x.Cd_PreNota == filtro.Cd_PreNota.Value);

			if (filtro.Cd_Tomador.HasValue && filtro.Cd_Tomador.Value > 0)
				consulta = consulta.Where(x => x.Cd_Tomador == filtro.Cd_Tomador.Value);

			if (filtro.Fl_AliquotaLocalPrestacao.HasValue && filtro.Fl_AliquotaLocalPrestacao.Value > 0)
				consulta = consulta.Where(x => x.Fl_AliquotaLocalPrestacao == filtro.Fl_AliquotaLocalPrestacao.Value);

			if (filtro.Cd_TipoCalculo.HasValue && filtro.Cd_TipoCalculo.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoCalculo == filtro.Cd_TipoCalculo.Value);

			if (filtro.Nr_GuiaUnificada.HasValue && filtro.Nr_GuiaUnificada.Value > 0)
				consulta = consulta.Where(x => x.Nr_GuiaUnificada == filtro.Nr_GuiaUnificada.Value);

			if (filtro.Dt_cancelamento.HasValue)
				consulta = consulta.Where(x => x.Dt_cancelamento == filtro.Dt_cancelamento.Value);

			if (filtro.Nr_AliquotaBeneficio.HasValue && filtro.Nr_AliquotaBeneficio.Value > 0)
				consulta = consulta.Where(x => x.Nr_AliquotaBeneficio == filtro.Nr_AliquotaBeneficio.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_DescricaoPercentualImposto))
				consulta = consulta.Where(x => x.Ds_DescricaoPercentualImposto == filtro.Ds_DescricaoPercentualImposto);
			*/

            #endregion


            #endregion


            #region Relacionamentos

            if (filtro.IncluirItens)
				consulta = consulta.Include(x => x.Itens);

			if (filtro.IncluirImpostos)
				consulta = consulta.Include(x => x.Impostos);

			//if (filtro.IncluirTomador)
			//	consulta = consulta.Include(x => x.Tomador);

            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalEntity>> ListarSQL(IssNotaFiscalFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscal WITH(NOLOCK) ");

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
			}

			if (filtro.Cd_Referencia.HasValue && filtro.Cd_Referencia.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Referencia = {filtro.Cd_Referencia}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF {MontarCampoString(filtro.Nr_CGCCPF)}");
			}

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFTomador))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Nr_CGCCPFTomador {MontarCampoString(filtro.Nr_CGCCPFTomador)}");
            }

            if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFTomadorIntermediario))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" nr_CGCCPFTomadorIntermediario {MontarCampoString(filtro.Nr_CGCCPFTomadorIntermediario)}");
            }

            if (!string.IsNullOrWhiteSpace(filtro.Govbr_ChaveAcesso))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Govbr_ChaveAcesso {MontarCampoString(filtro.Govbr_ChaveAcesso)}");
			}

            if (filtro.NrChaveValidacaoPreenchido.HasValue)
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");

                if (filtro.NrChaveValidacaoPreenchido.Value == true)
                    sqlWhere.AppendLine(" ISNULL(Nr_ChaveValidacao,'') = '' ");
                else
                    sqlWhere.AppendLine(" ISNULL(Nr_ChaveValidacao,'') <> '' ");
            }

            #region Outros campos ainda não usados no filtro

            /*
			if (filtro.Cd_TipoDocumento.HasValue && filtro.Cd_TipoDocumento.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoDocumento = {filtro.Cd_TipoDocumento}");
			}

			if (filtro.Nr_NotaFiscal.HasValue && filtro.Nr_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_NotaFiscal = {filtro.Nr_NotaFiscal}");
			}

			if (filtro.Cd_Situacao.HasValue && filtro.Cd_Situacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Situacao = {filtro.Cd_Situacao}");
			}

			if (filtro.Dt_Emissao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Emissao = {filtro.Dt_Emissao}");
			}


			if (!string.IsNullOrWhiteSpace(filtro.Ds_Observacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Observacao = '{filtro.Ds_Observacao.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioCriacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPFUsuarioCriacao = '{filtro.Nr_CGCCPFUsuarioCriacao.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_Criacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Criacao = {filtro.Dt_Criacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioAtualizacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPFUsuarioAtualizacao = '{filtro.Nr_CGCCPFUsuarioAtualizacao.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_Atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Atualizacao = {filtro.Dt_Atualizacao}");
			}

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Certificado = {filtro.Nr_Certificado}");
			}

			if (filtro.Nr_NotaFiscalSubstituta.HasValue && filtro.Nr_NotaFiscalSubstituta.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_NotaFiscalSubstituta = {filtro.Nr_NotaFiscalSubstituta}");
			}

			if (filtro.Fl_LocalPrestacao.HasValue && filtro.Fl_LocalPrestacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_LocalPrestacao = {filtro.Fl_LocalPrestacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_LocalPrestacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_LocalPrestacao = '{filtro.Ds_LocalPrestacao.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_LocalPrestacaoCompl))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_LocalPrestacaoCompl = '{filtro.Ds_LocalPrestacaoCompl.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_Imovel.HasValue && filtro.Cd_Imovel.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Imovel = {filtro.Cd_Imovel}");
			}

			if (filtro.Cd_CidadePrestacao.HasValue && filtro.Cd_CidadePrestacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_CidadePrestacao = {filtro.Cd_CidadePrestacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Logradouro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Logradouro = '{filtro.Nm_Logradouro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Numero))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Numero = '{filtro.Nr_Numero.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Complemento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Complemento = '{filtro.Ds_Complemento.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_Bairro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_Bairro = '{filtro.Nm_Bairro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_CEP))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_CEP = '{filtro.Cd_CEP.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Aviso))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Aviso = '{filtro.Nr_Aviso.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_PrestadorNaoInscrito.HasValue && filtro.Fl_PrestadorNaoInscrito.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_PrestadorNaoInscrito = {filtro.Fl_PrestadorNaoInscrito}");
			}

			if (filtro.Fl_Tomador.HasValue && filtro.Fl_Tomador.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Tomador = {filtro.Fl_Tomador}");
			}

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Web = {filtro.Fl_Web}");
			}

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Contribuinte = {filtro.Cd_Contribuinte}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_ChaveValidacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ChaveValidacao = '{filtro.Nr_ChaveValidacao.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_RPS.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_RPS = '{filtro.Cd_RPS.Value}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_MotivoCancelamento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_MotivoCancelamento = '{filtro.Ds_MotivoCancelamento.Trim().Replace("\'","")}'");
			}

			if (filtro.Nr_Lote.HasValue && filtro.Nr_Lote.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Lote = {filtro.Nr_Lote}");
			}

			if (filtro.Cd_PreNota.HasValue && filtro.Cd_PreNota.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_PreNota = {filtro.Cd_PreNota}");
			}

			if (filtro.Cd_Tomador.HasValue && filtro.Cd_Tomador.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Tomador = {filtro.Cd_Tomador}");
			}

			if (filtro.Fl_AliquotaLocalPrestacao.HasValue && filtro.Fl_AliquotaLocalPrestacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AliquotaLocalPrestacao = {filtro.Fl_AliquotaLocalPrestacao}");
			}

			if (filtro.Cd_TipoCalculo.HasValue && filtro.Cd_TipoCalculo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoCalculo = {filtro.Cd_TipoCalculo}");
			}

			if (filtro.Nr_GuiaUnificada.HasValue && filtro.Nr_GuiaUnificada.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_GuiaUnificada = {filtro.Nr_GuiaUnificada}");
			}

			if (filtro.Dt_cancelamento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_cancelamento = {filtro.Dt_cancelamento}");
			}

			if (filtro.Nr_AliquotaBeneficio.HasValue && filtro.Nr_AliquotaBeneficio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_AliquotaBeneficio = {filtro.Nr_AliquotaBeneficio}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_DescricaoPercentualImposto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_DescricaoPercentualImposto = '{filtro.Ds_DescricaoPercentualImposto.Trim().Replace("\'","")}'");
			}
			*/

            #endregion


            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }



        #region Gov.Br

        /// <summary>
        /// Atualizar na IssNotaFiscal os campos recebidos do gov.br ao criar a nota fiscal no servidor gov.br
        /// </summary>
        public async Task<int> UpdateGovBrCriacaoNotaFiscal(IssNotaFiscalEntity entity)
        {
			string chave = string.IsNullOrWhiteSpace(entity.Govbr_ChaveAcesso) ? "NULL" : "'" + entity.Govbr_ChaveAcesso + "'";

            string nsuEnviar = string.IsNullOrWhiteSpace(entity.GovBr_NsuEnvio) ? "NULL" : "'" + entity.GovBr_NsuEnvio + "'";
            
			string nsuCancelar = string.IsNullOrWhiteSpace(entity.GovBr_NsuCancelamento) ? "NULL" : "'" + entity.GovBr_NsuCancelamento + "'";

            string sql = @$"UPDATE ISSNotaFiscal 
				SET govbr_chaveAcesso = {chave}, 
					govbr_nsuEnvio = {nsuEnviar},
					govbr_nsuCancelamento = {nsuCancelar} 
				WHERE 
					cd_Cecam = {ParametrosGlobal.Cd_Cecam} 
					AND cd_NotaFiscal = {entity.Cd_NotaFiscal}";

            return await _issNotaFiscalRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }


        /// <summary>
        /// Atualizar na IssNotaFiscal a data hora da última consulta aos eventos da NFSe no gov.br
        /// </summary>
        public async Task<int> UpdateGovBrEventoUltimaConsulta(string govbrChaveAcesso)
        {
			if (string.IsNullOrWhiteSpace(govbrChaveAcesso))
				return 0;

            string sql = @$"UPDATE ISSNotaFiscal 
				SET govbr_eventoUltimaConsulta = GETDATE() 
				WHERE 
					cd_Cecam = {ParametrosGlobal.Cd_Cecam} 
					AND govbr_chaveAcesso = '{govbrChaveAcesso.Trim()}'";

            return await _issNotaFiscalRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }


		/// <summary>
		/// Listar a qtd de notas fiscais emitidas erradamente pelo IssWeb e não canceladas
		/// </summary>
        public async Task<Dictionary<int, int>> ListarNfseEmitidasErradamentePeloIssWeb()
        {
			return await _issNotaFiscalRepositorio.GetIQueryable()
				.Where(x => !string.IsNullOrWhiteSpace(x.Nr_ChaveValidacao) &&
					string.IsNullOrWhiteSpace(x.Govbr_ChaveAcesso) &&
					x.Cd_Referencia >= 202601 && 
                    x.Cd_Situacao == (int)IssNotaFiscalEnum.enumCdSituacao.Ativa)
                .OrderByDescending(x => x.Cd_Referencia)
                .GroupBy(x => x.Cd_Referencia)
				.AsNoTracking()
				.Select(x => new { cdReferencia = x.Key, qtd = x.Count() })
				.ToDictionaryAsync(x => x.cdReferencia, x => x.qtd);
        }

        #endregion

    }
}
