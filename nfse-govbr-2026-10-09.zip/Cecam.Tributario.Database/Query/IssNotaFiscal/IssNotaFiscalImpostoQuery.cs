﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Filter.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscal
{
    public class IssNotaFiscalImpostoQuery : QueryBase, IIssNotaFiscalImpostoQuery
    {
        protected readonly IIssNotaFiscalImpostoRepository _issNotaFiscalImpostoRepositorio;


        public IssNotaFiscalImpostoQuery(IIssNotaFiscalImpostoRepository issNotaFiscalImpostoRepositorio)
        {
            _issNotaFiscalImpostoRepositorio = issNotaFiscalImpostoRepositorio;
        }


        public async Task<IssNotaFiscalImpostoEntity?> PrimeiroOuNull(IssNotaFiscalImpostoFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssNotaFiscalImpostoEntity>> Listar(IssNotaFiscalImpostoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issNotaFiscalImpostoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

            if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
                consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

            /*
			if (filtro.Cd_NotaFiscal_Imposto.HasValue)
				consulta = consulta.Where(x => x.Cd_NotaFiscal_Imposto == filtro.Cd_NotaFiscal_Imposto.Value);

            if (filtro.Cd_Imposto.HasValue)
				consulta = consulta.Where(x => x.Cd_Imposto == filtro.Cd_Imposto.Value);

			if (filtro.Vl_imposto.HasValue && filtro.Vl_imposto.Value > 0)
				consulta = consulta.Where(x => x.Vl_imposto == filtro.Vl_imposto.Value);
            */


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalImpostoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalImpostoEntity>> ListarSQL(IssNotaFiscalImpostoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscalImpostos WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

            if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
            }

            /*
            if (filtro.Cd_NotaFiscal_Imposto.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal_Imposto = '{filtro.Cd_NotaFiscal_Imposto.Value}'");
			}

			if (filtro.Cd_Imposto.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Imposto = '{filtro.Cd_Imposto.Value}'");
			}

			if (filtro.Vl_imposto.HasValue && filtro.Vl_imposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_imposto = {filtro.Vl_imposto}");
			}
            */


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalImpostoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSNotaFiscalImpostos SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalImpostoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
