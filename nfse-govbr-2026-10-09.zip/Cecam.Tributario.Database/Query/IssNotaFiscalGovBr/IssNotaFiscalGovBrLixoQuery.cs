﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrLixoQuery : QueryBase, IIssNotaFiscalGovBrLixoQuery
    {
        protected readonly IIssNotaFiscalGovBrLixoRepository _issNotaFiscalGovBrLixoRepositorio;


        public IssNotaFiscalGovBrLixoQuery(IIssNotaFiscalGovBrLixoRepository issNotaFiscalGovBrLixoRepositorio)
        {
            _issNotaFiscalGovBrLixoRepositorio = issNotaFiscalGovBrLixoRepositorio;
        }


        public async Task<IssNotaFiscalGovBrLixoEntity?> PrimeiroOuNull(IssNotaFiscalGovBrLixoFilter filtro)
        {
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssNotaFiscalGovBrLixoEntity>> Listar(IssNotaFiscalGovBrLixoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issNotaFiscalGovBrLixoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
				consulta = consulta.Where(x => x.Id == filtro.Id.Value);

			if (filtro.ValorDecimalA.HasValue && filtro.ValorDecimalA.Value > 0)
				consulta = consulta.Where(x => x.ValorDecimalA == filtro.ValorDecimalA.Value);

			if (filtro.ValorNumericA.HasValue && filtro.ValorNumericA.Value > 0)
				consulta = consulta.Where(x => x.ValorNumericA == filtro.ValorNumericA.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Corpo))
				consulta = consulta.Where(x => x.Corpo == filtro.Corpo);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalGovBrLixoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalGovBrLixoEntity>> ListarSQL(IssNotaFiscalGovBrLixoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscal_GovBr_Lixo WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Id = {filtro.Id}");
			}

			if (filtro.ValorDecimalA.HasValue && filtro.ValorDecimalA.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" ValorDecimalA = {filtro.ValorDecimalA}");
			}

			if (filtro.ValorNumericA.HasValue && filtro.ValorNumericA.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" ValorNumericA = {filtro.ValorNumericA}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Corpo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Corpo {MontarCampoString(filtro.Corpo)}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalGovBrLixoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSNotaFiscal_GovBr_Lixo SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalGovBrLixoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
