﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscalGovBr
{
    public class ISSNotaFiscalGovBrDocArrecadacaoQuery : QueryBase, IISSNotaFiscalGovBrDocArrecadacaoQuery
    {
        protected readonly IISSNotaFiscalGovBrDocArrecadacaoRepository _iSSNotaFiscalGovBrDocArrecadacaoRepositorio;


        public ISSNotaFiscalGovBrDocArrecadacaoQuery(IISSNotaFiscalGovBrDocArrecadacaoRepository iSSNotaFiscalGovBrDocArrecadacaoRepositorio)
        {
            _iSSNotaFiscalGovBrDocArrecadacaoRepositorio = iSSNotaFiscalGovBrDocArrecadacaoRepositorio;
        }


        public async Task<ISSNotaFiscalGovBrDocArrecadacaoEntity?> PrimeiroOuNull(ISSNotaFiscalGovBrDocArrecadacaoFilter filtro)
        {
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<ISSNotaFiscalGovBrDocArrecadacaoEntity>> Listar(ISSNotaFiscalGovBrDocArrecadacaoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _iSSNotaFiscalGovBrDocArrecadacaoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
				consulta = consulta.Where(x => x.Id == filtro.Id.Value);

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_NotaFiscal == filtro.Cd_NotaFiscal.Value);

			if (filtro.Dt_criacao.HasValue)
				consulta = consulta.Where(x => x.Dt_criacao == filtro.Dt_criacao.Value);

			if (filtro.Dt_vencimento.HasValue)
				consulta = consulta.Where(x => x.Dt_vencimento == filtro.Dt_vencimento.Value);

			if (filtro.Dt_cancelamento.HasValue)
				consulta = consulta.Where(x => x.Dt_cancelamento == filtro.Dt_cancelamento.Value);

			if (filtro.Dt_pagamento.HasValue)
				consulta = consulta.Where(x => x.Dt_pagamento == filtro.Dt_pagamento.Value);

			if (filtro.Vl_tributo.HasValue && filtro.Vl_tributo.Value > 0)
				consulta = consulta.Where(x => x.Vl_tributo == filtro.Vl_tributo.Value);

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
				consulta = consulta.Where(x => x.Nr_Certificado == filtro.Nr_Certificado.Value);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<ISSNotaFiscalGovBrDocArrecadacaoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<ISSNotaFiscalGovBrDocArrecadacaoEntity>> ListarSQL(ISSNotaFiscalGovBrDocArrecadacaoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscal_GovBr_DocArrecadacao WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Id = {filtro.Id}");
			}

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_NotaFiscal.HasValue && filtro.Cd_NotaFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NotaFiscal = {filtro.Cd_NotaFiscal}");
			}

			if (filtro.Dt_criacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_criacao = {filtro.Dt_criacao}");
			}

			if (filtro.Dt_vencimento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_vencimento = {filtro.Dt_vencimento}");
			}

			if (filtro.Dt_cancelamento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_cancelamento = {filtro.Dt_cancelamento}");
			}

			if (filtro.Dt_pagamento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_pagamento = {filtro.Dt_pagamento}");
			}

			if (filtro.Vl_tributo.HasValue && filtro.Vl_tributo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_tributo = {filtro.Vl_tributo}");
			}

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Certificado = {filtro.Nr_Certificado}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _iSSNotaFiscalGovBrDocArrecadacaoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSNotaFiscal_GovBr_DocArrecadacao SET campo = 'valor' WHERE pk = 666";

            return await _iSSNotaFiscalGovBrDocArrecadacaoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
