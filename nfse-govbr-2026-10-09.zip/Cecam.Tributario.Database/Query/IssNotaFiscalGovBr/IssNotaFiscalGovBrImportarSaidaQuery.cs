﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrImportarSaidaQuery : QueryBase, IIssNotaFiscalGovBrImportarSaidaQuery
    {
        protected readonly IIssNotaFiscalGovBrImportarSaidaRepository _issNotaFiscalGovBrImportarSaidaRepositorio;


        public IssNotaFiscalGovBrImportarSaidaQuery(IIssNotaFiscalGovBrImportarSaidaRepository issNotaFiscalGovBrImportarSaidaRepositorio)
        {
            _issNotaFiscalGovBrImportarSaidaRepositorio = issNotaFiscalGovBrImportarSaidaRepositorio;
        }


        public async Task<List<IssNotaFiscalGovBrImportarSaidaEntity>> Listar(IssNotaFiscalGovBrImportarSaidaFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issNotaFiscalGovBrImportarSaidaRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
				consulta = consulta.Where(x => x.Id == filtro.Id.Value);

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.FilaTipo.HasValue && filtro.FilaTipo.Value > 0)
				consulta = consulta.Where(x => x.FilaTipo == filtro.FilaTipo.Value);

			if (filtro.Status.HasValue && filtro.Status.Value > 0)
				consulta = consulta.Where(x => x.Status == filtro.Status.Value);

			if (!string.IsNullOrWhiteSpace(filtro.ChaveAcesso))
				consulta = consulta.Where(x => x.ChaveAcesso == filtro.ChaveAcesso);

			if (filtro.Nsu.HasValue)
				consulta = consulta.Where(x => x.Nsu == filtro.Nsu.Value);

			if (!string.IsNullOrWhiteSpace(filtro.NfseId))
				consulta = consulta.Where(x => x.NfseId == filtro.NfseId);

			if (!string.IsNullOrWhiteSpace(filtro.DpsId))
				consulta = consulta.Where(x => x.DpsId == filtro.DpsId);

			/*
			if (filtro.DataHoraDocumento.HasValue)
				consulta = consulta.Where(x => x.DataHoraDocumento == filtro.DataHoraDocumento.Value);
			*/

			if (!string.IsNullOrWhiteSpace(filtro.TipoDocumento))
				consulta = consulta.Where(x => x.TipoDocumento == filtro.TipoDocumento);

			if (!string.IsNullOrWhiteSpace(filtro.TipoEvento))
				consulta = consulta.Where(x => x.TipoEvento == filtro.TipoEvento);

			/*
			if (filtro.DataHoraCriacao.HasValue)
				consulta = consulta.Where(x => x.DataHoraCriacao == filtro.DataHoraCriacao.Value);

			if (filtro.DataHoraProcessamento.HasValue)
				consulta = consulta.Where(x => x.DataHoraProcessamento == filtro.DataHoraProcessamento.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Corpo))
				consulta = consulta.Where(x => x.Corpo == filtro.Corpo);

			if (!string.IsNullOrWhiteSpace(filtro.Mensagem))
				consulta = consulta.Where(x => x.Mensagem == filtro.Mensagem);
			*/

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssNotaFiscalGovBrImportarSaidaEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssNotaFiscalGovBrImportarSaidaEntity>> ListarSQL(IssNotaFiscalGovBrImportarSaidaFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSNotaFiscal_GovBr_ImportarSaida WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Id.HasValue && filtro.Id.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Id = {filtro.Id}");
			}

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.FilaTipo.HasValue && filtro.FilaTipo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" FilaTipo = {filtro.FilaTipo}");
			}

			if (filtro.Status.HasValue && filtro.Status.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Status = {filtro.Status}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.ChaveAcesso))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" ChaveAcesso {MontarCampoString(filtro.ChaveAcesso)}");
			}

			if (filtro.Nsu.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nsu = {filtro.Nsu.Value}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.NfseId))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" NfseId {MontarCampoString(filtro.NfseId)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.DpsId))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" DpsId {MontarCampoString(filtro.DpsId)}");
			}

			/*
			if (filtro.DataHoraDocumento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" DataHoraDocumento = {filtro.DataHoraDocumento}");
			}
			*/

			if (!string.IsNullOrWhiteSpace(filtro.TipoDocumento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" TipoDocumento {MontarCampoString(filtro.TipoDocumento)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.TipoEvento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" TipoEvento {MontarCampoString(filtro.TipoEvento)}");
			}

            /*
			if (filtro.DataHoraCriacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" DataHoraCriacao = {filtro.DataHoraCriacao}");
			}

			if (filtro.DataHoraProcessamento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" DataHoraProcessamento = {filtro.DataHoraProcessamento}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Corpo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Corpo = '{filtro.Corpo.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Mensagem))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Mensagem = '{filtro.Mensagem.Trim().Replace("\'","")}'");
			}
			*/



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issNotaFiscalGovBrImportarSaidaRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSNotaFiscal_GovBr_ImportarSaida SET campo = 'valor' WHERE pk = 666";

            return await _issNotaFiscalGovBrImportarSaidaRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
