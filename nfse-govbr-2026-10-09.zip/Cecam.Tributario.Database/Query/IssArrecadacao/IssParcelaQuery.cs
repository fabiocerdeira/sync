﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.Filter.IssArrecadacao;
using Cecam.Tributario.Database.QueryInterface.IssArrecadacao;
using Cecam.Tributario.Database.RepositoryInterface.IssArrecadacao;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssArrecadacao
{
    public class IssParcelaQuery : QueryBase, IIssParcelaQuery
    {
        protected readonly IIssParcelaRepository _issParcelaRepositorio;


        public IssParcelaQuery(IIssParcelaRepository issParcelaRepositorio)
        {
            _issParcelaRepositorio = issParcelaRepositorio;
        }


        public async Task<IssParcelaEntity?> PrimeiroOuNull(IssParcelaFilter filtro)
        {
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssParcelaEntity>> Listar(IssParcelaFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issParcelaRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
				consulta = consulta.Where(x => x.Cd_Contribuinte == filtro.Cd_Contribuinte.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Aviso))
				consulta = consulta.Where(x => x.Nr_Aviso == filtro.Nr_Aviso);

			if (filtro.Cd_GrupoTributo.HasValue && filtro.Cd_GrupoTributo.Value > 0)
				consulta = consulta.Where(x => x.Cd_GrupoTributo == filtro.Cd_GrupoTributo.Value);

			if (filtro.Nr_parcela.HasValue && filtro.Nr_parcela.Value > 0)
				consulta = consulta.Where(x => x.Nr_parcela == filtro.Nr_parcela.Value);

			if (filtro.Cd_Lote.HasValue && filtro.Cd_Lote.Value > 0)
				consulta = consulta.Where(x => x.Cd_Lote == filtro.Cd_Lote.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_IndiceFinanceiro))
				consulta = consulta.Where(x => x.Sg_IndiceFinanceiro == filtro.Sg_IndiceFinanceiro);

			if (filtro.Dt_atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_atualizacao == filtro.Dt_atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
				consulta = consulta.Where(x => x.Nm_usuario == filtro.Nm_usuario);

			if (filtro.Dt_vencimento.HasValue)
				consulta = consulta.Where(x => x.Dt_vencimento == filtro.Dt_vencimento.Value);

			if (filtro.Vl_ReceitaBruta.HasValue && filtro.Vl_ReceitaBruta.Value > 0)
				consulta = consulta.Where(x => x.Vl_ReceitaBruta == filtro.Vl_ReceitaBruta.Value);

			if (filtro.Vl_aliquota.HasValue && filtro.Vl_aliquota.Value > 0)
				consulta = consulta.Where(x => x.Vl_aliquota == filtro.Vl_aliquota.Value);

			if (filtro.Vl_tributo.HasValue && filtro.Vl_tributo.Value > 0)
				consulta = consulta.Where(x => x.Vl_tributo == filtro.Vl_tributo.Value);

			if (filtro.Pc_desconto.HasValue && filtro.Pc_desconto.Value > 0)
				consulta = consulta.Where(x => x.Pc_desconto == filtro.Pc_desconto.Value);

			if (filtro.Vl_parcela.HasValue && filtro.Vl_parcela.Value > 0)
				consulta = consulta.Where(x => x.Vl_parcela == filtro.Vl_parcela.Value);

			if (filtro.Vl_multa.HasValue && filtro.Vl_multa.Value > 0)
				consulta = consulta.Where(x => x.Vl_multa == filtro.Vl_multa.Value);

			if (filtro.Vl_juros.HasValue && filtro.Vl_juros.Value > 0)
				consulta = consulta.Where(x => x.Vl_juros == filtro.Vl_juros.Value);

			if (filtro.Vl_correcao.HasValue && filtro.Vl_correcao.Value > 0)
				consulta = consulta.Where(x => x.Vl_correcao == filtro.Vl_correcao.Value);

			if (filtro.Vl_Tarifa.HasValue && filtro.Vl_Tarifa.Value > 0)
				consulta = consulta.Where(x => x.Vl_Tarifa == filtro.Vl_Tarifa.Value);

			if (filtro.Dt_pagamento.HasValue)
				consulta = consulta.Where(x => x.Dt_pagamento == filtro.Dt_pagamento.Value);

			if (filtro.Vl_pago.HasValue && filtro.Vl_pago.Value > 0)
				consulta = consulta.Where(x => x.Vl_pago == filtro.Vl_pago.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_DividaAtiva))
				consulta = consulta.Where(x => x.Fl_DividaAtiva == filtro.Fl_DividaAtiva);

			if (filtro.Vl_Diferenca.HasValue && filtro.Vl_Diferenca.Value > 0)
				consulta = consulta.Where(x => x.Vl_Diferenca == filtro.Vl_Diferenca.Value);

			if (filtro.Nr_Guia.HasValue && filtro.Nr_Guia.Value > 0)
				consulta = consulta.Where(x => x.Nr_Guia == filtro.Nr_Guia.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Obs))
				consulta = consulta.Where(x => x.Ds_Obs == filtro.Ds_Obs);

			if (filtro.Dt_Estorno.HasValue)
				consulta = consulta.Where(x => x.Dt_Estorno == filtro.Dt_Estorno.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_MotivoEstorno))
				consulta = consulta.Where(x => x.Ds_MotivoEstorno == filtro.Ds_MotivoEstorno);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuarioestorno))
				consulta = consulta.Where(x => x.Nm_usuarioestorno == filtro.Nm_usuarioestorno);

			if (filtro.Dt_criacao.HasValue)
				consulta = consulta.Where(x => x.Dt_criacao == filtro.Dt_criacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuariocriacao))
				consulta = consulta.Where(x => x.Nm_usuariocriacao == filtro.Nm_usuariocriacao);

			if (filtro.Fl_web.HasValue && filtro.Fl_web.Value > 0)
				consulta = consulta.Where(x => x.Fl_web == filtro.Fl_web.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_mesref))
				consulta = consulta.Where(x => x.Ds_mesref == filtro.Ds_mesref);

			if (filtro.Dt_Auditoria.HasValue)
				consulta = consulta.Where(x => x.Dt_Auditoria == filtro.Dt_Auditoria.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_AvisoOrigemGA))
				consulta = consulta.Where(x => x.Nr_AvisoOrigemGA == filtro.Nr_AvisoOrigemGA);

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
				consulta = consulta.Where(x => x.Nr_Certificado == filtro.Nr_Certificado.Value);

			if (filtro.Dt_AcaoFiscal.HasValue)
				consulta = consulta.Where(x => x.Dt_AcaoFiscal == filtro.Dt_AcaoFiscal.Value);

			if (filtro.Cd_AnoBase.HasValue && filtro.Cd_AnoBase.Value > 0)
				consulta = consulta.Where(x => x.Cd_AnoBase == filtro.Cd_AnoBase.Value);

			if (filtro.Nr_GuiaUnificada.HasValue && filtro.Nr_GuiaUnificada.Value > 0)
				consulta = consulta.Where(x => x.Nr_GuiaUnificada == filtro.Nr_GuiaUnificada.Value);

			if (filtro.Cd_TipoEstorno.HasValue && filtro.Cd_TipoEstorno.Value > 0)
				consulta = consulta.Where(x => x.Cd_TipoEstorno == filtro.Cd_TipoEstorno.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_CobrancaRegistro))
				consulta = consulta.Where(x => x.Fl_CobrancaRegistro == filtro.Fl_CobrancaRegistro);

			if (filtro.Cd_ExercicioGuiaUnificada.HasValue && filtro.Cd_ExercicioGuiaUnificada.Value > 0)
				consulta = consulta.Where(x => x.Cd_ExercicioGuiaUnificada == filtro.Cd_ExercicioGuiaUnificada.Value);

			if (filtro.Nr_Processo.HasValue && filtro.Nr_Processo.Value > 0)
				consulta = consulta.Where(x => x.Nr_Processo == filtro.Nr_Processo.Value);

			if (filtro.Aa_Processo.HasValue && filtro.Aa_Processo.Value > 0)
				consulta = consulta.Where(x => x.Aa_Processo == filtro.Aa_Processo.Value);

			if (filtro.Dt_Processo.HasValue)
				consulta = consulta.Where(x => x.Dt_Processo == filtro.Dt_Processo.Value);

			if (filtro.Nr_GuiaUnificadaISS.HasValue && filtro.Nr_GuiaUnificadaISS.Value > 0)
				consulta = consulta.Where(x => x.Nr_GuiaUnificadaISS == filtro.Nr_GuiaUnificadaISS.Value);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssParcelaEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssParcelaEntity>> ListarSQL(IssParcelaFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssParcelas WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			if (filtro.Cd_Contribuinte.HasValue && filtro.Cd_Contribuinte.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Contribuinte = {filtro.Cd_Contribuinte}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Aviso))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Aviso {MontarCampoString(filtro.Nr_Aviso)}");
			}

			if (filtro.Cd_GrupoTributo.HasValue && filtro.Cd_GrupoTributo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_GrupoTributo = {filtro.Cd_GrupoTributo}");
			}

			if (filtro.Nr_parcela.HasValue && filtro.Nr_parcela.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_parcela = {filtro.Nr_parcela}");
			}

			if (filtro.Cd_Lote.HasValue && filtro.Cd_Lote.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Lote = {filtro.Cd_Lote}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_IndiceFinanceiro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_IndiceFinanceiro {MontarCampoString(filtro.Sg_IndiceFinanceiro)}");
			}

			if (filtro.Dt_atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_atualizacao = {filtro.Dt_atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuario {MontarCampoString(filtro.Nm_usuario)}");
			}

			if (filtro.Dt_vencimento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_vencimento = {filtro.Dt_vencimento}");
			}

			if (filtro.Vl_ReceitaBruta.HasValue && filtro.Vl_ReceitaBruta.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_ReceitaBruta = {filtro.Vl_ReceitaBruta}");
			}

			if (filtro.Vl_aliquota.HasValue && filtro.Vl_aliquota.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_aliquota = {filtro.Vl_aliquota}");
			}

			if (filtro.Vl_tributo.HasValue && filtro.Vl_tributo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_tributo = {filtro.Vl_tributo}");
			}

			if (filtro.Pc_desconto.HasValue && filtro.Pc_desconto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_desconto = {filtro.Pc_desconto}");
			}

			if (filtro.Vl_parcela.HasValue && filtro.Vl_parcela.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_parcela = {filtro.Vl_parcela}");
			}

			if (filtro.Vl_multa.HasValue && filtro.Vl_multa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_multa = {filtro.Vl_multa}");
			}

			if (filtro.Vl_juros.HasValue && filtro.Vl_juros.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_juros = {filtro.Vl_juros}");
			}

			if (filtro.Vl_correcao.HasValue && filtro.Vl_correcao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_correcao = {filtro.Vl_correcao}");
			}

			if (filtro.Vl_Tarifa.HasValue && filtro.Vl_Tarifa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Tarifa = {filtro.Vl_Tarifa}");
			}

			if (filtro.Dt_pagamento.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_pagamento = {filtro.Dt_pagamento}");
			}

			if (filtro.Vl_pago.HasValue && filtro.Vl_pago.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_pago = {filtro.Vl_pago}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_DividaAtiva))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_DividaAtiva {MontarCampoString(filtro.Fl_DividaAtiva)}");
			}

			if (filtro.Vl_Diferenca.HasValue && filtro.Vl_Diferenca.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_Diferenca = {filtro.Vl_Diferenca}");
			}

			if (filtro.Nr_Guia.HasValue && filtro.Nr_Guia.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Guia = {filtro.Nr_Guia}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Obs))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Obs {MontarCampoString(filtro.Ds_Obs)}");
			}

			if (filtro.Dt_Estorno.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Estorno = {filtro.Dt_Estorno}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_MotivoEstorno))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_MotivoEstorno {MontarCampoString(filtro.Ds_MotivoEstorno)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuarioestorno))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuarioestorno {MontarCampoString(filtro.Nm_usuarioestorno)}");
			}

			if (filtro.Dt_criacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_criacao = {filtro.Dt_criacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuariocriacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuariocriacao {MontarCampoString(filtro.Nm_usuariocriacao)}");
			}

			if (filtro.Fl_web.HasValue && filtro.Fl_web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_web = {filtro.Fl_web}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_mesref))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_mesref {MontarCampoString(filtro.Ds_mesref)}");
			}

			if (filtro.Dt_Auditoria.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Auditoria = {filtro.Dt_Auditoria}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_AvisoOrigemGA))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_AvisoOrigemGA {MontarCampoString(filtro.Nr_AvisoOrigemGA)}");
			}

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Certificado = {filtro.Nr_Certificado}");
			}

			if (filtro.Dt_AcaoFiscal.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_AcaoFiscal = {filtro.Dt_AcaoFiscal}");
			}

			if (filtro.Cd_AnoBase.HasValue && filtro.Cd_AnoBase.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_AnoBase = {filtro.Cd_AnoBase}");
			}

			if (filtro.Nr_GuiaUnificada.HasValue && filtro.Nr_GuiaUnificada.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_GuiaUnificada = {filtro.Nr_GuiaUnificada}");
			}

			if (filtro.Cd_TipoEstorno.HasValue && filtro.Cd_TipoEstorno.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TipoEstorno = {filtro.Cd_TipoEstorno}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_CobrancaRegistro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_CobrancaRegistro {MontarCampoString(filtro.Fl_CobrancaRegistro)}");
			}

			if (filtro.Cd_ExercicioGuiaUnificada.HasValue && filtro.Cd_ExercicioGuiaUnificada.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ExercicioGuiaUnificada = {filtro.Cd_ExercicioGuiaUnificada}");
			}

			if (filtro.Nr_Processo.HasValue && filtro.Nr_Processo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Processo = {filtro.Nr_Processo}");
			}

			if (filtro.Aa_Processo.HasValue && filtro.Aa_Processo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Aa_Processo = {filtro.Aa_Processo}");
			}

			if (filtro.Dt_Processo.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Processo = {filtro.Dt_Processo}");
			}

			if (filtro.Nr_GuiaUnificadaISS.HasValue && filtro.Nr_GuiaUnificadaISS.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_GuiaUnificadaISS = {filtro.Nr_GuiaUnificadaISS}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issParcelaRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE IssParcelas SET campo = 'valor' WHERE pk = 666";

            return await _issParcelaRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
