﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.Filter.IssArrecadacao;
using Cecam.Tributario.Database.QueryInterface.IssArrecadacao;
using Cecam.Tributario.Database.RepositoryInterface.IssArrecadacao;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssArrecadacao
{
    public class IssCertificadoQuery : QueryBase, IIssCertificadoQuery
    {
        protected readonly IIssCertificadoRepository _issCertificadoRepositorio;


        public IssCertificadoQuery(IIssCertificadoRepository issCertificadoRepositorio)
        {
            _issCertificadoRepositorio = issCertificadoRepositorio;
        }


        public async Task<IssCertificadoEntity?> PrimeiroOuNull(IssCertificadoFilter filtro)
        {
			filtro.QtdMaximaRegistrosRetornados = 1;
            return (await Listar(filtro)).FirstOrDefault();
        }


        public async Task<List<IssCertificadoEntity>> Listar(IssCertificadoFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issCertificadoRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
				consulta = consulta.Where(x => x.Nr_Certificado == filtro.Nr_Certificado.Value);

			if (filtro.Cd_Situacao.HasValue && filtro.Cd_Situacao.Value > 0)
				consulta = consulta.Where(x => x.Cd_Situacao == filtro.Cd_Situacao.Value);

			if (filtro.Nr_Retificacao.HasValue && filtro.Nr_Retificacao.Value > 0)
				consulta = consulta.Where(x => x.Nr_Retificacao == filtro.Nr_Retificacao.Value);

			if (filtro.Fl_Pago.HasValue && filtro.Fl_Pago.Value > 0)
				consulta = consulta.Where(x => x.Fl_Pago == filtro.Fl_Pago.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioCriacao))
				consulta = consulta.Where(x => x.Nr_CGCCPFUsuarioCriacao == filtro.Nr_CGCCPFUsuarioCriacao);

			if (filtro.Dt_Criacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Criacao == filtro.Dt_Criacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioAtualizacao))
				consulta = consulta.Where(x => x.Nr_CGCCPFUsuarioAtualizacao == filtro.Nr_CGCCPFUsuarioAtualizacao);

			if (filtro.Dt_Atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_Atualizacao == filtro.Dt_Atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Aviso))
				consulta = consulta.Where(x => x.Nr_Aviso == filtro.Nr_Aviso);

			if (filtro.Dt_VencimentoGuia.HasValue)
				consulta = consulta.Where(x => x.Dt_VencimentoGuia == filtro.Dt_VencimentoGuia.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Chave))
				consulta = consulta.Where(x => x.Nr_Chave == filtro.Nr_Chave);

			if (filtro.Cd_Referencia.HasValue && filtro.Cd_Referencia.Value > 0)
				consulta = consulta.Where(x => x.Cd_Referencia == filtro.Cd_Referencia.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
				consulta = consulta.Where(x => x.Nr_CGCCPF == filtro.Nr_CGCCPF);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_MotivoCancelamento))
				consulta = consulta.Where(x => x.Ds_MotivoCancelamento == filtro.Ds_MotivoCancelamento);



            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssCertificadoEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssCertificadoEntity>> ListarSQL(IssCertificadoFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssCertificado WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Nr_Certificado.HasValue && filtro.Nr_Certificado.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Certificado = {filtro.Nr_Certificado}");
			}

			if (filtro.Cd_Situacao.HasValue && filtro.Cd_Situacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Situacao = {filtro.Cd_Situacao}");
			}

			if (filtro.Nr_Retificacao.HasValue && filtro.Nr_Retificacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Retificacao = {filtro.Nr_Retificacao}");
			}

			if (filtro.Fl_Pago.HasValue && filtro.Fl_Pago.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Pago = {filtro.Fl_Pago}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioCriacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPFUsuarioCriacao {MontarCampoString(filtro.Nr_CGCCPFUsuarioCriacao)}");
			}

			if (filtro.Dt_Criacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Criacao = {filtro.Dt_Criacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPFUsuarioAtualizacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPFUsuarioAtualizacao {MontarCampoString(filtro.Nr_CGCCPFUsuarioAtualizacao)}");
			}

			if (filtro.Dt_Atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_Atualizacao = {filtro.Dt_Atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Aviso))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Aviso {MontarCampoString(filtro.Nr_Aviso)}");
			}

			if (filtro.Dt_VencimentoGuia.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_VencimentoGuia = {filtro.Dt_VencimentoGuia}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_Chave))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Chave {MontarCampoString(filtro.Nr_Chave)}");
			}

			if (filtro.Cd_Referencia.HasValue && filtro.Cd_Referencia.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Referencia = {filtro.Cd_Referencia}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CGCCPF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CGCCPF {MontarCampoString(filtro.Nr_CGCCPF)}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_MotivoCancelamento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_MotivoCancelamento {MontarCampoString(filtro.Ds_MotivoCancelamento)}");
			}



            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issCertificadoRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE IssCertificado SET campo = 'valor' WHERE pk = 666";

            return await _issCertificadoRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
