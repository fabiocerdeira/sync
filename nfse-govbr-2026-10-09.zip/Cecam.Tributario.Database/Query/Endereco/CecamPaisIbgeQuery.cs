﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Endereco
{
    public class CecamPaisIbgeQuery : QueryBase, ICecamPaisIbgeQuery
    {
        protected readonly ICecamPaisIbgeRepository _cecamPaisIbgeRepositorio;


        public CecamPaisIbgeQuery(ICecamPaisIbgeRepository cecamPaisIbgeRepositorio)
        {
            _cecamPaisIbgeRepositorio = cecamPaisIbgeRepositorio;
        }


        public async Task<List<CecamPaisIbgeEntity>> Listar(CecamPaisIbgeFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _cecamPaisIbgeRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_pais_ISO2))
				consulta = consulta.Where(x => x.Sg_pais_ISO2 == filtro.Sg_pais_ISO2);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_paisDescricao))
				consulta = consulta.Where(x => x.Ds_paisDescricao == filtro.Ds_paisDescricao);

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<CecamPaisIbgeEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<CecamPaisIbgeEntity>> ListarSQL(CecamPaisIbgeFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISS_NFSE_Paises_ISO2_IBGE WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_pais_ISO2))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_pais_ISO2 = '{filtro.Sg_pais_ISO2.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_paisDescricao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_paisDescricao = '{filtro.Ds_paisDescricao.Trim().Replace("\'","")}'");
			}

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _cecamPaisIbgeRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISS_NFSE_Paises_ISO2_IBGE SET campo = 'valor' WHERE pk = 666";

            return await _cecamPaisIbgeRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
