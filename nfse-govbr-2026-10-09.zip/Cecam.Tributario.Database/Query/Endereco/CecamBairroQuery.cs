﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Endereco
{
    public class CecamBairroQuery : QueryBase, ICecamBairroQuery
    {
        protected readonly ICecamBairroRepository _cecamBairroRepositorio;


        public CecamBairroQuery(ICecamBairroRepository cecamBairroRepositorio)
        {
            _cecamBairroRepositorio = cecamBairroRepositorio;
        }


        public async Task<List<CecamBairroEntity>> Listar(CecamBairroFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _cecamBairroRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Bairro.HasValue && filtro.Cd_Bairro.Value > 0)
				consulta = consulta.Where(x => x.Cd_Bairro == filtro.Cd_Bairro.Value);

			/*
			if (!string.IsNullOrWhiteSpace(filtro.Ds_Bairro))
				consulta = consulta.Where(x => x.Ds_Bairro == filtro.Ds_Bairro);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_classificacaobairro))
				consulta = consulta.Where(x => x.Cd_classificacaobairro == filtro.Cd_classificacaobairro);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_inativo))
				consulta = consulta.Where(x => x.Fl_inativo == filtro.Fl_inativo);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_sistema))
				consulta = consulta.Where(x => x.Fl_sistema == filtro.Fl_sistema);

			if (filtro.Dt_atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_atualizacao == filtro.Dt_atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
				consulta = consulta.Where(x => x.Nm_usuario == filtro.Nm_usuario);

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
				consulta = consulta.Where(x => x.Fl_Web == filtro.Fl_Web.Value);
			*/


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<CecamBairroEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<CecamBairroEntity>> ListarSQL(CecamBairroFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM CECAMBairros WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Bairro.HasValue && filtro.Cd_Bairro.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Bairro = {filtro.Cd_Bairro}");
			}

			/*
			if (!string.IsNullOrWhiteSpace(filtro.Ds_Bairro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Bairro = '{filtro.Ds_Bairro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_classificacaobairro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_classificacaobairro = '{filtro.Cd_classificacaobairro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_inativo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_inativo = '{filtro.Fl_inativo.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_sistema))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_sistema = '{filtro.Fl_sistema.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_atualizacao = {filtro.Dt_atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuario = '{filtro.Nm_usuario.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Web = {filtro.Fl_Web}");
			}
			*/


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _cecamBairroRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE CECAMBairros SET campo = 'valor' WHERE pk = 666";

            return await _cecamBairroRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
