﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Enumerado.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Endereco
{
    public class CecamMunicipioQuery : QueryBase, ICecamMunicipioQuery
    {
        protected readonly ICecamMunicipioRepository _cecamMunicipioRepositorio;


        public CecamMunicipioQuery(ICecamMunicipioRepository cecamMunicipioRepositorio)
        {
            _cecamMunicipioRepositorio = cecamMunicipioRepositorio;
        }

        
        public async Task<CecamMunicipioEntity?> PrimeiroOuNull(CecamMunicipioFilter filtro)
        {
            filtro.QtdMaximaRegistrosRetornados = 1;
            var lista = await Listar(filtro);
            return lista.FirstOrDefault();
        }


        public async Task<List<CecamMunicipioEntity>> Listar(CecamMunicipioFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _cecamMunicipioRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_MunicipioIBGE.HasValue && filtro.Cd_MunicipioIBGE.Value > 0)
				consulta = consulta.Where(x => x.Cd_MunicipioIBGE == filtro.Cd_MunicipioIBGE.Value);

			if (filtro.Cd_Municipio.HasValue && filtro.Cd_Municipio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Municipio == filtro.Cd_Municipio.Value);

            if (!string.IsNullOrWhiteSpace(filtro.Sg_UF))
                consulta = consulta.Where(x => x.Sg_UF == filtro.Sg_UF);

            /*
			if (filtro.Nr_Ano.HasValue && filtro.Nr_Ano.Value > 0)
				consulta = consulta.Where(x => x.Nr_Ano == filtro.Nr_Ano.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_NomeMunicipio))
				consulta = consulta.Where(x => x.Ds_NomeMunicipio == filtro.Ds_NomeMunicipio);

			if (filtro.Cd_CEPInicial.HasValue && filtro.Cd_CEPInicial.Value > 0)
				consulta = consulta.Where(x => x.Cd_CEPInicial == filtro.Cd_CEPInicial.Value);

			if (filtro.Cd_CEPFinal.HasValue && filtro.Cd_CEPFinal.Value > 0)
				consulta = consulta.Where(x => x.Cd_CEPFinal == filtro.Cd_CEPFinal.Value);

			if (filtro.Cd_Jucesp.HasValue && filtro.Cd_Jucesp.Value > 0)
				consulta = consulta.Where(x => x.Cd_Jucesp == filtro.Cd_Jucesp.Value);
            */


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<CecamMunicipioEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        /// <summary>
        /// Carregar o Municipio que representa OP (Outros paises)
        /// Se não existir na base, ele carrega um default
        /// </summary>
        public async Task<CecamMunicipioEntity> CarregarOutroPais()
        {
            var municipio = await _cecamMunicipioRepositorio.GetIQueryable()
                .Where(x => x.Sg_UF == CecamEnderecoEnum.kEstadoOutroPais)
                .FirstOrDefaultAsync();

            // se não encontrou na base, então retornar um default
            if (municipio == null)
            {
                municipio = new CecamMunicipioEntity()
                {
                    Cd_MunicipioIBGE = 9999999,
                    Cd_Municipio = 999999999999,
                    Nr_Ano = (short)ParametrosGlobal.Cd_Exercicio,
                    Sg_UF = CecamEnderecoEnum.kEstadoOutroPais,
                    Ds_NomeMunicipio = "OUTROS PAÍSES / CONTRIBUINTES DIVERSOS",
                    Cd_CEPInicial = 99999999,
                    Cd_CEPFinal = 99999999
                };
            }

            return municipio;
        }


        public async Task<List<CecamMunicipioEntity>> ListarSQL(CecamMunicipioFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM CECAMMunicipio WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_MunicipioIBGE.HasValue && filtro.Cd_MunicipioIBGE.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_MunicipioIBGE = {filtro.Cd_MunicipioIBGE}");
			}

			if (filtro.Cd_Municipio.HasValue && filtro.Cd_Municipio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Municipio = {filtro.Cd_Municipio}");
			}

            if (!string.IsNullOrWhiteSpace(filtro.Sg_UF))
            {
                if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
                sqlWhere.AppendLine($" Sg_UF {MontarCampoString(filtro.Sg_UF)}");
            }


            /*
			if (filtro.Nr_Ano.HasValue && filtro.Nr_Ano.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_Ano = {filtro.Nr_Ano}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_NomeMunicipio))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_NomeMunicipio = '{filtro.Ds_NomeMunicipio.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_CEPInicial.HasValue && filtro.Cd_CEPInicial.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_CEPInicial = {filtro.Cd_CEPInicial}");
			}

			if (filtro.Cd_CEPFinal.HasValue && filtro.Cd_CEPFinal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_CEPFinal = {filtro.Cd_CEPFinal}");
			}

			if (filtro.Cd_Jucesp.HasValue && filtro.Cd_Jucesp.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Jucesp = {filtro.Cd_Jucesp}");
			}
            */


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _cecamMunicipioRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE CECAMMunicipio SET campo = 'valor' WHERE pk = 666";

            return await _cecamMunicipioRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
