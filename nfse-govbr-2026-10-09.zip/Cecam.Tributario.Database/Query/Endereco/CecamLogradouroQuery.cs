﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Filter.Endereco;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.Endereco
{
    public class CecamLogradouroQuery : QueryBase, ICecamLogradouroQuery
    {
        protected readonly ICecamLogradouroRepository _cecamLogradouroRepositorio;


        public CecamLogradouroQuery(ICecamLogradouroRepository cecamLogradouroRepositorio)
        {
            _cecamLogradouroRepositorio = cecamLogradouroRepositorio;
        }


        public async Task<List<CecamLogradouroEntity>> Listar(CecamLogradouroFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _cecamLogradouroRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Logradouro))
				consulta = consulta.Where(x => x.Cd_Logradouro == filtro.Cd_Logradouro);

			/*
			if (!string.IsNullOrWhiteSpace(filtro.Ds_TipoLogradouro))
				consulta = consulta.Where(x => x.Ds_TipoLogradouro == filtro.Ds_TipoLogradouro);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Logradouro))
				consulta = consulta.Where(x => x.Ds_Logradouro == filtro.Ds_Logradouro);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Antigo))
				consulta = consulta.Where(x => x.Ds_Antigo == filtro.Ds_Antigo);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_LeiDecreto))
				consulta = consulta.Where(x => x.Ds_LeiDecreto == filtro.Ds_LeiDecreto);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_inativo))
				consulta = consulta.Where(x => x.Fl_inativo == filtro.Fl_inativo);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_sistema))
				consulta = consulta.Where(x => x.Fl_sistema == filtro.Fl_sistema);

			if (filtro.Dt_atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_atualizacao == filtro.Dt_atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
				consulta = consulta.Where(x => x.Nm_usuario == filtro.Nm_usuario);

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
				consulta = consulta.Where(x => x.Fl_Web == filtro.Fl_Web.Value);

			if (filtro.Cd_Loteamento.HasValue && filtro.Cd_Loteamento.Value > 0)
				consulta = consulta.Where(x => x.Cd_Loteamento == filtro.Cd_Loteamento.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Loteamento))
				consulta = consulta.Where(x => x.Ds_Loteamento == filtro.Ds_Loteamento);

			if (filtro.Cd_bairro.HasValue && filtro.Cd_bairro.Value > 0)
				consulta = consulta.Where(x => x.Cd_bairro == filtro.Cd_bairro.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_bairro))
				consulta = consulta.Where(x => x.Ds_bairro == filtro.Ds_bairro);

			if (filtro.Cd_CEP.HasValue && filtro.Cd_CEP.Value > 0)
				consulta = consulta.Where(x => x.Cd_CEP == filtro.Cd_CEP.Value);
			*/


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<CecamLogradouroEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<CecamLogradouroEntity>> ListarSQL(CecamLogradouroFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM CECAMLogradouros WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Cd_Logradouro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Logradouro = '{filtro.Cd_Logradouro.Trim().Replace("\'","")}'");
			}

			/*
			if (!string.IsNullOrWhiteSpace(filtro.Ds_TipoLogradouro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_TipoLogradouro = '{filtro.Ds_TipoLogradouro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Logradouro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Logradouro = '{filtro.Ds_Logradouro.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Antigo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Antigo = '{filtro.Ds_Antigo.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_LeiDecreto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_LeiDecreto = '{filtro.Ds_LeiDecreto.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_inativo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_inativo = '{filtro.Fl_inativo.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_sistema))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_sistema = '{filtro.Fl_sistema.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_atualizacao = {filtro.Dt_atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuario = '{filtro.Nm_usuario.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_Web.HasValue && filtro.Fl_Web.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Web = {filtro.Fl_Web}");
			}

			if (filtro.Cd_Loteamento.HasValue && filtro.Cd_Loteamento.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Loteamento = {filtro.Cd_Loteamento}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Loteamento))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Loteamento = '{filtro.Ds_Loteamento.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_bairro.HasValue && filtro.Cd_bairro.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_bairro = {filtro.Cd_bairro}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_bairro))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_bairro = '{filtro.Ds_bairro.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_CEP.HasValue && filtro.Cd_CEP.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_CEP = {filtro.Cd_CEP}");
			}
			*/


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _cecamLogradouroRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE CECAMLogradouros SET campo = 'valor' WHERE pk = 666";

            return await _cecamLogradouroRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
