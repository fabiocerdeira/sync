﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.Filter.IssParametros;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Cecam.Tributario.Database.RepositoryInterface.IssParametros;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssParametros
{
    public class IssParametrosNfseQuery : QueryBase, IIssParametrosNfseQuery
    {
        protected readonly IIssParametrosNfseRepository _issParametrosNfseRepositorio;


        public IssParametrosNfseQuery(IIssParametrosNfseRepository issParametrosNfseRepositorio)
        {
            _issParametrosNfseRepositorio = issParametrosNfseRepositorio;
        }


        public async Task<IssParametrosNfseEntity?> Carregar()
        {
            return await _issParametrosNfseRepositorio.GetIQueryable()
                .AsNoTracking()
                .Where(x => x.Cd_Cecam == ParametrosGlobal.Cd_Cecam)
                .FirstOrDefaultAsync();
        }


        /// <summary>
        /// Carregar somente campos gov.br
        /// </summary>
        public async Task<IssParametrosNfseEntity?> CarregarGovBr()
        {
            return await _issParametrosNfseRepositorio.GetIQueryable()
                .AsNoTracking()
                .Where(x => x.Cd_Cecam == ParametrosGlobal.Cd_Cecam)
                .Select(x => new IssParametrosNfseEntity { 
                    Govbr_nsuBaixadoHorario = x.Govbr_nsuBaixadoHorario,
                    Govbr_nsuBaixadoUltimo = x.Govbr_nsuBaixadoUltimo
                })
                .FirstOrDefaultAsync();
        }


        public async Task<List<IssParametrosNfseEntity>> Listar(IssParametrosNfseFilter filtro)
        {
            // MODELO PADRÃO, 

            var consulta = _issParametrosNfseRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

            /*
			if (filtro.Cd_IBGE.HasValue && filtro.Cd_IBGE.Value > 0)
				consulta = consulta.Where(x => x.Cd_IBGE == filtro.Cd_IBGE.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CNPJMunicipio))
				consulta = consulta.Where(x => x.Nr_CNPJMunicipio == filtro.Nr_CNPJMunicipio);

			if (!string.IsNullOrWhiteSpace(filtro.Nr_legislacaoBenefício))
				consulta = consulta.Where(x => x.Nr_legislacaoBenefício == filtro.Nr_legislacaoBenefício);
            */

            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssParametrosNfseEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssParametrosNfseEntity>> ListarSQL(IssParametrosNfseFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM IssParametrosNfSE WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

            /*
			if (filtro.Cd_IBGE.HasValue && filtro.Cd_IBGE.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_IBGE = {filtro.Cd_IBGE}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_CNPJMunicipio))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_CNPJMunicipio = '{filtro.Nr_CNPJMunicipio.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nr_legislacaoBenefício))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_legislacaoBenefício = '{filtro.Nr_legislacaoBenefício.Trim().Replace("\'","")}'");
			}
            */

            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issParametrosNfseRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }



        #region Atualizações

        /// <summary>
        /// Atualizar o último nsu baixado do gov.br e a data hora da última consulta para baixar gov.br
        /// </summary>
        public async Task AtualizarNsuBaixadoUltimo(long ultimoNsu)
        {
            if (ultimoNsu <= 0)
                return;

            string sql = $"UPDATE IssParametrosNfSE SET govbr_nsuBaixadoUltimo = {ultimoNsu}, govbr_nsuBaixadoHorario = CONVERT(datetime,'{DateTime.UtcNow.AddHours(-3).ToString("yyyy-MM-dd HH:mm:ss")}',102) WHERE cd_cecam = {ParametrosGlobal.Cd_Cecam}";

            await _issParametrosNfseRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }


        /// <summary>
        /// Atualizar a data hora da última consulta para baixar gov.br
        /// </summary>
        public async Task AtualizarNsuBaixadoHorario(DateTime dataHora)
        {
            string sql = $"UPDATE IssParametrosNfSE SET govbr_nsuBaixadoHorario = CONVERT(datetime,'{dataHora.ToString("yyyy-MM-dd HH:mm:ss")}',102) WHERE cd_cecam = {ParametrosGlobal.Cd_Cecam}";

            await _issParametrosNfseRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }

        #endregion

    }
}
