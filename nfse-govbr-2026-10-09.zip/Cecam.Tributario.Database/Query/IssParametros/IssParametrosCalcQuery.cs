﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.Filter.IssParametros;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Cecam.Tributario.Database.RepositoryInterface.IssParametros;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace Cecam.Tributario.Database.Query.IssParametros
{
    public class IssParametrosCalcQuery : QueryBase, IIssParametrosCalcQuery
    {
        protected readonly IIssParametrosCalcRepository _issParametrosCalcRepositorio;


        public IssParametrosCalcQuery(IIssParametrosCalcRepository issParametrosCalcRepositorio)
        {
            _issParametrosCalcRepositorio = issParametrosCalcRepositorio;
        }


        public async Task<IssParametrosCalcEntity?> Carregar()
		{
			return await _issParametrosCalcRepositorio.GetIQueryable()
				.AsNoTracking()
				.Where(x => x.Cd_Cecam == ParametrosGlobal.Cd_Cecam && x.Cd_Exercicio == ParametrosGlobal.Cd_Exercicio)
				.FirstOrDefaultAsync();
        }


        public async Task<List<IssParametrosCalcEntity>> Listar(IssParametrosCalcFilter filtro)
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            var consulta = _issParametrosCalcRepositorio.GetIQueryable();

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
				consulta = consulta.Where(x => x.Cd_Cecam == filtro.Cd_Cecam.Value);

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
				consulta = consulta.Where(x => x.Cd_Exercicio == filtro.Cd_Exercicio.Value);

			/*
			if (filtro.Fl_emitecarneisentos.HasValue && filtro.Fl_emitecarneisentos.Value > 0)
				consulta = consulta.Where(x => x.Fl_emitecarneisentos == filtro.Fl_emitecarneisentos.Value);

			if (filtro.Cd_SubGrupoImposto.HasValue && filtro.Cd_SubGrupoImposto.Value > 0)
				consulta = consulta.Where(x => x.Cd_SubGrupoImposto == filtro.Cd_SubGrupoImposto.Value);

			if (filtro.Cd_SubGrupoTaxa.HasValue && filtro.Cd_SubGrupoTaxa.Value > 0)
				consulta = consulta.Where(x => x.Cd_SubGrupoTaxa == filtro.Cd_SubGrupoTaxa.Value);

			if (filtro.Cd_GrupoISS.HasValue && filtro.Cd_GrupoISS.Value > 0)
				consulta = consulta.Where(x => x.Cd_GrupoISS == filtro.Cd_GrupoISS.Value);

			if (filtro.Cd_GrupoISSvar.HasValue && filtro.Cd_GrupoISSvar.Value > 0)
				consulta = consulta.Where(x => x.Cd_GrupoISSvar == filtro.Cd_GrupoISSvar.Value);

			if (filtro.Cd_SubGrupoISSvar.HasValue && filtro.Cd_SubGrupoISSvar.Value > 0)
				consulta = consulta.Where(x => x.Cd_SubGrupoISSvar == filtro.Cd_SubGrupoISSvar.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_MoedaPadrao))
				consulta = consulta.Where(x => x.Sg_MoedaPadrao == filtro.Sg_MoedaPadrao);

			if (filtro.Fl_UtilizaFaixaValores.HasValue)
				consulta = consulta.Where(x => x.Fl_UtilizaFaixaValores == filtro.Fl_UtilizaFaixaValores.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizaValorMinimo))
				consulta = consulta.Where(x => x.Fl_UtilizaValorMinimo == filtro.Fl_UtilizaValorMinimo);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizaValorMinimoTaxa))
				consulta = consulta.Where(x => x.Fl_UtilizaValorMinimoTaxa == filtro.Fl_UtilizaValorMinimoTaxa);

			if (filtro.Fl_UtilizaConversaoCertidoes.HasValue)
				consulta = consulta.Where(x => x.Fl_UtilizaConversaoCertidoes == filtro.Fl_UtilizaConversaoCertidoes.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_Desconto))
				consulta = consulta.Where(x => x.Fl_Desconto == filtro.Fl_Desconto);

			if (filtro.Vlr_Minimo.HasValue && filtro.Vlr_Minimo.Value > 0)
				consulta = consulta.Where(x => x.Vlr_Minimo == filtro.Vlr_Minimo.Value);

			if (filtro.Vlr_MinimoTaxa.HasValue && filtro.Vlr_MinimoTaxa.Value > 0)
				consulta = consulta.Where(x => x.Vlr_MinimoTaxa == filtro.Vlr_MinimoTaxa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_DescontoEspecial))
				consulta = consulta.Where(x => x.Ds_DescontoEspecial == filtro.Ds_DescontoEspecial);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoValorIntervaloBaixa))
				consulta = consulta.Where(x => x.Fl_TipoValorIntervaloBaixa == filtro.Fl_TipoValorIntervaloBaixa);

			if (filtro.Vlr_IntervaloMaximoBaixa.HasValue && filtro.Vlr_IntervaloMaximoBaixa.Value > 0)
				consulta = consulta.Where(x => x.Vlr_IntervaloMaximoBaixa == filtro.Vlr_IntervaloMaximoBaixa.Value);

			if (filtro.Vlr_IntervaloMinimoBaixa.HasValue && filtro.Vlr_IntervaloMinimoBaixa.Value > 0)
				consulta = consulta.Where(x => x.Vlr_IntervaloMinimoBaixa == filtro.Vlr_IntervaloMinimoBaixa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Juros))
				consulta = consulta.Where(x => x.Ds_Juros == filtro.Ds_Juros);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Multa))
				consulta = consulta.Where(x => x.Ds_Multa == filtro.Ds_Multa);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Imposto))
				consulta = consulta.Where(x => x.Ds_Imposto == filtro.Ds_Imposto);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizacaoValoresJurosMulta))
				consulta = consulta.Where(x => x.Fl_UtilizacaoValoresJurosMulta == filtro.Fl_UtilizacaoValoresJurosMulta);

			if (!string.IsNullOrWhiteSpace(filtro.Sg_MoedaCorrente))
				consulta = consulta.Where(x => x.Sg_MoedaCorrente == filtro.Sg_MoedaCorrente);

			if (filtro.Cd_TributoJurosImposto.HasValue && filtro.Cd_TributoJurosImposto.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoJurosImposto == filtro.Cd_TributoJurosImposto.Value);

			if (filtro.Cd_TributoMultasImposto.HasValue && filtro.Cd_TributoMultasImposto.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoMultasImposto == filtro.Cd_TributoMultasImposto.Value);

			if (filtro.Cd_TributoCorrecaoImposto.HasValue && filtro.Cd_TributoCorrecaoImposto.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoCorrecaoImposto == filtro.Cd_TributoCorrecaoImposto.Value);

			if (filtro.Cd_TributoTarifaBancaria.HasValue && filtro.Cd_TributoTarifaBancaria.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoTarifaBancaria == filtro.Cd_TributoTarifaBancaria.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_DiretorioDocumentos))
				consulta = consulta.Where(x => x.Nm_DiretorioDocumentos == filtro.Nm_DiretorioDocumentos);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoAtualizacaoValor))
				consulta = consulta.Where(x => x.Fl_TipoAtualizacaoValor == filtro.Fl_TipoAtualizacaoValor);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoNrAviso))
				consulta = consulta.Where(x => x.Fl_TipoNrAviso == filtro.Fl_TipoNrAviso);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnica))
				consulta = consulta.Where(x => x.Msg_ParcelaUnica == filtro.Msg_ParcelaUnica);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelas))
				consulta = consulta.Where(x => x.Msg_DemaisParcelas == filtro.Msg_DemaisParcelas);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_TipoAplicacaoJuros))
				consulta = consulta.Where(x => x.Nm_TipoAplicacaoJuros == filtro.Nm_TipoAplicacaoJuros);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_TipoAplicacaoMulta))
				consulta = consulta.Where(x => x.Nm_TipoAplicacaoMulta == filtro.Nm_TipoAplicacaoMulta);

			if (filtro.Cd_FicharecImposto.HasValue && filtro.Cd_FicharecImposto.Value > 0)
				consulta = consulta.Where(x => x.Cd_FicharecImposto == filtro.Cd_FicharecImposto.Value);

			if (filtro.Cd_FicharecTaxa.HasValue && filtro.Cd_FicharecTaxa.Value > 0)
				consulta = consulta.Where(x => x.Cd_FicharecTaxa == filtro.Cd_FicharecTaxa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_Ajuste))
				consulta = consulta.Where(x => x.Fl_Ajuste == filtro.Fl_Ajuste);

			if (filtro.Cd_GrupoGuiaExpediente.HasValue && filtro.Cd_GrupoGuiaExpediente.Value > 0)
				consulta = consulta.Where(x => x.Cd_GrupoGuiaExpediente == filtro.Cd_GrupoGuiaExpediente.Value);

			if (filtro.Cd_TributoJurosTaxa.HasValue && filtro.Cd_TributoJurosTaxa.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoJurosTaxa == filtro.Cd_TributoJurosTaxa.Value);

			if (filtro.Cd_TributoMultasTaxa.HasValue && filtro.Cd_TributoMultasTaxa.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoMultasTaxa == filtro.Cd_TributoMultasTaxa.Value);

			if (filtro.Cd_TributoCorrecaoTaxa.HasValue && filtro.Cd_TributoCorrecaoTaxa.Value > 0)
				consulta = consulta.Where(x => x.Cd_TributoCorrecaoTaxa == filtro.Cd_TributoCorrecaoTaxa.Value);

			if (filtro.Cd_FichaRecImpostoTaxas.HasValue && filtro.Cd_FichaRecImpostoTaxas.Value > 0)
				consulta = consulta.Where(x => x.Cd_FichaRecImpostoTaxas == filtro.Cd_FichaRecImpostoTaxas.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasVariaveis))
				consulta = consulta.Where(x => x.Msg_ParcelasVariaveis == filtro.Msg_ParcelasVariaveis);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnicaTaxa))
				consulta = consulta.Where(x => x.Msg_ParcelaUnicaTaxa == filtro.Msg_ParcelaUnicaTaxa);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelasTaxa))
				consulta = consulta.Where(x => x.Msg_DemaisParcelasTaxa == filtro.Msg_DemaisParcelasTaxa);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasGuias))
				consulta = consulta.Where(x => x.Msg_ParcelasGuias == filtro.Msg_ParcelasGuias);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasEventuais))
				consulta = consulta.Where(x => x.Msg_ParcelasEventuais == filtro.Msg_ParcelasEventuais);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasExpediente))
				consulta = consulta.Where(x => x.Msg_ParcelasExpediente == filtro.Msg_ParcelasExpediente);

			if (filtro.Vlr_ResCalculo.HasValue && filtro.Vlr_ResCalculo.Value > 0)
				consulta = consulta.Where(x => x.Vlr_ResCalculo == filtro.Vlr_ResCalculo.Value);

			if (filtro.Cd_ReceitaAClassificar.HasValue && filtro.Cd_ReceitaAClassificar.Value > 0)
				consulta = consulta.Where(x => x.Cd_ReceitaAClassificar == filtro.Cd_ReceitaAClassificar.Value);

			if (filtro.Cd_ClienteGOL.HasValue && filtro.Cd_ClienteGOL.Value > 0)
				consulta = consulta.Where(x => x.Cd_ClienteGOL == filtro.Cd_ClienteGOL.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoNrOcorrencia))
				consulta = consulta.Where(x => x.Fl_TipoNrOcorrencia == filtro.Fl_TipoNrOcorrencia);

			if (filtro.Dt_atualizacao.HasValue)
				consulta = consulta.Where(x => x.Dt_atualizacao == filtro.Dt_atualizacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
				consulta = consulta.Where(x => x.Nm_usuario == filtro.Nm_usuario);

			if (filtro.Nr_ISSEAnoMesImplantacao.HasValue && filtro.Nr_ISSEAnoMesImplantacao.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEAnoMesImplantacao == filtro.Nr_ISSEAnoMesImplantacao.Value);

			if (filtro.Nr_ISSEMesesParaEscrituracao.HasValue && filtro.Nr_ISSEMesesParaEscrituracao.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEMesesParaEscrituracao == filtro.Nr_ISSEMesesParaEscrituracao.Value);

			if (filtro.Nr_ISSEMesesParaRetificacao.HasValue && filtro.Nr_ISSEMesesParaRetificacao.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEMesesParaRetificacao == filtro.Nr_ISSEMesesParaRetificacao.Value);

			if (filtro.Nr_ISSEDiaVencimento.HasValue && filtro.Nr_ISSEDiaVencimento.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEDiaVencimento == filtro.Nr_ISSEDiaVencimento.Value);

			if (filtro.Nr_ISSENumeroDiasVencimento.HasValue && filtro.Nr_ISSENumeroDiasVencimento.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSENumeroDiasVencimento == filtro.Nr_ISSENumeroDiasVencimento.Value);

			if (filtro.Nr_ISSEPermitirOutraAtividade.HasValue && filtro.Nr_ISSEPermitirOutraAtividade.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEPermitirOutraAtividade == filtro.Nr_ISSEPermitirOutraAtividade.Value);

			if (filtro.Nr_ISSEDiasStandBy.HasValue && filtro.Nr_ISSEDiasStandBy.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEDiasStandBy == filtro.Nr_ISSEDiasStandBy.Value);

			if (filtro.Nr_ISSEConfirmacaoCadastro.HasValue && filtro.Nr_ISSEConfirmacaoCadastro.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEConfirmacaoCadastro == filtro.Nr_ISSEConfirmacaoCadastro.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ObsAdicionaisCapaCarne))
				consulta = consulta.Where(x => x.Msg_ObsAdicionaisCapaCarne == filtro.Msg_ObsAdicionaisCapaCarne);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_emiteAlvaraWEB))
				consulta = consulta.Where(x => x.Fl_emiteAlvaraWEB == filtro.Fl_emiteAlvaraWEB);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoValorIntervaloBaixaDVAT))
				consulta = consulta.Where(x => x.Fl_TipoValorIntervaloBaixaDVAT == filtro.Fl_TipoValorIntervaloBaixaDVAT);

			if (filtro.Vlr_IntervaloMaximoBaixaDVAT.HasValue && filtro.Vlr_IntervaloMaximoBaixaDVAT.Value > 0)
				consulta = consulta.Where(x => x.Vlr_IntervaloMaximoBaixaDVAT == filtro.Vlr_IntervaloMaximoBaixaDVAT.Value);

			if (filtro.Vlr_IntervaloMinimoBaixaDVAT.HasValue && filtro.Vlr_IntervaloMinimoBaixaDVAT.Value > 0)
				consulta = consulta.Where(x => x.Vlr_IntervaloMinimoBaixaDVAT == filtro.Vlr_IntervaloMinimoBaixaDVAT.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ISSESenhaAdmin))
				consulta = consulta.Where(x => x.Ds_ISSESenhaAdmin == filtro.Ds_ISSESenhaAdmin);

			if (filtro.Nr_NFEQtdeDiasPreCadastro.HasValue && filtro.Nr_NFEQtdeDiasPreCadastro.Value > 0)
				consulta = consulta.Where(x => x.Nr_NFEQtdeDiasPreCadastro == filtro.Nr_NFEQtdeDiasPreCadastro.Value);

			if (filtro.Nr_NFEQtdeNFBloco.HasValue && filtro.Nr_NFEQtdeNFBloco.Value > 0)
				consulta = consulta.Where(x => x.Nr_NFEQtdeNFBloco == filtro.Nr_NFEQtdeNFBloco.Value);

			if (filtro.Nr_NFEQtdeDiasRPS.HasValue && filtro.Nr_NFEQtdeDiasRPS.Value > 0)
				consulta = consulta.Where(x => x.Nr_NFEQtdeDiasRPS == filtro.Nr_NFEQtdeDiasRPS.Value);

			if (filtro.Cd_NFETipoDocto.HasValue && filtro.Cd_NFETipoDocto.Value > 0)
				consulta = consulta.Where(x => x.Cd_NFETipoDocto == filtro.Cd_NFETipoDocto.Value);

			if (filtro.Cd_NFETipoDoctoRPS.HasValue && filtro.Cd_NFETipoDoctoRPS.Value > 0)
				consulta = consulta.Where(x => x.Cd_NFETipoDoctoRPS == filtro.Cd_NFETipoDoctoRPS.Value);

			if (filtro.Fl_NFEDiscriminaImposto.HasValue && filtro.Fl_NFEDiscriminaImposto.Value > 0)
				consulta = consulta.Where(x => x.Fl_NFEDiscriminaImposto == filtro.Fl_NFEDiscriminaImposto.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_NFECapaBloco))
				consulta = consulta.Where(x => x.Ds_NFECapaBloco == filtro.Ds_NFECapaBloco);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_permiteAlteracaoSenhaWEB))
				consulta = consulta.Where(x => x.Fl_permiteAlteracaoSenhaWEB == filtro.Fl_permiteAlteracaoSenhaWEB);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnica_Ambulantes))
				consulta = consulta.Where(x => x.Msg_ParcelaUnica_Ambulantes == filtro.Msg_ParcelaUnica_Ambulantes);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelas_Ambulantes))
				consulta = consulta.Where(x => x.Msg_DemaisParcelas_Ambulantes == filtro.Msg_DemaisParcelas_Ambulantes);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnicaTaxa_Ambulantes))
				consulta = consulta.Where(x => x.Msg_ParcelaUnicaTaxa_Ambulantes == filtro.Msg_ParcelaUnicaTaxa_Ambulantes);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelasTaxa_Ambulantes))
				consulta = consulta.Where(x => x.Msg_DemaisParcelasTaxa_Ambulantes == filtro.Msg_DemaisParcelasTaxa_Ambulantes);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasGuias_Ambulantes))
				consulta = consulta.Where(x => x.Msg_ParcelasGuias_Ambulantes == filtro.Msg_ParcelasGuias_Ambulantes);

			if (filtro.Cd_ControleAmbulanteInicial.HasValue && filtro.Cd_ControleAmbulanteInicial.Value > 0)
				consulta = consulta.Where(x => x.Cd_ControleAmbulanteInicial == filtro.Cd_ControleAmbulanteInicial.Value);

			if (filtro.Cd_ControleAmbulanteFinal.HasValue && filtro.Cd_ControleAmbulanteFinal.Value > 0)
				consulta = consulta.Where(x => x.Cd_ControleAmbulanteFinal == filtro.Cd_ControleAmbulanteFinal.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasExpediente_Ambulantes))
				consulta = consulta.Where(x => x.Msg_ParcelasExpediente_Ambulantes == filtro.Msg_ParcelasExpediente_Ambulantes);

			if (filtro.Fl_PermitirAcessoGuiaAvulsa.HasValue)
				consulta = consulta.Where(x => x.Fl_PermitirAcessoGuiaAvulsa == filtro.Fl_PermitirAcessoGuiaAvulsa.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Msg_NotificacaoCarne))
				consulta = consulta.Where(x => x.Msg_NotificacaoCarne == filtro.Msg_NotificacaoCarne);

			if (filtro.Fl_VerificaAlvaraBombeiros.HasValue && filtro.Fl_VerificaAlvaraBombeiros.Value > 0)
				consulta = consulta.Where(x => x.Fl_VerificaAlvaraBombeiros == filtro.Fl_VerificaAlvaraBombeiros.Value);

			if (filtro.Nr_QtdDiasVencimentoAlvaraWeb.HasValue && filtro.Nr_QtdDiasVencimentoAlvaraWeb.Value > 0)
				consulta = consulta.Where(x => x.Nr_QtdDiasVencimentoAlvaraWeb == filtro.Nr_QtdDiasVencimentoAlvaraWeb.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_UrlCadastroWeb))
				consulta = consulta.Where(x => x.Ds_UrlCadastroWeb == filtro.Ds_UrlCadastroWeb);

			if (filtro.Cd_ISSEVencimento.HasValue && filtro.Cd_ISSEVencimento.Value > 0)
				consulta = consulta.Where(x => x.Cd_ISSEVencimento == filtro.Cd_ISSEVencimento.Value);

			if (filtro.Pc_desconto_Principal.HasValue && filtro.Pc_desconto_Principal.Value > 0)
				consulta = consulta.Where(x => x.Pc_desconto_Principal == filtro.Pc_desconto_Principal.Value);

			if (filtro.Pc_desconto_Multa.HasValue && filtro.Pc_desconto_Multa.Value > 0)
				consulta = consulta.Where(x => x.Pc_desconto_Multa == filtro.Pc_desconto_Multa.Value);

			if (filtro.Pc_desconto_Juros.HasValue && filtro.Pc_desconto_Juros.Value > 0)
				consulta = consulta.Where(x => x.Pc_desconto_Juros == filtro.Pc_desconto_Juros.Value);

			if (filtro.Pc_desconto_Correcao.HasValue && filtro.Pc_desconto_Correcao.Value > 0)
				consulta = consulta.Where(x => x.Pc_desconto_Correcao == filtro.Pc_desconto_Correcao.Value);

			if (filtro.Fl_AceitedoTomador.HasValue && filtro.Fl_AceitedoTomador.Value > 0)
				consulta = consulta.Where(x => x.Fl_AceitedoTomador == filtro.Fl_AceitedoTomador.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Nm_TipoAplicacaoCorrecao))
				consulta = consulta.Where(x => x.Nm_TipoAplicacaoCorrecao == filtro.Nm_TipoAplicacaoCorrecao);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ISSEMsgPersonalRPS))
				consulta = consulta.Where(x => x.Ds_ISSEMsgPersonalRPS == filtro.Ds_ISSEMsgPersonalRPS);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_URLISSEletronico))
				consulta = consulta.Where(x => x.Ds_URLISSEletronico == filtro.Ds_URLISSEletronico);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_InibirInfo))
				consulta = consulta.Where(x => x.Fl_InibirInfo == filtro.Fl_InibirInfo);

			if (filtro.Fl_NaoConsultarDivida.HasValue)
				consulta = consulta.Where(x => x.Fl_NaoConsultarDivida == filtro.Fl_NaoConsultarDivida.Value);

			if (filtro.Fl_UtilizaDescAtivBoleto.HasValue)
				consulta = consulta.Where(x => x.Fl_UtilizaDescAtivBoleto == filtro.Fl_UtilizaDescAtivBoleto.Value);

			if (filtro.Dt_VencMaxImpressaoParcelaWeb.HasValue)
				consulta = consulta.Where(x => x.Dt_VencMaxImpressaoParcelaWeb == filtro.Dt_VencMaxImpressaoParcelaWeb.Value);

			if (filtro.Vlr_ValorMinimoISSEletronico.HasValue && filtro.Vlr_ValorMinimoISSEletronico.Value > 0)
				consulta = consulta.Where(x => x.Vlr_ValorMinimoISSEletronico == filtro.Vlr_ValorMinimoISSEletronico.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_PermiteEncerrar))
				consulta = consulta.Where(x => x.Fl_PermiteEncerrar == filtro.Fl_PermiteEncerrar);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_FinalidadeParcelasWeb))
				consulta = consulta.Where(x => x.Ds_FinalidadeParcelasWeb == filtro.Ds_FinalidadeParcelasWeb);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AtualizaEmissaoGuiaWEB))
				consulta = consulta.Where(x => x.Fl_AtualizaEmissaoGuiaWEB == filtro.Fl_AtualizaEmissaoGuiaWEB);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AlteraDECA))
				consulta = consulta.Where(x => x.Fl_AlteraDECA == filtro.Fl_AlteraDECA);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_VerDebExercDVAT))
				consulta = consulta.Where(x => x.Fl_VerDebExercDVAT == filtro.Fl_VerDebExercDVAT);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_ConsistirPagtoCancNF))
				consulta = consulta.Where(x => x.Fl_ConsistirPagtoCancNF == filtro.Fl_ConsistirPagtoCancNF);

			if (filtro.Cd_subGrupoTxCompensacao.HasValue && filtro.Cd_subGrupoTxCompensacao.Value > 0)
				consulta = consulta.Where(x => x.Cd_subGrupoTxCompensacao == filtro.Cd_subGrupoTxCompensacao.Value);

			if (filtro.Cd_tributoTxCompensacao.HasValue && filtro.Cd_tributoTxCompensacao.Value > 0)
				consulta = consulta.Where(x => x.Cd_tributoTxCompensacao == filtro.Cd_tributoTxCompensacao.Value);

			if (filtro.Vl_TxCompensacao.HasValue && filtro.Vl_TxCompensacao.Value > 0)
				consulta = consulta.Where(x => x.Vl_TxCompensacao == filtro.Vl_TxCompensacao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirRetencaoTomador))
				consulta = consulta.Where(x => x.Fl_NaoPermitirRetencaoTomador == filtro.Fl_NaoPermitirRetencaoTomador);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirCancNotasGuiaPaga))
				consulta = consulta.Where(x => x.Fl_NaoPermitirCancNotasGuiaPaga == filtro.Fl_NaoPermitirCancNotasGuiaPaga);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirRetencaoTomadorSuperSimples))
				consulta = consulta.Where(x => x.Fl_NaoPermitirRetencaoTomadorSuperSimples == filtro.Fl_NaoPermitirRetencaoTomadorSuperSimples);

			if (filtro.Cd_taxaGuiaeventual.HasValue && filtro.Cd_taxaGuiaeventual.Value > 0)
				consulta = consulta.Where(x => x.Cd_taxaGuiaeventual == filtro.Cd_taxaGuiaeventual.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirCancNotaGuiaGerada))
				consulta = consulta.Where(x => x.Fl_NaoPermitirCancNotaGuiaGerada == filtro.Fl_NaoPermitirCancNotaGuiaGerada);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirCancNotaGuiaVencida))
				consulta = consulta.Where(x => x.Fl_NaoPermitirCancNotaGuiaVencida == filtro.Fl_NaoPermitirCancNotaGuiaVencida);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizaBeneficioFiscal))
				consulta = consulta.Where(x => x.Fl_UtilizaBeneficioFiscal == filtro.Fl_UtilizaBeneficioFiscal);

			if (filtro.Cd_BeneficioFiscal.HasValue && filtro.Cd_BeneficioFiscal.Value > 0)
				consulta = consulta.Where(x => x.Cd_BeneficioFiscal == filtro.Cd_BeneficioFiscal.Value);

			if (filtro.Pc_AliquotaBeneficioFiscal.HasValue && filtro.Pc_AliquotaBeneficioFiscal.Value > 0)
				consulta = consulta.Where(x => x.Pc_AliquotaBeneficioFiscal == filtro.Pc_AliquotaBeneficioFiscal.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ServicosBeneficioFiscal))
				consulta = consulta.Where(x => x.Ds_ServicosBeneficioFiscal == filtro.Ds_ServicosBeneficioFiscal);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_UrlAPIIntegracaoNFE))
				consulta = consulta.Where(x => x.Ds_UrlAPIIntegracaoNFE == filtro.Ds_UrlAPIIntegracaoNFE);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_UrlAPIIntegracaoNFEDados))
				consulta = consulta.Where(x => x.Ds_UrlAPIIntegracaoNFEDados == filtro.Ds_UrlAPIIntegracaoNFEDados);

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AliquotaDiferenteLocalPrestacao))
				consulta = consulta.Where(x => x.Fl_AliquotaDiferenteLocalPrestacao == filtro.Fl_AliquotaDiferenteLocalPrestacao);

			if (filtro.Nr_ISSEqtdeDiasCancelAposEmissao.HasValue && filtro.Nr_ISSEqtdeDiasCancelAposEmissao.Value > 0)
				consulta = consulta.Where(x => x.Nr_ISSEqtdeDiasCancelAposEmissao == filtro.Nr_ISSEqtdeDiasCancelAposEmissao.Value);

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ISSEleiPermissaoCancelAposEmissao))
				consulta = consulta.Where(x => x.Ds_ISSEleiPermissaoCancelAposEmissao == filtro.Ds_ISSEleiPermissaoCancelAposEmissao);
			*/


            #endregion

            #region Relacionamentos
            #endregion

            // campos do filtro base (tracking, paginação, etc)
            consulta = ListarFilterBase<IssParametrosCalcEntity>(consulta, filtro);

            return await consulta.ToListAsync();
        }


        public async Task<List<IssParametrosCalcEntity>> ListarSQL(IssParametrosCalcFilter filtro)
        {
            var sql = new StringBuilder();
            var sqlWhere = new StringBuilder();

            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            sql.AppendLine("SELECT ");

            if (filtro.QtdMaximaRegistrosRetornados.HasValue && filtro.QtdMaximaRegistrosRetornados.Value > 0)
                sql.AppendLine($" TOP {filtro.QtdMaximaRegistrosRetornados.Value} ");

            sql.AppendLine("* FROM ISSParametrosCalc WITH(NOLOCK) ");

            #region Propriedades

			if (filtro.Cd_Cecam.HasValue && filtro.Cd_Cecam.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Cecam = {filtro.Cd_Cecam}");
			}

			if (filtro.Cd_Exercicio.HasValue && filtro.Cd_Exercicio.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_Exercicio = {filtro.Cd_Exercicio}");
			}

			/*
			if (filtro.Fl_emitecarneisentos.HasValue && filtro.Fl_emitecarneisentos.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_emitecarneisentos = {filtro.Fl_emitecarneisentos}");
			}

			if (filtro.Cd_SubGrupoImposto.HasValue && filtro.Cd_SubGrupoImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_SubGrupoImposto = {filtro.Cd_SubGrupoImposto}");
			}

			if (filtro.Cd_SubGrupoTaxa.HasValue && filtro.Cd_SubGrupoTaxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_SubGrupoTaxa = {filtro.Cd_SubGrupoTaxa}");
			}

			if (filtro.Cd_GrupoISS.HasValue && filtro.Cd_GrupoISS.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_GrupoISS = {filtro.Cd_GrupoISS}");
			}

			if (filtro.Cd_GrupoISSvar.HasValue && filtro.Cd_GrupoISSvar.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_GrupoISSvar = {filtro.Cd_GrupoISSvar}");
			}

			if (filtro.Cd_SubGrupoISSvar.HasValue && filtro.Cd_SubGrupoISSvar.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_SubGrupoISSvar = {filtro.Cd_SubGrupoISSvar}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_MoedaPadrao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_MoedaPadrao = '{filtro.Sg_MoedaPadrao.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_UtilizaFaixaValores.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizaFaixaValores = {filtro.Fl_UtilizaFaixaValores}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizaValorMinimo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizaValorMinimo = '{filtro.Fl_UtilizaValorMinimo.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizaValorMinimoTaxa))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizaValorMinimoTaxa = '{filtro.Fl_UtilizaValorMinimoTaxa.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_UtilizaConversaoCertidoes.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizaConversaoCertidoes = {filtro.Fl_UtilizaConversaoCertidoes}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_Desconto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Desconto = '{filtro.Fl_Desconto.Trim().Replace("\'","")}'");
			}

			if (filtro.Vlr_Minimo.HasValue && filtro.Vlr_Minimo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_Minimo = {filtro.Vlr_Minimo}");
			}

			if (filtro.Vlr_MinimoTaxa.HasValue && filtro.Vlr_MinimoTaxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_MinimoTaxa = {filtro.Vlr_MinimoTaxa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_DescontoEspecial))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_DescontoEspecial = '{filtro.Ds_DescontoEspecial.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoValorIntervaloBaixa))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_TipoValorIntervaloBaixa = '{filtro.Fl_TipoValorIntervaloBaixa.Trim().Replace("\'","")}'");
			}

			if (filtro.Vlr_IntervaloMaximoBaixa.HasValue && filtro.Vlr_IntervaloMaximoBaixa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_IntervaloMaximoBaixa = {filtro.Vlr_IntervaloMaximoBaixa}");
			}

			if (filtro.Vlr_IntervaloMinimoBaixa.HasValue && filtro.Vlr_IntervaloMinimoBaixa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_IntervaloMinimoBaixa = {filtro.Vlr_IntervaloMinimoBaixa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Juros))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Juros = '{filtro.Ds_Juros.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Multa))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Multa = '{filtro.Ds_Multa.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_Imposto))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_Imposto = '{filtro.Ds_Imposto.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizacaoValoresJurosMulta))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizacaoValoresJurosMulta = '{filtro.Fl_UtilizacaoValoresJurosMulta.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Sg_MoedaCorrente))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Sg_MoedaCorrente = '{filtro.Sg_MoedaCorrente.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_TributoJurosImposto.HasValue && filtro.Cd_TributoJurosImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoJurosImposto = {filtro.Cd_TributoJurosImposto}");
			}

			if (filtro.Cd_TributoMultasImposto.HasValue && filtro.Cd_TributoMultasImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoMultasImposto = {filtro.Cd_TributoMultasImposto}");
			}

			if (filtro.Cd_TributoCorrecaoImposto.HasValue && filtro.Cd_TributoCorrecaoImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoCorrecaoImposto = {filtro.Cd_TributoCorrecaoImposto}");
			}

			if (filtro.Cd_TributoTarifaBancaria.HasValue && filtro.Cd_TributoTarifaBancaria.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoTarifaBancaria = {filtro.Cd_TributoTarifaBancaria}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_DiretorioDocumentos))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_DiretorioDocumentos = '{filtro.Nm_DiretorioDocumentos.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoAtualizacaoValor))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_TipoAtualizacaoValor = '{filtro.Fl_TipoAtualizacaoValor.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoNrAviso))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_TipoNrAviso = '{filtro.Fl_TipoNrAviso.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnica))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelaUnica = '{filtro.Msg_ParcelaUnica.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelas))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_DemaisParcelas = '{filtro.Msg_DemaisParcelas.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_TipoAplicacaoJuros))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_TipoAplicacaoJuros = '{filtro.Nm_TipoAplicacaoJuros.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_TipoAplicacaoMulta))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_TipoAplicacaoMulta = '{filtro.Nm_TipoAplicacaoMulta.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_FicharecImposto.HasValue && filtro.Cd_FicharecImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_FicharecImposto = {filtro.Cd_FicharecImposto}");
			}

			if (filtro.Cd_FicharecTaxa.HasValue && filtro.Cd_FicharecTaxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_FicharecTaxa = {filtro.Cd_FicharecTaxa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_Ajuste))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_Ajuste = '{filtro.Fl_Ajuste.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_GrupoGuiaExpediente.HasValue && filtro.Cd_GrupoGuiaExpediente.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_GrupoGuiaExpediente = {filtro.Cd_GrupoGuiaExpediente}");
			}

			if (filtro.Cd_TributoJurosTaxa.HasValue && filtro.Cd_TributoJurosTaxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoJurosTaxa = {filtro.Cd_TributoJurosTaxa}");
			}

			if (filtro.Cd_TributoMultasTaxa.HasValue && filtro.Cd_TributoMultasTaxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoMultasTaxa = {filtro.Cd_TributoMultasTaxa}");
			}

			if (filtro.Cd_TributoCorrecaoTaxa.HasValue && filtro.Cd_TributoCorrecaoTaxa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_TributoCorrecaoTaxa = {filtro.Cd_TributoCorrecaoTaxa}");
			}

			if (filtro.Cd_FichaRecImpostoTaxas.HasValue && filtro.Cd_FichaRecImpostoTaxas.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_FichaRecImpostoTaxas = {filtro.Cd_FichaRecImpostoTaxas}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasVariaveis))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelasVariaveis = '{filtro.Msg_ParcelasVariaveis.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnicaTaxa))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelaUnicaTaxa = '{filtro.Msg_ParcelaUnicaTaxa.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelasTaxa))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_DemaisParcelasTaxa = '{filtro.Msg_DemaisParcelasTaxa.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasGuias))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelasGuias = '{filtro.Msg_ParcelasGuias.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasEventuais))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelasEventuais = '{filtro.Msg_ParcelasEventuais.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasExpediente))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelasExpediente = '{filtro.Msg_ParcelasExpediente.Trim().Replace("\'","")}'");
			}

			if (filtro.Vlr_ResCalculo.HasValue && filtro.Vlr_ResCalculo.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_ResCalculo = {filtro.Vlr_ResCalculo}");
			}

			if (filtro.Cd_ReceitaAClassificar.HasValue && filtro.Cd_ReceitaAClassificar.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ReceitaAClassificar = {filtro.Cd_ReceitaAClassificar}");
			}

			if (filtro.Cd_ClienteGOL.HasValue && filtro.Cd_ClienteGOL.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ClienteGOL = {filtro.Cd_ClienteGOL}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoNrOcorrencia))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_TipoNrOcorrencia = '{filtro.Fl_TipoNrOcorrencia.Trim().Replace("\'","")}'");
			}

			if (filtro.Dt_atualizacao.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_atualizacao = {filtro.Dt_atualizacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_usuario))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_usuario = '{filtro.Nm_usuario.Trim().Replace("\'","")}'");
			}

			if (filtro.Nr_ISSEAnoMesImplantacao.HasValue && filtro.Nr_ISSEAnoMesImplantacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEAnoMesImplantacao = {filtro.Nr_ISSEAnoMesImplantacao}");
			}

			if (filtro.Nr_ISSEMesesParaEscrituracao.HasValue && filtro.Nr_ISSEMesesParaEscrituracao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEMesesParaEscrituracao = {filtro.Nr_ISSEMesesParaEscrituracao}");
			}

			if (filtro.Nr_ISSEMesesParaRetificacao.HasValue && filtro.Nr_ISSEMesesParaRetificacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEMesesParaRetificacao = {filtro.Nr_ISSEMesesParaRetificacao}");
			}

			if (filtro.Nr_ISSEDiaVencimento.HasValue && filtro.Nr_ISSEDiaVencimento.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEDiaVencimento = {filtro.Nr_ISSEDiaVencimento}");
			}

			if (filtro.Nr_ISSENumeroDiasVencimento.HasValue && filtro.Nr_ISSENumeroDiasVencimento.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSENumeroDiasVencimento = {filtro.Nr_ISSENumeroDiasVencimento}");
			}

			if (filtro.Nr_ISSEPermitirOutraAtividade.HasValue && filtro.Nr_ISSEPermitirOutraAtividade.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEPermitirOutraAtividade = {filtro.Nr_ISSEPermitirOutraAtividade}");
			}

			if (filtro.Nr_ISSEDiasStandBy.HasValue && filtro.Nr_ISSEDiasStandBy.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEDiasStandBy = {filtro.Nr_ISSEDiasStandBy}");
			}

			if (filtro.Nr_ISSEConfirmacaoCadastro.HasValue && filtro.Nr_ISSEConfirmacaoCadastro.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEConfirmacaoCadastro = {filtro.Nr_ISSEConfirmacaoCadastro}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ObsAdicionaisCapaCarne))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ObsAdicionaisCapaCarne = '{filtro.Msg_ObsAdicionaisCapaCarne.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_emiteAlvaraWEB))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_emiteAlvaraWEB = '{filtro.Fl_emiteAlvaraWEB.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_TipoValorIntervaloBaixaDVAT))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_TipoValorIntervaloBaixaDVAT = '{filtro.Fl_TipoValorIntervaloBaixaDVAT.Trim().Replace("\'","")}'");
			}

			if (filtro.Vlr_IntervaloMaximoBaixaDVAT.HasValue && filtro.Vlr_IntervaloMaximoBaixaDVAT.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_IntervaloMaximoBaixaDVAT = {filtro.Vlr_IntervaloMaximoBaixaDVAT}");
			}

			if (filtro.Vlr_IntervaloMinimoBaixaDVAT.HasValue && filtro.Vlr_IntervaloMinimoBaixaDVAT.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_IntervaloMinimoBaixaDVAT = {filtro.Vlr_IntervaloMinimoBaixaDVAT}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ISSESenhaAdmin))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ISSESenhaAdmin = '{filtro.Ds_ISSESenhaAdmin.Trim().Replace("\'","")}'");
			}

			if (filtro.Nr_NFEQtdeDiasPreCadastro.HasValue && filtro.Nr_NFEQtdeDiasPreCadastro.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_NFEQtdeDiasPreCadastro = {filtro.Nr_NFEQtdeDiasPreCadastro}");
			}

			if (filtro.Nr_NFEQtdeNFBloco.HasValue && filtro.Nr_NFEQtdeNFBloco.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_NFEQtdeNFBloco = {filtro.Nr_NFEQtdeNFBloco}");
			}

			if (filtro.Nr_NFEQtdeDiasRPS.HasValue && filtro.Nr_NFEQtdeDiasRPS.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_NFEQtdeDiasRPS = {filtro.Nr_NFEQtdeDiasRPS}");
			}

			if (filtro.Cd_NFETipoDocto.HasValue && filtro.Cd_NFETipoDocto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NFETipoDocto = {filtro.Cd_NFETipoDocto}");
			}

			if (filtro.Cd_NFETipoDoctoRPS.HasValue && filtro.Cd_NFETipoDoctoRPS.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_NFETipoDoctoRPS = {filtro.Cd_NFETipoDoctoRPS}");
			}

			if (filtro.Fl_NFEDiscriminaImposto.HasValue && filtro.Fl_NFEDiscriminaImposto.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NFEDiscriminaImposto = {filtro.Fl_NFEDiscriminaImposto}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_NFECapaBloco))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_NFECapaBloco = '{filtro.Ds_NFECapaBloco.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_permiteAlteracaoSenhaWEB))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_permiteAlteracaoSenhaWEB = '{filtro.Fl_permiteAlteracaoSenhaWEB.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnica_Ambulantes))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelaUnica_Ambulantes = '{filtro.Msg_ParcelaUnica_Ambulantes.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelas_Ambulantes))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_DemaisParcelas_Ambulantes = '{filtro.Msg_DemaisParcelas_Ambulantes.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelaUnicaTaxa_Ambulantes))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelaUnicaTaxa_Ambulantes = '{filtro.Msg_ParcelaUnicaTaxa_Ambulantes.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_DemaisParcelasTaxa_Ambulantes))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_DemaisParcelasTaxa_Ambulantes = '{filtro.Msg_DemaisParcelasTaxa_Ambulantes.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasGuias_Ambulantes))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelasGuias_Ambulantes = '{filtro.Msg_ParcelasGuias_Ambulantes.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_ControleAmbulanteInicial.HasValue && filtro.Cd_ControleAmbulanteInicial.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ControleAmbulanteInicial = {filtro.Cd_ControleAmbulanteInicial}");
			}

			if (filtro.Cd_ControleAmbulanteFinal.HasValue && filtro.Cd_ControleAmbulanteFinal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ControleAmbulanteFinal = {filtro.Cd_ControleAmbulanteFinal}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_ParcelasExpediente_Ambulantes))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_ParcelasExpediente_Ambulantes = '{filtro.Msg_ParcelasExpediente_Ambulantes.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_PermitirAcessoGuiaAvulsa.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_PermitirAcessoGuiaAvulsa = {filtro.Fl_PermitirAcessoGuiaAvulsa}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Msg_NotificacaoCarne))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Msg_NotificacaoCarne = '{filtro.Msg_NotificacaoCarne.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_VerificaAlvaraBombeiros.HasValue && filtro.Fl_VerificaAlvaraBombeiros.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_VerificaAlvaraBombeiros = {filtro.Fl_VerificaAlvaraBombeiros}");
			}

			if (filtro.Nr_QtdDiasVencimentoAlvaraWeb.HasValue && filtro.Nr_QtdDiasVencimentoAlvaraWeb.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_QtdDiasVencimentoAlvaraWeb = {filtro.Nr_QtdDiasVencimentoAlvaraWeb}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_UrlCadastroWeb))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_UrlCadastroWeb = '{filtro.Ds_UrlCadastroWeb.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_ISSEVencimento.HasValue && filtro.Cd_ISSEVencimento.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_ISSEVencimento = {filtro.Cd_ISSEVencimento}");
			}

			if (filtro.Pc_desconto_Principal.HasValue && filtro.Pc_desconto_Principal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_desconto_Principal = {filtro.Pc_desconto_Principal}");
			}

			if (filtro.Pc_desconto_Multa.HasValue && filtro.Pc_desconto_Multa.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_desconto_Multa = {filtro.Pc_desconto_Multa}");
			}

			if (filtro.Pc_desconto_Juros.HasValue && filtro.Pc_desconto_Juros.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_desconto_Juros = {filtro.Pc_desconto_Juros}");
			}

			if (filtro.Pc_desconto_Correcao.HasValue && filtro.Pc_desconto_Correcao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_desconto_Correcao = {filtro.Pc_desconto_Correcao}");
			}

			if (filtro.Fl_AceitedoTomador.HasValue && filtro.Fl_AceitedoTomador.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AceitedoTomador = {filtro.Fl_AceitedoTomador}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Nm_TipoAplicacaoCorrecao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nm_TipoAplicacaoCorrecao = '{filtro.Nm_TipoAplicacaoCorrecao.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ISSEMsgPersonalRPS))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ISSEMsgPersonalRPS = '{filtro.Ds_ISSEMsgPersonalRPS.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_URLISSEletronico))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_URLISSEletronico = '{filtro.Ds_URLISSEletronico.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_InibirInfo))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_InibirInfo = '{filtro.Fl_InibirInfo.Trim().Replace("\'","")}'");
			}

			if (filtro.Fl_NaoConsultarDivida.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NaoConsultarDivida = {filtro.Fl_NaoConsultarDivida}");
			}

			if (filtro.Fl_UtilizaDescAtivBoleto.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizaDescAtivBoleto = {filtro.Fl_UtilizaDescAtivBoleto}");
			}

			if (filtro.Dt_VencMaxImpressaoParcelaWeb.HasValue)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Dt_VencMaxImpressaoParcelaWeb = {filtro.Dt_VencMaxImpressaoParcelaWeb}");
			}

			if (filtro.Vlr_ValorMinimoISSEletronico.HasValue && filtro.Vlr_ValorMinimoISSEletronico.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vlr_ValorMinimoISSEletronico = {filtro.Vlr_ValorMinimoISSEletronico}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_PermiteEncerrar))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_PermiteEncerrar = '{filtro.Fl_PermiteEncerrar.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_FinalidadeParcelasWeb))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_FinalidadeParcelasWeb = '{filtro.Ds_FinalidadeParcelasWeb.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AtualizaEmissaoGuiaWEB))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AtualizaEmissaoGuiaWEB = '{filtro.Fl_AtualizaEmissaoGuiaWEB.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AlteraDECA))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AlteraDECA = '{filtro.Fl_AlteraDECA.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_VerDebExercDVAT))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_VerDebExercDVAT = '{filtro.Fl_VerDebExercDVAT.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_ConsistirPagtoCancNF))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_ConsistirPagtoCancNF = '{filtro.Fl_ConsistirPagtoCancNF.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_subGrupoTxCompensacao.HasValue && filtro.Cd_subGrupoTxCompensacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_subGrupoTxCompensacao = {filtro.Cd_subGrupoTxCompensacao}");
			}

			if (filtro.Cd_tributoTxCompensacao.HasValue && filtro.Cd_tributoTxCompensacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_tributoTxCompensacao = {filtro.Cd_tributoTxCompensacao}");
			}

			if (filtro.Vl_TxCompensacao.HasValue && filtro.Vl_TxCompensacao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Vl_TxCompensacao = {filtro.Vl_TxCompensacao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirRetencaoTomador))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NaoPermitirRetencaoTomador = '{filtro.Fl_NaoPermitirRetencaoTomador.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirCancNotasGuiaPaga))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NaoPermitirCancNotasGuiaPaga = '{filtro.Fl_NaoPermitirCancNotasGuiaPaga.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirRetencaoTomadorSuperSimples))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NaoPermitirRetencaoTomadorSuperSimples = '{filtro.Fl_NaoPermitirRetencaoTomadorSuperSimples.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_taxaGuiaeventual.HasValue && filtro.Cd_taxaGuiaeventual.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_taxaGuiaeventual = {filtro.Cd_taxaGuiaeventual}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirCancNotaGuiaGerada))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NaoPermitirCancNotaGuiaGerada = '{filtro.Fl_NaoPermitirCancNotaGuiaGerada.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_NaoPermitirCancNotaGuiaVencida))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_NaoPermitirCancNotaGuiaVencida = '{filtro.Fl_NaoPermitirCancNotaGuiaVencida.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_UtilizaBeneficioFiscal))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_UtilizaBeneficioFiscal = '{filtro.Fl_UtilizaBeneficioFiscal.Trim().Replace("\'","")}'");
			}

			if (filtro.Cd_BeneficioFiscal.HasValue && filtro.Cd_BeneficioFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Cd_BeneficioFiscal = {filtro.Cd_BeneficioFiscal}");
			}

			if (filtro.Pc_AliquotaBeneficioFiscal.HasValue && filtro.Pc_AliquotaBeneficioFiscal.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Pc_AliquotaBeneficioFiscal = {filtro.Pc_AliquotaBeneficioFiscal}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ServicosBeneficioFiscal))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ServicosBeneficioFiscal = '{filtro.Ds_ServicosBeneficioFiscal.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_UrlAPIIntegracaoNFE))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_UrlAPIIntegracaoNFE = '{filtro.Ds_UrlAPIIntegracaoNFE.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_UrlAPIIntegracaoNFEDados))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_UrlAPIIntegracaoNFEDados = '{filtro.Ds_UrlAPIIntegracaoNFEDados.Trim().Replace("\'","")}'");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Fl_AliquotaDiferenteLocalPrestacao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Fl_AliquotaDiferenteLocalPrestacao = '{filtro.Fl_AliquotaDiferenteLocalPrestacao.Trim().Replace("\'","")}'");
			}

			if (filtro.Nr_ISSEqtdeDiasCancelAposEmissao.HasValue && filtro.Nr_ISSEqtdeDiasCancelAposEmissao.Value > 0)
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Nr_ISSEqtdeDiasCancelAposEmissao = {filtro.Nr_ISSEqtdeDiasCancelAposEmissao}");
			}

			if (!string.IsNullOrWhiteSpace(filtro.Ds_ISSEleiPermissaoCancelAposEmissao))
			{
				if (sqlWhere.Length > 0) sqlWhere.Append(" AND ");
				sqlWhere.AppendLine($" Ds_ISSEleiPermissaoCancelAposEmissao = '{filtro.Ds_ISSEleiPermissaoCancelAposEmissao.Trim().Replace("\'","")}'");
			}
			*/


            #endregion

            #region Relacionamentos
            #endregion

            if (sqlWhere.Length > 0)
            {
                sql.AppendLine(" WHERE " + sqlWhere.ToString());
            }

            return await _issParametrosCalcRepositorio.DbSetEntity.FromSqlRaw(sql.ToString()).AsNoTracking().ToListAsync();
        }


        /*
        public async Task<int> UpdateExemploSQL()
        {
            // MODELO PADRÃO, 
            // UTILIZADO SOMENTE PARA EXEMPLO, 
            // POR FAVOR ALTERAR OS CAMPOS DA QUERY COM OS CAMPOS DA RESPECTIVA CLASSE
            // APAGAR ESSE COMENTÁRIO

            string sql = "UPDATE ISSParametrosCalc SET campo = 'valor' WHERE pk = 666";

            return await _issParametrosCalcRepositorio.DbContext.Database.ExecuteSqlRawAsync(sql);
        }
        */
    }
}
