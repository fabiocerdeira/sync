﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssComunicadoUsuarioWebFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades


		public decimal? Cd_Comunicado { get; set; }

		public decimal? Nr_CGCCPF { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
