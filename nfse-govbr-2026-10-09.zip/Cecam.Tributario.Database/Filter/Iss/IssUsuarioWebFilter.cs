﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssUsuarioWebFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public string? Nr_CGCCPF { get; set; }

		public string? Nm_Usuario { get; set; }

		public string? Nm_Login { get; set; }

		public string? Pw_Login { get; set; }

		public string? Ds_email { get; set; }

		public byte? Fl_Tipo { get; set; }

		public byte? Nr_Acesso { get; set; }

		public decimal? Cd_Contribuinte { get; set; }

		public DateTime? Dt_Cadastro { get; set; }

		public string? Ds_Usuario { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
