﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssItensAtividadesFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public int? Cd_grupo_atividade { get; set; }

		public int? Cd_sub_grupo_atividade { get; set; }

		public int? Cd_item_atividade { get; set; }

		public string? Ds_item_atividade { get; set; }

		public string? Cd_Servico { get; set; }

		public decimal? Vl_Taxa { get; set; }

		public string? Sg_IndiceFinanceiro { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public string? Nm_Usuario { get; set; }

		public byte? Fl_Eventual { get; set; }

		public byte? Fl_Web { get; set; }

		public decimal? Cd_AtividadeCNAE { get; set; }

		public string? Fl_ResponsavelTecnicoObras { get; set; }

		public string? Fl_Item_Atividade_NFE { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
