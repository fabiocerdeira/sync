﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssEventualFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades


		public decimal? Cd_Eventual { get; set; }

		public string? Ds_RazaoSocial { get; set; }

		public string? Nr_CGCCPF { get; set; }

		public string? Ds_EnderTributario { get; set; }

		public string? Ds_BairroTributario { get; set; }

		public string? Ds_CidadeTributario { get; set; }

		public string? Cd_CepTributario { get; set; }

        #region Endereço Correspondência

        public string? Ds_EnderCorr { get; set; }

		public string? Ds_ComplCorr { get; set; }

		public string? Ds_BairroCorr { get; set; }

		public string? Ds_CidadeCorr { get; set; }

		public string? Cd_CepCorr { get; set; }

		public string? Sg_EstadoCorr { get; set; }

        #endregion

        public string? Ds_Item_Atividade { get; set; }

		public byte? Fl_web { get; set; }

		public string? Cd_RG_IE { get; set; }

		public string? Sg_EstadoTributario { get; set; }

		public string? Cd_TelefoneTributario { get; set; }

		public string? Cd_FAXTributario { get; set; }

		public string? Ds_Email { get; set; }

		public string? Nm_Contato { get; set; }

		public string? Nm_ResponsavelCadastroWeb { get; set; }

		public string? Nr_ResponsavelCadastroWebCPF { get; set; }

		public string? Nr_ResponsavelCadastroWebRG { get; set; }

		public string? Ds_ResponsavelCadastroWebEmail { get; set; }

		public int? Cd_Grupo_Atividade { get; set; }

		public int? Cd_Sub_Grupo_Atividade { get; set; }

		public int? Cd_Item_Atividade { get; set; }

		public DateTime? Dt_Criacao { get; set; }

		public string? Nm_UsuarioCriacao { get; set; }

		public byte? Fl_CadastroOBRAS { get; set; }

		public string? Ds_Inscricao_Municipal { get; set; }

		public string? Ds_Inscricao_Estadual { get; set; }

		public string? Ds_ComplTributario { get; set; }

		public byte? Fl_IgnorarISSWEB { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public string? Nm_UsuarioAtualizacao { get; set; }

		public byte? Fl_IncentivoFiscal { get; set; }

		public string? Nr_Registro { get; set; }

		public int? Cd_Conselho_Regional { get; set; }

		public string? Ds_Registro_Conselho { get; set; }

		public int? Cd_TipoCalculo { get; set; }

		public string? Cd_NumeroTributario { get; set; }

		public string? Cd_NumeroCorr { get; set; }

		public string? Ds_EmailTributario { get; set; }

		public string? Ds_EmailCorr { get; set; }

		public string? Cd_TelefoneCorr { get; set; }

        
		#endregion


        #region Relacionamentos
        #endregion
    }
}
