﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class CecamImpostoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades


		public Guid? Cd_Imposto { get; set; }

		public string? Sg_Imposto { get; set; }

		public string? Ds_Imposto { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
