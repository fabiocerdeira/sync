﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssComunicadoWebFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public decimal? Cd_Comunicado { get; set; }

		public DateTime? Dt_Criacao { get; set; }

		public DateTime? Dt_Validade { get; set; }

		public string? Ds_Titulo { get; set; }

		public string? Ds_Assunto { get; set; }

		public string? Ds_Anexo { get; set; }

		public byte? Fl_Especifico { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
