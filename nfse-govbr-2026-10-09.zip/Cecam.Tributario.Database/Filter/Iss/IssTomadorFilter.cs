﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssTomadorFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region PK

        public string? Nr_CGCCPF { get; set; }

        public string? Cd_Usuario { get; set; }

        #endregion

        #region Propriedades

        public string? Ds_inscricao_municipal { get; set; }

        public decimal? Cd_Tomador { get; set; }

        public decimal? Cd_MunicipioTomador { get; set; }

        public string? Sg_UF { get; set; }
        
        /*
		public string? Ds_RazaoSocial { get; set; }

		public byte? Fl_TipoPessoa { get; set; }

		public string? Ds_Logradouro { get; set; }

		public string? Cd_Numero { get; set; }

		public string? Ds_Complemento { get; set; }

		public string? Ds_Bairro { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }


		public string? Ds_Email { get; set; }

		public string? Cd_CEP { get; set; }

		public string? Cd_RG_IE { get; set; }

		public int? Cd_TipoCalculo { get; set; }
		*/


        #endregion


        #region Relacionamentos
        #endregion
    }
}
