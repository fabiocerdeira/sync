﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Iss
{
    public class IssServicoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public string? Cd_Servico { get; set; }

		public int? Cd_incidencia { get; set; }

		public string? Sg_IndiceFinanceiro { get; set; }

		public string? Ds_Servico { get; set; }

		public decimal? Vl_Fixo { get; set; }

		public decimal? Vl_Aliquota { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public string? Nm_Usuario { get; set; }

		public byte? Fl_Local { get; set; }

		public byte? Fl_AceitaDeducao { get; set; }

		public byte? Fl_AceitaRetido { get; set; }

		public byte? Fl_Web { get; set; }

		public decimal? Vl_PercDeducao { get; set; }

		public string? Fl_tipoLancamentoISSWeb { get; set; }

		public byte? FL_OBRIGARETENCAO { get; set; }

		public byte? Fl_ImpDevidoDomTomador { get; set; }

		public byte? Fl_ExcetoMEI { get; set; }

		public decimal? Vl_AliquotaRetroativa { get; set; }

		public DateTime? Dt_LimiteIncidencia { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
