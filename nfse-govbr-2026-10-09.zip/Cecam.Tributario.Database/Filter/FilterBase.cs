﻿using Cecam.Tributario.Extend.Globals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Filter
{
    public abstract class FilterBase
    {
        public bool AsNoTracking { get; set; } = true;

        public int? QtdMaximaRegistrosRetornados { get; set; }


        #region Propriedades

        /// <summary>
        /// Cd_Cecam tem valor default carregado do ParametrosGlobal usando o appSettings
        /// </summary>
        public int? Cd_Cecam { get; set; } = ParametrosGlobal.Cd_Cecam;

        /// <summary>
        /// Cd_Exercicio tem valor default carregado do ParametrosGlobal usando o DateTime.Year
        /// </summary>
        public int? Cd_Exercicio { get; set; } = ParametrosGlobal.Cd_Exercicio;

        #endregion
    }
}

