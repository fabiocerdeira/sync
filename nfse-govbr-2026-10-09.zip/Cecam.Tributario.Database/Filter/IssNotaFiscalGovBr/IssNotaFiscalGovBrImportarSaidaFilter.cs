﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrImportarSaidaFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public int? Id { get; set; }

		public int? FilaTipo { get; set; }

		public int? Status { get; set; }

		public string? ChaveAcesso { get; set; }

		public long? Nsu { get; set; }

		public string? NfseId { get; set; }

		public string? DpsId { get; set; }

		/*
		public DateTime? DataHoraDocumento { get; set; }
		*/

		public string? TipoDocumento { get; set; }

		public string? TipoEvento { get; set; }
		
		/*
		public DateTime? DataHoraCriacao { get; set; }

		public DateTime? DataHoraProcessamento { get; set; }

		public string? Corpo { get; set; }

		public string? Mensagem { get; set; }
		*/


        #endregion

        #region Relacionamentos
        #endregion
    }
}
