﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr
{
    public class ISSNotaFiscalGovBrDocArrecadacaoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public long? Id { get; set; }

		public int? Cd_Cecam { get; set; }

		public decimal? Cd_NotaFiscal { get; set; }

		public DateTime? Dt_criacao { get; set; }

		public DateTime? Dt_vencimento { get; set; }

		public DateTime? Dt_cancelamento { get; set; }

		public DateTime? Dt_pagamento { get; set; }

		public decimal? Vl_tributo { get; set; }

		public decimal? Nr_Certificado { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
