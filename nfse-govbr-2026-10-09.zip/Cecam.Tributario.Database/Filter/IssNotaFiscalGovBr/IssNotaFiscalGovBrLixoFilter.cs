﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrLixoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public int? Id { get; set; }

		public decimal? ValorDecimalA { get; set; }

		public decimal? ValorNumericA { get; set; }

		public string? Corpo { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
