﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscal
{
    public class IssNotaFiscalRejeicaoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public decimal? Cd_NotaFiscal { get; set; }

		public string? Ds_Rejeicao { get; set; }

		public DateTime? Dt_AceitoRejeitado { get; set; }

		public string? Fl_AceitoRejeitado { get; set; }

        #endregion


        #region Relacionamentos
        #endregion
    }
}
