﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscal
{
    public class IssNotaFiscalServicoVinculoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades


		public string? Cd_Servico { get; set; }

		public string? Cd_tributacaoNacional { get; set; }

		public string? Cd_nbs { get; set; }


        #endregion

        #region Relacionamentos
        #endregion
    }
}
