﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscal
{
    public class IssNotaFiscalImpostoFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

        /*
		public Guid? Cd_NotaFiscal_Imposto { get; set; }
        */

		public decimal? Cd_NotaFiscal { get; set; }

        /*
		public Guid? Cd_Imposto { get; set; }

		public decimal? Vl_imposto { get; set; }
        */


        #endregion

        #region Relacionamentos
        #endregion
    }
}
