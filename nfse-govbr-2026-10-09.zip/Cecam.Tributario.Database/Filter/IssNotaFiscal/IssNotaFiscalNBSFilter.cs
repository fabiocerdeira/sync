﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssNotaFiscal
{
    public class IssNotaFiscalNBSFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public string? Cd_nbs { get; set; }

		public string? Ds_nbsDescricao { get; set; }

        public string? Cd_nbsFormatado { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
