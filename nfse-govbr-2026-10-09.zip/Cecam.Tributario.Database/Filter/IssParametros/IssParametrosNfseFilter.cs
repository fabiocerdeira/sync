﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.IssParametros
{
    public class IssParametrosNfseFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public decimal? Cd_IBGE { get; set; }

        /*
		public string? Nr_CNPJMunicipio { get; set; }

		public string? Nr_legislacaoBenefício { get; set; }
        */


        #endregion

        #region Relacionamentos
        #endregion
    }
}
