﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Endereco
{
    public class CecamMunicipioFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public decimal? Cd_MunicipioIBGE { get; set; }

		public decimal? Cd_Municipio { get; set; }

        /// <summary>
        /// Sigla do Estado Brasileiro
        /// OP = Outros paises
        /// </summary>
        public string? Sg_UF { get; set; }

        /*
		public short? Nr_Ano { get; set; }

		public string? Ds_NomeMunicipio { get; set; }

		public decimal? Cd_CEPInicial { get; set; }

		public decimal? Cd_CEPFinal { get; set; }

		public int? Cd_Jucesp { get; set; }
        */


        #endregion

        #region Relacionamentos
        #endregion
    }
}
