﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Endereco
{
    public class CecamLogradouroFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public string? Cd_Logradouro { get; set; }

		/*
		public string? Ds_TipoLogradouro { get; set; }

		public string? Ds_Logradouro { get; set; }

		public string? Ds_Antigo { get; set; }

		public string? Ds_LeiDecreto { get; set; }

		public string? Fl_inativo { get; set; }

		public string? Fl_sistema { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public string? Nm_usuario { get; set; }

		public byte? Fl_Web { get; set; }

		public int? Cd_Loteamento { get; set; }

		public string? Ds_Loteamento { get; set; }

		public int? Cd_bairro { get; set; }

		public string? Ds_bairro { get; set; }

		public int? Cd_CEP { get; set; }
		*/


        #endregion

        #region Relacionamentos
        #endregion
    }
}
