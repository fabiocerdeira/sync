﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Endereco
{
    public class CecamPaisIbgeFilter : FilterBase
    {
        #region Propriedades


		public string? Sg_pais_ISO2 { get; set; }

		public string? Ds_paisDescricao { get; set; }


        #endregion

        #region Relacionamentos
        #endregion
    }
}
