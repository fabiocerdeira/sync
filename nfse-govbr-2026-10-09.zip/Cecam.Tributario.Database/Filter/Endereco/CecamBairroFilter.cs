﻿using Cecam.Tributario.Database.Filter;

namespace Cecam.Tributario.Database.Filter.Endereco
{
    public class CecamBairroFilter : FilterBase
    {
        // MODELO PADRÃO, 
        // REMOVER OS CAMPOS QUE NÃO PRECISAM SER PARTE DO FILTRO
        // APAGAR ESSE COMENTÁRIO
        // TODOS OS CAMPOS DO FILTER DEVEM SER NULLABLES (?)

        #region Propriedades

		public int? Cd_Bairro { get; set; }

        /*
		public string? Ds_Bairro { get; set; }

		public string? Cd_classificacaobairro { get; set; }

		public string? Fl_inativo { get; set; }

		public string? Fl_sistema { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public string? Nm_usuario { get; set; }

		public byte? Fl_Web { get; set; }
        */


        #endregion

        #region Relacionamentos
        #endregion
    }
}
