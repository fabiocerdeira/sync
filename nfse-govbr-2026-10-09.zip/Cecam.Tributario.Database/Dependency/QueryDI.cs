﻿using Cecam.Tributario.Database.Query.Endereco;
using Cecam.Tributario.Database.Query.Iss;
using Cecam.Tributario.Database.Query.IssArrecadacao;
using Cecam.Tributario.Database.Query.IssNotaFiscal;
using Cecam.Tributario.Database.Query.ISSNotaFiscal;
using Cecam.Tributario.Database.Query.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Query.IssParametros;
using Cecam.Tributario.Database.QueryInterface.Endereco;
using Cecam.Tributario.Database.QueryInterface.Iss;
using Cecam.Tributario.Database.QueryInterface.IssArrecadacao;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.QueryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.QueryInterface.IssParametros;
using Microsoft.Extensions.DependencyInjection;

namespace Cecam.Tributario.Database.Dependency
{
    public static class QueryDI
    {
        public static IServiceCollection QueryAddServices(this IServiceCollection services)
        {
            // Endereco
            services.AddTransient<ICecamBairroQuery, CecamBairroQuery>();
            services.AddTransient<ICecamLogradouroQuery, CecamLogradouroQuery>();
            services.AddTransient<ICecamMunicipioQuery, CecamMunicipioQuery>();
            services.AddTransient<ICecamPaisIbgeQuery, CecamPaisIbgeQuery>();

            // Iss
            services.AddTransient<ICecamImpostoQuery, CecamImpostoQuery>();
            services.AddTransient<IIssComunicadoUsuarioWebQuery, IssComunicadoUsuarioWebQuery>();
            services.AddTransient<IIssComunicadoWebQuery, IssComunicadoWebQuery>();
            services.AddTransient<IIssContribuinteQuery, IssContribuinteQuery>();
            services.AddTransient<IIssEventualQuery, IssEventualQuery>();
            services.AddTransient<IIssItensAtividadesQuery, IssItensAtividadesQuery>();
            services.AddTransient<IIssServicoQuery, IssServicoQuery>();
            services.AddTransient<IIssTomadorQuery, IssTomadorQuery>();
            services.AddTransient<IIssUsuarioWebQuery, IssUsuarioWebQuery>();

            // IssArrecadacao
            services.AddTransient<IIssCertificadoQuery, IssCertificadoQuery>();
            services.AddTransient<IIssParcelaQuery, IssParcelaQuery>();

            // IssNotaFiscal
            services.AddTransient<IIssNotaFiscalImpostoQuery, IssNotaFiscalImpostoQuery>();
            services.AddTransient<IIssNotaFiscalItemQuery, IssNotaFiscalItemQuery>();
            services.AddTransient<IIssNotaFiscalNBSQuery, IssNotaFiscalNBSQuery>();
            services.AddTransient<IIssNotaFiscalQuery, IssNotaFiscalQuery>();
            services.AddTransient<IIssNotaFiscalRejeicaoQuery, IssNotaFiscalRejeicaoQuery>();
            services.AddTransient<IIssNotaFiscalServicoNacionalQuery, IssNotaFiscalServicoNacionalQuery>();
            services.AddTransient<IIssNotaFiscalServicoVinculoQuery, IssNotaFiscalServicoVinculoQuery>();

            // IssNotaFiscalGovBr
            services.AddTransient<IISSNotaFiscalGovBrDocArrecadacaoQuery, ISSNotaFiscalGovBrDocArrecadacaoQuery>();
            services.AddTransient<IIssNotaFiscalGovBrFilaEntradaQuery, IssNotaFiscalGovBrFilaEntradaQuery>();
            services.AddTransient<IIssNotaFiscalGovBrFilaSaidaQuery, IssNotaFiscalGovBrFilaSaidaQuery>();
            services.AddTransient<IIssNotaFiscalGovBrImportarEntradaQuery, IssNotaFiscalGovBrImportarEntradaQuery>();
            services.AddTransient<IIssNotaFiscalGovBrImportarSaidaQuery, IssNotaFiscalGovBrImportarSaidaQuery>();
            services.AddTransient<IIssNotaFiscalGovBrLixoQuery, IssNotaFiscalGovBrLixoQuery>();

            // IssParametros
            services.AddTransient<IIssParametrosNfseQuery, IssParametrosNfseQuery>();
            services.AddTransient<IIssParametrosCalcQuery, IssParametrosCalcQuery>();

            return services;
        }
    }
}
