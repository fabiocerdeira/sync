﻿using Cecam.Tributario.Database.Repository.Endereco;
using Cecam.Tributario.Database.Repository.Iss;
using Cecam.Tributario.Database.Repository.IssArrecadacao;
using Cecam.Tributario.Database.Repository.IssNotaFiscal;
using Cecam.Tributario.Database.Repository.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Repository.IssParametros;
using Cecam.Tributario.Database.Repository.SysObject;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Database.RepositoryInterface.IssArrecadacao;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.RepositoryInterface.IssParametros;
using Cecam.Tributario.Database.RepositoryInterface.SysObject;
using Microsoft.Extensions.DependencyInjection;

namespace Cecam.Tributario.Database.Dependency
{
    public static class RepositoryDI
    {
        public static IServiceCollection RepositoryAddServices(this IServiceCollection services)
        {
            // repositorios

            // Endereco
            services.AddTransient<ICecamBairroRepository>(p => { return new CecamBairroRepository(); });
            services.AddTransient<ICecamLogradouroRepository>(p => { return new CecamLogradouroRepository(); });
            services.AddTransient<ICecamMunicipioRepository>(p => { return new CecamMunicipioRepository(); });
            services.AddTransient<ICecamPaisIbgeRepository>(p => { return new CecamPaisIbgeRepository(); });

            // Iss
            services.AddTransient<ICecamImpostoRepository>(p => { return new CecamImpostoRepository(); });
            services.AddTransient<IIssComunicadoUsuarioWebRepository>(p => { return new IssComunicadoUsuarioWebRepository(); });
            services.AddTransient<IIssComunicadoWebRepository>(p => { return new IssComunicadoWebRepository(); });
            services.AddTransient<IIssContribuinteRepository>(p => { return new IssContribuinteRepository(); });
            services.AddTransient<IIssEventualRepository>(p => { return new IssEventualRepository(); });
            services.AddTransient<IIssItensAtividadesRepository>(p => { return new IssItensAtividadesRepository(); });
            services.AddTransient<IIssServicoRepository>(p => { return new IssServicoRepository(); });
            services.AddTransient<IIssTomadorRepository>(p => { return new IssTomadorRepository(); });
            services.AddTransient<IIssUsuarioWebRepository>(p => { return new IssUsuarioWebRepository(); });

            // IssArrecadacao
            services.AddTransient<IIssCertificadoRepository>(p => { return new IssCertificadoRepository(); });
            services.AddTransient<IIssParcelaRepository>(p => { return new IssParcelaRepository(); });

            // IssNotaFiscal
            services.AddTransient<IIssNotaFiscalImpostoRepository>(p => { return new IssNotaFiscalImpostoRepository(); });
            services.AddTransient<IIssNotaFiscalItemRepository>(p => { return new IssNotaFiscalItemRepository(); });
            services.AddTransient<IIssNotaFiscalNBSRepository>(p => { return new IssNotaFiscalNBSRepository(); });
            services.AddTransient<IIssNotaFiscalRejeicaoRepository>(p => { return new IssNotaFiscalRejeicaoRepository(); });
            services.AddTransient<IIssNotaFiscalRepository>(p => { return new IssNotaFiscalRepository(); });
            services.AddTransient<IIssNotaFiscalServicoNacionalRepository>(p => { return new IssNotaFiscalServicoNacionalRepository(); });
            services.AddTransient<IIssNotaFiscalServicoVinculoRepository>(p => { return new IssNotaFiscalServicoVinculoRepository(); });

            // IssNotaFiscalGovBr
            services.AddTransient<IIssNotaFiscalGovBrFilaEntradaRepository>(p => { return new IssNotaFiscalGovBrFilaEntradaRepository(); });
            services.AddTransient<IIssNotaFiscalGovBrFilaSaidaRepository>(p => { return new IssNotaFiscalGovBrFilaSaidaRepository(); });
            services.AddTransient<IIssNotaFiscalGovBrImportarEntradaRepository>(p => { return new IssNotaFiscalGovBrImportarEntradaRepository(); });
            services.AddTransient<IIssNotaFiscalGovBrImportarSaidaRepository>(p => { return new IssNotaFiscalGovBrImportarSaidaRepository(); });
            services.AddTransient<IIssNotaFiscalGovBrLixoRepository>(p => { return new IssNotaFiscalGovBrLixoRepository(); });

            // IssParametros
            services.AddTransient<IIssParametrosNfseRepository>(p => { return new IssParametrosNfseRepository(); });
            services.AddTransient<IIssParametrosCalcRepository>(p => { return new IssParametrosCalcRepository(); });

            // SysObject
            services.AddTransient<ISysColumnRepository>(p => { return new SysColumnRepository(); });
            services.AddTransient<ISysIndexColumnRepository>(p => { return new SysIndexColumnRepository(); });
            services.AddTransient<ISysIndexRepository>(p => { return new SysIndexRepository(); });
            services.AddTransient<ISysObjectRepository>(p => { return new SysObjectRepository(); });

            return services;
        }
    }
}
