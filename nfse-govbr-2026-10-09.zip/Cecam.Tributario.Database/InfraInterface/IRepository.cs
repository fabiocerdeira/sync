﻿using Microsoft.EntityFrameworkCore;

namespace Cecam.Tributario.Database.InfraInterface
{
    public interface IRepository<TEntity> where TEntity : class
    {
        #region Contexto

        ITributosContext DbContext { get; }

        DbSet<TEntity> DbSetEntity { get; }

        void SetUnitOfWork(IUnitOfWork unit);

        #endregion


        IQueryable<TEntity> GetIQueryable();

        void Add(TEntity entity);

        void AddList(List<TEntity> entities);

        void Update(TEntity entity);

        void UpdateList(List<TEntity> entities);

        Task<int> SaveChangesAsync();


        #region Transação

        Task BeginTransactionAsync();

        Task CommitTransactionAsync();

        Task RollbackTransactionAsync();

        #endregion


        /*
        void Add(TEntity entity);

        void AddRange(IEnumerable<TEntity> entity);


        void UpdateRange(IEnumerable<TEntity> entities);

        void Delete(TEntity entity);

        void DeleteRange(IEnumerable<TEntity> entity);

        [Obsolete("Utilize SaveChangesAsync")]
        int SaveChanges();

        */

    }
}
