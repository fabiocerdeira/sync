﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssArrecadacao
{
    public class IssCertificadoEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal Nr_Certificado { get; set; }

		public byte Cd_Situacao { get; set; }

		public decimal Nr_Retificacao { get; set; }

		public byte Fl_Pago { get; set; }

		public string Nr_CGCCPFUsuarioCriacao { get; set; } = string.Empty;

		public DateTime Dt_Criacao { get; set; }

		public string? Nr_CGCCPFUsuarioAtualizacao { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public string? Nr_Aviso { get; set; }

		public DateTime? Dt_VencimentoGuia { get; set; }

		public string Nr_Chave { get; set; } = string.Empty;

		public int? Cd_Referencia { get; set; }

		public string? Nr_CGCCPF { get; set; }

		public string? Ds_MotivoCancelamento { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
