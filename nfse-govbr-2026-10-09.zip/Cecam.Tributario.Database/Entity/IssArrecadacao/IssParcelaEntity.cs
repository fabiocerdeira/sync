﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssArrecadacao
{
    public class IssParcelaEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public int Cd_Exercicio { get; set; }

		public decimal Cd_Contribuinte { get; set; }

		public string Nr_Aviso { get; set; } = string.Empty;

		public int Cd_GrupoTributo { get; set; }

		public int? Nr_parcela { get; set; }

		public decimal? Cd_Lote { get; set; }

		public string? Sg_IndiceFinanceiro { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public string? Nm_usuario { get; set; }

		public DateTime? Dt_vencimento { get; set; }

		public decimal? Vl_ReceitaBruta { get; set; }

		public decimal? Vl_aliquota { get; set; }

		public decimal? Vl_tributo { get; set; }

		public decimal? Pc_desconto { get; set; }

		public decimal? Vl_parcela { get; set; }

		public decimal? Vl_multa { get; set; }

		public decimal? Vl_juros { get; set; }

		public decimal? Vl_correcao { get; set; }

		public decimal? Vl_Tarifa { get; set; }

		public DateTime? Dt_pagamento { get; set; }

		public decimal? Vl_pago { get; set; }

		public string? Fl_DividaAtiva { get; set; }

		public decimal? Vl_Diferenca { get; set; }

		public decimal? Nr_Guia { get; set; }

		public string? Ds_Obs { get; set; }

		public DateTime? Dt_Estorno { get; set; }

		public string? Ds_MotivoEstorno { get; set; }

		public string? Nm_usuarioestorno { get; set; }

		public DateTime? Dt_criacao { get; set; }

		public string? Nm_usuariocriacao { get; set; }

		public byte? Fl_web { get; set; }

		public string? Ds_mesref { get; set; }

		public DateTime? Dt_Auditoria { get; set; }

		public string? Nr_AvisoOrigemGA { get; set; }

		public decimal? Nr_Certificado { get; set; }

		public DateTime? Dt_AcaoFiscal { get; set; }

		public int? Cd_AnoBase { get; set; }

		public decimal? Nr_GuiaUnificada { get; set; }

		public decimal? Cd_TipoEstorno { get; set; }

		public string? Fl_CobrancaRegistro { get; set; }

		public int? Cd_ExercicioGuiaUnificada { get; set; }

		public decimal? Nr_Processo { get; set; }

		public int? Aa_Processo { get; set; }

		public DateTime? Dt_Processo { get; set; }

		public int? Nr_GuiaUnificadaISS { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
