﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class CecamImpostoEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public Guid Cd_Imposto { get; set; }

		public string Sg_Imposto { get; set; } = string.Empty;

		public string Ds_Imposto { get; set; } = string.Empty;

        #endregion


        #region Relacionamentos
        #endregion
    }
}
