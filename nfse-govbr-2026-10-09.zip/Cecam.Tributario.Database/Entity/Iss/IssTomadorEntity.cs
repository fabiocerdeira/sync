﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Enumerado.Endereco;
using Cecam.Tributario.Database.Enumerado.Iss;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssTomadorEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public string Nr_CGCCPF { get; set; } = string.Empty;

		public string? Ds_RazaoSocial { get; set; }


        /// <summary>
        /// Código do município do IBGE<br/>
        /// Ver tabela CECAMMunicipio
        /// </summary>
        public decimal Cd_MunicipioTomador { get; set; }


		public string Sg_UF { get; set; } = string.Empty;


        /// <summary>
        /// Tipo de Pessoa:<br/>
        /// 0 = PJ = Pessoa Jurídica<br/>
        /// 1 = PF = Pessoa Física<br/>
        /// 2 = OP = Outro Pais
        /// </summary>
        public byte Fl_TipoPessoa { get; set; }

		public string Ds_Logradouro { get; set; } = string.Empty;

		public string Cd_Numero { get; set; } = string.Empty;

		public string Ds_Complemento { get; set; } = string.Empty;

		public string Ds_Bairro { get; set; } = string.Empty;

		public DateTime Dt_Atualizacao { get; set; }

		public string Cd_Usuario { get; set; } = string.Empty;

		public string? Ds_Email { get; set; }

		public string? Cd_CEP { get; set; }

		public string? Cd_RG_IE { get; set; }

		public string? Ds_inscricao_municipal { get; set; }

		public decimal Cd_Tomador { get; set; }

		public int? Cd_TipoCalculo { get; set; }


        #region Endereço no exterior (fora do Brasil)

        public string? Sg_Pais_ISO2 { get; set; }

        public string? Ds_EnderecoExt { get; set; }

        public string? Ds_CidadeExt { get; set; }

        public string? Ds_EstadoExt { get; set; }

		#endregion


		#endregion

		#region Relacionamentos


		/// <summary>
		/// Várias notas fiscais desse tomador
		/// </summary>
		[NotMapped]
        public ICollection<IssNotaFiscalEntity>? NotasFiscais { get; set; }


        #endregion

		/// <summary>
		/// Indica se o tomador é de outro pais que não seja Brasil ?
		/// </summary>
		public bool HeOutroPais()
		{
			return string.Equals(Sg_UF, CecamEnderecoEnum.kEstadoOutroPais, StringComparison.InvariantCultureIgnoreCase) ||
				Fl_TipoPessoa == (byte)IssTomadorEnum.enumFlTipoPessoa.OutroPaisEstrangeiro ||
				!string.IsNullOrWhiteSpace(Ds_EnderecoExt) ||
				!string.IsNullOrWhiteSpace(Ds_CidadeExt) ||
				!string.IsNullOrWhiteSpace(Ds_EstadoExt);
        }


		/// <summary>
		/// Criar um CNPJ/CPF aleatório para quando o tomador é de outro pais estrangeiro
		/// </summary>
		public void CriarCnpjCpfOutroPais()
		{
            Nr_CGCCPF = "OP-" + Guid.NewGuid().ToString().Replace("-", "").Substring(0, 12).ToUpper();
        }

    }
}
