﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssServicoEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public string Cd_Servico { get; set; } = string.Empty;

		public int Cd_Exercicio { get; set; }

		public int? Cd_incidencia { get; set; }

		public string? Sg_IndiceFinanceiro { get; set; }

		public string? Ds_Servico { get; set; }

		public decimal? Vl_Fixo { get; set; }

		public decimal? Vl_Aliquota { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public string? Nm_Usuario { get; set; }

		public byte? Fl_Local { get; set; }

		public byte? Fl_AceitaDeducao { get; set; }

		public byte? Fl_AceitaRetido { get; set; }

		public byte? Fl_Web { get; set; }

		public decimal? Vl_PercDeducao { get; set; }

		public string? Fl_tipoLancamentoISSWeb { get; set; }

		public byte? FL_OBRIGARETENCAO { get; set; }

		public byte? Fl_ImpDevidoDomTomador { get; set; }

		public byte? Fl_ExcetoMEI { get; set; }

		public decimal? Vl_AliquotaRetroativa { get; set; }

		public DateTime? Dt_LimiteIncidencia { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
