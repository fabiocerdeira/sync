﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssComunicadoWebEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal Cd_Comunicado { get; set; }

		public DateTime Dt_Criacao { get; set; }

		public DateTime Dt_Validade { get; set; }

		public string Ds_Titulo { get; set; } = string.Empty;

		public string Ds_Assunto { get; set; } = string.Empty;

		public string Ds_Anexo { get; set; } = string.Empty;

		public byte Fl_Especifico { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
