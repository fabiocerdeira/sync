﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssEventualEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal Cd_Eventual { get; set; }

		public string? Ds_Razaosocial { get; set; }

		public string? Nr_CGCCPF { get; set; }

		public string? Ds_EnderTributario { get; set; }

		public string? Ds_BairroTributario { get; set; }

		public string? Ds_CidadeTributario { get; set; }

		public string? Cd_CepTributario { get; set; }

		public string? Ds_EnderCorr { get; set; }

		public string? Ds_ComplCorr { get; set; }

		public string? Ds_BairroCorr { get; set; }

		public string? Ds_CidadeCorr { get; set; }

		public string? Cd_CepCorr { get; set; }

		public string? Sg_EstadoCorr { get; set; }

		public string? Ds_Item_Atividade { get; set; }

		public byte? Fl_web { get; set; }

		public string? Cd_RG_IE { get; set; }

		public string? Sg_EstadoTributario { get; set; }

		public string? Cd_TelefoneTributario { get; set; }

		public string? Cd_FAXTributario { get; set; }

		public string? Ds_Email { get; set; }

		public string? Nm_Contato { get; set; }

		public string? Nm_ResponsavelCadastroWeb { get; set; }

		public string? Nr_ResponsavelCadastroWebCPF { get; set; }

		public string? Nr_ResponsavelCadastroWebRG { get; set; }

		public string? Ds_ResponsavelCadastroWebEmail { get; set; }

		public int? Cd_Grupo_Atividade { get; set; }

		public int? Cd_Sub_Grupo_Atividade { get; set; }

		public int? Cd_Item_Atividade { get; set; }

		public DateTime? Dt_Criacao { get; set; }

		public string? Nm_UsuarioCriacao { get; set; }

		public byte? Fl_CadastroOBRAS { get; set; }

		public string? Ds_Inscricao_Municipal { get; set; }

		public string? Ds_Inscricao_Estadual { get; set; }

		public string? Ds_ComplTributario { get; set; }

		public byte? Fl_IgnorarISSWEB { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public string? Nm_UsuarioAtualizacao { get; set; }

		public byte? Fl_IncentivoFiscal { get; set; }

		public string? Nr_Registro { get; set; }

		public int? Cd_Conselho_Regional { get; set; }

		public string? Ds_Registro_Conselho { get; set; }

		public int? Cd_TipoCalculo { get; set; }

		public string? Cd_NumeroTributario { get; set; }

		public string? Cd_NumeroCorr { get; set; }

		public string? Ds_EmailTributario { get; set; }

		public string? Ds_EmailCorr { get; set; }

		public string? Cd_TelefoneCorr { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
