﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssUsuarioWebEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public string Nr_CGCCPF { get; set; } = string.Empty;

		public string Nm_Usuario { get; set; } = string.Empty;

		public string Nm_Login { get; set; } = string.Empty;

		public string Pw_Login { get; set; } = string.Empty;

		public string? Ds_email { get; set; }

		public byte Fl_Tipo { get; set; }

		public byte? Nr_Acesso { get; set; }

		public decimal? Cd_Contribuinte { get; set; }

		public DateTime? Dt_Cadastro { get; set; }

		public string? Ds_Usuario { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
