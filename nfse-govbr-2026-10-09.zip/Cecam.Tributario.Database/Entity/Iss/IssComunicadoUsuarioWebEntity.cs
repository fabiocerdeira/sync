﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssComunicadoUsuarioWebEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal Cd_Comunicado { get; set; }

		public decimal Nr_CGCCPF { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
