﻿using Cecam.Tributario.Database.Entity.Endereco;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Iss
{
    public class IssContribuinteEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal Cd_Contribuinte { get; set; }

		public int Cd_Exercicio { get; set; }

		public int? Cd_TipoImposto { get; set; }

		public int? Cd_tipocalculo { get; set; }

		public int? Cd_Estimado { get; set; }

		public int? Cd_periodo { get; set; }

		public string Ds_inscricao_municipal { get; set; } = string.Empty;

		public int? Cd_conselho_regional { get; set; }

		public decimal? Cd_Imovel { get; set; }

		public string? Cd_Logradouro { get; set; }

		public int? Cd_Bairro { get; set; }

		public int? Cd_Trecho { get; set; }

		public int? Cd_Contador { get; set; }

		public string? Ds_razaosocial { get; set; }

		public string? Ds_fantasia { get; set; }

		public string? Cd_numero { get; set; }

		public string? Ds_complemento { get; set; }

		public string? Ds_andar { get; set; }

		public string? Ds_apto { get; set; }

		public string? Cd_LogradouroCorr { get; set; }

		public string? Ds_TipoLogradouroCorr { get; set; }

		public string? Ds_EnderCorr { get; set; }

		public string? Cd_numcorr { get; set; }

		public int? Cd_TrechoCorr { get; set; }

		public string? Ds_Trechocorr { get; set; }

		public int? Cd_BairroCorr { get; set; }

		public string? Ds_bairrocorr { get; set; }

		public string? Ds_complcorr { get; set; }

		public string? Ds_andarcorr { get; set; }

		public string? Ds_aptocorr { get; set; }

		public string? Ds_cidadecorr { get; set; }

		public string? Cd_cepcorr { get; set; }

		public string? Sg_estadocorr { get; set; }

		public string? Ds_paiscorr { get; set; }

		public string? Nr_CGCCPF { get; set; }

		public string? Cd_rg_ie { get; set; }

		public string? Ds_OrgEmissor { get; set; }

		public DateTime? Dt_inicio_ativ { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public DateTime? Dt_encerramento { get; set; }

		public DateTime? Dt_reabertura { get; set; }

		public string? Cd_telefone { get; set; }

		public string? Ds_complTelefone { get; set; }

		public string? Cd_fax { get; set; }

		public string? Ds_complFax { get; set; }

		public string? Ds_email { get; set; }

		public decimal? Vl_area_ocupada { get; set; }

		public decimal? Vl_area_direta { get; set; }

		public decimal? Vl_area_indireta { get; set; }

		public decimal? Vl_capital_social { get; set; }

		public string? Ds_ativ { get; set; }

		public string? Ds_registro_conselho { get; set; }

		public string Fl_EndEntrega { get; set; } = string.Empty;

		public string? Ds_Obs { get; set; }

		public int? Qd_Funcionarios { get; set; }

		public int? Cd_TipoEstabelec { get; set; }

		public int? Cd_TipoEmpresa { get; set; }

		public string? Fl_MicroEmpresa { get; set; }

        /// <summary>
        /// Tipo de Pessoa<br/>
        /// F = Pessoa Física<br/>
        /// J = Pessoa Jurídica
        /// </summary>
        public string? Fl_FisicaJuridica { get; set; }

		public string? Nm_usuario { get; set; }

		public string? Ds_inscricao_anterior { get; set; }

		public int? Cd_dbaubanco { get; set; }

		public string? Cd_dbauagencia { get; set; }

		public string? Cd_dbauconta { get; set; }

		public DateTime? Dt_cadastrobanco { get; set; }

		public int? Cd_categoria { get; set; }

		public byte? Fl_web { get; set; }

		public byte? Fl_IgnorarISSWEB { get; set; }

		public string? Nr_CGCCPFMatriz { get; set; }

		public string? Ds_Obs_Carne { get; set; }

		public byte? Fl_IncentivoFiscal { get; set; }

		public int? Nr_ISSEAnoMesCertificado { get; set; }

		public int? Cd_RegimeTributacao { get; set; }

		public DateTime? Dt_inicioRegimeTributacao { get; set; }

		public DateTime? Dt_fimRegimeTributacao { get; set; }

		public DateTime? Dt_AberturaEmpresa { get; set; }

		public string Fl_estabelecido { get; set; } = string.Empty;

		public string? Nr_ProtocoloJUCESP { get; set; }

		public string? Nr_CPFResponsavel { get; set; }

		public string? Nm_Responsavel { get; set; }

		public string? Ds_EmailResponsavel { get; set; }

		public string? Ds_QualificacaoResponsavel { get; set; }

		public string? Cd_TelefoneResponsavel1 { get; set; }

		public string? Cd_TelefoneResponsavel2 { get; set; }

		public string? Cd_FaxResponsavel { get; set; }

		public string? Ds_Enquadramento { get; set; }

		public string? Ds_FormaAtuacao { get; set; }

		public string? Ds_TipoUnidade { get; set; }

		public string? Fl_ISSDigital { get; set; }

		public string? Sg_Estado { get; set; }

		public string? Ds_Cidade { get; set; }


		#endregion


		#region Relacionamentos


		[NotMapped]
        public CecamLogradouroEntity? Logradouro { get; set; }


        [NotMapped]
        public CecamBairroEntity? Bairro { get; set; }


        #endregion
    }
}
