﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssParametros
{
    public class IssParametrosCalcEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public int Cd_Exercicio { get; set; }

		public int? Fl_emitecarneisentos { get; set; }

		public int? Cd_SubGrupoImposto { get; set; }

		public int? Cd_SubGrupoTaxa { get; set; }

		public int? Cd_GrupoISS { get; set; }

		public int? Cd_GrupoISSvar { get; set; }

		public int? Cd_SubGrupoISSvar { get; set; }

		public string? Sg_MoedaPadrao { get; set; }

		public bool Fl_UtilizaFaixaValores { get; set; }

		public string? Fl_UtilizaValorMinimo { get; set; }

		public string? Fl_UtilizaValorMinimoTaxa { get; set; }

		public bool Fl_UtilizaConversaoCertidoes { get; set; }

		public string? Fl_Desconto { get; set; }

		public decimal? Vlr_Minimo { get; set; }

		public decimal? Vlr_MinimoTaxa { get; set; }

		public string? Ds_DescontoEspecial { get; set; }

		public string? Fl_TipoValorIntervaloBaixa { get; set; }

		public decimal? Vlr_IntervaloMaximoBaixa { get; set; }

		public decimal? Vlr_IntervaloMinimoBaixa { get; set; }

		public string? Ds_Juros { get; set; }

		public string? Ds_Multa { get; set; }

		public string? Ds_Imposto { get; set; }

		public string? Fl_UtilizacaoValoresJurosMulta { get; set; }

		public string? Sg_MoedaCorrente { get; set; }

		public int? Cd_TributoJurosImposto { get; set; }

		public int? Cd_TributoMultasImposto { get; set; }

		public int? Cd_TributoCorrecaoImposto { get; set; }

		public int? Cd_TributoTarifaBancaria { get; set; }

		public string? Nm_DiretorioDocumentos { get; set; }

		public string? Fl_TipoAtualizacaoValor { get; set; }

		public string? Fl_TipoNrAviso { get; set; }

		public string? Msg_ParcelaUnica { get; set; }

		public string? Msg_DemaisParcelas { get; set; }

		public string? Nm_TipoAplicacaoJuros { get; set; }

		public string? Nm_TipoAplicacaoMulta { get; set; }

		public int? Cd_FicharecImposto { get; set; }

		public int? Cd_FicharecTaxa { get; set; }

		public string? Fl_Ajuste { get; set; }

		public int? Cd_GrupoGuiaExpediente { get; set; }

		public int? Cd_TributoJurosTaxa { get; set; }

		public int? Cd_TributoMultasTaxa { get; set; }

		public int? Cd_TributoCorrecaoTaxa { get; set; }

		public int? Cd_FichaRecImpostoTaxas { get; set; }

		public string? Msg_ParcelasVariaveis { get; set; }

		public string? Msg_ParcelaUnicaTaxa { get; set; }

		public string? Msg_DemaisParcelasTaxa { get; set; }

		public string? Msg_ParcelasGuias { get; set; }

		public string? Msg_ParcelasEventuais { get; set; }

		public string? Msg_ParcelasExpediente { get; set; }

		public decimal? Vlr_ResCalculo { get; set; }

		public decimal? Cd_ReceitaAClassificar { get; set; }

		public decimal? Cd_ClienteGOL { get; set; }

		public string? Fl_TipoNrOcorrencia { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public string? Nm_usuario { get; set; }

		public int? Nr_ISSEAnoMesImplantacao { get; set; }

		public byte? Nr_ISSEMesesParaEscrituracao { get; set; }

		public byte? Nr_ISSEMesesParaRetificacao { get; set; }

		public byte? Nr_ISSEDiaVencimento { get; set; }

		public byte? Nr_ISSENumeroDiasVencimento { get; set; }

		public byte? Nr_ISSEPermitirOutraAtividade { get; set; }

		public byte? Nr_ISSEDiasStandBy { get; set; }

		public byte? Nr_ISSEConfirmacaoCadastro { get; set; }

		public string? Msg_ObsAdicionaisCapaCarne { get; set; }

		public string? Fl_emiteAlvaraWEB { get; set; }

		public string? Fl_TipoValorIntervaloBaixaDVAT { get; set; }

		public decimal? Vlr_IntervaloMaximoBaixaDVAT { get; set; }

		public decimal? Vlr_IntervaloMinimoBaixaDVAT { get; set; }

		public string? Ds_ISSESenhaAdmin { get; set; }

		public byte? Nr_NFEQtdeDiasPreCadastro { get; set; }

		public int? Nr_NFEQtdeNFBloco { get; set; }

		public byte? Nr_NFEQtdeDiasRPS { get; set; }

		public int? Cd_NFETipoDocto { get; set; }

		public int? Cd_NFETipoDoctoRPS { get; set; }

		public byte? Fl_NFEDiscriminaImposto { get; set; }

		public string? Ds_NFECapaBloco { get; set; }

		public string? Fl_permiteAlteracaoSenhaWEB { get; set; }

		public string? Msg_ParcelaUnica_Ambulantes { get; set; }

		public string? Msg_DemaisParcelas_Ambulantes { get; set; }

		public string? Msg_ParcelaUnicaTaxa_Ambulantes { get; set; }

		public string? Msg_DemaisParcelasTaxa_Ambulantes { get; set; }

		public string? Msg_ParcelasGuias_Ambulantes { get; set; }

		public decimal? Cd_ControleAmbulanteInicial { get; set; }

		public decimal? Cd_ControleAmbulanteFinal { get; set; }

		public string? Msg_ParcelasExpediente_Ambulantes { get; set; }

		public bool Fl_PermitirAcessoGuiaAvulsa { get; set; }

		public string? Msg_NotificacaoCarne { get; set; }

		public byte? Fl_VerificaAlvaraBombeiros { get; set; }

		public int? Nr_QtdDiasVencimentoAlvaraWeb { get; set; }

		public string? Ds_UrlCadastroWeb { get; set; }

		public int Cd_ISSEVencimento { get; set; }

		public decimal? Pc_desconto_Principal { get; set; }

		public decimal? Pc_desconto_Multa { get; set; }

		public decimal? Pc_desconto_Juros { get; set; }

		public decimal? Pc_desconto_Correcao { get; set; }

		public byte? Fl_AceitedoTomador { get; set; }

		public string? Nm_TipoAplicacaoCorrecao { get; set; }

		public string Ds_ISSEMsgPersonalRPS { get; set; } = string.Empty;

		public string? Ds_URLISSEletronico { get; set; }

		public string? Fl_InibirInfo { get; set; }

		public bool? Fl_NaoConsultarDivida { get; set; }

		public bool Fl_UtilizaDescAtivBoleto { get; set; }

		public DateTime? Dt_VencMaxImpressaoParcelaWeb { get; set; }

		public decimal? Vlr_ValorMinimoISSEletronico { get; set; }

		public string? Fl_PermiteEncerrar { get; set; }

		public string? Ds_FinalidadeParcelasWeb { get; set; }

		public string? Fl_AtualizaEmissaoGuiaWEB { get; set; }

		public string? Fl_AlteraDECA { get; set; }

		public string? Fl_VerDebExercDVAT { get; set; }

		public string? Fl_ConsistirPagtoCancNF { get; set; }

		public int? Cd_subGrupoTxCompensacao { get; set; }

		public int? Cd_tributoTxCompensacao { get; set; }

		public decimal? Vl_TxCompensacao { get; set; }

		public string? Fl_NaoPermitirRetencaoTomador { get; set; }

		public string? Fl_NaoPermitirCancNotasGuiaPaga { get; set; }

		public string? Fl_NaoPermitirRetencaoTomadorSuperSimples { get; set; }

		public int? Cd_taxaGuiaeventual { get; set; }

		public string? Fl_NaoPermitirCancNotaGuiaGerada { get; set; }

		public string? Fl_NaoPermitirCancNotaGuiaVencida { get; set; }

		public string? Fl_UtilizaBeneficioFiscal { get; set; }

		public int? Cd_BeneficioFiscal { get; set; }

		public decimal? Pc_AliquotaBeneficioFiscal { get; set; }

		public string? Ds_ServicosBeneficioFiscal { get; set; }

		public string? Ds_UrlAPIIntegracaoNFE { get; set; }

		public string? Ds_UrlAPIIntegracaoNFEDados { get; set; }

		public string? Fl_AliquotaDiferenteLocalPrestacao { get; set; }

		public int? Nr_ISSEqtdeDiasCancelAposEmissao { get; set; }

		public string? Ds_ISSEleiPermissaoCancelAposEmissao { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
