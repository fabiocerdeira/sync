﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssParametros
{
    public class IssParametrosNfseEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal? Cd_IBGE { get; set; }

		public string Nr_CNPJMunicipio { get; set; } = string.Empty;

		public string? Nr_LegislacaoBenefício { get; set; }

        public DateTime? Dt_InicioIntegracao { get; set; }

        public string? Tp_IntegracaoTipo { get; set; }

        /// <summary>
        /// Id do último NSU baixado do gov.br
        /// Se for 0 ou NULL então nunca teve uma NFSe baixada
        /// Usado para saber a última NSU baixada e no próximo processamento começar por esse NSU
        /// </summary>
        public long? Govbr_nsuBaixadoUltimo { get; set; }

        /// <summary>
        /// Data e hora do último NSU baixado do gov.br
        /// Se for NULL então nunca teve uma NFSe baixada
        /// Usado para esperar X horas após o último processamento de baixar notas
        /// </summary>
        public DateTime? Govbr_nsuBaixadoHorario { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
