﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr
{
    public class ISSNotaFiscalGovBrDocArrecadacaoEntity : EntityBase
    {
        #region Propriedades

		public long Id { get; set; }

		public int Cd_Cecam { get; set; }

		public decimal Cd_NotaFiscal { get; set; }

		public DateTime Dt_criacao { get; set; }

		public DateTime Dt_vencimento { get; set; }

		public DateTime? Dt_cancelamento { get; set; }

		public DateTime? Dt_pagamento { get; set; }

		public decimal? Vl_tributo { get; set; }

		public decimal? Nr_Certificado { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
