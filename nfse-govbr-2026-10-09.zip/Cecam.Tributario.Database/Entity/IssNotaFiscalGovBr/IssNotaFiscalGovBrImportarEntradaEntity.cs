﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrImportarEntradaEntity : EntityBase
    {
        #region Propriedades


        public int Id { get; set; }


		public int Cd_Cecam { get; set; }


        /// <summary>
        /// Fila tipo
        /// 0 = Não identificado
        /// 1 = NFSe
        /// 2 = Evento de cancelamento
        /// 3 = AceiteNotaFiscal 
        /// 4 = Ignorado
        /// </summary>
        public int FilaTipo { get; set; }


		/// <summary>
		/// Status da entrada importada
		/// 0 = baixado mas nunca processado
		/// 1 = processado mas deu erro
		/// 2 = duplicado então não pode ser processado
		/// </summary>
		public int Status { get; set; }


		public string? ChaveAcesso { get; set; }

		public long? Nsu { get; set; }

		public string? NfseId { get; set; }

		public string? DpsId { get; set; }

		public DateTime? DataHoraDocumento { get; set; }

		public string? TipoDocumento { get; set; }

		public string? TipoEvento { get; set; }

		public DateTime DataHoraCriacao { get; set; }

		public DateTime? DataHoraProcessamento { get; set; }

		public string? Corpo { get; set; }

		public string? Mensagem { get; set; }

		public decimal? Cd_Contribuinte { get; set; }

		public string? Nr_CGCCPF { get; set; }

        public string? Motivo { get; set; }

        #endregion

        #region Relacionamentos
        #endregion
    }
}
