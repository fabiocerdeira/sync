﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr
{
    public class IssNotaFiscalGovBrLixoEntity : EntityBase
    {
        #region Propriedades

		public int Id { get; set; }

		public decimal? ValorDecimalA { get; set; }

		public decimal? ValorNumericA { get; set; }

		public string? Corpo { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
