﻿using Cecam.Tributario.Database.Entity.Iss;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static Cecam.Tributario.Database.Enumerado.IssNotaFiscal.IssNotaFiscalEnum;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalEntity : EntityBase
    {
        #region Propriedades

        public int Cd_Cecam { get; set; }

        /// <summary>
        /// Código da nota fiscal
        /// </summary>
		public decimal Cd_NotaFiscal { get; set; }

        /// <summary>
        /// Mês e ano da NF no formato "aaaamm"
        /// </summary>
		public int Cd_Referencia { get; set; }

        /// <summary>
        /// CNPJ ou CPF do emissor da nota fiscal (somente números => 15 (quinze) dígitos para CNPJ e 11 (onze) para CPF
        /// </summary>
		public string Nr_CGCCPF { get; set; } = string.Empty;

        /// <summary>
        /// Tipo de documento emitido
        /// </summary>
		public int Cd_TipoDocumento { get; set; }

        /// <summary>
        /// Número da Nota Fiscal
        /// </summary>
		public decimal Nr_NotaFiscal { get; set; }

        /// <summary>
        /// Código da situação<br/>
        /// 0 = ativa<br/>
        /// 1 = cancelada<br/>
        /// 2 = excluida<br/>
        /// Utilizar IssNotaFiscalEnum.enumCdSituacao
        /// </summary>
        public byte Cd_Situacao { get; set; }

        /// <summary>
        /// Data da emissão da NF
        /// </summary>
		public DateTime Dt_Emissao { get; set; }

        /// <summary>
        /// CNPJ ou CPF do tomador (retentor do ISS no pagamento do produto ou da prestação do serviço) da nota fiscal (somente números => 15 (quinze) dígitos para CNPJ e 11 (onze) para CPF, preenchidos com zeros a esquerda). 
        /// Este campo deve ser 0(zero) caso não seja nota de tomador.
        /// </summary>
		public string? Nr_CGCCPFTomador { get; set; }

        /// <summary>
        /// CNPJ ou CPF do intermediario (retentor do ISS no pagamento do produto ou da prestação do serviço) da nota fiscal (somente números => 15 (quinze) dígitos para CNPJ e 11 (onze) para CPF, preenchidos com zeros a esquerda). 
        /// Este campo deve ser 0(zero) caso não seja nota de tomador.
        /// </summary>
		public string? Nr_CGCCPFTomadorIntermediario { get; set; }

        /// <summary>
        /// Observações (200 caracteres)
        /// </summary>
		public string? Ds_Observacao { get; set; }

		public string Nr_CGCCPFUsuarioCriacao { get; set; } = string.Empty;

		public DateTime Dt_Criacao { get; set; }

        /// <summary>
        /// CNPJ do usuario quem fez a alteração na nota fiscal
        /// Esse campo tem uma FK com IssUsuarioWeb
        /// </summary>
		public string? Nr_CGCCPFUsuarioAtualizacao { get; set; }

		public DateTime? Dt_Atualizacao { get; set; }

		public decimal? Nr_Certificado { get; set; }


        /// <summary>
        /// Número da NF a ser substituída (no caso de correção de notas cujo certificado já tenha sido enviado através do sistema de ISS-Eletrônico)
        /// </summary>
		public decimal Nr_NotaFiscalSubstituta { get; set; }


        /// <summary>
        /// Local de prestação do serviço.<br/>
        /// Utilizar IssNotaFiscalEnum.enumLocalPrestacao<br/>
        /// <br/>
        /// (0) AINDA NÃO SABEMOS O QUE SIGNIFICA !<br/>
        /// (1) Na Sede do Prestador do Serviço (Mesmo local da emissão da NF) <br/> 
        /// (2) Em imóvel específico no município <br/>
        /// (3) Via pública <br/>
        /// (4) Fora do município <br/>
		/// <br/>
        /// 0 = AINDA NÃO SABEMOS O QUE SIGNIFICA ! <br/>
        /// 1 = (prestador e tomador são do mesmo municipio OU são municipios diferentes) e local prestação na sede do prestador <br/>
        /// 2 = TALVEZ = precisa ter a Insc Municipal do Imovel na NFSe e provavelmente local prestação na sede do prestador <br/>
        /// 3 = TALVEZ = prestador e tomador são municipios diferentes e local prestação fora do municipio do prestador <br/>
        /// 4 = (prestador e tomador são do mesmo municipio OU são municipios diferentes) e local prestação fora do municipio do prestador, nesse caso o campo 'cd_CidadePrestacao' precisa ser informado.
        /// </summary>
        public byte Fl_LocalPrestacao { get; set; }


        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 4, informar neste campo o endereço da prestação do serviço (60 caracteres)
        /// </summary>
		public string? Ds_LocalPrestacao { get; set; }


        /// <summary>
        /// Complemento do campo de endereço da prestação do serviço
        /// </summary>
		public string? Ds_LocalPrestacaoCompl { get; set; }


        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 2, informar neste campo a inscrição municipal do imóvel sem formatação
        /// </summary>
		public decimal? Cd_Imovel { get; set; }

        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 4, informar neste campo o código do município IBGE 
        /// </summary>
		public decimal? Cd_CidadePrestacao { get; set; }

        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 2 ou 3, informar neste campo o endereço da prestação do serviço (60 caracteres)
        /// </summary>
		public string? Nm_Logradouro { get; set; }

        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 2, informar neste campo o número do imóvel da prestação do serviço (20 caracteres)
        /// </summary>
		public string? Nr_Numero { get; set; }

        /// <summary>
        /// Complemento do campo "nm_logradouro"
        /// </summary>
		public string? Ds_Complemento { get; set; }

        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 2 ou 3, informar neste campo o Bairro do endereço da prestação do serviço
        /// </summary>
		public string? Nm_Bairro { get; set; }

        /// <summary>
        /// Caso o campo fl_LocalPrestacao seja 2, informar neste campo o CEP do endereço da prestação do serviço
        /// </summary>
        public string? Cd_CEP { get; set; }

		public string? Nr_Aviso { get; set; }

        /// <summary>
        /// Flag prestador não inscrito no municipio
        /// 0 = quando prestador e tomador são do mesmo municipio
        /// 0 = se a NFSe estiver sendo gravada no municipio do prestador é sempre 0 (zero)
        /// 1 = se a NFSe estiver sendo gravada no municipio do tomador e o prestador é de outro municipio
        /// </summary>
        public byte Fl_PrestadorNaoInscrito { get; set; }


        /// <summary>
        /// Flag se foi o tomador quem escriturou a NFSe?<br/>
        /// 0 = NFSe emitida pelo prestador.<br/>
        /// 1 = NFSe escriturada pelo tomador <br/>
        /// Utilizar IssNotaFiscalEnum.enumFlTomador
        /// </summary>
        public byte Fl_Tomador { get; set; }


		public byte? Fl_Web { get; set; }

        /// <summary>
        /// Código único identificador do contribuinte como prestador na prefeira/cecam
        /// Pode ser issContribuinte ou issEventual
        /// </summary>
		public decimal? Cd_Contribuinte { get; set; }

        /// <summary>
        /// Chave de validação da cecam para NFSe emitidas pelo prestador.
        /// Notas escrituradas não tem chave de validação
        /// Esse campo é preenchido pelo sistema no processo de salvar a NFSe pq ele precisa ser único na base, então tem uma rotina para esse tratamento.
        /// </summary>
		public string? Nr_ChaveValidacao { get; set; }

        /// <summary>
        /// cd_rps é um guid ou null
        /// cd_rps = 5F4DCBE7-76E6-4BB1-9240-0D4FDC721CB4
        /// somente é gerado/preenchido pela tela de wfGeracaoRPS.aspx
		/// então cd_rps é sempre null na criação da nfse
		/// </summary>
		public Guid? Cd_RPS { get; set; }

		public string? Ds_MotivoCancelamento { get; set; }


        /// <summary>
        /// Usado na importação de NFS-e via webservice
        /// </summary>
		public int Nr_Lote { get; set; }


		public decimal? Cd_PreNota { get; set; }


        /// <summary>
        /// Código único do tomador.<br/>
        /// Relação com a tabela IssTomador<br/>
        /// O tomador é obrigatório
        /// </summary>
		public decimal? Cd_Tomador { get; set; }


        /// <summary>
        /// Código único do intermediario.<br/>
        /// Relação com a tabela IssTomador<br/>
        /// O intermediário é opcional 
        /// </summary>
		public decimal? Cd_TomadorIntermediario { get; set; }

        /// <summary>
        /// Indica que o prestador informou a aliquota do serviço prestado<br/>
        /// 0 = prestador NÃO informou a aliquota<br/>
        /// 1 = prestador informou a aliquota, <br/>
        /// Opção 1 ocorre somente em duas situações:<br/>
        /// a) Se empresa do Simples Nacional e valor da Aliquota > 0 ou<br/>
        /// b) Se empresa comum e serviço prestado fora do municipio e valor da aliquota > 0
        /// </summary>
        public byte Fl_AliquotaLocalPrestacao { get; set; }

		public int? Cd_TipoCalculo { get; set; }

		public decimal? Nr_GuiaUnificada { get; set; }

		public DateTime? Dt_cancelamento { get; set; }

		public decimal? Nr_AliquotaBeneficio { get; set; }

		public string? Ds_DescricaoPercentualImposto { get; set; }


        #region NFSe do gov.br

        public string? Govbr_ChaveAcesso { get; set; }

		public string? GovBr_NsuEnvio { get; set; }

		public string? GovBr_NsuCancelamento { get; set; }

		public string? GovBr_NfseId { get; set; }

		public string? GovBr_DpsId { get; set; }
		
        /// <summary>
        /// Data e hora da última vez que foi consultado por Eventos dessa NFSe no gov.br
        /// Se NULL então nunca foi consultado
        /// </summary>
        public DateTime? Govbr_EventoUltimaConsulta { get; set; }

        #endregion


        #endregion


        #region Relacionamentos

        /// <summary>
        /// Itens da NFSe
        /// Relação com a tabela IssNotaFiscalItem
        /// O item é obrigatório
        /// </summary>
        public ICollection<IssNotaFiscalItemEntity>? Itens { get; set; }


        /// <summary>
        /// Tomador da NFSe
        /// Relação com a tabela IssTomador
        /// O tomador é obrigatório
        /// </summary>
		[NotMapped]
        public IssTomadorEntity? Tomador { get; set; }


        /// <summary>
        /// Intermediario da NFSe
        /// Relação com a tabela IssTomador
        /// O intermediario é opcional
        /// </summary>
		[NotMapped]
        public IssTomadorEntity? Intermediario { get; set; }


        /// <summary>
        /// Impostos
        /// Relação com a tabela IssNotaFiscalImposto
        /// </summary>
		public ICollection<IssNotaFiscalImpostoEntity>? Impostos { get; set; }


        /// <summary>
        /// Prestador do serviço da nota quando for IssContribuinte
        /// </summary>
        [NotMapped]
        public IssContribuinteEntity? Contribuinte { get; set; }


        /// <summary>
        /// Prestador do serviço da nota quando for IssEventual
        /// </summary>
        [NotMapped]
        public IssEventualEntity? Eventual { get; set; }


		#endregion


		#region Funções


        /// <summary>
        /// Retornar qual é o tipo de contribuinte associado com a Nota
        /// Pode ser um IssContribuinte ou IssEventual
        /// A exceção vai retornar 'NaoInformado'
        /// </summary>
        public enumTipoContribuinte TipoContribuinte()
        {
            if (!Cd_Contribuinte.HasValue)
                return enumTipoContribuinte.NaoInformado;
            else if (Cd_Contribuinte.Value.ToString().Substring(0, 1) == "9")
                return enumTipoContribuinte.IssEventual;
            else
                return enumTipoContribuinte.IssContribuinte;
        }

        #endregion
    }
}
