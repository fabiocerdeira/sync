﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    /// <summary>
    /// NBS - Nomenclatura Brasileira de Serviços, Intangíveis e outras Operações que produzam Variações no Patrimônio
    /// </summary>
    public class IssNotaFiscalNBSEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public int Cd_Exercicio { get; set; }

        private string _cdNbs = string.Empty;

		public string Cd_nbs { 
            get { return _cdNbs; }
            set { _cdNbs = value.Trim(); }
        }

		public string Ds_nbsDescricao { get; set; } = string.Empty;

        public string Cd_nbsFormatado { get; set; } = string.Empty;

        #endregion

        #region Relacionamentos
        #endregion
    }
}
