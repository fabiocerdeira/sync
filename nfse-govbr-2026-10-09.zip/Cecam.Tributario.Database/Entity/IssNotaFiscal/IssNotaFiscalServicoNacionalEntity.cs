﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalServicoNacionalEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public int Cd_Exercicio { get; set; }

		public string? Cd_tributacaoNacional { get; set; }

		public string Cd_Item { get; set; } = string.Empty;

		public string Cd_subItem { get; set; } = string.Empty;

		public string Cd_Desdobro { get; set; } = string.Empty;

		public string Ds_servicoDescricao { get; set; } = string.Empty;

        #endregion

        #region Relacionamentos
        #endregion
    }
}
