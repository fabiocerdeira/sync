﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalImpostoEntity : EntityBase
    {
        #region Propriedades


		public int Cd_Cecam { get; set; }

		public Guid Cd_NotaFiscal_Imposto { get; set; }

		public decimal Cd_NotaFiscal { get; set; }

		public Guid Cd_Imposto { get; set; }

		public decimal? Vl_Imposto { get; set; }


        #endregion


        #region Relacionamentos


        /// <summary>
        /// Tabela/Objeto pai da NFSe
        /// </summary>
        public IssNotaFiscalEntity? NotaFiscal { get; set; }


        #endregion
    }
}
