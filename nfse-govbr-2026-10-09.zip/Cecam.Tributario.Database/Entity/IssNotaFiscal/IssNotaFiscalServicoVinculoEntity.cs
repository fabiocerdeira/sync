﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalServicoVinculoEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public int Cd_Exercicio { get; set; }

		public string Cd_Servico { get; set; } = string.Empty;

		public string Cd_tributacaoNacional { get; set; } = string.Empty;

		public string Cd_nbs { get; set; } = string.Empty;


        #endregion

        #region Relacionamentos
        #endregion
    }
}
