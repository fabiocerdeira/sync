﻿using Cecam.Tributario.Database.Entity.Iss;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalItemEntity : EntityBase
    {
        #region Propriedades

        public int Cd_Cecam { get; set; }

        /// <summary>
        /// Código da nota fiscal
        /// </summary>
		public decimal Cd_NotaFiscal { get; set; }

        /// <summary>
        /// Código do serviço
        /// </summary>
		public string Cd_Servico { get; set; } = string.Empty;

        /// <summary>
        /// Código do grupo de atividade
        /// </summary>
		public int Cd_GrupoAtividade { get; set; }

        /// <summary>
        /// Código do subgrupo de atividade
        /// </summary>
		public int Cd_SubGrupoAtividade { get; set; }

        /// <summary>
        /// Código do item de atividade
        /// </summary>
		public int Cd_ItemAtividade { get; set; }

        /// <summary>
        /// Valor do item
        /// </summary>
		public decimal Vl_Item { get; set; }

		public decimal Vl_Deducao { get; set; }

		public decimal Pc_Aliquota { get; set; }

        /// <summary>
        /// Valor retido do ISS no pagamento do produto ou da prestação de serviço, sem separação de milhar e com, apenas, duas casas decimais)<br/>
        /// Valor Tomado não pode ser calculado quando o Serviço é pago no Local de Prestação e o local de Prestação for em outro Municipio (então informar ValorTomado = 0)
        /// </summary>
		public decimal Vl_Tomado { get; set; }


        /// <summary>
        /// Caso o item tenha o imposto correspondente retido pela fonte pagadora o valor deste campo deve ser "1", do contrário deve conter 0 (zero)<br/>
        /// Utilizar IssNotaFiscalItemEnum.enumFlRetido<br/>
        /// 0 = imposto ISSQN retido pelo tomador<br/>
        /// 1 = imposto ISSQN NÃO é retido pelo tomador, então é pago pelo prestador<br/>
        /// Utilizar enumerador enumFlRetido
        /// </summary>
		public byte Fl_Retido { get; set; }

        /// <summary>
        /// Caso o pagamento do produto ou da prestação de serviço tenha sido efetuado por estrangeiro (exportação), o valor deste campo deve ser "1", do contrário deve conter 0 (zero).<br/>
        /// Se UF do tomador for fora do Brasil então fl_Exportado = 1 e cd_Pais precisa ser informado diferente de 0 se não fl_Exportado = 0 e cd_Pais = 0
        /// </summary>
		public byte Fl_Exportado { get; set; }

        /// <summary>
        /// Caso o campo "fl_exportado" seja "1", o código do país da exportação (conforme tabela disponibilizada) deve ser informado neste campo
        /// </summary>
		public int? Cd_Pais { get; set; }

		public int? Nr_Quantidade { get; set; }

		public int? Cd_Unidade { get; set; }

		public string? Ds_ItemServico { get; set; }

		public decimal? Vl_BaseCalculo { get; set; }

		public decimal? Vl_DevidoItem { get; set; }

		public decimal? Vl_Devido { get; set; }


        public decimal? vl_DescontoIncondicionado { get; set; }

        public decimal? vl_DescontoCondicionado { get; set; }


        /// <summary>
        /// Código de tributação nacional (tabela ISS_NFSE_ListaServicoNacional campo Cd_TributacaoNacional)
        /// </summary>
		public string? Cd_TributacaoNacional { get; set; }

        /// <summary>
        /// Código da Nomenclatura Brasileira de Serviços (tabela ISS_NFSE_ListaNBS campo Cd_Nbs)
        /// </summary>
		public string? Cd_Nbs { get; set; }

        #endregion


        #region Relacionamentos


        /// <summary>
        /// Tabela/Objeto pai da NFSe
        /// </summary>
        public IssNotaFiscalEntity? NotaFiscal { get; set; }


        /// <summary>
        /// Servico nacional (cd_tributacaoNacional)
        /// </summary>
        [NotMapped]
        public IssNotaFiscalServicoNacionalEntity? ServicoNacional { get; set; }


        /// <summary>
        /// Servico nacional (cd_nbs)
        /// Código de Tributação Nacional do serviço prestado.
        /// NBS - Nomenclatura Brasileira de Serviços, Intangíveis e outras Operações que produzam Variações no Patrimônio
        /// </summary>
        [NotMapped]
        public IssNotaFiscalNBSEntity? NBS { get; set; }


        /// <summary>
        /// Serviço municipal (cd_servico)
        /// </summary>
        [NotMapped]
        public IssServicoEntity? Servico { get; set; }


        #endregion
    }
}
