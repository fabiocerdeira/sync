﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.IssNotaFiscal
{
    public class IssNotaFiscalRejeicaoEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public decimal Cd_NotaFiscal { get; set; }

		public string Ds_Rejeicao { get; set; } = string.Empty;

		public DateTime Dt_AceitoRejeitado { get; set; }

		public string Fl_AceitoRejeitado { get; set; } = string.Empty;



        #endregion

        #region Relacionamentos
        #endregion
    }
}
