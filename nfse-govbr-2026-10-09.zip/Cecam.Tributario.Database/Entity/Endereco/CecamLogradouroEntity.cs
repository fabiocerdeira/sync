﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Endereco
{
    public class CecamLogradouroEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public string Cd_Logradouro { get; set; } = string.Empty;

		public string? Ds_TipoLogradouro { get; set; }

		public string? Ds_Logradouro { get; set; }

		public string? Ds_Antigo { get; set; }

		public string? Ds_LeiDecreto { get; set; }

		public string? Fl_inativo { get; set; }

		public string? Fl_sistema { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public string? Nm_usuario { get; set; }

		public byte? Fl_Web { get; set; }

		public int? Cd_Loteamento { get; set; }

		public string? Ds_Loteamento { get; set; }

		public int? Cd_bairro { get; set; }

		public string? Ds_bairro { get; set; }

		public int? Cd_CEP { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
