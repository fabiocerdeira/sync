﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Endereco
{
    public class CecamPaisIbgeEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public string Sg_pais_ISO2 { get; set; } = string.Empty;

		public string Ds_paisDescricao { get; set; } = string.Empty;


        #endregion


        #region Relacionamentos
        #endregion
    }
}
