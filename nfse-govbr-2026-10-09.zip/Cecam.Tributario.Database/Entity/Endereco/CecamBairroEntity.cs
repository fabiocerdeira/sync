﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Endereco
{
    public class CecamBairroEntity : EntityBase
    {
        #region Propriedades

		public int Cd_Cecam { get; set; }

		public int Cd_Bairro { get; set; }

		public string? Ds_Bairro { get; set; }

		public string? Cd_classificacaobairro { get; set; }

		public string? Fl_inativo { get; set; }

		public string? Fl_sistema { get; set; }

		public DateTime? Dt_atualizacao { get; set; }

		public string? Nm_usuario { get; set; }

		public byte? Fl_Web { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
