﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Entity.Endereco
{
    public class CecamMunicipioEntity : EntityBase
    {
        #region Propriedades

		public decimal Cd_MunicipioIBGE { get; set; }

		public decimal Cd_Municipio { get; set; }

		public short Nr_Ano { get; set; }

		public string Sg_UF { get; set; } = string.Empty;

		public string Ds_NomeMunicipio { get; set; } = string.Empty;

		public decimal Cd_CEPInicial { get; set; }

		public decimal Cd_CEPFinal { get; set; }

		public int? Cd_Jucesp { get; set; }



        #endregion

        #region Relacionamentos
        #endregion
    }
}
