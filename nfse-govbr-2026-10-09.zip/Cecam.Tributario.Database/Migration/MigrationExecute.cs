﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Migration
{
    public class MigrationExecute
    {
        /// <summary>
        /// Executa todos os scripts de alteração de base de dados que estão na pasta de entrada
        /// </summary>
        public async Task Execute()
        {
            await Task.CompletedTask;

            // pasta com todos os arquivos sql que precisam ser executados
            var pasta = AppDomain.CurrentDomain.BaseDirectory + "Migration\\Entrada";

            if (Directory.Exists(pasta))
            {
                // recuperar todos os arquivos na fila de entrada
                var arquivos = Directory.GetFiles(pasta, "*.sql");
            }
            else
            {
                throw new Exception("MigrationExecute.Execute() - Erro - Pasta com os arquivos sql de migration não existe.");
            }
        }

    }
}
