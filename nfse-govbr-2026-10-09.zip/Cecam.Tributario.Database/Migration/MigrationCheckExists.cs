﻿using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Extend.Globals;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecam.Tributario.Database.Migration
{
    public class MigrationCheckExists
    {
        private readonly ITributosContext _tributosContext;

        public MigrationCheckExists()
        {
            _tributosContext = ServiceProviderGlobal.GetServico<ITributosContext>();
        }

        public async Task<List<string>> CheckExists()
        {
            // valor retornado pelo método
            var retorno = new List<string>();

            var lista = new List<CheckExistsCampos>();
            lista.Add(new CheckExistsCampos("ISSNotaFiscal_GovBr_ImportarEntrada", "ChaveAcesso", 100));
            lista.Add(new CheckExistsCampos("ISSNotaFiscal_GovBr_ImportarEntrada", "cd_Contribuinte", 9));
            lista.Add(new CheckExistsCampos("ISSNotaFiscal_GovBr_ImportarEntrada", "nr_CGCCPF", 25));

            int? t;
            foreach (var item in lista)
            {
                t = await Consultar(item);

                if (t == null)
                {
                    retorno.Add($"Tabela {item.Tabela}, campo {item.Campo} NÃO EXISTE");
                    continue;
                }

                if (t.GetValueOrDefault() != item.Tamanho)
                {
                    retorno.Add($"Tabela {item.Tabela}, campo {item.Campo} tamanho do campo esta errado, esperado {item.Tamanho}");
                    continue;
                }
            }

            //  valor retornado pelo método
            return retorno;
        }

        private async Task<int?> Consultar(CheckExistsCampos item)
        {
            string sql = $"SELECT col_length('{item.Tabela}','{item.Campo}') value";
            return await _tributosContext.Database.SqlQueryRaw<short?>(sql).SingleOrDefaultAsync();
        }

    }

    internal class CheckExistsCampos
    {
        public CheckExistsCampos(string tabela, string campo, int tamanho)
        {
            Tabela = tabela;
            Campo = campo;
            Tamanho = tamanho;
        }
        public string Tabela { get; set; } = string.Empty;
        public string Campo { get; set; } = string.Empty;
        public int Tamanho { get; set; }
    }
}
