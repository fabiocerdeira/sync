﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.Iss
{
    public interface IIssTomadorRepository : IRepository<IssTomadorEntity>, IDisposable
    {
        Task Salvar(IssTomadorEntity issTomadorEntity);
    }
}
