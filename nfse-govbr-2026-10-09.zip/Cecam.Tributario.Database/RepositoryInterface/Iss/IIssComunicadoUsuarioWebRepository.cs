﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.Iss
{
    public interface IIssComunicadoUsuarioWebRepository : IRepository<IssComunicadoUsuarioWebEntity>, IDisposable
    {
    }
}
