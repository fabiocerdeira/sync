﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal
{
    public interface IIssNotaFiscalRepository : IRepository<IssNotaFiscalEntity>, IDisposable
    {
    }
}
