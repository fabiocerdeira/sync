﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.IssArrecadacao
{
    public interface IIssCertificadoRepository : IRepository<IssCertificadoEntity>, IDisposable
    {
    }
}
