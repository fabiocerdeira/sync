﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.Endereco
{
    public interface ICecamPaisIbgeRepository : IRepository<CecamPaisIbgeEntity>, IDisposable
    {
    }
}
