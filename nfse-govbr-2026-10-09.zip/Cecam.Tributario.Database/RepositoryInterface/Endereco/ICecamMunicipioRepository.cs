﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.Endereco
{
    public interface ICecamMunicipioRepository : IRepository<CecamMunicipioEntity>, IDisposable
    {
    }
}
