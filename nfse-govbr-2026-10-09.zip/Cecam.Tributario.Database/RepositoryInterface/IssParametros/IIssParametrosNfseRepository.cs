﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.InfraInterface;

namespace Cecam.Tributario.Database.RepositoryInterface.IssParametros
{
    public interface IIssParametrosNfseRepository : IRepository<IssParametrosNfseEntity>, IDisposable
    {
    }
}
