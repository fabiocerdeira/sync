﻿using Cecam.Tributario.Database.Entity.SysObject;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.SysObject;

namespace Cecam.Tributario.Database.Repository.SysObject
{
    public class SysObjectRepository : Repository<SysObjectEntity>, ISysObjectRepository
    {
        public SysObjectRepository() : base() { }
    }
}
