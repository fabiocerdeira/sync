﻿using Cecam.Tributario.Database.Entity.SysObject;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.SysObject;

namespace Cecam.Tributario.Database.Repository.SysObject
{
    public class SysIndexColumnRepository : Repository<SysIndexColumnEntity>, ISysIndexColumnRepository
    {
        public SysIndexColumnRepository() : base() { }
    }
}
