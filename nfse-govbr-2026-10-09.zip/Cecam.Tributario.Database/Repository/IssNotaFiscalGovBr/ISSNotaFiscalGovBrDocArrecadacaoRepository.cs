﻿using Cecam.Tributario.Database.Entity.IssNotaFiscalGovBr;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscalGovBr;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscalGovBr
{
    public class ISSNotaFiscalGovBrDocArrecadacaoRepository : Repository<ISSNotaFiscalGovBrDocArrecadacaoEntity>, IISSNotaFiscalGovBrDocArrecadacaoRepository
    {
        public ISSNotaFiscalGovBrDocArrecadacaoRepository() : base() { }
    }
}
