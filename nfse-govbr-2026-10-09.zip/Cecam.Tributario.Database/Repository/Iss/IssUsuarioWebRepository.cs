﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.Iss;

namespace Cecam.Tributario.Database.Repository.Iss
{
    public class IssUsuarioWebRepository : Repository<IssUsuarioWebEntity>, IIssUsuarioWebRepository
    {
        public IssUsuarioWebRepository() : base() { }
    }
}
