﻿using Cecam.Tributario.Database.Entity.Iss;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.Iss;
using Cecam.Tributario.Extend.Globals;

namespace Cecam.Tributario.Database.Repository.Iss
{
    public class IssTomadorRepository : Repository<IssTomadorEntity>, IIssTomadorRepository
    {
        public IssTomadorRepository() : base() { }


        public async Task Salvar(IssTomadorEntity issTomadorEntity)
        {
            // cd_cecam
            if (issTomadorEntity.Cd_Cecam <= 0)
                issTomadorEntity.Cd_Cecam = ParametrosGlobal.Cd_Cecam;

            await Task.CompletedTask;
        }

    }
}
