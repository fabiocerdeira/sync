﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscal
{
    public class IssNotaFiscalRepository : Repository<IssNotaFiscalEntity>, IIssNotaFiscalRepository
    {
        public IssNotaFiscalRepository() : base() { }
    }
}
