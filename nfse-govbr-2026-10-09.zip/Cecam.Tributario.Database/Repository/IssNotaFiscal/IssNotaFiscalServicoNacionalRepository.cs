﻿using Cecam.Tributario.Database.Entity.IssNotaFiscal;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.IssNotaFiscal;

namespace Cecam.Tributario.Database.Repository.IssNotaFiscal
{
    public class IssNotaFiscalServicoNacionalRepository : Repository<IssNotaFiscalServicoNacionalEntity>, IIssNotaFiscalServicoNacionalRepository
    {
        public IssNotaFiscalServicoNacionalRepository() : base() { }
    }
}
