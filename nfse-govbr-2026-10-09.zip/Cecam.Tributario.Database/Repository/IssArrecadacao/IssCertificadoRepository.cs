﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.IssArrecadacao;

namespace Cecam.Tributario.Database.Repository.IssArrecadacao
{
    public class IssCertificadoRepository : Repository<IssCertificadoEntity>, IIssCertificadoRepository
    {
        public IssCertificadoRepository() : base() { }
    }
}
