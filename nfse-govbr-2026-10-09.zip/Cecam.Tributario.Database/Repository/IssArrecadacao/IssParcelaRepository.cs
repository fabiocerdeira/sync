﻿using Cecam.Tributario.Database.Entity.IssArrecadacao;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.IssArrecadacao;

namespace Cecam.Tributario.Database.Repository.IssArrecadacao
{
    public class IssParcelaRepository : Repository<IssParcelaEntity>, IIssParcelaRepository
    {
        public IssParcelaRepository() : base() { }
    }
}
