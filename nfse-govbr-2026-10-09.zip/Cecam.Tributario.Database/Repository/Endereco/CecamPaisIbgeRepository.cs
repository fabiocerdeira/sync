﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;

namespace Cecam.Tributario.Database.Repository.Endereco
{
    public class CecamPaisIbgeRepository : Repository<CecamPaisIbgeEntity>, ICecamPaisIbgeRepository
    {
        public CecamPaisIbgeRepository() : base() { }
        //public CecamPaisIbgeRepository(ITributosContext dbContexto) : base(dbContexto) { }
        //public CecamPaisIbgeRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
