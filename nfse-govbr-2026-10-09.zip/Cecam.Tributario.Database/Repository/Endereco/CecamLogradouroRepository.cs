﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;

namespace Cecam.Tributario.Database.Repository.Endereco
{
    public class CecamLogradouroRepository : Repository<CecamLogradouroEntity>, ICecamLogradouroRepository
    {
        public CecamLogradouroRepository() : base() { }
        //public CecamLogradouroRepository(ITributosContext dbContexto) : base(dbContexto) { }
        //public CecamLogradouroRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
