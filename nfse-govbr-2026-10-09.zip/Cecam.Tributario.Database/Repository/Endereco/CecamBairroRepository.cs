﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;

namespace Cecam.Tributario.Database.Repository.Endereco
{
    public class CecamBairroRepository : Repository<CecamBairroEntity>, ICecamBairroRepository
    {
        public CecamBairroRepository() : base() { }
        //public CecamBairroRepository(ITributosContext dbContexto) : base(dbContexto) { }
        //public CecamBairroRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
