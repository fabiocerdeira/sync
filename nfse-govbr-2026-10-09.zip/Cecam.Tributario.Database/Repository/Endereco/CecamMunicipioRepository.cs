﻿using Cecam.Tributario.Database.Entity.Endereco;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.InfraInterface;
using Cecam.Tributario.Database.RepositoryInterface.Endereco;

namespace Cecam.Tributario.Database.Repository.Endereco
{
    public class CecamMunicipioRepository : Repository<CecamMunicipioEntity>, ICecamMunicipioRepository
    {
        public CecamMunicipioRepository() : base() { }
        //public CecamMunicipioRepository(ITributosContext dbContexto) : base(dbContexto) { }
        //public CecamMunicipioRepository(IUnitOfWork unitOfWork) : base(unitOfWork) { }
    }
}
