﻿using Cecam.Tributario.Database.Entity.IssParametros;
using Cecam.Tributario.Database.Infra;
using Cecam.Tributario.Database.RepositoryInterface.IssParametros;

namespace Cecam.Tributario.Database.Repository.IssParametros
{
    public class IssParametrosCalcRepository : Repository<IssParametrosCalcEntity>, IIssParametrosCalcRepository
    {
        public IssParametrosCalcRepository() : base() { }
    }
}
