﻿using Cecam.Tributario.Database.Configuration;
using System.Security.Cryptography.X509Certificates;

namespace Cecam.Tributario.Manager.Helper
{
    /// <summary>
    /// Carregar o certificado seguro a partir das configurações do app.settings.
    /// </summary>
    public class X509CertificateHelper
    {

        /// <summary>
        /// Retornar o certificado seguro, instalado no servidor ou arquivo em disco.
        /// Para funcionar é necessário confgiurar o app.settings.
        /// </summary>
        public X509Certificate2? GetCertificate()
        {
            // carregar o certificado que esta instalado nos servidor.
            X509Certificate2? cert = GetCertificateInstalado();

            // verificar se não encontrou o certificado instalado no servidor,
            // então carregar o certificado a partir do arquivo em disco.
            if (cert == null)
                cert = GetCertificatePorArquivo();

            return cert;
        }


        /// <summary>
        /// Retornar o certificado instalado no servidor.
        /// Esse método busca em todos os storeLocations (LocalMachine ou CurrentUser)
        /// </summary>
        public X509Certificate2? GetCertificateInstalado()
        {
            // verificar se temos o thumbprint configurado para carregar o certificado instalado no servidor.
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalThumbPrint))
                return null;

            // tentar carregar certificado se estiver instalado em LocalMachine
            X509Certificate2? cert = GetCertificateInstaladoPorStoreLocation(StoreLocation.LocalMachine);

            // tentar carregar certificado se estiver instalado em CurrentUser
            if (cert == null)
                cert = GetCertificateInstaladoPorStoreLocation(StoreLocation.CurrentUser);

            // valor retornado pelo método
            return cert;
        }


        /// <summary>
        /// Retornar o certificado instalado no servidor informando o StoreLocation (LocalMachine ou CurrentUser)
        /// </summary>
        public X509Certificate2? GetCertificateInstaladoPorStoreLocation(StoreLocation storeLocation)
        {
            // verificar se temos o thumbprint configurado para carregar o certificado instalado no servidor.
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalThumbPrint))
                return null;

            var listaCertificados = new X509Store(storeLocation);

            listaCertificados.Open(OpenFlags.ReadOnly);

            if (listaCertificados.Certificates.Count > 0)
            {
                var certInstalado = listaCertificados.Certificates.FirstOrDefault(x => x.Thumbprint.ToUpper() == ParametrosGlobal.CertificadoDigitalThumbPrint.ToUpper());

                // valor retornado pelo método
                return certInstalado;
            }

            // valor retornado pelo método
            return null;
        }


        /// <summary>
        /// Retornar o certificado seguro do servidor a partir de um arquivo .cer ou .pfx copiado em alguma pasta do servidor
        /// </summary>
        public X509Certificate2? GetCertificatePorArquivo()
        {
            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalCaminho))
                throw new Exception("Certificado digital da prefeitura não foi configurado no app.settings. **erro**");

            // validar parametros configurado no app.settings
            if (string.IsNullOrWhiteSpace(ParametrosGlobal.CertificadoDigitalSenha))
                throw new Exception("Senha para certificado digital da prefeitura não foi configurado no app.settings. **erro**");

            // validar parametros configurado no app.settings
            if (!File.Exists(ParametrosGlobal.CertificadoDigitalCaminho))
                throw new Exception("Certificado digital da prefeitura não foi encontrado no servidor. **erro**");

            // carregar o certificado do disco
            return X509CertificateLoader.LoadPkcs12FromFile(ParametrosGlobal.CertificadoDigitalCaminho,
                ParametrosGlobal.CertificadoDigitalSenha,
                X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
        }
    }
}
