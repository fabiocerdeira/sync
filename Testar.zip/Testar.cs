 public async Task TestarHttpClient()
 {
     // parametros do httpClient
     var httpClientHandler = new HttpClientHandler();

     // incluir o certificado seguro no header
     var certificadoHelp = new X509CertificateHelper();
     var certificadoSeguro = certificadoHelp.GetCertificate();
     if (certificadoSeguro != null)
         httpClientHandler.ClientCertificates.Add(certificadoSeguro);

     // ------------

     /*
     var client = new HttpClient(httpClientHandler);
     var request = new HttpRequestMessage(HttpMethod.Get, "https://adn.producaorestrita.nfse.gov.br/municipios/dfe/19?tipoNSU=DISTRIBUICAO&lote=true");
     var response = await client.SendAsync(request);
     response.EnsureSuccessStatusCode();
     Console.WriteLine(await response.Content.ReadAsStringAsync());
     */

     var _httpClient = new HttpClient(httpClientHandler);

     _httpClient.DefaultRequestHeaders.Add("User-Agent", "PostmanRuntime/7.49.1");
     _httpClient.DefaultRequestHeaders.Add("Accept", "*/*");
     _httpClient.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
     _httpClient.DefaultRequestHeaders.Add("Accept-Encoding", "gzip, deflate, br");
     _httpClient.DefaultRequestHeaders.Add("Connection", "keep-alive");

     string url = "https://adn.producaorestrita.nfse.gov.br/municipios/dfe/10?tipoNSU=DISTRIBUICAO&lote=true";

     var respostaApi = await _httpClient.GetAsync(url);

     // corpo retornado pela api externa do gov.br
     var respostaCorpo = await respostaApi.Content.ReadAsStringAsync();

 }